﻿
var divisa = getParamUrl("divisa");
var monto = getParamUrl("monto");
var usuario = getParamUrl("usuario");
var ws = getParamUrl("ws");
var tipoH = 1;
var app = "Fondeo Automatico";
var topH = "230";
var afectaHD = true;
var conAutorizacion = true;
var autenticoEmpleado = false;
var autenticoAutorizador = false;
var jSonPerfiles;
var esWeb;
var montoTotal;

$(document).ready(function () {
    try {
        esWeb = getParamUrl("esWeb");
    }
    catch (erro) { esWeb = true; }

    if (esWeb == "false") {
        $('#ErrorFondeo').hide();
    }
    else {
        $('#ErrorFondeo').show();
    }

    validaGet();
});

function validaGet() {
    try {



        if (divisa != "" || monto != "" || usuario != "" || ws != "") {
            if (divisa === undefined || monto === undefined || usuario === undefined || ws === undefined) {
                $('#content').load("../error.html");
            } else {
                mostrarCarga(true);
                setTimeout(function () {
                    serviceFondeoValidaSaldo(divisa, monto, usuario, ws);
                }, 500);
                mostrarCarga(false);
            }
        } else {
            document.getElementById("lblMensaje").innerHTML = "Envia todos los valores";
        }

    }
    catch (err) {
        document.getElementById("lblMensaje").innerHTML = err.message;
    }

}

function serviceRestValidaSaldo(jsonResp) {
    $(".modal").show();
    if (jsonResp.NoError == 0) {
        document.getElementById("lblMensaje").innerHTML = jsonResp.Descripcion;
    } else if (jsonResp.NoError == 1) {
        document.getElementById("lblMensaje").innerHTML = jsonResp.Descripcion;
        divisa_symbol = "";
        document.getElementById("montoFondeo").innerHTML = formatMoney(jsonResp.MontoFondeo);
        $('#ExitoFondeo').show();
        montoTotal = jsonResp.MontoFondeo;   
    } else if (jsonResp.NoError == 3) {
        document.getElementById("lblMensaje").innerHTML = jsonResp.Descripcion;
    } else {
        document.getElementById("lblMensaje").innerHTML = "Intente mas tarde";
    }
}

//Funcion para abrir el componente de huellas
function abrirHuella() {

    var perfiles = "0";
    var empAutenticador = usuario;
    var bolConsultoServicio = false
    afectaHD = false;


    if (conAutorizacion == true) {
        if (autenticoEmpleado == true) {
            //Consulta en servicio los puestos autorizador
            mostrarCarga(true);
            try {
                if (jSonPerfiles.Estatus == 0) {

                    perfiles = jSonPerfiles.EmpPerfiles;
                    empAutenticador = jSonPerfiles.EmpAutorizador;
                        bolConsultoServicio = true;
                        afectaHD = true;

                }

                if (bolConsultoServicio == false) {
                    autenticoEmpleado = false;
                    mostrarCarga(false);
                    $('#content').show();
                    document.getElementById("resultado").innerHTML = "[abrirHuella] - Ocurrió un error en el consumo del servicio *" + err.toString();
                    document.getElementById("resultadoExito").innerHTML = "";
                    return;
                }

            } 
            catch (err) {
                autenticoEmpleado = false;
                mostrarCarga(false);
                $('#content').show();
                document.getElementById("resultado").innerHTML = "[abrirHuella] - Ocurrió un error en el consumo del servicio *" + err.toString();
                document.getElementById("resultadoExito").innerHTML = "";
                return;
            }
            mostrarCarga(false);
        }
    }

    let workstation= getParamUrl("ws");    
    document.getElementById("resultado").innerHTML = "";
    var json = '{"validarEmp":"' + usuario + '",' +
                '"validarAut":"' + empAutenticador + '",' +
                '"tipo":"' + tipoH + '",' +
                '"app":"' + app + '",' +
                '"top":"' + topH + '",' +
                '"afectaHD":"' + afectaHD + '",' +
                '"perfiles":"' + perfiles + '",' +
                '"ws":"' + workstation + '"}';

    json = JSON.parse(json);
    setHuellaMsgImporte("Se realiza un Fondeo por el importe de: $"+ formatMoney(montoTotal));
    AutenticacionHuella(json);

}

//Funcion callback del componente de huellas
function RecibirResultadoHuella(resultado) {

    if (resultado.Status == 0) {
        $('#content').show();
        document.getElementById("resultado").innerHTML = resultado.Descripcion;
    } else { //Si la autenticacion es correcta realiza la afectacion 
        if (conAutorizacion == true && autenticoEmpleado == false) {       //Valida la autenticacion el empleado solicitante
            autenticoEmpleado = true;
            fnValidaAutorizador();
        }
        else {  //Se Autorizo la solicitud
            autenticoEmpleado = false;
            mostrarCarga(true);
            setTimeout(function () {
                serviceAfectaCajaFondeo();
            }, 500);
        }
    }
}

//Muestra los mensajes correspondientes, dependiendo si la afectacion fue correcta o no
function serviceRestAfectaCaja(jsonResp) {
    $('#content').show(); 
    document.getElementById("resultadoExito").innerHTML="";
    document.getElementById("resultado").innerHTML="";
    if (jsonResp.NoError == 0) { //Exito
        document.getElementById("resultadoExito").innerHTML = jsonResp.Descripcion;
        $('#ExitoFondeo').hide();
    } else if (jsonResp.NoError == 1) { 
        document.getElementById("resultado").innerHTML = jsonResp.Descripcion;        
    } else if (jsonResp.Respuesta == 3) {
        document.getElementById("resultado").innerHTML = jsonResp.Descripcion;
    } else {
        document.getElementById("resultado").innerHTML = "Intente mas tarde";            
    }
}

function fnValidaAutorizador() {

    getPerfilesAutorizador();
}

function fnCargoPerfiles(jsonResp) {

    jSonPerfiles = jsonResp;
    abrirHuella();
}
