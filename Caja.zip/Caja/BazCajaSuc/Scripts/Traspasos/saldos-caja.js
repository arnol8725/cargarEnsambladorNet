﻿
$(document).ready(function () {
    document.title = titulo;
    divisa = divisa == '' ? "1" : divisa;
    desc_divisa = desc_divisa = '' ? "Moneda Nacional" : desc_divisa;
    $('#desc_divisa').html(desc_divisa);
    $(".documentos").hide();

    $('#radio1').on("change", function () {
        $('.efectivo').show();
        $('.documentos').hide();
        return false;
    });
    $('#radio2').on("change", function () {
        $('.efectivo').hide();
        $('.documentos').show();
        return false;
    });
    consultarDenominacion();
});



