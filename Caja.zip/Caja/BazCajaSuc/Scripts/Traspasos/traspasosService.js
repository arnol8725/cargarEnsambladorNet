﻿//CONSULTA EL MENU DISPONIBLE PARA EL USUARIO
function wsConfiguraMenu(opc, opc1, opc2, opc3) {
    $('#lblMensaje').html("");
    let result;
    var consulta = {
        "NoEmpleado": usuario, 
        "OpcionMenu": opc,
        "Opcion1": opc1,
        "Opcion2": opc2,
        "Opcion3": opc3};
    return $.ajax({
        url: getUrl(urlConfiguraMenu),
        type: "POST",
        data: JSON.stringify(consulta),
        cache: false,
        contentType: "application/json; charset=UTF-8",
        dataType: 'JSON',
        success: function (resp) {
            switch (resp.NoError){
                case 1:
                    showMesagge(resp.NoError, resp.Descripcion);
                    mostrarCarga(false);
                    break;
                case 0:
                    result= resp;
                    break;                    
            }
            
        },
        error: function () {
            mostrarCarga(false);
            showMesagge(1, "Ocurrió un error en el servidor");
        }
    });
    return result;
}

//CONSULTA LAS DENOMINACIONES PARA LA REALIZACION DEL TRASPASO
function consultarDenominacion() {
    $('#lblMensaje').html("");
    var consulta = {"Divisa": divisa};
    $.ajax({
        url: getUrl(urlTraspDenominaciones),
        type: "POST",
        data: JSON.stringify(consulta),
        cache: false,
        contentType: "application/json; charset=UTF-8",
        dataType: 'JSON',
        success: function (resp) {
            switch (resp.NoError){
                case 1:
                    showMesagge(resp.NoError, resp.Descripcion);
                    mostrarCarga(false);
                    break;
                case 0:
                    validaMorralla(resp.DetalleDenomina);
                    break;                    
            }   
            
        },
        error: function () {
            mostrarCarga(false);
            showMesagge(1, "Ocurrió un error en el servidor");
        }
    });
}

//valida si se aceptan monedas
function validaMorralla(denominaciones){
    lstSrvDenominaciones=denominaciones;
    isMonedas=false;
    $.each(lstSrvDenominaciones, function (i, p) {
        isMonedas=isMonedas?isMonedas:p.DescDenominacion=="MORRALLA";        
    }); 
    reloadContent();
}

//llena la tabla que se muestra en la ventana de denominaciones
function llenarDenominacion() {
    var tabla = '';    
    let den=0;
    $.each(lstSrvDenominaciones, function (i, p) {        
        den=p.IdDenominacion.substring(0, p.IdDenominacion.length-3);;
        if(p.DescDenominacion!="MORRALLA")
        tabla += '<tr><td>' + p.IdDenominacion + '</td>'+
                     '<td class="w100"><input onfocus="this.oldvalue = this.value;" id="den' + den + '" class="monto" onchange="totales('+ p.IdDenominacion +', this);this.oldvalue = this.value;" placeholder="0" type="text" onkeypress="return isNumberKey(event,false)"/></td>'+
                     '<td><label id="total' + den + '" class="total">'+formatMoney(0)+'</label></td></tr>';
    });   
    $("#tableDenominacion > tbody").html(tabla);
    if(!isMonedas){
        $('#totalesDen > td:nth-child(1)').hide();
        $('#totalesDen > td:nth-child(2)').hide();
        $('#ipMorralla').hide();
        $('#lblMorralla').hide();
    }else{
        $('#ipMorralla').show();
        $('#lblMorralla').show();
    }
    mostrarCarga(false);        
    $j('#modal01').modal();
}

//CONSULTA DEL SALDO EN CAJA
function wsConsultaSaldoCaja(usuario, divisa) {
    $('#lblMensaje').html("");
    var consulta = {
        "NoEmpleado": usuario,
        "Divisa": divisa
    };

    $.ajax({
        url: getUrl(urlConsultaConcentracionSaldosACaja),
        type: "POST",
        data: JSON.stringify(consulta),
        cache: false,
        contentType: "application/json; charset=UTF-8",
        dataType: "JSON",
        success: function (resp) {            
            switch (resp.NoError){
                case 1:
                    llenarTraspPend([], true, "adtEfec", "addEfec", "efectivotable", true);
                    llenarDocumentos([], [], 0);
                    saldosEfectivo([], 0);
                    $('#content').show();  
                    activeBtn(true);                    
                    mostrarCarga(false);                    
                    break;
                case 0:                    
                    llenarTraspPend(resp.DetalleSaldo.DetalleTraspasos, true, "adtEfec", "addEfec", "efectivotable", true);
                    llenarDocumentos(resp.DetalleSaldo.SaldoDocumentos, resp.DetalleSaldo.DetalleSaldo, 
                                resp.DetalleSaldo.TotalFondeos);
                    saldosEfectivo(resp.DetalleSaldo.SaldoEfectivo, resp.DetalleSaldo.TotalFondeos);
                    activeBtn(false);
                    $('#content').show();
                    break;                    
            }
        },
        error: function (error) {            
            showMesagge(1, "Ocurrió un error en el servidor");
            mostrarCarga(false);
            $('#content').hide();
        }
    });
}

function activeBtn(status){
    $('#btn'+page_select).attr("disabled", status);
    $('#importe'+page_select).attr("disabled", status);
    $('#selectDocs').attr("disabled", status);
    $('#btncajaDoc').attr("disabled", status);
    
}

//CONSULTA HISTORIAL
function wsConsultaHistorialTraspasos(usuario, divisa) {
    $('#lblMensaje').html("");
    var consulta = {
        "NoEmpleado": usuario,
        "Divisa": divisa
    };

    $.ajax({
        url: getUrl(urlConsultaHistorialTraspasos),
        type: "POST",
        data: JSON.stringify(consulta),
        cache: false,
        contentType: "application/json; charset=UTF-8",
        dataType: "JSON",
        success: function (resp) {          
            switch (resp.NoError){
                case 1:                    
                    showMesagge(resp.NoError, resp.Descripcion);
                    mostrarCarga(false);
                    $('#content').hide();
                    break;
                case 0:
                    llenarTraspPend(resp.DetalleHistorialTraspasos.DetalleHistorialTraspasosConfirmados, 
                            false, "adtEfecConfir", "addEfecConfir", "traspasosConfirmados", false);  
                    llenarTraspPend(resp.DetalleHistorialTraspasos.DetalleHistorialTraspasosCancelados, 
                            false, "adtEfec", "addEfec", "efectivotable", false);
                    saldosEfectivo(resp.DetalleHistorialTraspasos.SaldoEfectivo, resp.DetalleHistorialTraspasos.TotalFondeos);
                    break;                    
            }         
        },
        error: function (error) {
            showMesagge(1, "Ocurrió un error en el servidor");
            mostrarCarga(false);
            $('#content').hide();
        }
    });
}

//CONSULTA Traspasos saldos a cajero
function wsConsultaTraspasosSaldosACajeros(usuario, divisa) {
    $('#lblMensaje').html("");
    var consulta = {
        "NoEmpleado": usuario,
        "Divisa": divisa
    };

    $.ajax({
        url: getUrl(urlConsultaTraspasosSaldosACajeros),
        type: "POST",
        data: JSON.stringify(consulta),
        cache: false,
        contentType: "application/json; charset=UTF-8",
        dataType: "JSON",
        success: function (resp) {              
            switch (resp.NoError){
                case 1:                    
                    showMesagge(resp.NoError, resp.Descripcion);
                    mostrarCarga(false);
                    $('#content').hide();
                    break;
                case 0:
                    llenaEmpleados(resp.DetalleTraspasoSaldosACajeros.DetalleSaldoEmpleados);
                    llenarTraspPend(resp.DetalleTraspasoSaldosACajeros.DetalleFondeosPendientes, 
                            true, "adtEfec", "addEfec", "efectivotable", true);
                    saldosEfectivo(resp.DetalleTraspasoSaldosACajeros.SaldoEfectivo, resp.DetalleTraspasoSaldosACajeros.TotalFondeos);
                    break;                    
            } 
        },
        error: function (error) {            
            showMesagge(1, "Ocurrió un error en el servidor");
            mostrarCarga(false);
            $('#content').hide();
        }
    });
}


//CONSULTA Fondeos
function wsConsultaFondeoEfecCajaACajero(usuario, divisa) {
    $('#lblMensaje').html("");
    var consulta = {
        "NoEmpleado": usuario,
        "Divisa": divisa
    };

    $.ajax({
        url: getUrl(urlConsultaFondeoEfecCajaACajero),
        type: "POST",
        data: JSON.stringify(consulta),
        cache: false,
        contentType: "application/json; charset=UTF-8",
        dataType: "JSON",
        success: function (resp) {  
            switch (resp.NoError){
                case 1:                    
                    showMesagge(resp.NoError, resp.Descripcion);
                    mostrarCarga(false);
                    $('#content').hide();
                    break;
                case 0:
                    llenaEmpleados(resp.DetalleTraspasoSaldosACajeros.DetalleSaldoEmpleados);
                    llenarTraspPend(resp.DetalleTraspasoSaldosACajeros.DetalleFondeosPendientes, 
                            true, "adtEfec", "addEfec", "efectivotable", true);
                    saldosEfectivo(resp.DetalleTraspasoSaldosACajeros.SaldoEfectivo, resp.DetalleTraspasoSaldosACajeros.TotalFondeos);
                    break;                    
            }
        },
        error: function (error) {
            showMesagge(1, "Ocurrió un error en el servidor");
            mostrarCarga(false);
            $('#content').hide();
        }
    });
}

function llenaEmpleados(empleados){
    detalleEmpleados=empleados;
    var tabla = '';
    $.each(empleados, function (i, p) {        
        tabla += '<tr>'+
                     '<td>'+					  	
                        '<input type="checkbox" onchange="onCheckEmpleado(\''+p.NoEmpledo.toString()+'\','+i+')" id="checkEmp'+i+'" />'+
						'<label for="checkEmp'+i+'" class="inputTS"></label>'+
					  '</td>'+
                     '<td>' + p.NoEmpledo + '</td>'+//numero de empleado
                     '<td>'+p.Nombre+'</td>'+ //nombre
                     '<td style="width:150px;">' + p.PuestoRol + '</td>' + //puesto/rol 
                     '<td class="tRight">'+ formatMoney(Number(p.SaldoCjr))+'</td></tr>'; //saldo
                     //saldo disponible 
    });   
    $("#empleados > tbody").html(tabla);
}

//LLENA LOS SALDOS EN EFECTIVO
function saldosEfectivo(saldos, totalFondeos){
    let saldoDisponible=(saldos.SaldoEfectivo || 0) - Number(totalFondeos);
    saldoDisponible=saldoDisponible<0?0:saldoDisponible;
    $('#origenSaldo'+page_select).html(saldos.OrigenSaldo || 0);
    $('#saldoActual'+page_select).html(formatMoney(saldos.SaldoEfectivo || 0));
    $('#traspPendientes'+page_select).html(formatMoney(Number(totalFondeos)));
    $('#saldoDisponible'+page_select).html(formatMoney(saldoDisponible));
    $('#topeMax'+page_select).html(formatMoney(saldos.TopeMax || 0));
    mostrarCarga(false);
}

//LLENA LOS TRASPASOS PENDIENTES
function llenarTraspPend(traspasos, isCheck, iddt, iddd, idTable, isReplace) {    
    var accordion='<dl class="accordion">';   
    $("#recEfec"+page_select).attr("disabled", true); 
    if (traspasos.length>0){
        $('#divCancelar'+page_select).show();
    }else{
        $('#divCancelar'+page_select).hide();
    }    
    let params;
    if (isReplace){
        detalleTraspasos=traspasos;
    }
    let ultimoTrasp="";
    $.each(traspasos, function (i, p) {
        ultimoTrasp=p.UltTraspaso=="0"?"No":"Si";
        if (isCheck)
        accordion += "<div class='checks'>" +
                        "<input type='checkbox' onchange='onCheckTraspaso("+p.Concentracion+","+i+")' id='checkE"+i+"' />"+
					    "<label for='checkE"+i+"'></label>"+
				     "</div>";
        accordion+="<dt id='"+iddt+i+"' class='AcoInpar' onclick='expandEfectivo("+iddt+i+","+iddd+i+")'>"+
                        '<table class="tblGeneral3 w90 tblAco1">'+
                            '<tbody>'+
                                '<tr>'+
							        '<td class="tLeft">'+p.Concentracion+'</td>'+
                                    '<td>'+p.FechaOperacion+'</td>'+
                                    '<td>Caja</td>'+
                                    '<td>'+ultimoTrasp+'</td>'+
                                    '<td class="tRight">'+formatMoney(Number(p.Importe))+'</td>';
                                    if(p.Origen!=undefined)accordion+='<td>'+p.Origen+'</td>';
                                accordion+='</tr>'+
                            '</tbody>'+
                        '</table>'+
                    '</dt>'+
                    '<dd id="'+iddd+i+'" style="display: none;">'+
                        '<div class="inner"> '+
                            '<div class="divAco">'+                                
                                '<table class="tblGeneral tblAco2">'+
                                "<tbody>";
                                let table="";
                                $.each(p.DetalleDivisa, function (j, d) {
                                    table+= "<tr>"+
                                                '<td>&nbsp;</td>'+
                                                '<td>Denominación:</td>'+
                                                '<td>'+d.Denominacion+'</td>'+
                                                '<td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>'+
                                                '<td>Cantidad:</td>'+
                                                '<td class="tRight">'+d.Cantidad+'</td>'+
                                                '<td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>'+
                                                '<td class="tRight">' + formatMoney(Number(d.Importe)) + '</td>' +
                                            "</tr>";
                                });
                                if (table==""){
                                    table="<tr><td>&nbsp;</td></tr>";
                                }
                                accordion+= table + "</tbody></table>"+
                             '</div>'+
                         '</div>'+
                     '</dd> '+
				     '<div class="clear"></div>'; 
    });
    accordion+='</dl>';
    $('#'+idTable).html(accordion);    
}

//LLENA LOS DOCUMENTOS
function llenarDocumentos(saldos, documentos, totalFondeos) {
    $('#saldoActualDoc'+page_select).html(formatMoney(saldos.SaldoDocumentos || 0));
    $('#traspPendDoc'+page_select).html(formatMoney(Number(saldos.TrasPendientes || 0)));
    $('#saldoDispDoc'+page_select).html(formatMoney((saldos.SaldoDocumentos || 0) - Number(totalFondeos)));
            
    var tabla = '<dl class="accordion1">';    
    let params;
    $.each(documentos, function (i, p) {   
        params = {           
            tipoId: p.Tipo_PagoId,
            desc: p.TipoPagoDesc,
            saldo: p.SaldoTotal,
            detalleDocs: p.LstDocumento
        };     
        detalleDocuments.push(params);
        tabla += "<div class='checks'>" +
                    "<input type='checkbox' onchange='onCheckDoc("+i+","+true+")' id='check"+i+"' />"+
					"<label for='check"+i+"'></label>"+
				 "</div>";
        tabla += "<dt id='adt"+i+"' class='AcoInpar' onclick='expandDocument("+i+")'>"+
                    "<table class='tblGeneral3 w90 tblAco1'>"+
                        "<tbody>"+
						    "<tr>"+
							    "<td class='tLeft'>" + p.TipoPagoDesc + "</td>"+ //tipo de pago
								"<td>" + formatMoney(Number(p.SaldoTotal)) + "</td>"+ //saldo pendiente
								"<td>" + p.NoDoctos + "</td>"+ //no doctos por traspasar
								"<td>" +formatMoney(Number( p.SaldoConfirm)) + "</td>"+ //saldo por confirmar
								"<td>" + p.NoDoctosConfirm + "</td>"+ //no doctos por confirmar
								"<td>" + formatMoney(Number(p.Tope)) + "</td>"+ //tope maximo
						    "</tr>"+
						"</tbody>"+
					"</table>"+
				"</dt>"+				
                "<dd id='add"+i+"' style='display: none;'>"+
                        "<div class='inner'> "+
                            "<div class='divAco'>"+
                                "<table id='documentosDetalle' class='tblGeneral tblAco2'>"+
                                "<tbody>";
                                let table="";
                                $.each(p.LstDocumento, function (j, d) {
                                    table+= "<tr>"+
                                                "<td>"+
                                                    "<div class='checks'>" +
                                                        "<input type='checkbox' onchange='onCheckDetalleDoc("+i+","+j+")' id='checkDocuments"+j+i+"' />"+
					                                    "<label for='checkDocuments"+j+i+"'></label>"+
				                                    "</div>"+
                                                "</td>"+
                                                "<td>"+formatMoney(Number(d.Importe))+"</td>"+
                                                "<td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>"+                                                
                                                "<td>"+d.NoDocto+"</td>"+
                                                "<td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>"+                                                
                                            "</tr>";
                                });
                                if (table==""){
                                    table="<tr><td>&nbsp;</td></tr>";
                                }
                                tabla+= table + "</tbody></table>"+
                             "</div>"+
                         "</div>"+
                     "</dd> "+
				"<div class='clear'></div>";                
    });
    tabla+="</dl>";
    $('#documentosPend').html(tabla);    
}

//Realiza Concentraciones
function RealizaConcentraciones(consulta, divisa, tipo) {    
    $('#lblMensaje').html("");
    $.ajax({
        url: getUrl(urlRealizaConcentracion),
        type: "POST",
        data: JSON.stringify(consulta),
        cache: false,
        contentType: "application/json; charset=UTF-8",
        dataType: 'JSON',
        success: function (resp) {
            mostrarCarga(false);
            switch (resp.NoError){
                case 1:                    
                    reloadContent();
                    showMesagge(resp.NoError, resp.Descripcion);                    
                    break;
                case 0:
                    deleteImporte(tipo);            
                    $j('#modal04').modal();
                    break;                    
            }
        },
        error: function () {
            showMesagge(1, "Ocurrió un error en el servidor");
            mostrarCarga(false);
        }
    });
}

//Confirma Concentraciones
function ConfirmaConcentraciones(consulta, concentracion, divisa, tipo) {  
    $('#lblMensaje').html("");  
    $.ajax({
        url: getUrl(urlConfirmaConcentracion),
        type: "POST",
        data: JSON.stringify(consulta),
        cache: false,
        contentType: "application/json; charset=UTF-8",
        dataType: 'JSON',
        success: function (resp) {            
            switch (resp.NoError){
                case 1:
                    reloadContent();
                    showMesagge(resp.NoError, resp.Descripcion);                    
                    break;
                case 0:
                    concentracionImpr=concentracion;
                    transaccionImpr=resp.Descripcion;
                    deleteImporte(tipo);    
                    mostrarCarga(false);                
                    $j('#modal08').modal();
                    $('#lblConfirmacion').html("Se realizo correctamente el traspaso. Folio traspaso: "+resp.Descripcion);                                        
                    break;                    
            }            
        },
        error: function () {
             showMesagge(1, "Ocurrió un error en el servidor");
             mostrarCarga(false);
        }
    });
}

//Cancela traspaso
function cancelaTraspaso(usuario, divisa, concentracion) {
    $('#lblMensaje').html("");
    var consulta = {
            "NoEmpleado": usuario, 
            "Divisa": divisa,
            "NoTraspaso": concentracion
        };
    $.ajax({
        url: getUrl(urlCancelaTraspaso),
        type: "POST",
        data: JSON.stringify(consulta),
        cache: false,
        contentType: "application/json; charset=UTF-8",
        dataType: 'JSON',
        success: function (resp) {            
            switch (resp.NoError){
                case 1:                    
                    reloadContent();
                    showMesagge(resp.NoError, resp.Descripcion);                    
                    break;
                case 0:                    
                    reloadContent();
                    showMesagge(resp.NoError, resp.Descripcion);
                    break;                    
            }
        },
        error: function () {
            showMesagge(1, "Ocurrió un error en el servidor");
            mostrarCarga(false);
        }
    });
}

//Carta Faltate
function wsurlGeneraCartaFaltante(pagare, totalfaltate) {
    $('#lblMensaje').html("");
    var consulta = {
        "ImporteFaltante": totalfaltate,
        "ImporteFaltanteletra": NumeroALetras(Number(totalfaltate)),
        "Ciudad": pagare.lugar.ciudad,
        "Estado": pagare.lugar.estado,
        "Suscriptor": {
            "Nombre": pagare.suscriptor.nombre,
            "Calle" : pagare.suscriptor.calle,
            "Colonia" : pagare.suscriptor.colonia,
            "Ciudad" : pagare.suscriptor.ciudad,
            "CodigoPostal" :  pagare.suscriptor.cp
        },"Aval": {
            "Nombre": pagare.aval.nombre,
            "Calle" : pagare.aval.calle,
            "Colonia" : pagare.aval.colonia,
            "Ciudad" : pagare.aval.ciudad,
            "CodigoPostal" :  pagare.aval.cp
        }};
    let ruta="";
    $.ajax({
        url: getUrl(urlGeneraCartaFaltante),
        type: "POST",
        data: JSON.stringify(consulta),
        cache: false,
        async:false,
        contentType: "application/json; charset=UTF-8",
        dataType: "JSON",
        success: function (resp) {              
            switch (resp.NoError){
                case 1:
                    ruta="";                   
                    showMesagge(resp.NoError, resp.Descripcion);
                    mostrarCarga(false);
                    break;
                case 0:
                    ruta=resp.Descripcion;                    
                    break;                    
            } 
        },
        error: function (error) {            
            showMesagge(1, "Ocurrió un error en el servidor");
            ruta="";            
        }
    });
    return ruta;
}
