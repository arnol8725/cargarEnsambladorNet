﻿
$(document).ready(function () {
    document.title = titulo;
    mostrarCarga(true);    
    divisa = divisa == '' ? "1" : divisa;
    desc_divisa = desc_divisa=''?"Moneda Nacional":desc_divisa;
    $('#desc_divisa').html(desc_divisa);
    var consulta = {
        "NoEmpleado": usuario,
        "Divisa": divisa
    };

    $.ajax({
        url: getUrl(urlConsultaConcentracionSaldosACaja),
        type: "POST",
        data: JSON.stringify(consulta),
        async: false,
        cache: false,
        contentType: "application/json; charset=UTF-8",
        dataType: "JSON",
        success: function (resp) {            
            switch (resp.NoError){
                case 1:
                    llenarTraspPend([], true, "adtEfec", "addEfec", "efectivotable", true);
                    llenarDocumentos([], []);
                    saldosEfectivo([], 0);
                    $('#content').show();  
                    activeBtn(true);                    
                    mostrarCarga(false);                    
                    break;
                case 0:                    
                    let totalTraspasos=llenarTraspPend(resp.DetalleSaldo.DetalleTraspasos, true, "adtEfec", "addEfec", "efectivotable", true);
                    llenarDocumentos(resp.DetalleSaldo.SaldoDocumentos, resp.DetalleSaldo.DetalleSaldo);
                    saldosEfectivo(resp.DetalleSaldo.SaldoEfectivo, totalTraspasos);
                    activeBtn(false);
                    $('#content').show();
                    break;                    
            }
        },
        error: function (error) {            
            showMesagge(1, "Ocurrió un error en el servidor");
            mostrarCarga(false);
            $('#content').hide();
        }
    });

    wsConsultaHistorialTraspasos(usuario, divisa);
});



