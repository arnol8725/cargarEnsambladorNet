﻿$(document).ready(function () {
    document.title = titulo;
    mostrarCarga(true);
    divisa = divisa == '' ? "1" : divisa;
    desc_divisa = desc_divisa = '' ? "Moneda Nacional" : desc_divisa;
    $('#desc_divisa').html(desc_divisa);

    if (id_page_select == "fondeo") {
        $("#recEfeccajero").hide();
    } else {
        //$("#recEfeccajero").html("Recibir ahora"); //versions newer than 1.6
        $("#fondEfeccajero").hide();
    }
    consultarDenominacion();
});