﻿if ($j === undefined) { var $j = jQuery.noConflict(true); console.log($().jquery); console.log($j().jquery); }
var usuario = getParamUrl("usuario");
var workstation = getParamUrl("ws");
var isMonedas=true;
var cantBilletes=0;
var cantMonedas=0;
var importeTraspDen=0;
var importeTrasp=0;
var tipoH = 1;
var app = "Traspasos";
var topH = "230";
var afectaHD = true;

var idInputTraspaso="";
var tipoTraspaso="";
var servicioVistas="Servicios/Traspasos/Traspasos.svc/wsRequestTipoVistaTraspaso";
var perfil="F"; //D=Concentracion, T=Saldos a cajero, F=Fondeo, A=?
var origen=""; //D=Concentracion, T=?, D=?, F=?

var ultimoTraspaso=0;

var lstDenominaciones=[];

var detalleDocuments=[];
var docsLista=[];
var detalleDocsLista=[];

var detalleTraspasos=[];
var traspasoSelect = undefined;

var detalleEmpleados=[];
var empleadoSelect = undefined;

var page_select="";
var id_page_select="";

var titulo="";

var indexDetalleDocs=[];

var tipoAccion="";

var totalRecibir="";
var totalRecibirRestante="";
var tipoPago;

var pagare=[];

var userAuto="";
var perfil="";

var isHuellaT=false;
var isHuellaR=false;

var concentracionImpr="";
var transaccionImpr="";

var opc="1";
var idModulo="27";
var idFolio="3";

var lstSrvDenominaciones=[];

var continuar;

var huella1correcta;

$(document).ready(function () {
    $('#nav').hide();
    document.title = titulo;
    mostrarCarga(true);
    if (getParamUrl("opc1") && getParamUrl("opc2") && getParamUrl("opc3") && getParamUrl("usuario") && getParamUrl("ws")){        
        $.when(wsConsultaDivisa()).done(function(result){
            if(result.NoError==0){
                $.when(wsConfiguraMenu(1, getParamUrl("opc1"), getParamUrl("opc2"), getParamUrl("opc3"))).done(function(resultMenu){
                    if(resultMenu.NoError==0){
                        let opc= resultMenu.Descripcion.split(",");
                        let opcLoad="";
                        perfil= opc[0].split("|")[1];
                        for(let index=1; index<opc.length;index++){
                            if(opc[index].split("|")[1]=="1"){
                                if(index==1) opcLoad=opc[index].split("|")[0];
                                $('#'+opc[index].split("|")[0]).show();
                            }else
                                $('#'+opc[index].split("|")[0]).hide();
                        }
                        $('#nav').show();
                        pantallas();
                        if(opcLoad!=""){
                            if (changeMenu($('#'+opcLoad))){            
                                $('#content').hide().load( $('#'+opcLoad).attr("href") , function(){
                                    $('#selectValor').removeAttr("disabled");
			                        $('#content').show();
			                    });
                            }
                        }
                    }                    
                });
            }        
        });        
    }else {
        showMesagge(1, "Parámetros de entrada incorrectos");              
    }



});
function getUrlTraspaso(servicio) {    
    var url = "";
    if(window.location.hostname == "localhost"){
        url="http://10.54.28.226:9014/Caja/"+ servicio;
    }else{
        url="http://" + window.location.hostname + ":9014/Caja/"+ servicio;
    }    
    return url;
}
var servicioVistas="Servicios/Traspasos/Traspasos.svc/wsRequestTipoVistaTraspaso";
function pantallas() {
    var empleado = usuario;
    $.ajax({
        url: getUrlTraspaso(servicioVistas),
       
        contentType: "application/json; charset=UTF-8",
        type: "POST",
        data: JSON.stringify({
            "Cajero": empleado,
        }),
        dataType: 'json',
        crossDomain: true,
        success: function (resps) {
            //mostrarCarga(false);
            mostrarCarga(false);
                if (resps.NoError==0) {
                pantalla(resps.Vista);    
                }
                else
                {
                    msjs(resps.DescripcionError);
                }
            
        },
        error: function () {
            msjs("Ocurrió un error en el consumo del servicio.");
        }
    });
}
function pantalla(jsonVista){
        
           var vista=jsonVista[0];
           var vista2=jsonVista[1];
           var vista3=jsonVista[2];
           var vista4=jsonVista[3];
           //if (vista3.key==3){
            if (vista.Value==false) {                
                document.getElementById('caja').style.display='none';
                //$('#consulta').hide();
            }
            
            if (vista2.Value==false) {                
                document.getElementById('cajero').style.display='none';
                //$('#consulta').hide();
            }

            if (vista3.Value==false) {                
                document.getElementById('fondeo').style.display='none';
                //$('#consulta').hide();
            }

            if (vista4.Value==false) {                
                document.getElementById('consulta').style.display='none';
                //$('#consulta').hide();
            }
           

}

//Carga la pagina solicitada
$(function(){
    $('#nav a').click(function(e) { 
        if (changeMenu( $(this))){   
            isHuellaT=false;
            isHuellaR=false;
            $("#btnDelete"+page_select).attr("disabled", true);
            $('#content').hide().load( $(this).attr('href') , function(){
                $('#selectValor').removeAttr("disabled");
			    $('#content').show();
			});
        }
         return false;
	});
})

//----- CLOSE popup
function onClosePopup(id){
    $('#btnAceptarPopup').off('click');
    $('[data-popup="'+id+'"]').fadeOut(350);
}

function isNumberKey(evt, allowDot) {
    let charCode = (evt.which) ? evt.which : event.keyCode;
    let val=true;    
    if ((charCode < 48 || charCode > 57))
        val= false;
    if(allowDot && charCode == 46)
            val=true;   
    if (charCode==13)val=true;
    if (charCode==8)val=true; 
    return val;
}

function validaImporte(evt) {

    let charCode = (evt.which) ? evt.which : event.keyCode;
    let val=true;    
    if ((charCode < 48 || charCode > 57))
        val= false;
    if(isMonedas && charCode == 46)
            val=true;   
    if (charCode==13)val=true;
    if (charCode==8)val=true; 
    return val;
}

  
////////////////////////////////////////////////

//configura titulos, estilos al cambiar de menu
function changeMenu(e){    
    if ($(e).attr('id')!=id_page_select){
        mostrarCarga(true);
        if(id_page_select!=""){
            $('#'+id_page_select).removeClass('Act');//class="Act"
            $('#'+id_page_select+' img:last-child').remove();        
        }        
        id_page_select=$(e).attr('id');
        page_select=id_page_select;
        page_select=page_select=='cajero'||page_select=='fondeo'?'cajero':page_select;
        switch (id_page_select){
            case "caja": //Concentracion
                origen="D";
                break;
            case "cajero": //Traspaso saldo a cajero
                origen="T";
                break;
            case "fondeo": //Fondeo
                origen="F";
                break;
            default:
                origen="";
                break;
        }
        titulo=$(e).text();
        $('html head').find('title').text(titulo);
        $('#titulo').text(titulo);
        $(e).addClass('Act');//class="Act"
        $(e).prepend('<img src="../../Imgs/slider/cuadroV.jpg" class="png">');
        return true;
    }
    return false;  
}

function changeDivisas() {   
    $('#desc_divisa').html(desc_divisa);       
    consultarDenominacion();    
}

function expandDocument(id){
    $this =$('#adt'+id);
        //the target panel content
        $target = $this.next();
        jQuery(document.getElementById('add'+id)).removeClass('accordion-active');
        if ($target.hasClass("in")) {
            $this.removeClass('accordion-active');
            $target.slideUp();
            $target.removeClass("in");

        } else {
            $this.addClass('accordion-active');
            jQuery('.accordion1 > dd').removeClass("in");
            $target.addClass("in");
            $(".subSeccion").show();
            //jQuery('.accordion > dd').slideUp();
            $target.slideDown();
        }
}


function expandEfectivo(name, subname){
$this = $('#'+name.id);
        //the target panel content
        $target = $this.next();

        jQuery(document.getElementById(''+subname.id)).removeClass('accordion-active');
        if ($target.hasClass("in")) {
            $this.removeClass('accordion-active');
            $target.slideUp();
            $target.removeClass("in");

        } else {
            $this.addClass('accordion-active');
            jQuery('.accordion > dd').removeClass("in");
            $target.addClass("in");
            $(".subSeccion").show();
            $target.slideDown();
        }
}

function beforeHuella(){
    if (tipoAccion!="recibir"){
        if (idInputTraspaso!="")
            $("#"+idInputTraspaso).attr("disabled", true);
    }
    if (page_select=="caja"){
            $("#btnCancelaDoc").removeAttr("disabled");            
    }
}

function openDenominaciones(val, importe, tipo){  
    tipoAccion=tipo;   
    mostrarCarga(true);
    tipoTraspaso=val;    
    $('#divImporte').show();  
    let band=0;  
    let continuaFlujo=true;
    if(tipoAccion=="traspasar"){
        idInputTraspaso=val=="efectivo"?'importe'+page_select:'importe'+page_select+'Doc';
        importe=importe==0?$('#'+idInputTraspaso).val():importe;
        if(page_select=='cajero'){
            if (empleadoSelect!=undefined) {
            if((empleadoSelect.SaldoCjr+Number(importe))<=empleadoSelect.Tope || importe==0)
                continuaFlujo=true;
            else{
                band=3;
                continuaFlujo=false;
            }
        }else{
            msjs("Seleccione un empleado");
            continuaFlujo=false;
        }
        }
        if(continuaFlujo){   
            if (!isHuellaT){
                band=activebtnTraspaso(val)?1:0;
                if(band==1){
                    let idInput=val=="efectivo"?'importe'+page_select:'importe'+page_select+'Doc';        
                    $("#"+idInput).attr("disabled", true);                    
                    importeTrasp=importe;
                    if (importe>0){            
                        $('#importe_denominacion').val(importe);
                    }
                }
            }else{           
                band=2;
            }
       }                
    }else{
        if (!isHuellaR){
            importeTrasp=importe;
            $('#divImporte').hide();
            band=1;
        }else{
            band=2;
        }
    }
    switch(band){
        case 0:
            mostrarCarga(false);
            break;
        case 1: 
            cantBilletes=0;
            cantMonedas=0;
            importeTraspDen=0;
            $('#cantMoneda').val(cantMonedas);
            $('#cantBilletes').val(cantBilletes);
            $('#totalMB').val(formatMoney(importeTraspDen));      
            llenarDenominacion();
            break;
        case 2: 
            mostrarCarga(false);
            traspasar();
            break;
        case 3:
            mostrarCarga(false);
            msjs("No es posible efectuar el Traspaso porque el Empleado "+empleadoSelect.NoEmpledo+" tiene un saldo mayor a su tope de "+formatMoney(empleadoSelect.Tope)+" en Divisa "+divisa_descorta);
            //msjs("No es posible efectuar el Traspaso porque el Empleado "+empleadoSelect.NoEmpledo+" tiene un saldo mayor a su tope de "+formatMoney(empleadoSelect.Tope)+" en Divisa "+divisa_descorta);
            break;
    }
}

function totales(IdDenominacion, id) {    
    let cantOld = Number(id.oldvalue);       
    let importeTotal = tipoAccion=="recibir"?Number(traspasoSelect.Importe):Number(importeTrasp);
    let idInput="";
    let denominacion="";
    let cant=0;
    cantBilletes=0;
    importeTraspDen=0;
    $("#tableDenominacion :input").each(function() {
        cant = Number($(this).val());
        if(cant>0){
            cantBilletes+=cant;
            denominacion = $(this).attr('id').substring(3,$(this).attr('id').length);            
            importeTraspDen+= cant * Number(denominacion);
        }
    });
    cant = Number($('#cantMoneda').val());
    if(cant>0)
        importeTraspDen+= cant;
    //$("#btnAcepTrasp").attr("disabled", true);
    idInput=IdDenominacion==1&& isMonedas?'cantMoneda':'den'+IdDenominacion.toString().replace(/\./g,'');
    if(importeTraspDen > importeTotal && tipoAccion!="recibir"){        
        $('#'+idInput).val(cantOld);
        importeTraspDen=deleteFormatMoney($('#totalMB').val());         
        //if(importeTraspDen==importeTotal)
            //$("#btnAcepTrasp").removeAttr("disabled");
        msjs("Monto excedido");        
    }else{
        $('#total'+IdDenominacion.toString().replace(/\./g,'')).html(formatMoney(Number(IdDenominacion) * Number(id.value)));
        $('#totalMB').val(formatMoney(importeTraspDen));
        $('#cantBilletes').val(cantBilletes);                 
        //if(importeTraspDen==importeTotal)
            //$("#btnAcepTrasp").removeAttr("disabled");
    }  
    
    //if(tipoAccion=="recibir" && importeTraspDen>0)
        //$("#btnAcepTrasp").removeAttr("disabled");
}

function deleteImporte(val){
    isHuellaT=false;
    $('#lblMensaje').text("");
    let idInput=val=="efectivo"?'importe'+page_select:'importe'+page_select+'Doc';
    let idBtn=val=="efectivo"?'btn'+page_select:'btn'+page_select+'Doc';   
    $('#'+idInput).val("");
    $("#btnDelete"+page_select).attr("disabled", true);
    if(val=='efectivo'){
        $("#"+idInput).removeAttr("disabled");
        if(ultimoTraspaso==1){
            ultimoTraspaso=0;
            $('#checkUltimo').prop('checked', false);
        }
    }else{
        docsLista=[];
        $("#btnCancelaDoc").attr("disabled", true);

        checkUncheckDocs(false, false);
    }
    //$("#"+idBtn).attr("disabled", true);
}

function activebtnTraspaso(val){
    //validar si esta seleccionado un empleado. If page_select==cajero
    let idInput=val=="efectivo"?'importe'+page_select:'importe'+page_select+'Doc';
    let idBtn=val=="efectivo"?'btn'+page_select:'btn'+page_select+'Doc';
    let idSaldoActual=val=="efectivo"?'saldoDisponible'+page_select:'saldoDispDoc'+page_select;
    let saldo= deleteFormatMoney($('#'+idSaldoActual).text());
    let imp = $('#'+idInput).val();
    if (Number(imp)>0 && Number(imp)<=Number(saldo)){
        if(page_select=="caja")
            return true;
        else{
            if(empleadoSelect != undefined)
                return true;
            else{
                msjs("Debe seleccionar un empleado para realizar el traspaso");    
                //msjs("Debe seleccionar un empleado para realizar el traspaso");
                return false;
            }
        }
    }else{
        if (Number(imp)>Number(saldo)) msjs("Saldo insuficiente para el traspaso");
        else 
            msjs("El monto debe ser mayor a cero");
            //alert ("El monto debe ser mayor a cero");
        //$("#"+idBtn).attr("disabled", true);}
        return false; 
    }    
}


function doAceptDenominaciones(){
    lstDenominaciones=[];
    let denominacion="";
    let cant=0;
    let importe=0;
    $("#tableDenominacion :input").each(function() {
        cant = Number($(this).val());
        if(cant>0){
            denominacion = $(this).attr('id').substring(3,$(this).attr('id').length);            
            lstDenominaciones.push({"Denominacion": denominacion, "NumBilletes": cant});
            importe+=denominacion*cant;
        }
    });
    cant = Number($('#cantMoneda').val());
    if(cant>0){
        lstDenominaciones.push({"Denominacion": "0", "NumBilletes": cant});
        importe+=cant;
    }
    if(tipoAccion=="traspasar"){        
        if(importeTrasp==importe){
            $j.modal.close();
            traspasar();                       
        }else 
            alert("El Total es Diferente al Importe a Desglozar");
    }else{
        if(importe>0){
            //doRecibirAhora();        
            totalRecibir= deleteFormatMoney($("#totalMB").val());
            traspasoSelect.Importe = totalRecibir;
            $j.modal.close();
            $('#titlePoup').html("Confirmación de Concentración a caja");
            $('#msjPopup').html("<p>En concentración de saldos debe autorizar el encargado de sucursal. Pide que te autorice esta operacion</p><p>NOTA: Un mismo empleado NO puede rendir y validar el Traspaso.</p>");
            $("#btnAceptarPopup").click(function(){ abrirHuella(comprobarHuellaRecibir,2); });
            $('[data-popup="popupMsj"]').fadeIn(300);
        }else{
            alert("El Total no puede ser cero");
            //alert("El Total no puede ser cero");
        }
    }        
}
function msjs(mensaje) {
    $('#mensajeTitulo').html('Mensaje:');
    $('#mensajeTexto').html(mensaje);
    $j('#modal104').modal();
}

function traspasar(origen){
    let band=true;
    let msj="";
    if(origen){
        band=activebtnTraspaso('doc');    
        tipoAccion="traspasar";
        msj="¿Esta seguro de Realizar el Traspaso a la Caja Documentos?";
    }else{
        msj = "¿Está seguro de realizar la siguiente operación?<br/>"+
                  "Depósito a caja principal por: "+formatMoney(importeTrasp)+' (' + desc_divisa+')';        
    }  
    if(band){  
        $('#msjConfirmacion').html(msj);
        setTimeout(function() {
            $j('#modal02').modal({
		    });
		    return false;
	    }, 1);
    }
}

function doTraspasar(json){    
    isHuellaT=true;
    $("#btnDelete"+page_select).attr("disabled", false);
    if(json.Status==0){        
        mostrarCarga(false);
        showMesagge(1, json.Descripcion);
    }else{        
        RealizaConcentraciones(construirConsultaTraspaso(json.Autorizo), divisa, tipoTraspaso);        
    }
}

function construirConsultaTraspaso(user){
    let consulta;    
    let usuarioRec=page_select=="cajero"?empleadoSelect.NoEmpledo:user;    
    if(tipoTraspaso=='efectivo'){        
        consulta = {
            "NoEmpleado": usuario,
            "NoEmpleadoAuto":usuarioRec,
            "Divisa": divisa,
            "Origen": origen,
            "UltTraspaso": ultimoTraspaso,
            "Terminal": workstation,
            "LstTipoPago": [{ "Tipo_PagoId": 1, "TipoPagoDesc":"Efectivo", "SaldoTotal": $('#importe'+page_select).val(), 
                          "LstDenominaciones":lstDenominaciones,
                          //"referencia": ref, 
                          "LstDocumento": [{ "Importe":  $('#importe'+page_select).val(), "NoDeposito": "0"}]}]
        };
    } else {
        docsLista.Referencia = $('#referenciaDoc').val();
        for (let a of docsLista) {
            a.Referencia = $('#referenciaDoc').val();
        }
        consulta = {
            "NoEmpleado": usuario,
            "NoEmpleadoAuto":usuarioRec,
            "Divisa": divisa,
            "Origen": origen,
            "Terminal": workstation,
            "LstTipoPago": docsLista
        };
        consulta.LstTipoPago=docsLista;
    }
    return consulta;
} 

function recibirEfectivo(){
    tipoPago=0; 
    if(traspasoSelect!=undefined){
        openDenominaciones('efectivo', 0, "recibir");        
    }
}

function comprobarHuellaRecibir(json){    
    userAuto="";
    mostrarCarga(false);
    if(json.Status==0){        
        showMesagge(1, json.Descripcion);
    }else{    
        callback = null;
        totalRecibir=id_page_select=='fondeo'?traspasoSelect.Importe:totalRecibir;
        userAuto=json.Autorizo;              
        $('#titlePoup').html("Operación de Saldos");
        $('#msjPopup').html("<p>Se afectará con la autorización de T"+json.Autorizo+", por la cantidad de  "+formatMoney(totalRecibir)+"</p>");
        $("#btnAceptarPopup").click(function(){ doRecibirAhora(); });
        $('[data-popup="popupMsj"]').fadeIn(300);
    }
}

function doRecibirAhora(){   
    onClosePopup("popupMsj");
    let importeTotal= Number(traspasoSelect.Importe);    
    if(Number(totalRecibir)<importeTotal && traspasoSelect.UltTraspaso=="1"){
        totalRecibirRestante=importeTotal-Number(totalRecibir);
        $('#divisaAjuste').html(desc_divisa);
        $('#importeAjuste').html(formatMoney(totalRecibirRestante));
        $("#pagoAhoraCheck").attr("checked", false);
        $("#nominaCheck").attr("checked", false);
        $('[data-popup="popupAjusteSaldos"]').fadeIn(400); 
    }else{
        onClosePopup('popupAjusteSaldos');        
        mostrarCarga(true);    
        let saldo=tipoPago==1|| tipoPago==2?totalRecibir-totalRecibirRestante:deleteFormatMoney(totalRecibir);
        let usuarioRec=page_select=="cajero"?traspasoSelect.NoCajeroRec:userAuto;
        let consulta = {
            "NoEmpleado": usuario,
            "Origen": origen,
            "NoEmpleadoAuto": usuarioRec,
            "FormaPago":tipoPago,
            "Divisa": divisa,
            "Terminal": workstation,
            "UltTraspaso":traspasoSelect.UltTraspaso,
            "LstTipoPago": [{ "Tipo_PagoId": 1, "TipoPagoDesc":"Efectivo", "SaldoTotal": saldo,
                              "LstDenominaciones":lstDenominaciones,
                              "LstDocumento": [{ "Importe": saldo, "NoDeposito": traspasoSelect.Concentracion}]}]
        };
        ConfirmaConcentraciones(consulta, traspasoSelect.Concentracion, divisa, 'efectivo', pagare);
    }    
}

function ajusteSaldos(){
    if($('#pagoAhoraCheck').is(':checked') || $('#nominaCheck').is(':checked')){
        if($('#pagoAhoraCheck').is(':checked')){  
            tipoPago=2;          
            totalRecibir=Number(totalRecibirRestante)+Number(totalRecibir);
            doRecibirAhora();
        }
        if($('#nominaCheck').is(':checked')){
            tipoPago=1;
            onClosePopup('popupAjusteSaldos');
            abrirHuella(openFormularioPagare,3);            
        }
    }else 
        msjs("Debes seleccionar una opción");    
}

function openFormularioPagare(json){    
    userAuto="";
    if(json.Status==0){
        mostrarCarga(false);
        showMesagge(1, json.Descripcion);
    }else{        
        $("#formPagare :input").each(function() {
            let element = $(this);
            element.val("");
        });
        userAuto=json.Autorizo;        
        $('[data-popup="popupFormulario"]').fadeIn(400);
        mostrarCarga(false);
    }    
}

function doPagare(){
    let isValid;
    $("#formPagare :input").each(function() {
        let element = $(this);
        if (element.val() == "") {
            isValid = false;
            return false;
        }else{
            isValid = true;
        }
    });
    if(isValid){
        totalRecibir=Number(totalRecibirRestante)+Number(totalRecibir);
        pagare = {
            "suscriptor": {"nombre": $('#nombreSus').val(), "calle": $('#calleSus').val(), 
                             "colonia": $('#coloniaSus').val(), "ciudad": $('#ciudadSus').val(), "cp": $('#cpSus').val()},
            "aval": {"nombre": $('#nombreAval').val(), "calle": $('#calleAval').val(), "colonia": $('#coloniaAval').val(),
                             "ciudad": $('#ciudadAval').val(), "cp": $('#cpAval').val()},
            "lugar": {"ciudad": $('#ciudadExp').val(), "estado": $('#estadoExp').val()},
        };
        onClosePopup('popupFormulario');
        doRecibirAhora();        
    }else
        msjs("Debes ingresar todos los campos solicitados");
}

//Funcion para abrir el componente de huellas
function abrirHuella(callback, tipo) {
    mostrarCarga(true);
    //Quitar de opendenominaciones
    beforeHuella();    
    let emp="";
    let auth="";
    let perfiles="0";
    let continuar=true;
    switch(tipo){
        case 1: //Traspasos
            emp=usuario;
            auth=usuario;
            break;
        case 2: //Recibir concentraciones
            onClosePopup("popupMsj");
            emp=usuario;
            if (page_select=='caja'){                
                let result = getPerfilesAutorizador(opc, idModulo, idFolio);//Servicio de perfiles autorizadores;
                if(result && result.Estatus==0){
                    auth=result.EmpAutorizador;
                    perfiles=result.EmpPerfiles;
                }else{
                    continuar=false;
                    showMesagge(1, result.msjCliente || "Ocurrio un error en el servidor");
                }                
            }else{
                emp=traspasoSelect.NoCajeroRec;
                auth = traspasoSelect.NoCajeroRec;
            }
            break;
        case 3: //Pagare 
            emp = usuario;            
            let result = getPerfilesAutorizador(opc, idModulo, idFolio);//Servicio de perfiles autorizadores;
            if(result && result.Estatus==0){
                auth=result.EmpAutorizador;
                perfiles=result.EmpPerfiles;
            }else{
                continuar=false;
                showMesagge(1, result.msjCliente || "Ocurrio un error en el servidor");
            } 
            break;
    }
    if (continuar){
        let workstation= getParamUrl("ws"); 
        var json = '{"validarEmp":"' + emp + '",' +
                '"validarAut":"' + auth + '",' +
                '"tipo":"' + tipoH + '",' +
                '"app":"' + app + '",' +
                '"top":"' + topH + '",' +
                '"afectaHD":"' + afectaHD + '",' +
                '"perfiles":"' + perfiles + '",' +
                '"ws":"' + workstation + '"}';    
        json = JSON.parse(json);        
        jsonP = json;
        AutenticacionHuella(json,callback);
    }else{
        mostrarCarga(false);
    }
}

function btncancelaTraspaso(){
    if(traspasoSelect!=undefined){
        $j('#modal05').modal();        
    }
}

function doCancelacion(){
    mostrarCarga(true);
    let empleado=page_select=='caja'?usuario:traspasoSelect.empleado;
    cancelaTraspaso(empleado, divisa, traspasoSelect.Concentracion);
}

function onUltimoTraspaso(){
    ultimoTraspaso=0;
    if($('#checkUltimo').is(':checked')){
        let disponible = Number(deleteFormatMoney($('#saldoDisponiblecaja').text()));
        if(disponible>0){
            ultimoTraspaso=1;
            $('#importecaja').val(disponible);
            $('#titlePoup').html("Traspas de Saldos");
            $('#msjPopup').html("<p>Este será su último Traspaso de Efectivo a Caja Principal</p><p>Se deberá de Traspasar todo el Saldo de Efectivo, ya que éste será Validado en la Confirmación a Caja </p><p>Principal y si existiera alguna diferencia, se genenerá un Ajuste por Faltante o Sobrante. </p>");            
            $("#btnAceptarPopup").click(function(){ doUltimoTraspaso(); });
            $('[data-popup="popupMsj"]').fadeIn(300);
        }else{
            msjs("Saldo insuficiente");
            $('#checkUltimo').prop('checked', false);
        }
    }else{
        $('#importecaja').val("0");
    }
}

function doUltimoTraspaso(){
    onClosePopup("popupMsj");
    openDenominaciones('efectivo', $('#importecaja').val(), "traspasar");
}

function onCheckDoc(id, all){
    detalleDocsLista=[];    
    var importeTotalDocumentos=0;
    let importe = 0;
    if($('#check'+id).is(':checked') && Number(detalleDocuments[id].saldo)<=0 ){
        $('#check'+id).prop('checked', false);
    }else{
        let saldo= deleteFormatMoney($('#saldoDispDoccaja').text());
        let imp = detalleDocuments[id].saldo;
        if(Number(imp)<=Number(saldo)){
        docsLista=[];
        detalleDocsLista=[];
        
        if($('#check'+id).is(':checked')){
        $.each(detalleDocuments, function (i, doc) {
            importe= 0;
            detalleDocsLista=[];
            if($('#check'+i).is(':checked')){
            $.each(doc.detalleDocs, function (j, det) {                
                if (all && i==id){
                    if(Number(det.Importe)>0)
                        $('#checkDocuments'+j+i).prop('checked', true);
                }
                if($('#checkDocuments'+j+i).is(':checked') && Number(det.Importe)>0){    
                    importeTotalDocumentos += Number(det.Importe);
                    importe += Number(det.Importe);
                    detalleDocsLista.push({ "Importe":  det.Importe.toString(), "NoDocto": det.NoDocto, "NoDeposito": "0", "NoOperacion": det.NoOperacion});
                }
            });
            if(doc.detalleDocs.length>0)
                    docsLista.push({ "Tipo_PagoId": doc.tipoId, 
                              "TipoPagoDesc": doc.desc,
                              "Referencia": "",
                              "SaldoTotal": importe.toString(),
                              "LstDenominaciones":[],
                              "LstDocumento": detalleDocsLista}); 
            }
        });        
        }else{
            $.each(detalleDocuments[id].detalleDocs, function (j, doc) { 
                $('#checkDocuments'+j+id).prop('checked', false);                    
            });               
            if($('#selectDocs').is(':checked')) validaChecks();            
        }
        $('#importecajaDoc').val(importeTotalDocumentos.toFixed(2));
        //activebtnTraspaso('doc');
        }else{
            $('#check'+id).prop('checked', false);
            msjs("Saldo insuficiente para el traspaso");
        }
    }    
    console.log(docsLista);
}

function onCheckDetalleDoc(id, idDetalle){
    if($('#checkDocuments'+idDetalle+id).is(':checked')){
        let saldo= deleteFormatMoney($('#saldoDispDoccaja').text());
        let imp = detalleDocuments[id].detalleDocs[idDetalle].Importe;
        if(Number(imp)>Number(saldo)){
            $('#checkDocuments'+idDetalle+id).prop('checked',false);
            msjs("Saldo insuficiente para el traspaso");
        }else{
            $('#check'+id).prop('checked',true);
            onCheckDoc(id, false);
        }
    }else{
        onCheckDoc(id, false);
        validaDetalle(detalleDocuments[id].detalleDocs.length, id);
    }       
}

function validaDetalle(size, id){
    let status=false;
    for (let i=0; i<size;i++){       
        status= $('#checkDocuments'+i+id).is(':checked');
        if(status)break;       
    }
    $('#check'+id).prop('checked', status);
    return status;
}

function checkUncheckDocs(status, changeList){
    for (let i=0; i<detalleDocuments.length;i++){
        $('#check'+i).prop('checked', status);
        if (changeList){
            onCheckDoc(i, true);
        }
            
    }
}

function validaChecks(){
    let status=false;
    for (let i=0; i<detalleDocuments.length;i++){       
        status= $('#check'+i).is(':checked');
        if(status) break;
    }
    $('#selectDocs').prop('checked', status);
}

function selectDocs(){
    checkUncheckDocs($('#selectDocs').is(':checked'), true);
    validaChecks();
}

function onCheckTraspaso(concentracion, id){        
    $("#recEfec"+page_select).attr("disabled", true);
    $('#btnCancelar'+page_select).attr("disabled", true);
             
    let index = detalleTraspasos.findIndex(function(o){
                    return o.Concentracion === concentracion.toString();
             });
    let indexLst;
    if($('#checkE'+id).is(':checked')){
        traspasoSelect=detalleTraspasos[index];        
        $('#btnCancelar' + page_select).removeAttr("disabled");
        $('#btnCancelar' + page_select).removeClass("btnB").addClass("btnV");
        $("#recEfec"+page_select).removeAttr("disabled");   
		$('#recEfec' + page_select).removeClass("btnB").addClass("btnV");		
        for(let i=0; i<detalleTraspasos.length; i++){
            if (id!=i) {
                if($('#checkE'+i).is(':checked')){
                    $('#checkE'+i).prop('checked', false);                  
                }
            }
        }
    }else{
        traspasoSelect=undefined;
		$('#btnCancelar' + page_select).attr("disabled",true);
        $('#btnCancelar' + page_select).removeClass("btnV").addClass("btnB");
        $("#recEfec"+page_select).attr("disabled",true);   
		$('#recEfec' + page_select).removeClass("btnV").addClass("btnB");
    }
    console.log(traspasoSelect);
}

function onCheckEmpleado(empleado, id){
    mostrarCarga(true);  
    empleadoSelect=undefined;  
    $("#recEfec"+page_select).attr("disabled", true);    
    let index = detalleEmpleados.findIndex(function(o){
                    return o.NoEmpledo === empleado.toString();
             });
    let indexLst;
    if($('#checkEmp'+id).is(':checked')){
        empleadoSelect=detalleEmpleados[index];
        if(traspasoSelect!=undefined)
                $("#recEfec"+page_select).removeAttr("disabled");
        for(let i=0; i<detalleEmpleados.length; i++){
            if (id!=i) {
                if($('#checkEmp'+i).is(':checked')){
                    $('#checkEmp'+i).prop('checked', false);                  
                }
            }
        }
        llenarTraspPend(getAllValues(empleado), true, "adtEfec", "addEfec", "efectivotable", false);
        mostrarCarga(false);
    }else{
        llenarTraspPend([], true, "adtEfec", "addEfec", "efectivotable", false);
        empleadoSelect=undefined;
        mostrarCarga(false);
    }
    console.log(empleadoSelect);
    console.log(getAllValues(empleado));
}

function getAllValues(empleado) {
    var indexes = [], i;
    for(i = 0; i < detalleTraspasos.length; i++)
        if (detalleTraspasos[i].NoCajeroRec === empleado)
            indexes.push(detalleTraspasos[i]);
    return indexes;
}

function reloadContent(){
    mostrarCarga(true);
    limpiaVariblesConfirm();
    
    switch(id_page_select){
        case 'caja':
            wsConsultaSaldoCaja(usuario, divisa);
            break;
        case 'cajero':
            wsConsultaTraspasosSaldosACajeros(usuario, divisa);
            break;
        case 'fondeo': 
            wsConsultaFondeoEfecCajaACajero(usuario, divisa);
            break;
        case 'consulta':
            wsConsultaHistorialTraspasos(usuario, divisa);
            break;     
    }
    callback=null;
}

function limpiaVariblesConfirm(){
    if(typeof cantBilletes !== 'undefined'){
        cantBilletes = 0;
    }

    if(typeof  isHuellaT != 'undefined'){
        isHuellaT = false;
    }

    if(typeof  isHuellaR != 'undefined'){
        isHuellaR = false;
    }

    if(typeof  importeTrasp != 'undefined'){
        importeTrasp = 0;
    }

    if(typeof  cantBilletes != 'undefined'){
        cantBilletes = 0;
    }

    if(typeof  cantMonedas != 'undefined'){
        cantMonedas = 0;
    }

    if(typeof  importeTraspDen != 'undefined'){
        importeTraspDen = 0;
    } 

    if(typeof  importeTrasp != 'undefined'){
        importeTrasp = 0;
    } 

    if(typeof  lstDenominaciones != 'undefined'){
        lstDenominaciones = [];
    } 

    if(typeof  detalleDocuments != 'undefined'){
        detalleDocuments = [];
    } 

    if(typeof  docsLista != 'undefined'){
        docsLista = [];
    } 

    if(typeof  detalleDocsLista != 'undefined'){
        detalleDocsLista = [];
    } 

    if(typeof  detalleTraspasos != 'undefined'){
        detalleTraspasos = [];
    } 

    if(typeof  detalleEmpleados != 'undefined'){
        detalleEmpleados = [];
    } 

    if(typeof  indexDetalleDocs != 'undefined'){
        indexDetalleDocs = [];
    } 

    if(typeof  totalRecibir != 'undefined'){
        totalRecibir = "";
    } 

    if(typeof  totalRecibirRestante != 'undefined'){
        totalRecibirRestante = "";
    } 

    if(typeof empleadoSelect != 'undefined'){
        empleadoSelect = undefined;
    } 
    
    if(typeof  pagare != 'undefined'){
        pagare = [];
    } 

    if(typeof  userAuto != 'undefined'){
        userAuto = "";
    } 

    if(typeof  perfil != 'undefined'){
        perfil = "";
    } 

    if($("#recEfec"+page_select) !== 'undefined'){
        $("#recEfec"+page_select).attr("disabled", true);
    }

    if($('#btnCancelar'+page_select) !== 'undefined'){
        $('#btnCancelar'+page_select).attr("disabled", true);
    }

    if($("#importe"+page_select) !== 'undefined'){
        $("#importe"+page_select).val("");
    }

    if($("#importe"+page_select+"Doc") !== 'undefined'){
        $("#importe"+page_select+"Doc").val("");
    }

    if($("#btnDelete"+page_select) !== 'undefined'){
        $("#btnDelete"+page_select).attr("disabled", true);
    }

    if($("#referenciaDoc") !== 'undefined'){
        $("#referenciaDoc").val("");
    }

    if($('#btnDoc'+page_select) !== 'undefined'){
        $('#btnDoc'+page_select).attr("disabled", true);
    }

    setHuellaMsgImporte("");
}

function construirTicket(numOperacion,numTraspaso){
    let ticketEmp=generaContenido(numOperacion,numTraspaso, "Copia Empleado");
    let ticketTienda=generaContenido(numOperacion,numTraspaso, "Copia Tienda");
    let listaTickets={"ListaTickets":[{
		                "Aplicacion":"Caja",
		                "Contenido":ticketTienda,
		                "NoCopias": 1
	                 },
                     {
		                "Aplicacion":"Caja",
		                "Contenido":ticketEmp,
		                "NoCopias": 1
	                 }]};
    console.log(listaTickets);
    return listaTickets;    
}

function generaContenido(numOperacion,numTraspaso, tipo){
    let importeLetras = "( "+NumeroALetras(Number(totalRecibir))+" )";
    let cajeroTrasp= usuario+"-"+serviceNombreEmpleado(usuario); 
    let cajeroRec = userAuto+"-"+serviceNombreEmpleado(userAuto);  
    
    let tituloTicket1=id_page_select=="fondeo"?"Fondeo de Caja Principal":"Concentracion de Saldos";
    let tituloTicket2=id_page_select=="fondeo"?"a Cajero / Vendedor":"de Cajero a Caja Principal";
    let opero="Opero: "+empName+" en "+workstation;

    let contenido="<TICKET>"+
                    "<TEXT ALIGNH = \"CENTER\" FONTFAMILY = \"Cambria\" FONTSIZE = \"11\" FONTTYPE = \"N\">BANCO AZTECA, S.A</TEXT>"+
                    "<TEXT ALIGNH = \"CENTER\" FONTFAMILY = \"Cambria\" FONTSIZE = \"6\" FONTTYPE = \"N\">Tienda: "+sucNum+" "+sucName+"</TEXT>"+
                    "<TEXT ALIGNH = \"CENTER\" FONTFAMILY = \"Cambria\" FONTSIZE = \"6\" FONTTYPE = \"N\">"+getFecha()+"</TEXT>"+
                    "<TEXT></TEXT><TEXT></TEXT><TEXT ALIGNH = \"CENTER\" FONTFAMILY = \"Calibri\" FONTSIZE = \"11\" FONTTYPE = \"B\">"+tituloTicket1+"</TEXT>"+
                    "<TEXT ALIGNH = \"CENTER\" FONTFAMILY = \"Calibri\" FONTSIZE = \"11\" FONTTYPE = \"B\">"+tituloTicket2+"</TEXT>"+
                    "<TEXT ALIGNH = \"CENTER\" FONTFAMILY = \"Calibri\" FONTSIZE = \"6\" FONTTYPE = \"B\">"+opero+"</TEXT><TEXT></TEXT><LINE POSX = \"0\" WIDTH = \"100\" BORDERWIDTH = \"0.3\"></LINE>"+
                    "<TEXT ALIGNH = \"CENTER\" FONTFAMILY = \"Cambria\" FONTSIZE = \"9\" FONTTYPE = \"B\">Tipo de Pago  :  Efectivo</TEXT>"+
                    "<TEXT ALIGNH = \"CENTER\" FONTFAMILY = \"Cambria\" FONTSIZE = \"9\" FONTTYPE = \"B\">Divisa  :  "+desc_divisa+"</TEXT>"+
                    "<TEXT ALIGNH = \"CENTER\" FONTFAMILY = \"Cambria\" FONTSIZE = \"9\" FONTTYPE = \"B\">Num. Operacion  :  "+numOperacion+"</TEXT><TEXT></TEXT><TEXT></TEXT>"+
                    "<TEXT ALIGNH = \"CENTER\" FONTFAMILY = \"Cambria\" FONTSIZE = \"11\" FONTTYPE = \"B\">Folio de Traspaso  : "+numTraspaso+"</TEXT><TEXT></TEXT><TEXT></TEXT>";
    if(id_page_select=="fondeo"){
        contenido+="<TEXT ALIGNH = \"CENTER\" FONTFAMILY = \"Calibri\" FONTSIZE = \"9\" FONTTYPE = \"B\">Denominacion               Cantidad               Total</TEXT><TEXT></TEXT><TEXT></TEXT>";
        for(let div of traspasoSelect.DetalleDivisa){
            if(div.Denominacion==0)
                contenido+="<TEXT ALIGNH = \"CENTER\" FONTFAMILY = \"Cambria\" FONTSIZE = \"9\" FONTTYPE = \"B\">Morralla:                                                     "+formatMoney(div.Cantidad)+"</TEXT>";
            else
                contenido+="<TEXT ALIGNH = \"CENTER\" FONTFAMILY = \"Cambria\" FONTSIZE = \"9\" FONTTYPE = \"B\">"+formatMoney(div.Denominacion)+"                         "+div.Cantidad+"                         "+formatMoney(div.Cantidad*div.Denominacion)+"</TEXT>";
        }                   
        contenido+="<LINE POSX = \"50\" WIDTH = \"20\" BORDERWIDTH = \"0.3\"></LINE>"+
                   "<TEXT ALIGNH = \"RIGTH\" FONTFAMILY = \"Cambria\" FONTSIZE = \"9\" FONTTYPE = \"B\">Total a Fondear Efectivo:                          "+formatMoney(totalRecibir)+"</TEXT><TEXT></TEXT>"+
                   separaCadenasTickets(importeLetras,"Cambria",9,"B")+"<TEXT></TEXT><TEXT></TEXT><TEXT></TEXT>"+
                   "<TEXT ALIGNH = \"CENTER\" FONTFAMILY = \"Cambria\" FONTSIZE = \"9\" FONTTYPE = \"B\">Empleado que Recibio</TEXT>"+
                   separaCadenasTickets(cajeroRec,"Cambria",9, "B")+"<TEXT></TEXT><TEXT></TEXT><TEXT></TEXT><LINE POSX = \"20\" WIDTH = \"30\" BORDERWIDTH = \"0.3\"></LINE>"+
                   "<TEXT ALIGNH = \"CENTER\" FONTFAMILY = \"Cambria\" FONTSIZE = \"9\" FONTTYPE = \"B\">Firma</TEXT>";
    }else{
        contenido+="<TEXT ALIGNH = \"CENTER\" FONTFAMILY = \"Calibri\" FONTSIZE = \"9\" FONTTYPE = \"B\">Descripcion                                      Importe</TEXT><TEXT></TEXT><TEXT></TEXT>"+
                   "<TEXT ALIGNH = \"CENTER\" FONTFAMILY = \"Calibri\" FONTSIZE = \"7\" FONTTYPE = \"B\">Importe Traspasado por "+ usuario +"            "+formatMoney(traspasoSelect.Importe)+"</TEXT>"+
                   "<TEXT ALIGNH = \"CENTER\" FONTFAMILY = \"Calibri\" FONTSIZE = \"7\" FONTTYPE = \"B\">Importe Confirmado por "+ userAuto +"            "+formatMoney(traspasoSelect.Importe)+"</TEXT><TEXT></TEXT><TEXT></TEXT>"+
                   "<TEXT ALIGNH = \"CENTER\" FONTFAMILY = \"Cambria\" FONTSIZE = \"9\" FONTTYPE = \"B\">Cajero que entrego</TEXT>"+                   
                   separaCadenasTickets(cajeroTrasp,"Cambria",9, "B")+"<TEXT></TEXT><TEXT></TEXT><TEXT></TEXT><LINE POSX = \"20\" WIDTH = \"30\" BORDERWIDTH = \"0.3\"></LINE>"+
                   "<TEXT ALIGNH = \"CENTER\" FONTFAMILY = \"Cambria\" FONTSIZE = \"9\" FONTTYPE = \"B\">Firma</TEXT><TEXT></TEXT><TEXT></TEXT>"+
                   "<TEXT ALIGNH = \"CENTER\" FONTFAMILY = \"Cambria\" FONTSIZE = \"9\" FONTTYPE = \"B\">Cajero que Recibio</TEXT>"+
                   separaCadenasTickets(cajeroRec,"Cambria",9, "B")+"<TEXT></TEXT><TEXT></TEXT><TEXT></TEXT><LINE POSX = \"20\" WIDTH = \"30\" BORDERWIDTH = \"0.3\"></LINE>"+
                   "<TEXT ALIGNH = \"CENTER\" FONTFAMILY = \"Cambria\" FONTSIZE = \"9\" FONTTYPE = \"B\">Firma</TEXT>";
    }
    contenido+="<TEXT></TEXT><TEXT ALIGNH = \"LEFT\" FONTFAMILY = \"Cambria\" FONTSIZE = \"8\" FONTTYPE = \"B\">"+tipo+"</TEXT></TICKET>";
    console.log(contenido);    
    return contenido;
}

function separaCadenasTickets(cadena, font, size, fontType){
    let cant = Math.round(cadena.length/35);
    let result="";
    let iniIndex=0;
    let endIndex=35;    
    for (let i=0; i<=cant; i++){ 
        if(cadena.substring(iniIndex,endIndex)!=""){   	
        	result+="<TEXT ALIGNH = \"CENTER\" FONTFAMILY = \""+font+"\" FONTSIZE = \""+size+"\" FONTTYPE = \""+fontType+"\">"+cadena.substring(iniIndex,endIndex);
            result+=endIndex>=cadena.length?"</TEXT>":"-</TEXT>";            
        }
        iniIndex=endIndex;
        endIndex=iniIndex+35>cadena.length?cadena.length:iniIndex+35;
	}
    return result;
}

function editarMonto(){    
    $('#importe_denominacion').attr("disabled", false);
    $('#importe_denominacion').focus();
}

function cambiarMontoTrasp(val){ 
    console.log(val);  
    let newImporte=Number(val.value);
    let idSaldoActual="saldoDisponible"+page_select;
    let saldo= deleteFormatMoney($('#'+idSaldoActual).text());
    if(newImporte==0){
        msjs ("El monto debe ser mayor a cero");
    }else{
        if(newImporte>=saldo){
            msjs("Saldo insuficiente para el traspaso");
        }else{
            importeTrasp=newImporte;
            $('#importe'+page_select).val(importeTrasp);
        }
    }
}

function interrumpirProceso(){    
    reloadContent();
    if (tipoAccion=="traspasar"){
        /*isHuellaT=true;*/
        $("#btnDelete"+page_select).attr("disabled", false);
    }/*else
        isHuellaR=true;*/
    $j.modal.close();    
}

function salirDenominaciones(){
    $j.modal.close();
    $j("#modal06").modal();
}

function noSalirDenominaciones(){
    $j.modal.close();
    $j("#modal01").modal();
}

function siSalirDenominaciones(){
    if(tipoAccion=="traspasar"){
        importeTrasp=0;
        $("#importe"+page_select).val("");
        $("#importe"+page_select).attr("disabled", false);
    }
    $j.modal.close();
}

function finishConfirmacion(){    
    if(id_page_select=="caja" || id_page_select=="fondeo"){
        mostrarCarga(true);
        imprimir();                              
    } else{
        mostrarCarga(true);
        reloadContent();
    }
}

function imprimir(){
    mostrarCarga(true); 
    $.when(generaTicket(construirTicket(transaccionImpr,concentracionImpr), false, true)).done(function(result){       
        if(result.Contenido>0){
            mostrarCarga(true); 
            $.when(imprimirTicket(result.Contenido, false, true)).done(function(resultI){
                if(pagare.suscriptor){
                    let ruta = wsurlGeneraCartaFaltante(pagare, totalRecibirRestante);
                    $.when(imprimirCarta(ruta, false, true)).done(function(resultC){
                        mostrarCarga(false);
                    }).fail(function(){mostrarCarga(false); });
                } 
                mostrarCarga(false);
                $j.modal.close();
                $j('#modal07').modal();
            }).fail(function(){ 
                mostrarCarga(false);
                $j.modal.close();
                $j('#modal07').modal();});           
        }        
    }).fail(function(){ 
        mostrarCarga(false);
        $j.modal.close();
        $j('#modal07').modal();});
}

function fondearAhora(){
    if(traspasoSelect!=undefined){
        abrirHuella(null,2);
        
    }
}

function confirmaHuellaF(){
    if(huella1correcta){
    callback = comprobarHuellaRecibir;
    let result = getPerfilesAutorizador(opc, idModulo, idFolio);//Servicio de perfiles autorizadores;
    if(result && result.Estatus==0){
        auth=result.EmpAutorizador;
        perfiles=result.EmpPerfiles;
        continuar=true;
    }else{
        continuar=false;
        showMesagge(1, result.msjCliente || "Ocurrio un error en el servidor");
    }
    if (continuar){
        let workstation= getParamUrl("ws"); 
        var json = '{"validarEmp":"' + traspasoSelect.NoCajeroRec + '",' +
                '"validarAut":"' + auth + '",' +
                '"tipo":"' + tipoH + '",' +
                '"app":"' + app + '",' +
                '"top":"' + topH + '",' +
                '"afectaHD":"' + afectaHD + '",' +
                '"perfiles":"' + perfiles + '",' +
                '"ws":"' + workstation + '"}';    
        json = JSON.parse(json);        
        AutenticacionHuella(json,callback);
    }else{
        mostrarCarga(false);
    }

    }else{
        showMesagge(1, "Huella de Empleado no Validada");
    }
}


function validaFormulario(evt, tipo){    
    let valid;
    switch(tipo){
        case 1: //solo numeros
            valid = (evt.which >= 48 && evt.which <= 57) || (evt.wich == 8)|| (charCode == 13);
            break;
        case 2: //solo letras
            valid = (evt.which >= 65 && evt.which <= 90) || (evt.which >= 97 && evt.which <= 122) || (evt.which ==32) || (evt.wich == 8)|| (charCode == 13);
            break;
        case 3: //letras y numeros
            valid = (evt.which >= 48 && evt.which <= 57) || (evt.which >= 65 && evt.which <= 90) || (evt.which >= 97 && evt.which <= 122) || (evt.which ==32) || (evt.wich == 8)|| (charCode == 13);
            break;
        case 4:
            valid = (evt.which >= 48 && evt.which <= 57) || (evt.which >= 65 && evt.which <= 90) || (evt.which >= 97 && evt.which <= 122) || (evt.which == 32) || (evt.wich == 8);
            break;

    }   
    return valid;
}

function RecibirResultadoHuella(resultado) {
    if (resultado.Status == 0) {
        huella1correcta = false;
        mostrarCarga(false);
        // $('#content').show();
        // document.getElementById("resultado").innerHTML = resultado.Descripcion;
    } else { //Si la autenticacion es correcta realiza Autorizacion de Huella.
        huella1correcta=true;
        alert("Se requiere Autorización para esta transaccion");
        confirmaHuellaF();
    }


}