﻿if ($j === undefined) { var $j = jQuery.noConflict(true); console.log($().jquery); console.log($j().jquery); }

//const AUrlValidaAcceso = "Arqueo/WsCajaArqueo.svc/wsValidaAccesoArqueo";
const AnclUrlValidaEmpleado = "Comun/WsCajaComun.svc/wsConsultaInformacionInicial";
const AnclUrlDivisas = "Comun/WsCajaComun.svc/wsConsultaDivisa";
const AnclUrlObtieneValidadores = "wsUtileriaCaja/wsUtileria.svc/wsPerfilAutorizador";
//nuevas url
const AnclUrlObtieneSaldoInicial = "DesAnclaje/WSDesAnclaje.svc/wsconsultaSaldosIncialesAn";
const AnclUrlDenominaciones = "DesAnclaje/WSDesAnclaje.svc/wsObtieneDenominacionesPorDivisaAn";
const AnclUrlRegistrarAnclaje = "DesAnclaje/WSDesAnclaje.svc/wsAfectacionDeTraspasoAn";
const AnclUrlRecoleccionAnclaje = "DesAnclaje/WSDesAnclaje.svc/wsGeneraRecoleccionAn";

var empleadoID = null;
var cajaNombre = null;
var empleadoPuesto = null;
var empleadosVal = null;
var empleadosValPerfs = null;

var datosAnclaje = null;
var indicesDivisas = [];
var divisaActual = null;

var refAncCont = null;
var tiempoRestante = null;
var validarOperador = null;
var pantallaCargada = false;
var refFuncMensaje = null;
var refFuncAceptar = null;
var refFuncCancelar = null;

const limitePiezas   = 1000000000;
const limiteMorralla = 1000000000.0;

var opc="1"; 
var idModulo="113"; //Modulo Anclaje
var idFolio="2";//Consultar Perfiles autorizadores
var usuario="";

var idPais="";
var idCanal="";
var idSucursal="";
var topeSucursal="";

//carga datos iniciales
$(document).ready(function () {
    $('#botonRegistrar').hide();
    var date = new Date();
    $('#tagHora').html(date.getHours() + ":" + date.getMinutes());
    $('#tagFecha').html((date.getMonth() + 1) + "/" + date.getDate() + "/" + date.getFullYear());

    empleadoID = getUrlVars()["empleado"];
    cajaNombre = getUrlVars()["ws"];
    if (empleadoID === undefined || empleadoID == ""
        || cajaNombre === undefined || cajaNombre == "") {
        DispararError("Los parámetros no son correctos.",'parámetros de la URL');
        return;
    }
    usuario=empleadoID;
    mostrarCarga(true); //
    let result = getPerfilesAutorizador(opc, idModulo, idFolio);//Servicio de perfiles autorizadores;
    if(result && result.Estatus==0){
        empleadosVal=result.EmpAutorizador;
        empleadosValPerfs=result.EmpPerfiles;        
    }else{
        if(result && result.Estatus==1){
            mostrarCarga(false);
            DispararError(result.msjCliente+" para realizar un anclaje",result.msjCliente);
        }
        return;
    }
    loadPage();
    
});

function loadPage(){
    setTimeout(function () {
        obj = AnclServConsultaEmpleado(empleadoID);
        if (obj.NoError != 0) {
            DispararError(obj.Descripcion,'consulta de empleado');
            mostrarCarga(false);
            return;
        }
        idPais=obj.InformacionInicial.Pais;
        idCanal=obj.InformacionInicial.Canal;
        idSucursal=obj.InformacionInicial.NoTienda;

        $('#tagEmpNombre').html(obj.InformacionInicial.NombreEmpleado);
        $('#tagEmpDescripcion').html(obj.InformacionInicial.DescripcionPBase);
        empleadoPuesto = obj.InformacionInicial.PuestoRol;
        $('#tagNumTienda').html(obj.InformacionInicial.NoTienda);
        $('#tagNombreTienda').html(obj.InformacionInicial.NombreTienda);
        $('#tagPais').html(obj.InformacionInicial.DescripcionPais);
        $('#textoObservaciones').val(''); //vaciar comentarios
        LlenarSelectDivisas(); //aqui se incluye el llenado de tablas inicial
        mostrarCarga(false);

        //declarar comportamiento de elementos estáticos
        $('#selectDivisas').on('change', function () {
            AsignarEventosDenominaciones(divisaActual, false); //desasignar eventos antes de cambiar la divisa actual
            divisaActual = $(this).val().toString();
            LlenarCamposSaldos(divisaActual);
            LlenarTablaResultados(divisaActual);
        });
        $('#textoObservaciones').on('change focusout', function () {
            if ($(this).val().length > 100) {
                $('#textoObservaciones').val($(this).val().substring(0, 100));
            }
        });
    }, 200);

}
/////////////////////////Funciones para rellenar las tablas//////////////////////////////////////////

function LlenarSelectDivisas() { //solo se ejecuta una sola vez, al principio
    //consulta servicio de divisas
    var obj = AnclServConsultaDivisa();
    if (obj.NoError != 0) {
        DispararError(obj.Descripcion,'consulta de divisas');
        return;
    }
    var divisas = obj.Divisas;
    //llenar select grafico
    var opciones = "";
    var strSelected;
    for (let i = 0 ; i < divisas.length ; i++) {
        strSelected = (i == 0) ? "selected" : "";
        opciones += '<option value="' + divisas[i].Id + '" ' + strSelected + '>' + divisas[i].Descripcion + '</option>';
        indicesDivisas.push(divisas[i].Id);
    }
    $('#selectDivisas').html(opciones);
    //inicializar objeto para almacenar datos de las divisas, saldos de anclaje
    datosAnclaje = {};
    //al acceder a los datos de una divisa, de debe usar un indice que sea STRING, no que sea numerico
    divisaActual = divisas[0].Id.toString();
    for (let i = 0 ; i < divisas.length ; i++) {
        //definir el objeto de divisas con indices que correspondan a su ID del servicio, no a su indice del arreglo
        Object.defineProperty(datosAnclaje, divisas[i].Id.toString(), { enumerable: true, configurable: true, writable: true, value: divisas[i] });
        //lista de denominaciones.
        Object.defineProperty(datosAnclaje[divisas[i].Id.toString()], "Denominaciones", { enumerable: true, configurable: true, writable: true, value: null });
        //cantidades de denominaciones
        Object.defineProperty(datosAnclaje[divisas[i].Id.toString()], "TablaDenominaciones", { enumerable: true, configurable: true, writable: true, value: null });
        //lista de saldos que se listan en la interfaz
        Object.defineProperty(datosAnclaje[divisas[i].Id.toString()], "Saldos", { enumerable: true, configurable: true, writable: true, value: null });
    }
    LlenarCamposSaldos(divisaActual); //supongo siempre que campos saldos se va a ejecutar antes de tabla denimonaciones
    LlenarTablaResultados(divisaActual);
}

function LlenarCamposSaldos(divisaID) {
    if (datosAnclaje[divisaID].Saldos == null) { //si no se han definido los saldos de esta divisa
        var obj = AnclServConsultaSaldoInicial(divisaID);
        if (obj.NoError != 0) {
            DispararError(obj.Descripcion,'consulta de saldo inicial');
            return false;
        }
        datosAnclaje[divisaID].Saldos = {
            "montoSaldoCP": obj.Saldos.SaldoCP, //saldo disponible en CP
            "montoTopeCP": obj.Saldos.TopeCP, //tope de caja principal
            "montoExcedente": obj.Saldos.Excedente, //tope de caja principal
            "numeroBilletes": 0, //numero de billetes total
            "importeTotal": 0.0, //importe de todo lo que el usuario va a traspasar
            "importeMorralla": null //importe que el usuario ha escrito con respecto al importe que se va a pasar de morralla
        };
        topeSucursal=obj.Saldos.TopeCP;
    }
    //procedemos a asignarlos a los campos de entrada
    let dat = datosAnclaje[divisaID].Saldos;
    $('#montoTopeCP').val(formatoDinero(datosAnclaje[divisaID].Saldos.montoTopeCP, divisaID));
    $('#montoSaldoCP').val(formatoDinero(datosAnclaje[divisaID].Saldos.montoSaldoCP, divisaID));
    $('#montoExcedente').val(formatoDinero(datosAnclaje[divisaID].Saldos.montoExcedente, divisaID));
    LlenarTotales(divisaID);
}

function LlenarTotales(divisaID) {
    $('#numeroBilletes').val(datosAnclaje[divisaID].Saldos.numeroBilletes);
    $('#numeroBilletes_in').val(datosAnclaje[divisaID].Saldos.numeroBilletes);

    $('#importeTotal').val(formatoDinero(datosAnclaje[divisaID].Saldos.importeTotal, divisaID));
    $('#importeTotal_in').val(formatoDinero(datosAnclaje[divisaID].Saldos.importeTotal, divisaID));

    if (datosAnclaje[divisaID].Saldos.importeMorralla != null) { //nota:como esto es al inicio, tengo que mostrar luego este importe
        $('.elementoMorralla').show();
        $('#importeMorralla').val(formatoDinero(datosAnclaje[divisaID].Saldos.importeMorralla, divisaID));
        $('#importeMorralla_in').val(datosAnclaje[divisaID].Saldos.importeMorralla, divisaID);
    } else {
        $('.elementoMorralla').hide();
    }
}

//aqui tambien se inicializan los datos de las denominaciones, en el popup solo se imprimen
function LlenarTablaResultados(divisaID) { //este se ejecuta cada vez que cambian la divisa
    let tabla = '<tbody><tr><th>Denominación</th><th>Número de billetes</th><th>Total</th></tr>';
    //define solo los DATOS de las denominaciones si no los tiene
    //no lo separo porque se necesita saber cuantas denominaciones hay para asignar en el arreglo de valores de piezas solicitadas
    if (datosAnclaje[divisaID].Denominaciones == null) {
        //obtener las denominaciones y las piezas disponibles
        let obj = AnclServDenominaciones(divisaID);
        if (obj.NoError != 0) {
            DispararError(obj.Descripcion,'consulta de denominaciones');
            return false;
        }
        datosAnclaje[divisaID].Denominaciones = obj.Denominaciones;
        //asignar los nombres de etiquetas a las denominaciones
        let tagnombre;
        datosAnclaje[divisaID].Saldos.importeMorralla = null;
        for (let i = 0 ; i < datosAnclaje[divisaID].Denominaciones.length ; i++) {
            if (datosAnclaje[divisaID].Denominaciones[i].TipoDenominacion == 0) { //si es la denominacion de morralla
                datosAnclaje[divisaID].Saldos.importeMorralla = 0.0;
                $('.elementoMorralla').show(); //mostrar los elementos de morralla si estaban ocultos
                $('#importeMorralla').val(formatoDinero(0.0, divisaID));
            }
            tagnombre = 'div' + datosAnclaje[divisaID].Denominaciones[i].TipoDivisa + '_' + i;
            Object.defineProperty(datosAnclaje[divisaID].Denominaciones[i], "Etiqueta", { enumerable: true, configurable: true, writable: true, value: tagnombre });
        }
        //asignar a cada una de las divisas sus piezas
        var arrValores = [];
        for (let i = 0 ; i < datosAnclaje[divisaID].Denominaciones.length ; i++) {
            arrValores.push(0); // valor de piezas solicidadas inicial
        }
        datosAnclaje[divisaID].TablaDenominaciones = arrValores;
        $('#botonRegistrar').hide();
    } else { //ya fueron definidas las denominaciones, hay que ver sus valores
        let dat = datosAnclaje[divisaID];
        if (divisaID == "3") { //onzas
            if (dat.TablaDenominaciones[0] != 0) {
                let tagnombre = dat.Denominaciones[0].Etiqueta;
                tabla += '<tr><td>Onzas</td><td>' + dat.TablaDenominaciones[0] + '</td><td>' + formatoDinero(dat.TablaDenominaciones[0], divisaID) + '</td></tr>';
                $('#botonRegistrar').show();
            } else $('#botonRegistrar').hide();
        } else { //otras divisas
            let tagnombre;
            let mostrado = false;
            for (let i = 0 ; i < dat.Denominaciones.length ; i++) {
                if (dat.TipoDenominacion == 0 || dat.TablaDenominaciones[i] == 0) //se brinca le entrada de la morralla o las que tengan cantidad 0
                    continue;
                mostrado = true;
                tagnombre = dat.Etiqueta;
                tabla += '<tr><td>' + dat.Denominaciones[i].TipoDenominacion + '</td><td>' + dat.TablaDenominaciones[i] + '</td><td>' + formatoDinero((dat.TablaDenominaciones[i] * dat.Denominaciones[i].TipoDenominacion),divisaID) + '</td></tr>';
            }
            if (dat.Saldos.importeMorralla != null && dat.Saldos.importeMorralla > 0)
                mostrado = true;
            if(mostrado) $('#botonRegistrar').show();
            else $('#botonRegistrar').hide();
        }
    }
    tabla += '</tbody>';
    $('#tablaResultados').html(tabla);
    LlenarTotales(divisaID);
}

//boton donde se van a mostrar el popup de las denominaciones
function botonDetalle() {
    $('#importeMorralla_in').prop('disabled', true);
    $('#nombreDivisa').html(datosAnclaje[divisaActual].Descripcion);
    LlenarTablaDenominaciones(divisaActual);
    $j('#modalDenom').modal();
}

function LlenarTablaDenominaciones(divisaID) {
    //poner elementos graficos, solo estamos jalando datos
    let dat = datosAnclaje[divisaID];
    let tabla = '<tbody><tr><th>Denominación</th><th>Cantidad</th><th>Importe</th></tr>';
    let tagnombre;
    for (let i = 0 ; i < dat.Denominaciones.length ; i++) {
        if (dat.Denominaciones[i].TipoDenominacion == 0) //se brinca le entrada de la morralla
            continue;
        tagnombre = dat.Denominaciones[i].Etiqueta;
        tabla += '<tr><td>' + dat.Denominaciones[i].TipoDenominacion + '</td>' +
            '<td><b id="tag_' + tagnombre + '" style="display:block">' + dat.TablaDenominaciones[i] + '</b>' +
            '<input id="in_' + tagnombre + '" value="' + dat.TablaDenominaciones[i] + '" onkeypress="return isNumberKey(event)" style="display:none"></td>' +
            '<td>' + formatoDinero((dat.Denominaciones[i].TipoDenominacion * dat.TablaDenominaciones[i]), divisaID) + '</td></tr>';
    }
    tabla += '</tbody>';
    
    $('#tablaDenominaciones').html(tabla);
    LlenarTablaResultados(divisaID);
    AsignarEventosDenominaciones(divisaActual, true);
    $('#importeMorralla_in').prop('disabled', false);
}

function AsignarEventosDenominaciones(divisaID, asignarEvento) {
    //ahora se asigna el comportamiento de las etiquetas, DESPUES de cargar la pagina
    let tagnombre;
    for (let i = 0 ; i < datosAnclaje[divisaID].Denominaciones.length ; i++) {
        tagnombre = datosAnclaje[divisaID].Denominaciones[i].Etiqueta;
        $('#in_' + tagnombre).unbind('focusout keypress');
        $('#tag_' + tagnombre).unbind('click');
        $('#importeMorralla_in').unbind('keypress change click focusout');
        if (asignarEvento) {
            if (datosAnclaje[divisaID].Denominaciones[i].TipoDenominacion == 0) {
                $('#importeMorralla_in').on('click', function (event) {
                    $(this).focus().select();
                });
                $('#importeMorralla_in').on('keypress change', function (event) {
                    if ((event.type == 'keypress' && event.which === 13) || event.type == 'change') {
                        ActualizarTablaDenominaciones(divisaActual);
                        LlenarTablaDenominaciones(divisaActual);
                        $(this).blur();
                    }
                });
                $('#importeMorralla_in').on('focusout', function (event) {
                    ActualizarTablaDenominaciones(divisaActual);
                    LlenarTablaDenominaciones(divisaActual);
                });
            } else {
                $('#in_' + tagnombre).on('focusout keypress', function (event) {
                    if ((event.type == 'keypress' && event.which === 13) || event.type == 'focusout') {
                        let valor = '#' + event.target.id;
                        $(valor).css("display", "none");
                        valor = valor.replace("in", "tag");
                        $(valor).css("display", "block");
                        ActualizarTablaDenominaciones(divisaActual);
                        LlenarTablaDenominaciones(divisaActual, true);
                        if (event.type == 'keypress') {
                            valor = event.target.id;
                            valor = valor.replace("in_div" + divisaActual + "_", "");
                            valor = Number(valor) + 1;
                            //si este elemento de la table es el ultimo
                            let dat = datosAnclaje[divisaActual];
                            if (valor != dat.Denominaciones.length && 
                                (dat.Saldos.importeMorralla == null ||
                                (dat.Saldos.importeMorralla != null && valor != (dat.Denominaciones.length - 1))
                                )) {
                                //brincar al siguiente
                                let el = document.getElementById("tag_div" + divisaActual + "_" + valor);
                                if (el.fireEvent) {
                                    el.fireEvent('onclick');
                                } else {
                                    var evObj = document.createEvent('Events');
                                    evObj.initEvent('click', true, false);
                                    el.dispatchEvent(evObj);
                                }
                            }
                        }
                    }
                });
                $('#tag_' + tagnombre).on('click', function (event) {
                    let valor = '#' + event.target.id;
                    $(valor).css("display", "none");
                    valor = valor.replace("tag", "in");
                    $(valor).css("display", "block");
                    $(valor).focus().select();
                });
            }
            
        }
    }
}

//esta funcion se dispara cuando se actuliza algun valor, y actualiza los totales
function ActualizarTablaDenominaciones(divisaID) {
    var total = 0;
    var totalBilletes = 0;
    let mostrarMensaje = false;
    for (let i = 0 ; i < datosAnclaje[divisaID].Denominaciones.length ; i++) {
        let tagnombre = datosAnclaje[divisaID].Denominaciones[i].Etiqueta; //ETIQUETA DE NUMERO DE PIEZAS
        let valor = Number($('#in_' + tagnombre).val());
        valor = (isNaN(valor) || valor > limitePiezas) ? 0 : valor;
        let suma = (divisaID == "3") ? valor : datosAnclaje[divisaID].Denominaciones[i].TipoDenominacion * valor;
        //alert('denom: ' + datosAnclaje[divisaID].Denominaciones[i].TipoDenominacion + ' suma: ' + (total + suma))
        if ((total + suma) > datosAnclaje[divisaID].Saldos.montoSaldoCP) {
            valor = 0;
            mostrarMensaje = true;
        }
        else total += suma;
        totalBilletes += valor;
        $('#in_' + tagnombre).val(datosAnclaje[divisaID].TablaDenominaciones[i] = valor);
    }
    if (datosAnclaje[divisaID].Saldos.importeMorralla != null) {
        let valor = Number($('#importeMorralla_in').val());
        valor = (isNaN(valor) || valor > limiteMorralla) ? 0.0 : Number(toFixedJ(valor, 2));
        if ((total + valor) > datosAnclaje[divisaID].Saldos.montoSaldoCP){
            valor = 0;
            mostrarMensaje = true;
        }
        else total += valor;
        $('#importeMorralla_in').val(datosAnclaje[divisaID].Saldos.importeMorralla = valor);
    }
    if(mostrarMensaje)
        DispararMensaje('El total para anclar no puede exceder los ' + formatoDinero(datosAnclaje[divisaID].Saldos.montoSaldoCP, divisaID), true);
    datosAnclaje[divisaID].Saldos.importeTotal = total;
    datosAnclaje[divisaID].Saldos.numeroBilletes = totalBilletes;
}

//puede que este metodo tenga una estructura distinta que desanclaje
function RegistrarAnclaje() {
    let dat = datosAnclaje[divisaActual];
    const objDenVacio = {
        "Cantidad": null,
        "TipoDenominacion": null,
        "TipoDivisa": divisaActual
    }

    let objRegistro = {
        "NoEmpleado": empleadoID,
        "NoEmpleadoAuto": empleadosVal,
        "Terminal": cajaNombre,
        "ImporteTotalOperacion": dat.Saldos.importeTotal,
		"TipoDivisa": parseInt(divisaActual),
        "Denominaciones": []
    }

    for (let i = 0 ; i < dat.Denominaciones.length ; i++) {
        let temp = objDenVacio;
        temp.Cantidad = (dat.Denominaciones[i].TipoDenominacion == 0) ?
            dat.Saldos.importeMorralla : temp.Cantidad = dat.TablaDenominaciones[i];
        temp.TipoDenominacion = dat.Denominaciones[i].TipoDenominacion;
        if (temp.Cantidad>0) objRegistro.Denominaciones.push($.extend({}, (temp)));
    }
    //$('#test').html(JSON.stringify(objRegistro));
    var obj = AnclServResgistraAnclaje(objRegistro);    
    if (obj.NoError != 0) {
        DispararError(obj.Descripcion,'registro de anclaje');
        return false;
    }
    let objRecoleccion = {
        "FiDivisa": parseInt(divisaActual),
        "FiPais": idPais,
        "FiCanal": idCanal,
        "FcSucursal": idSucursal,
        "FnTopeSucursal": topeSucursal,
        "Usuario": empleadoID,
    }
    var respRecoleccion = RecoleccionAnclaje(objRecoleccion);
    let msjRecoleccion="";
    if(respRecoleccion.NoError==1) msjRecoleccion="No se pudo generar la recolección automática";
    if(respRecoleccion.NoError==2) msjRecoleccion=respRecoleccion.Descripcion;
    DispararMensaje('Anclaje registrado correctamente.' + "\n" + msjRecoleccion,false, CerrarAnclaje);
}

/////////////////////////////////////Funciones para la ventana y la pagina////////////////////

function botonRegistrar() {
    DispararConfirmacion('¿Desea confirmar la operación de anclaje?', AbrirHuellaOperador, null);
}

//de esta manera se inicializa la autenticación
function AbrirHuellaOperador() {
    validarOperador = true;
    mostrarCarga(true); //
    setTimeout(function () {
        mostrarCarga(false);        
        var json = '{"validarEmp":"' + empleadoID + '","validarAut":"' + empleadoID + '","perfiles":"' + empleadoPuesto + '","tipo":"1","app":"Anclaje","ws":"' + cajaNombre + '","top":"325","afectaHD":true}';
        json = JSON.parse(json);
        AutenticacionHuella(json);
    }, 300);
}

function AbrirHuellaValidar() {
    validarOperador = false;    
    var json = '{"validarEmp":"' + empleadoID + '","validarAut":"' + empleadosVal + 
    '","perfiles":"' + empleadosValPerfs + '","tipo":"1","app":"Anclaje","ws":"' + cajaNombre + '","top":"325","afectaHD":true}';
    json = JSON.parse(json);
    AutenticacionHuella(json);
}

//se necesita definir esta función de esta manera para que la pagina pueda recibir el resultado de la autenticación
function RecibirResultadoHuella(resultado) {
    if (resultado.Status == 0) { //si hubo error
        DispararError(resultado.Descripcion,'autenticación de huella digital');
        return;
    }
    if (validarOperador) {
//        //ahora se obtienen a las personas que deben validar la operacion
//        mostrarCarga(true); //
//        setTimeout(function () {
//            var obj = AnclServObtenerValidadores(empleadoID);
//            if (obj.Estatus != 0) { //si hubo error
//                DispararError(obj.msjError,'obtención de empleados validadores');
//                mostrarCarga(false);
//                return;
//            }
//            empleadosVal = obj.EmpAutorizador;
//            empleadosValPerfs = obj.EmpPerfiles;
//            mostrarCarga(false);
            AbrirHuellaValidar();
//        }, 300);
    } else {
        //ahora se confirma la operacion
        empleadosVal = resultado.Autorizo;
        mostrarCarga(true); //
        setTimeout(function () {
            RegistrarAnclaje();
            mostrarCarga(false);
        }, 200);
    }
}

function DispararError(mensaje,causa) {
    $('#errorTitulo').html('Error de ' + causa + ':');
    $('#errorTexto').html(mensaje);
    $j('#modalError').modal();
    iniciartimerAnclaje(5);
}

function DispararMensaje(mensaje, cerrarVentana, refM) {
    refFuncMensaje = (refM !== undefined) ? refM : null;
    if (cerrarVentana) {
        let el = document.getElementById("cerrarVentanaDenominaciones");
        if (el.fireEvent) {
            el.fireEvent('onclick');
        } else {
            var evObj = document.createEvent('Events');
            evObj.initEvent('click', true, false);
            el.dispatchEvent(evObj);
        }
        setTimeout(function () {
            $('#mensajeTitulo').html('Mensaje del sistema:');
            $('#mensajeTexto').html(mensaje);
            $j('#modalMensaje').modal();
        },100);
    } else {
        $('#mensajeTitulo').html('Mensaje del sistema:');
        $('#mensajeTexto').html(mensaje);
        $j('#modalMensaje').modal();
    }
}

function DispararConfirmacion(mensaje, refA, refC) {
    refFuncAceptar = (refA !== undefined) ? refA : null;
    refFuncCancelar = (refC !== undefined) ? refC : null;
    $('#confTitulo').html('Mensaje del sistema:');
    $('#confTexto').html(mensaje);
    $j('#modalConfirmacion').modal();
}

function botonDiagMensaje() {
    if (refFuncMensaje != null)
        refFuncMensaje();
}

function botonDiagAceptar() {
    if (refFuncAceptar != null)
        refFuncAceptar();
}

function botonDiagCancelar() {
    if (refFuncCancelar != null)
        refFuncCancelar();
}

function CerrarAnclaje() {
    clearInterval(refAncCont);
    try {
        //window.close();
        mostrarCarga(true);
        loadPage();
    } catch (err) {
        alert('La ventana debería cerrarse, Error: ' + err);
    }
}

function iniciartimerAnclaje(tiempoArg) {
    tiempoRestante = tiempoArg;
    timerAnclaje();
    refAncCont = setInterval(function () { timerAnclaje() }, 1000);
}

function timerAnclaje() {
    $("#anclajeTimer").html("Tiempo de espera (" + tiempoRestante + ")");
    if (tiempoRestante > 0) {
        tiempoRestante -= 1;
    }
    else {
        CerrarAnclaje();
    }
}

/////////////////////////////////////Funciones de utilidad///////////////////////////////////////

function getUrlAnclaje(servicio) {
    var url = "";
    if (window.location.hostname == "localhost") {
        url = "http://10.54.28.114:9014/Caja/Servicios/" + servicio;
    } else {
        url = "http://" + window.location.hostname + ":9014/Caja/Servicios/" + servicio;
    }
    return url;
}

Number.prototype.formatMoney = function (c, d, t) {
    var n = this,
        c = isNaN(c = Math.abs(c)) ? 2 : c,
        d = d == undefined ? "." : d,
        t = t == undefined ? "," : t,
        s = n < 0 ? "-" : "",
        i = String(parseInt(n = Math.abs(Number(n) || 0).toFixed(c))),
        j = (j = i.length) > 3 ? j % 3 : 0;
    return s + (j ? i.substr(0, j) + t : "") + i.substr(j).replace(/(\d{3})(?=\d)/g, "$1" + t) + (c ? d + Math.abs(n - i).toFixed(c).slice(2) : "");
};

//imprimir un valor monetario con el formato correcto, dependiendo de la divias
function formatoDinero(numero, divisaID) {
    numero = Number(numero);
    return (divisaID == "3") ? datosAnclaje[divisaID].Simbolo + ' ' + numero : datosAnclaje[divisaID].Simbolo + (numero).formatMoney(2);
}

function isNumberKey(evt) {
    var charCode = (evt.which) ? evt.which : evt.keyCode
    if (charCode > 31 && (charCode < 48 || charCode > 57))
        return false;
    return true;
}

function isNumberDecimalKey(evt) {
    var charCode = (evt.which) ? evt.which : evt.keyCode
    if (charCode > 31 && (charCode < 48 || charCode > 57) && charCode != 46)
        return false;
    return true;
}

function toFixedJ(num, fixed) {
    var re = new RegExp('^-?\\d+(?:\.\\d{0,' + (fixed || -1) + '})?');
    return num.toString().match(re)[0];
}

document.getElementById("textoObservaciones").onkeypress = function (e) {

    if ((e.charCode === 0) || (e.charCode === 32) || (e.charCode > 47 && e.charCode < 58) || (e.charCode > 64 && e.charCode < 91) || (e.charCode > 96 && e.charCode < 123)) {
    } else {
        return false;
    }

    var txtReferencia = document.getElementById("textoObservaciones").value;
    if ((txtReferencia.length >= 24) && (e.charCode != 0))
        return false

};

/////////////////////////////////////Servicios////////////////////////////////////////////////

function AnclServConsultaEmpleado(empleado) {
    var objRespuesta = { NoError: null, Descripcion: null };
    var url = getUrlAnclaje(AnclUrlValidaEmpleado);
    $.ajax({
        url: "" + url,
        contentType: "application/json; charset=UTF-8",
        type: "POST",
        async: false,
        data: JSON.stringify({
            "NoEmpleado": "" + empleado
        }),
        dataType: 'json',
        crossDomain: true,
        success: function (data) {
            objRespuesta = data;
        },
        error: function () {
            objRespuesta.NoError = 1;
            objRespuesta.Descripcion = "Error: No se pudo contactar al servicio de validación de empleado.";
        }
    });
    return objRespuesta;
}

function AnclServConsultaDivisa() {
    var objRespuesta = { NoError: null, Descripcion: null };
    var url = getUrlAnclaje(AnclUrlDivisas);
    $.ajax({
        url: "" + url,
        contentType: "application/json; charset=UTF-8",
        type: "POST",
        async: false,
        dataType: 'json',
        crossDomain: true,
        success: function (data) {
            objRespuesta = data;
        },
        error: function () {
            objRespuesta.NoError = 1;
            objRespuesta.Descripcion = "Error: No se pudo contactar al servicio de consulta de divisas.";
        }
    });
    return objRespuesta;
}

function AnclServDenominaciones(divisaID) {
    var objRespuesta = { NoError: null, Descripcion: null };
    var url = getUrlAnclaje(AnclUrlDenominaciones);
    $.ajax({
        url: "" + url,
        contentType: "application/json; charset=UTF-8",
        type: "POST",
        async: false,
        data: JSON.stringify({
            "TipoDivisa": "" + divisaID
        }),
        dataType: 'json',
        crossDomain: true,
        success: function (data) {
            objRespuesta = data;
        },
        error: function () {
            objRespuesta.NoError = 1;
            objRespuesta.Descripcion = "Error: No se pudo contactar al servicio de consulta de denominaciones.";
        }
    });
    return objRespuesta;
}

function AnclServObtenerValidadores(empleado) {
    var objRespuesta = { Estatus: null, msjError: null };
    var url = getUrlAnclaje(AnclUrlObtieneValidadores);
    $.ajax({
        url: "" + url,
        contentType: "application/json; charset=UTF-8",
        type: "POST",
        async: false,
        data: JSON.stringify({
            "opc": 2,
            "Empleado": "" + empleado
        }),
        dataType: 'json',
        crossDomain: true,
        success: function (data) {
            objRespuesta = data;
        },
        error: function () {
            objRespuesta.Estatus = 1;
            objRespuesta.msjError = "Error: No se pudo contactar al servicio de consulta de validadores de anclaje.";
        }
    });
    return objRespuesta;
}

function AnclServConsultaSaldoInicial(divisaID) {
    var objRespuesta = { NoError: null, Descripcion: null };
    var url = getUrlAnclaje(AnclUrlObtieneSaldoInicial);
    $.ajax({
        url: "" + url,
        contentType: "application/json; charset=UTF-8",
        type: "POST",
        async: false,
        data: JSON.stringify({
            "TipoDivisa": divisaID
        }),
        dataType: 'json',
        crossDomain: true,
        success: function (data) {
            objRespuesta = data;
        },
        error: function () {
            objRespuesta.NoError = 1;
            objRespuesta.Descripcion = "Error: No se pudo contactar al servicio de consulta de saldo inicial.";
        }
    });
    return objRespuesta;
}

function AnclServResgistraAnclaje(objRegistro) {
    var objRespuesta = { NoError: null, Descripcion: null };
    var url = getUrlAnclaje(AnclUrlRegistrarAnclaje);
    $.ajax({
        url: "" + url,
        contentType: "application/json; charset=UTF-8",
        type: "POST",
        async: false,
        data: JSON.stringify(objRegistro),
        dataType: 'json',
        crossDomain: true,
        success: function (data) {
            objRespuesta = data;
        },
        error: function () {
            objRespuesta.NoError = 1;
            objRespuesta.Descripcion = "Error: No se pudo contactar al servicio de registro de anclaje.";
        }
    });
    return objRespuesta;
}

function RecoleccionAnclaje(objRegistro) {
    var objRespuesta = { NoError: null, Descripcion: null };
    var url = getUrlAnclaje(AnclUrlRecoleccionAnclaje);
    $.ajax({
        url: "" + url,
        contentType: "application/json; charset=UTF-8",
        type: "POST",
        async: false,
        data: JSON.stringify(objRegistro),
        dataType: 'json',
        crossDomain: true,
        success: function (data) {
            objRespuesta = data;
        },
        error: function () {
            objRespuesta.NoError = 1;
            objRespuesta.Descripcion = "Error: No se pudo contactar al servicio de recoleccion.";
        }
    });
    return objRespuesta;
}
