﻿if ($j === undefined) { var $j = jQuery.noConflict(true); console.log($().jquery); console.log($j().jquery); }

//const AUrlValidaAcceso = "Arqueo/WsCajaArqueo.svc/wsValidaAccesoArqueo";
const DnclUrlValidaEmpleado = "Comun/WsCajaComun.svc/wsConsultaInformacionInicial";
const DnclUrlDivisas = "Comun/WsCajaComun.svc/wsConsultaDivisa";
const DnclUrlObtieneValidadores = "wsUtileriaCaja/wsUtileria.svc/wsPerfilAutorizador";
//nuevas url
const DnclUrlObtieneSaldoInicial = "DesAnclaje/WSDesAnclaje.svc/wsconsultaSaldosIncial";
const DnclUrlDenominaciones = "DesAnclaje/WSDesAnclaje.svc/wsObtieneDenominacionesPorDivisa";
const DnclUrlRegistrarDesanclaje = "DesAnclaje/WSDesAnclaje.svc/wsAfectacionDeTraspaso";

var empleadoID = null;
var cajaNombre = null;
var empleadoPuesto = null;
var empleadosVal = null;
var empleadosValPerfs = null;

var datosDesanclaje = null;
var indicesDivisas = [];
var divisaActual = null;

var refDncCont = null;
var tiempoRestante = null;
var validarOperador = null;
var pantallaCargada = false;
var refFuncMensaje = null;
var refFuncAceptar = null;
var refFuncCancelar = null;

var opc="1"; 
var idModulo="114"; //Modulo Desanclaje
var idFolio="2";//Consultar Perfiles autorizadores
var usuario="";

//carga datos iniciales
$(document).ready(function () {

    var date = new Date();
    $('#tagHora').html(date.getHours() + ":" + date.getMinutes());
    $('#tagFecha').html((date.getMonth() + 1) + "/" + date.getDate() + "/" + date.getFullYear());

    empleadoID = getUrlVars()["empleado"];
    cajaNombre = getUrlVars()["ws"];
    if (empleadoID === undefined || empleadoID == ""
        || cajaNombre === undefined || cajaNombre == "") {
        DispararError("Los parámetros no son correctos.",'parámetros de la URL');
        return;
    }
    usuario=empleadoID;
    mostrarCarga(true); //
    let result = getPerfilesAutorizador(opc, idModulo, idFolio);//Servicio de perfiles autorizadores;
    if(result && result.Estatus==0){
        empleadosVal=result.EmpAutorizador;
        empleadosValPerfs=result.EmpPerfiles;        
    }else{
        if(result && result.Estatus==1){
            mostrarCarga(false);
            DispararError(result.msjCliente+" para realizar un desanclaje",result.msjCliente);
        }
        return;
    }
    loadPage();
});

function loadPage(){
    setTimeout(function () {
        obj = DnclServConsultaEmpleado(empleadoID);
        if (obj.NoError != 0) {
            DispararError(obj.Descripcion,'consulta de empleado');
            mostrarCarga(false);
            return;
        }
        $('#tagEmpNombre').html(obj.InformacionInicial.NombreEmpleado);
        $('#tagEmpDescripcion').html(obj.InformacionInicial.DescripcionPBase);
        empleadoPuesto = obj.InformacionInicial.PuestoRol;
        $('#tagNumTienda').html(obj.InformacionInicial.NoTienda);
        $('#tagNombreTienda').html(obj.InformacionInicial.NombreTienda);
        $('#tagPais').html(obj.InformacionInicial.DescripcionPais);

        LlenarSelectDivisas(); //aqui se incluye el llenado de tablas inicial
        mostrarCarga(false);

        //declarar comportamiento de elementos estáticos
        $('#selectDivisas').on('change', function () {
            AsignarEventosDenominaciones(divisaActual, false); //desasignar eventos antes de cambiar la divisa actual
            divisaActual = $(this).val().toString();
            LlenarCamposSaldos(divisaActual);
            LlenarTablaDenominaciones(divisaActual, true);
        });
        $('#checkMax').on('change', function () {
            datosDesanclaje[divisaActual].Saldos.checkMax = $(this).prop('checked');
            if (!datosDesanclaje[divisaActual].Saldos.checkMax) { //hay que checar si el importe a traspasar se pasa del maximo
                let dat = datosDesanclaje[divisaActual].Saldos;
                if (dat.importeTraspasar > dat.montoMaxTras) {
                    datosDesanclaje[divisaActual].Saldos.importeTraspasar = 0.0;
                    $('#tag_importeTraspasar').val(formatoDinero(0.0,divisaActual));
                }
            }
        });
        $('#tag_importeTraspasar').on('focus', function () {
            $(this).css('display', 'none');
            let in_ref = $('#in_importeTraspasar');
            in_ref.css('display', 'block');
            in_ref.val(datosDesanclaje[divisaActual].Saldos.importeTraspasar);
            in_ref.focus().select();
        });
        $('#in_importeTraspasar').on('change focusout', function () {
            let dat = datosDesanclaje[divisaActual].Saldos;
            let valor = Number($(this).val());
            //hay que checar que se esté metiendo un importe correcto
            valor = (isNaN(valor) || //metio el numero mal?
                    (!dat.checkMax && (valor > dat.montoMaxTras)) || //esta pasando el maximo (si esta definido)?
                    (valor > dat.montoSaldoBov)) //esta pasando el saldo de la bóveda?
                ? 0.0 : Number(toFixedJ(valor,2));
            datosDesanclaje[divisaActual].Saldos.importeTraspasar = valor;
            $('#tag_importeTraspasar').val(formatoDinero(datosDesanclaje[divisaActual].Saldos.importeTraspasar,divisaActual));
            $('#tag_importeTraspasar').css('display', 'block');
            $(this).css('display', 'none');
        });
    }, 200);
}

/////////////////////////Funciones para rellenar las tablas//////////////////////////////////////////

function LlenarSelectDivisas() { //solo se ejecuta una sola vez, al principio
    //consulta servicio de divisas
    var obj = DnclServConsultaDivisa();
    if (obj.NoError != 0) {
        DispararError(obj.Descripcion,'consulta de divisas');
        return;
    }
    var divisas = obj.Divisas;
    //llenar select grafico
    var opciones = "";
    var strSelected;
    for (let i = 0 ; i < divisas.length ; i++) {
        strSelected = (i == 0) ? "selected" : "";
        opciones += '<option value="' + divisas[i].Id + '" ' + strSelected + '>' + divisas[i].Descripcion + '</option>';
        indicesDivisas.push(divisas[i].Id);
    }
    $('#selectDivisas').html(opciones);
    //inicializar objeto para almacenar datos de las divisas, saldos de desanclaje y piezas disponibles
    datosDesanclaje = {};
    //al acceder a los datos de una divisa, de debe usar un indice que sea STRING, no que sea numerico
    divisaActual = divisas[0].Id.toString();
    for (let i = 0 ; i < divisas.length ; i++) {
        //definir el objeto de divisas con indices que correspondan a su ID del servicio, no a su indice del arreglo
        Object.defineProperty(datosDesanclaje, divisas[i].Id.toString(), { enumerable: true, configurable: true, writable: true, value: divisas[i] });
        //lista de denominaciones y sus cantidades disponibles.
        Object.defineProperty(datosDesanclaje[divisas[i].Id.toString()], "Denominaciones", { enumerable: true, configurable: true, writable: true, value: null });
        //lista de piezas que se van a solicitar a la caja
        Object.defineProperty(datosDesanclaje[divisas[i].Id.toString()], "TablaDenominaciones", { enumerable: true, configurable: true, writable: true, value: null });
        //lista de saldos que se listan en la interfaz
        Object.defineProperty(datosDesanclaje[divisas[i].Id.toString()], "Saldos", { enumerable: true, configurable: true, writable: true, value: null });
    }
    LlenarCamposSaldos(divisaActual); //supongo siempre que campos saldos se va a ejecutar antes de tabla denominaciones
    LlenarTablaDenominaciones(divisaActual, true);
}

function LlenarCamposSaldos(divisaID) {
    if (datosDesanclaje[divisaID].Saldos == null) { //si no se han definido los saldos de esta divisa
        var obj = DnclServConsultaSaldoInicial(divisaID);
        if (obj.NoError != 0) {
            DispararError(obj.Descripcion,'consulta de saldo inicial');
            return false;
        }
        datosDesanclaje[divisaID].Saldos = {
            "montoMaxTras": obj.Saldos.Maximo, //maximo saldo que se puede traspasar
            "montoMinTras": obj.Saldos.Minimo, //minimo saldo que se puede traspasar
            "montoSaldoBov": obj.Saldos.SaldoCA, //total de cuanto dinero hay en la boveda. Supongo que es igual o mayor a lo que hay disponible en billetes
            "montoSaldoCP": obj.Saldos.SaldoCP, //saldo disponible en CP, solo es muestra
            "montoTopeCP": obj.Saldos.TopeCP, //tope de caja principal, solo se muestra
            "importeCaptura": 0.0, //total de todo lo que tiene el usuario disponible con los billetes que ha registrado
            "importeTraspasar": 0.0, //importe que el usuario ha escrito y que quiere traspasar
            "checkMax": false
        };
    }
    //procedemos a asignarlos a los campos de entrada
    $('#montoTopeCP').val(formatoDinero(datosDesanclaje[divisaID].Saldos.montoTopeCP, divisaID));
    $('#montoSaldoCP').val(formatoDinero(datosDesanclaje[divisaID].Saldos.montoSaldoCP, divisaID));
    $('#montoSaldoBov').val(formatoDinero(datosDesanclaje[divisaID].Saldos.montoSaldoBov, divisaID));
    $('#montoMaxTras').val(formatoDinero(datosDesanclaje[divisaID].Saldos.montoMaxTras, divisaID));
    $('#montoMinTras').val(formatoDinero(datosDesanclaje[divisaID].Saldos.montoMinTras, divisaID));
    $('#tag_importeTraspasar').val(formatoDinero(datosDesanclaje[divisaID].Saldos.importeTraspasar, divisaID));
    $('#checkMax').prop('checked',datosDesanclaje[divisaID].Saldos.checkMax);
}

function LlenarTablaDenominaciones(divisaID, llenarValores) { //este se ejecuta cada vez que cambian la divisa

    //define solo los DATOS de las denominaciones si no los tiene
    //no lo separo porque se necesita saber cuantas denominaciones hay para asignar en el arreglo de valores de piezas solicitadas
    if (datosDesanclaje[divisaID].Denominaciones == null) {
        //obtener las denominaciones y las piezas disponibles
        var obj = DnclServDenominaciones(divisaID);
        if (obj.NoError != 0) {
            DispararError(obj.Descripcion,'consulta de denominaciones');
            return false;
        }
        datosDesanclaje[divisaID].Denominaciones = obj.Denominaciones;
        //asignar los nombres de etiquetas a las denominaciones
        var tagnombre;
        for (let i = 0 ; i < datosDesanclaje[divisaID].Denominaciones.length ; i++) {
            tagnombre = 'div' + datosDesanclaje[divisaID].Denominaciones[i].TipoDivisa + '_' + i;
            Object.defineProperty(datosDesanclaje[divisaID].Denominaciones[i], "Etiqueta", { enumerable: true, configurable: true, writable: true, value: tagnombre });
        }
        //asignar a cada una de las divisas sus piezas
        let arrValores = [];
        for (let i = 0 ; i < datosDesanclaje[divisaID].Denominaciones.length ; i++)
            arrValores.push(0); // valor de piezas solicidadas inicial
        datosDesanclaje[divisaID].TablaDenominaciones = arrValores;
    }

    if (llenarValores) {
        //poner elementos graficos, solo estamos jalando datos
        let tabla = '';
        tabla += '<tbody><tr><th>Denominación</th><th>Piezas disponibles</th><th>Piezas solicitadas</th></tr>';
        if (divisaID == "3") { //onzas
            let tagnombre = datosDesanclaje[divisaID].Denominaciones[0].Etiqueta;
            tabla += '<tr><td>Onzas</td><td>' + datosDesanclaje[divisaID].Denominaciones[0].Cantidad + '</td><td><b id="tag_' + tagnombre + '" style="display:block">' + Number(datosDesanclaje[divisaID].TablaDenominaciones[0]) + '</b><input id="in_' + tagnombre + '" value="' + Number(datosDesanclaje[divisaID].TablaDenominaciones[0]) + '" onkeypress="return isNumberKey(event)" style="display:none"></td></tr>';
        } else { //otras divisas
            let tagnombre;
            for (let i = 0 ; i < datosDesanclaje[divisaID].Denominaciones.length ; i++) {
                tagnombre = datosDesanclaje[divisaID].Denominaciones[i].Etiqueta;
                tabla += '<tr><td id="val_' + tagnombre + '">';
                tabla += (datosDesanclaje[divisaID].Denominaciones[i].TipoDenominacion == 0) ? 'Morralla</td>' : Number(datosDesanclaje[divisaID].Denominaciones[i].TipoDenominacion) + '</td>';
                tabla += '<td>' + datosDesanclaje[divisaID].Denominaciones[i].Cantidad + '</td><td><b id="tag_' + tagnombre + '" style="display:block">' + Number(datosDesanclaje[divisaID].TablaDenominaciones[i]) + '</b><input id="in_' + tagnombre + '" value="' + Number(datosDesanclaje[divisaID].TablaDenominaciones[i]);
                tabla += (datosDesanclaje[divisaID].Denominaciones[i].TipoDenominacion != 0) ?
                    '" onkeypress="return isNumberKey(event)" style="display:none"></td></tr>' :
                    '" onkeypress="return isNumberDecimalKey(event)" style="display:none"></td></tr>';
            }
        }
        tabla += '</tbody>';
        $('#tablaSolicita').html(tabla);
        AsignarEventosDenominaciones(divisaActual, true);
        //lenar totales de desanclaje en las tablas
        LlenarTotalesDesanclaje(divisaID);
    }
}

function AsignarEventosDenominaciones(divisaID, asignarEvento) {
    //ahora se asigna el comportamiento de las etiquetas, DESPUES de cargar la pagina
    var tagnombre;
    for (let i = 0 ; i < datosDesanclaje[divisaID].Denominaciones.length ; i++) {
        tagnombre = datosDesanclaje[divisaID].Denominaciones[i].Etiqueta;
        $('#in_' + tagnombre).unbind('focusout keypress');
        $('#tag_' + tagnombre).unbind('click');
        if (asignarEvento) {
            $('#in_' + tagnombre).on('keypress focusout', function (event) {
                if ((event.type == 'keypress' && event.which === 13) || event.type == 'focusout') {
                    let valor = '#' + event.target.id;
                    $(valor).css("display", "none");
                    valor = valor.replace("in", "tag");
                    $(valor).css("display", "block");
                    let lanzoMensaje = ActualizarTablaDenominaciones(divisaActual);
                    LlenarTablaDenominaciones(divisaActual, true);
                    if (event.type == 'keypress') {
                        valor = event.target.id;
                        valor = valor.replace("in_div" + divisaActual + "_", "");
                        valor = Number(valor) + 1;
                        //si este elemento de la table es el ultimo
                        if (valor != datosDesanclaje[divisaActual].Denominaciones.length && !lanzoMensaje) {
                            //brincar al siguiente
                            let el = document.getElementById("tag_div" + divisaActual + "_" + valor);
                            if (el.fireEvent) {
                                el.fireEvent('onclick');
                            } else {
                                var evObj = document.createEvent('Events');
                                evObj.initEvent('click', true, false);
                                el.dispatchEvent(evObj);
                            }
                        }
                    }
                } 
            });
            $('#tag_' + tagnombre).on('click', function (event) {
                let valor = '#' + event.target.id;
                $(valor).css("display", "none");
                valor = valor.replace("tag", "in");
                $(valor).css("display", "block");
                $(valor).focus().select();
            });
        }
    }
}

//esta funcion se dispara cuando se actuliza algun valor, y actualiza los totales
function ActualizarTablaDenominaciones(divisaID) {
    let lanzoMensaje = false;
    var total = 0;
    for (let i = 0 ; i < datosDesanclaje[divisaID].Denominaciones.length ; i++) {
        let tagnombre = datosDesanclaje[divisaID].Denominaciones[i].Etiqueta; //ETIQUETA DE NUMERO DE PIEZAS
        let valor = Number($('#in_' + tagnombre).val());
        if (!isNaN(valor) && valor > datosDesanclaje[divisaID].Denominaciones[i].Cantidad) {
            if (datosDesanclaje[divisaID].Denominaciones[i].TipoDenominacion != 0)
                DispararMensaje('No hay suficientes piezas de ' + formatoDinero(datosDesanclaje[divisaID].Denominaciones[i].TipoDenominacion, divisaID));
            else
                DispararMensaje('No hay suficientes piezas de la morralla.');
            lanzoMensaje = true;
        }
        valor = (isNaN(valor) || valor > datosDesanclaje[divisaID].Denominaciones[i].Cantidad) ? 0 : 
            ((datosDesanclaje[divisaID].Denominaciones[i].TipoDenominacion == 0) ? Number(toFixedJ(valor,2)) : valor);
        total += (datosDesanclaje[divisaID].Denominaciones[i].TipoDenominacion == 0) ? valor : datosDesanclaje[divisaID].Denominaciones[i].TipoDenominacion * valor;
        $('#in_' + tagnombre).val(datosDesanclaje[divisaID].TablaDenominaciones[i] = valor);
    }
    datosDesanclaje[divisaID].Saldos.importeCaptura = total;
    return lanzoMensaje;
}

//este metodo es para llenar el total de arqueo del objeto actual y llena la tabla de informes 
//se debe mandar a llamar DESPUES de actualizar correctamente a los valores de la tabla
function LlenarTotalesDesanclaje(divisaID) {
    $('#importeCaptura').html(formatoDinero(datosDesanclaje[divisaID].Saldos.importeCaptura, divisaID));
}

function VerificarSaldos(divisaID) {
    //primero revisar que el desanclaje no tenga algun saldo que no corresponda
    var ref = datosDesanclaje[divisaID];
    let errmsg = 'Error en la divisa: ' + datosDesanclaje[divisaID].DescripcionCorta + '<br>';
    //el importe de captura es 0?
    if (ref.Saldos.importeCaptura == 0) {
        DispararMensaje(errmsg + 'No se capturó ninguna pieza para desanclar.');
        return;
    }
    //el importe a traspasar corresponde con el importe capturado?
    if (ref.Saldos.importeTraspasar != ref.Saldos.importeCaptura) {
        DispararMensaje(errmsg + 'El importe a traspasar y el importe capturado no coinciden.');
        return;
    } //son iguales
    //supera al minimo a traspasar?
    if (ref.Saldos.importeCaptura < ref.Saldos.montoMinTras) {
        DispararMensaje(errmsg + 'El importe a traspasar es menor al mínimo monto permitido.');
        return;
    } //el maximo no lo revisa porque eso ya está limitado por la interfaz
    //termina de revisar
    DispararConfirmacion('Los datos de entrada de ' + datosDesanclaje[divisaID].DescripcionCorta + ' han sido verificados.<br>¿Desea confirmar la operación de desanclaje en esta divisa?', AbrirHuellaOperador, null);
}

function RegistrarDesanclaje(){
    let dat = datosDesanclaje[divisaActual];
    const objDenVacio = {
        "Cantidad": null,
        "TipoDenominacion": null,
        "TipoDivisa": divisaActual
    }

    let objRegistro = {
        "NoEmpleado": empleadoID,
        "NoEmpleadoAuto": empleadosVal,
        "Terminal": cajaNombre,
        "ImporteTotalOperacion": dat.Saldos.importeCaptura,
		"TipoDivisa": parseInt(divisaActual),
        "Denominaciones": []
    }

    for (let i = 0 ; i < dat.Denominaciones.length ; i++) {
        let temp = objDenVacio;
        temp.Cantidad = dat.TablaDenominaciones[i];
        temp.TipoDenominacion = dat.Denominaciones[i].TipoDenominacion;
        if (temp.Cantidad>0) objRegistro.Denominaciones.push($.extend({}, (temp)));
    }
    var obj = DnclServResgistraDesanclaje(objRegistro);
    if (obj.NoError != 0) {
        DispararError(obj.Descripcion,'registro de desanclaje');
        return false;
    }
    DispararMensaje('Desanclaje registrado correctamente.', CerrarDesanclaje);
}

/////////////////////////////////////Funciones para la ventana y la pagina////////////////////

function botonRegistrar() {
    VerificarSaldos(divisaActual);
}

//de esta manera se inicializa la autenticación
function AbrirHuellaOperador() {
    validarOperador = true;
    mostrarCarga(true); //
    setTimeout(function () {
        mostrarCarga(false);
        var json = '{"validarEmp":"' + empleadoID + '","validarAut":"' + empleadoID + '","perfiles":"' + empleadoPuesto + '","tipo":"1","app":"Desanclaje","ws":"' + cajaNombre + '","top":"186","afectaHD":true}';
        json = JSON.parse(json);
        AutenticacionHuella(json);
    }, 300);
}

function AbrirHuellaValidar() {
    validarOperador = false;
    var json = '{"validarEmp":"' + empleadoID + '","validarAut":"' + empleadosVal + '","perfiles":"' + empleadosValPerfs + '","tipo":"1","app":"Desanclaje","ws":"' + cajaNombre + '","top":"186","afectaHD":true}';
    json = JSON.parse(json);
    AutenticacionHuella(json);
}

//se necesita definir esta función de esta manera para que la pagina pueda recibir el resultado de la autenticación
function RecibirResultadoHuella(resultado) {
    if (resultado.Status == 0) { //si hubo error
        DispararError(resultado.Descripcion,'autenticación de huella digital');
        return;
    }
    if (validarOperador) {
        //ahora se obtienen a las personas que deben validar la operacion
//        mostrarCarga(true); //
//        setTimeout(function () {
//            var obj = DnclServObtenerValidadores(empleadoID);
//            if (obj.Estatus != 0) { //si hubo error
//                DispararError(obj.msjError,'obtención de empleados validadores');
//                mostrarCarga(false);
//                return;
//            }
//            empleadosVal = obj.EmpAutorizador;
//            empleadosValPerfs = obj.EmpPerfiles;
//            mostrarCarga(false);
            AbrirHuellaValidar();
//        }, 200);
    } else {
        //ahora se confirma la operacion
        empleadosVal = resultado.Autorizo;
        mostrarCarga(true); //
        setTimeout(function () {
            
            RegistrarDesanclaje();
            mostrarCarga(false);
        }, 200);
    }
}

function DispararError(mensaje,causa) {
    $('#errorTitulo').html('Error de ' + causa + ':');
    $('#errorTexto').html(mensaje);
    $j('#modalError').modal();
    iniciarTimerDesanclaje(5);
}

function DispararMensaje(mensaje,refM) {
    refFuncMensaje = (refM !== undefined) ? refM : null;
    $('#mensajeTitulo').html('Mensaje del sistema:');
    $('#mensajeTexto').html(mensaje);
    $j('#modalMensaje').modal();
}

function DispararConfirmacion(mensaje, refA, refC) {
    refFuncAceptar = (refA !== undefined) ? refA : null;
    refFuncCancelar = (refC !== undefined) ? refC : null;
    $('#confTitulo').html('Mensaje del sistema:');
    $('#confTexto').html(mensaje);
    $j('#modalConfirmacion').modal();
}

function botonDiagMensaje() {
    if (refFuncMensaje != null)
        refFuncMensaje();
}

function botonDiagAceptar() {
    if (refFuncAceptar != null)
        refFuncAceptar();
}

function botonDiagCancelar() {
    if (refFuncCancelar != null)
        refFuncCancelar();
}

function CerrarDesanclaje() {
    clearInterval(refDncCont);
    try {
        //window.close();
        mostrarCarga(true);
        loadPage();
    } catch (err) {
        alert('La ventana debería cerrarse, Error: ' + err);
    }
}

function iniciarTimerDesanclaje(tiempoArg) {
    tiempoRestante = tiempoArg;
    timerDesanclaje();
    refDncCont = setInterval(function () { timerDesanclaje() }, 1000);
}

function timerDesanclaje() {
    $("#desanclajeTimer").html("Tiempo de espera (" + tiempoRestante + ")");
    if (tiempoRestante > 0) {
        tiempoRestante -= 1;
    }
    else {
        CerrarDesanclaje();
    }
}

/////////////////////////////////////Funciones de utilidad///////////////////////////////////////

function getUrlDesanclaje(servicio) {
    var url = "";
    if (window.location.hostname == "localhost") {
        url = "http://10.54.28.114:9014/Caja/Servicios/" + servicio;
    } else {
        url = "http://" + window.location.hostname + ":9014/Caja/Servicios/" + servicio;
    }
    return url;
}

Number.prototype.formatMoney = function (c, d, t) {
    var n = this,
        c = isNaN(c = Math.abs(c)) ? 2 : c,
        d = d == undefined ? "." : d,
        t = t == undefined ? "," : t,
        s = n < 0 ? "-" : "",
        i = String(parseInt(n = Math.abs(Number(n) || 0).toFixed(c))),
        j = (j = i.length) > 3 ? j % 3 : 0;
    return s + (j ? i.substr(0, j) + t : "") + i.substr(j).replace(/(\d{3})(?=\d)/g, "$1" + t) + (c ? d + Math.abs(n - i).toFixed(c).slice(2) : "");
};

//imprimir un valor monetario con el formato correcto, dependiendo de la divias
function formatoDinero(numero, divisaID) {
    numero = Number(numero);
    return (divisaID == "3") ? datosDesanclaje[divisaID].Simbolo + ' ' + numero : datosDesanclaje[divisaID].Simbolo + (numero).formatMoney(2);
}

function isNumberKey(evt) {
    var charCode = (evt.which) ? evt.which : evt.keyCode
    if (charCode > 31 && (charCode < 48 || charCode > 57))
        return false;
    return true;
}

function isNumberDecimalKey(evt) {
    var charCode = (evt.which) ? evt.which : evt.keyCode
    if (charCode > 31 && (charCode < 48 || charCode > 57) && charCode != 46)
        return false;
    return true;
}

function toFixedJ(num, fixed) {
    var re = new RegExp('^-?\\d+(?:\.\\d{0,' + (fixed || -1) + '})?');
    return num.toString().match(re)[0];
}

/////////////////////////////////////Servicios////////////////////////////////////////////////

function DnclServConsultaEmpleado(empleado) {
    var objRespuesta = { NoError: null, Descripcion: null };
    var url = getUrlDesanclaje(DnclUrlValidaEmpleado);
    $.ajax({
        url: "" + url,
        contentType: "application/json; charset=UTF-8",
        type: "POST",
        async: false,
        data: JSON.stringify({
            "NoEmpleado": "" + empleado
        }),
        dataType: 'json',
        crossDomain: true,
        success: function (data) {
            objRespuesta = data;
        },
        error: function () {
            objRespuesta.NoError = 1;
            objRespuesta.Descripcion = "Error: No se pudo contactar al servicio de validación de empleado.";
        }
    });
    return objRespuesta;
}

function DnclServConsultaDivisa() {
    var objRespuesta = { NoError: null, Descripcion: null };
    var url = getUrlDesanclaje(DnclUrlDivisas);
    $.ajax({
        url: "" + url,
        contentType: "application/json; charset=UTF-8",
        type: "POST",
        async: false,
        dataType: 'json',
        crossDomain: true,
        success: function (data) {
            objRespuesta = data;
        },
        error: function () {
            objRespuesta.NoError = 1;
            objRespuesta.Descripcion = "Error: No se pudo contactar al servicio de consulta de divisas.";
        }
    });
    return objRespuesta;
}

function DnclServDenominaciones(divisaID) {
    var objRespuesta = { NoError: null, Descripcion: null };
    var url = getUrlDesanclaje(DnclUrlDenominaciones);
    $.ajax({
        url: "" + url,
        contentType: "application/json; charset=UTF-8",
        type: "POST",
        async: false,
        data: JSON.stringify({
            "TipoDivisa": "" + divisaID
        }),
        dataType: 'json',
        crossDomain: true,
        success: function (data) {
            objRespuesta = data;
        },
        error: function () {
            objRespuesta.NoError = 1;
            objRespuesta.Descripcion = "Error: No se pudo contactar al servicio de consulta de denominaciones.";
        }
    });
    return objRespuesta;
}

function DnclServObtenerValidadores(empleado) {
    var objRespuesta = { Estatus: null, msjError: null };
    var url = getUrlDesanclaje(DnclUrlObtieneValidadores);
    $.ajax({
        url: "" + url,
        contentType: "application/json; charset=UTF-8",
        type: "POST",
        async: false,
        data: JSON.stringify({
            "opc": 2,
            "Empleado": "" + empleado
        }),
        dataType: 'json',
        crossDomain: true,
        success: function (data) {
            objRespuesta = data;
        },
        error: function () {
            objRespuesta.Estatus = 1;
            objRespuesta.msjError = "Error: No se pudo contactar al servicio de consulta de validadores de anclaje.";
        }
    });
    return objRespuesta;
}

function DnclServConsultaSaldoInicial(divisaID) {
    var objRespuesta = { NoError: null, Descripcion: null };
    var url = getUrlDesanclaje(DnclUrlObtieneSaldoInicial);
    $.ajax({
        url: "" + url,
        contentType: "application/json; charset=UTF-8",
        type: "POST",
        async: false,
        data: JSON.stringify({
            "TipoDivisa": divisaID
        }),
        dataType: 'json',
        crossDomain: true,
        success: function (data) {
            objRespuesta = data;
        },
        error: function () {
            objRespuesta.NoError = 1;
            objRespuesta.Descripcion = "Error: No se pudo contactar al servicio de consulta de saldo inicial.";
        }
    });
    return objRespuesta;
}

function DnclServResgistraDesanclaje(objRegistro) {
    var objRespuesta = { NoError: null, Descripcion: null };
    var url = getUrlDesanclaje(DnclUrlRegistrarDesanclaje);

    $.ajax({
        url: "" + url,
        contentType: "application/json; charset=UTF-8",
        type: "POST",
        async: false,
        data: JSON.stringify(objRegistro),
        dataType: 'json',
        crossDomain: true,
        success: function (data) {
            objRespuesta = data;
        },
        error: function () {
            objRespuesta.NoError = 1;
            objRespuesta.Descripcion = "Error: No se pudo contactar al servicio de registro de desanclaje.";
        }
    });
    return objRespuesta;
}