﻿var divisa = "";
var desc_divisa = "";
var idComponente_divisa = "";
var divisa_symbol = "";
var divisasArray = [];
var divisa_descorta = "";
var divisa_tipo = "";

function cargaInicial() {
    setTimeout(function () {
        //carga header y footer
        $("#contHeader").load("../../Fronts/includes/header.html");
        $("#contFooter").load("../../Fronts/includes/footer.html");
        setTimeout(function () {
            getTimeSystem();
            getDateSystem();
            serviceTiendaEmpleado();
        }, 1500);
        //mostrarCarga(false);
        //mostrarCarga(true);                            
    }, 500);
}


function mostrarCarga(mostrar) {
    if (mostrar && !pantallaCargada) {
        pantallaCargada = true;
        $.LoadingOverlay("show");
    } else if (!mostrar && pantallaCargada) {
        pantallaCargada = false;
        $.LoadingOverlay("hide");
    }
}

//Obtiene hora actual y lo pone en la etiqueta timesis
function getTimeSystem() {
    var date = new Date();
    var hora = date.getHours();
    var min = date.getMinutes();
    var horaSis = hora + ":" + min;
    $("#timeSis").text(horaSis + "Hrs | CDMX");
}

//Obtiene hora actual y lo pone en la etiqueta fechasis
function getDateSystem() {
    var date = new Date();
    var mes = date.getMonth() + 1;
    var dia = date.getDate();
    var anio = date.getFullYear();

    var diaAct = (dia < 10) ? '0' + dia : dia;
    var mesAct = (mes < 10) ? '0' + mes : mes;

    var fechaSis = diaAct + "/" + mesAct + "/" + anio;

    $("#fechaSis").text(fechaSis);
}

function getUrlVars() {
    var vars = [], hash;
    var limite = window.location.href.indexOf('#');
    if (limite === -1)
        var hashes = window.location.href.slice(window.location.href.indexOf('?') + 1).split('&');
    else
        var hashes = window.location.href.slice(window.location.href.indexOf('?') + 1, limite).split('&');
    for (var i = 0; i < hashes.length; i++) {
        hash = hashes[i].split('=');
        vars.push(hash[0]);
        vars[hash[0]] = hash[1];
    }
    return vars;
}

//Obtiene un parametro de la url - Yadira JH
function getParamUrl(name) {
    let url = new URL(window.location.href);
    let param = url.searchParams.get(name);
    return param;
}

//Llena combo de divisas  - Yadira H
function serviceLecturaDivisa(divisas, idComponente) {
    if (divisas.length > 0) {
        divisa = divisas[0].Id;
        desc_divisa = divisas[0].Descripcion;
        divisa_symbol = divisas[0].Simbolo;
        divisa_descorta = divisas[0].DescripcionCorta;
        divisa_tipo = divisas[0].Leyenda.split("|")[1];
        divisasArray = divisas;
    }
    idComponente_divisa = idComponente;
    var $secondChoice = $("#" + idComponente);
    $secondChoice.empty();
    $.each(divisas, function (index, value) {
        $secondChoice.append('<option value="' + value.Id + '">' + value.Descripcion + '</option>');
    });
    mostrarCarga(false);
}

//OnChange de divisas - Yadira JH
function onchangeDivisas() {
    let id = $('#' + idComponente_divisa + ' option:selected').val();
    let index = divisasArray.findIndex(function (o) {
        return o.Id === Number(id);
    });
    divisa = divisasArray[index].Id;
    desc_divisa = divisasArray[index].Descripcion;
    divisa_symbol = divisasArray[index].Simbolo;
    divisa_descorta = divisasArray[index].DescripcionCorta;
    divisa_tipo = divisasArray[index].Leyenda.split("|")[1];
    mostrarCarga(true);
}

//Da formato de dinero a una cadena, regresa un number - Yadira JH
function formatMoney(num) {
    var p = Number(num).toFixed(2).split(".");
    return divisa_symbol + p[0].split("").reverse().reduce(function (acc, num, i, orig) {
        return num == "-" ? acc : num + (i && !(i % 3) ? "," : "") + acc;
    }, "") + "." + p[1];
}

//quita formato de dinero a una cadena, regresa un string - Yadira JH
function deleteFormatMoney(str) {
    let res = str.toString().split(divisa_symbol).join("");
    res = res.split(",").join("");
    return res;
}

//Muestra mensaje de error o exito - Yadira JH
//Recibe el tipo de mensaje (0=Exito, 1=Error) y el mensaje 
//Debe haber una etiqueta con el nombre = lblMensaje
//Debe de incluirse estilos.css
function showMesagge(tipo, mensaje) {
    $('#lblMensaje').removeClass('lblError');
    $('#lblMensaje').removeClass('lblExito');
    switch (tipo) {
        case 1:
            $('#lblMensaje').addClass('lblError');
            break;
        case 0:
            $('#lblMensaje').addClass('lblExito');
            break;
    }
    $('#lblMensaje').html(mensaje);
}

function getFecha() {
    let d = new Date();
    let fecha = ("00" + (d.getMonth() + 1)).slice(-2) + "/" + ("00" + d.getDate()).slice(-2) + "/" + d.getFullYear() + " " + ("00" + d.getHours()).slice(-2) + ":" + ("00" + d.getMinutes()).slice(-2) + ":" + ("00" + d.getSeconds()).slice(-2);
    return fecha;
}

function getParamUrl(name) {
    let url = new URL(window.location.href);
    let param = url.searchParams.get(name);
    return param;
}

function getUrl(servicio) {
    var url = "";
    if (window.location.hostname == "localhost") {
        url = "http://10.54.28.226:9014/Caja/" + servicio;
    } else {
        url = "http://" + window.location.hostname + ":9014/Caja/" + servicio;
    }
    return url;
}

function AutenticacionEstructuraJson(empleados, ...coordenadas) {
    var objetoEntrada = '';
    if (empleados == null || empleados == "")
        return false;

    if (!(coordenadas.length == 2 || coordenadas.length == 0))
        return false;

    if (empleados.length == 6) {
        objetoEntrada = '{ "employee": { "numberEmployee": "' + empleados + '" }, "settings": { "numberAttempts": 3';
    } else if (empleados.length > 6) {
        objetoEntrada = '{"collection":[';
        var bEmpleados = empleados.split("|");
        for (var i in bEmpleados) {
            objetoEntrada += '"' + bEmpleados[i] + '",';
        }
        var tam = objetoEntrada.length;
        objetoEntrada = objetoEntrada.substring(0, tam - 1);
        alert(objetoEntrada);
        objetoEntrada += '],"settings":{"numberAttempts": 3';
    } else {
        return false;
    }

    if (coordenadas.length == 2) //si se definieron coordenadas
        objetoEntrada += ',"location": [ ' + coordenadas[0] + ',' + coordenadas[1] + ' ]';
    objetoEntrada += '}}';
    return objetoEntrada;
}

function invocacionHuella(empleadoHuella) {
    var msg = null;
    var idFlagHuella = null;
    try {
        //msg = CJSGlobalObject.JSCallEnviaMensaje('standard',empleadoHuella);
        msg = '{"PluginResponse":{"authenticated":1,"coincidence":"","processDetail":"con conincidencia"},"lssue":{"statusControl":false,"detail":{"typeError":0,"codeError":5,"message":""}}}';
        idFlagHuella = JSON.parse(msg);
        alert(JSON.stringify(idFlagHuella));
        autorizarHuella(idFlagHuella);
    } catch (err) {
        msg = err.message;
    }
}

function autorizarHuella(idFlagHuella) {
    var codigoError = idFlagHuella.PluginResponse.authenticated;
    if (codigoError === 1) {
        mostrarCarga(true);
        setTimeout(function () {
            serviceAfectaCajaFondeo();
        }, 500);

    } else {
        alert();
    }
}

function cerrarControl() {
    //val = window.opener.document.getElementById("status").innerHTML = '{"status": "1". "msj": "Exito". "atr1": "Resp1", "atr2": "Resp2", "atr3": "Resp3"}';
    try {
        $('#content').hide();
        e = document.getElementById("overlay");
        if (!(e === null || e === undefined || e === "")) {
            $("#overlay").show();
         
        }
        window.close();
    } catch (err) {
        msg = err.message;
    }
}

function cerrarControlFlotillas() {
    //val = window.opener.document.getElementById("status").innerHTML = '{"status": "1". "msj": "Exito". "atr1": "Resp1", "atr2": "Resp2", "atr3": "Resp3"}';
    try {
        //$('#content').hide();
        e = document.getElementById("overlay");
        if (!(e === null || e === undefined || e === "")) {
            $("#overlay").show();
        }
        window.close();
    } catch (err) {
        msg = err.message;
    }
}

function disableElements(el) {
    for (var i = 0; i < el.length; i++) {
        el[i].disabled = true;
        el[i].style.opacity = "0.1";
        if (el[i].tagName.toLowerCase() == "a")
            el[i].style.display = 'none';
        disableElements(el[i].children);
    }
}

function enableElements(el) {
    for (var i = 0; i < el.length; i++) {
        el[i].disabled = false;
        el[i].style.opacity = "1";
        if (el[i].tagName.toLowerCase() == "a")
            el[i].style.display = 'block';
        enableElements(el[i].children);
    }
}

function getElementInsideContainer(containerID, childID) {
    var elm = document.getElementById(childID);
    var parent = elm ? elm.parentNode : {};
    return (parent.id && parent.id === containerID) ? elm : {};
}

function guardaVariableSesion(key, value) {
    sessionStorage.setItem(key, JSON.stringify(value));
}

function obtenVariableSesion(key) {
    return JSON.parse(sessionStorage.getItem(key));
}

function eliminaVariableSesion(key) {
    sessionStorage.removeItem(key)
}


var timeStampErroresCommons;
var sesionRandomId = "";
var modalContent;
var keyIsDown;
var loadingOverLayShowed
$(document).ready(function () {
    let e = document.getElementById("modal00");
    if (e === null || e === undefined || e === "") {
        $("body").append('<div id="modal00" class="modal"> </div>');
    }
    e = document.getElementById("whiteOverlay");
    if (e === null || e === undefined || e === "") {
        $("body").append('<div id="whiteOverlay"></div>');
        $("<style type='text/css'> #whiteOverlay { background-color: rgba(255,255,255, 1); z-index: 999; position: absolute; left: 0; top: 0; width: 100%; height: 100%; display: none;} </style>").appendTo("head");
    }
    e = document.getElementById("transparentOverlay");
    if (e === null || e === undefined || e === "") {
        $("body").append('<div id="transparentOverlay"></div>');
        $("<style type='text/css'> #transparentOverlay { background-color: rgba(255,255,255, 0.5); z-index: 999; position: absolute; left: 0; top: 0; width: 100%; height: 100%; display: none;} </style>").appendTo("head");
    }
});

function MesLetra(mes) {
    var mesLetra = "";
    switch (mes) {
        case 1:
            mesLetra = "Ene";
            break;
        case 2:
            mesLetra = "Feb";
            break;
        case 3:
            mesLetra = "Mar";
            break;
        case 4:
            mesLetra = "Abr";
            break;
        case 5:
            mesLetra = "May";
            break;
        case 6:
            mesLetra = "Jun";
            break;
        case 7:
            mesLetra = "Jul";
            break;
        case 8:
            mesLetra = "Ago";
            break;
        case 9:
            mesLetra = "Sep";
            break;
        case 10:
            mesLetra = "Oct";
            break;
        case 11:
            mesLetra = "Nov";
            break;
        case 12:
            mesLetra = "Dic";
            break;
    }
    return mesLetra;
}
function ocultarElementosPantalla() {
    $('#whiteOverlay').show();
}

function mostrarElementosPantalla() {
    $('#whiteOverlay').hide();
}

function deshabilitarPantalla() {
    $('#transparentOverlay').show();
}

function habilitarPantalla() {
    $('#transparentOverlay').hide();
}
function getStampId(sesion) {
    if (!isDefined(sesion)) {
        if (sesionRandomId === "")
            sesionRandomId = (Math.floor(10000 + Math.random() * 90000)).toString()
        sesion = sesionRandomId;
    }
    let timeStamp = Date.now();
    let stamp = "";
    stamp = sesion + "#" + timeStamp;
    return stamp;
}
function getDateDDMMYYYY() {
    var d = new Date();
    var dia = "" + d.getDate();
    var pad = "00";
    var diaProcesado = pad.substring(0, pad.length - dia.length) + dia;

    var mes = "" +(d.getMonth()+1);
    var pad = "00";
    var mesProcesado = pad.substring(0, pad.length - mes.length) + mes;

    var anio = "" + d.getFullYear();

    var fecha = diaProcesado + "/" + mesProcesado + "/" + anio
    return fecha;
}
    function getHourHHmm() {
    var d = new Date();
    var horas = "" + d.getHours();
    var pad = "00";
    var horasProcesado = pad.substring(0, pad.length - horas.length) + horas;

    var minutos = "" + d.getMinutes();
    var pad = "00";
    var minutosProcesado = pad.substring(0, pad.length - minutos.length) + minutos;

    var segundos = "" + d.getSeconds();
    var pad = "00";
    var segundosProcesado = pad.substring(0, pad.length - segundos.length) + segundos;


    var tiempo = horasProcesado + ":" + minutosProcesado + ":" + segundosProcesado;
    return tiempo;
}


/**////////////////////////////////////////////////////////////////////////////////////////////////////////////**/   
/**///Esta funcionalidad es para que los excepciones puedan ser convertidas a string mediante JSON.stringify  /**/
/**/if (!('toJSON' in Error.prototype))                                                                       /**/
/**/Object.defineProperty(Error.prototype, 'toJSON', {                                                        /**/
/**/    value: function () {                                                                                  /**/
/**/        var alt = {};                                                                                     /**/
/**/        Object.getOwnPropertyNames(this).forEach(function (key) {                                         /**/
/**/            alt[key] = this[key];                                                                         /**/
/**/        }, this);                                                                                         /**/
/**/        return alt;                                                                                       /**/
/**/    },                                                                                                    /**/
/**/    configurable: true,                                                                                   /**/
/**/    writable: true                                                                                        /**/
/**/});                                                                                                       /**/
/**////////////////////////////////////////////////////////////////////////////////////////////////////////////**/
