/*
* @Author: jagonzalezu
* @Date:   2018-02-10 20:07:40
* @Last Modified by:   jagonzalezu
* @Last Modified time: 2018-02-14 16:45:16
*/
function isDefined(obj) {
    if (obj === undefined || obj === null) {
        return false;
    }
    else {
        return true
    }
}

//Modo de uso: eventFire(document.getElementById('mytest1'), 'click');
function eventFire(el, etype){
  if (el.fireEvent) {
    el.fireEvent('on' + etype);
  } else {
    var evObj = document.createEvent('Events');
    evObj.initEvent(etype, true, false);
    el.dispatchEvent(evObj);
  }
}

var FuncionesCommons = {
    mostrarModal: function mostrarModal(tipo) {
        html = ManejadorMsgCommons.getContent(tipo);
        muestraModal(html);
    }    
};
