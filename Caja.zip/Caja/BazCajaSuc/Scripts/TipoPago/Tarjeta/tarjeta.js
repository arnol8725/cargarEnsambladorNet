﻿/*
* @Author: jagonzalezu
* @Date:   2017-10-31 09:01:37
* @Last Modified by:   jagonzalezu
* @Last Modified time: 2018-02-22 12:20:24
*/
var identificacionSeleccionada; //Opcion de identificacion <- esto es para facilitar el flujo
var folioIdentificacion; //Folio de la identificacion a  usar <- esto es para facilitar el flujo
var importeVentaTarjeta; //Cnatidad de dinero que se esta manejando para la transaccion de tarjeta
var timeStampErroresTarjeta; //Variable para los codigos de errores de la funcionalidad de tarjetas
var esConFirmaElectronica; //Variable para conocer si la tarjeta tiene firma electronica
var puedeValidarLlaves;

function eventValidaImporteTBan(event) {
    try
    {
        if(document.getElementById("txtfolioIdentificacion").value =="")
        {
            document.getElementById("txtTban").value = "";
            disableElements($('#txtTban'))
            event.preventDefault();
        }
        var keyCode;
        var objeto;
        
        if (!event) {
            event = window.event;
            keyCode = event.keyCode;
        }
        else { 
            keyCode = event.which;
        }
        objeto = document.getElementById("txtTban");        
        if (keyCode == 13) {
            objeto.value = objeto.value.replace("$","");
            if(!(!!objeto.value.match(/(?=.)^(([1-9][0-9]{0,2}(,[0-9]{3})*)|[0-9]+)?(\.[0-9]{1,2})?$/)))
            {
                timeStampErroresTarjeta = Commons.getStampId(datosOperacion.wS);      
                registraHistorial("El usuario ha intentado ingresar un valor de importe invalido; "+JSON.stringify(objeto.value, null, 4),timeStampErroresTarjeta,2);                                                            
                avisaError("El importe ingresado es incorrecto realice la corrección pertinente e intente de nuevo. </br> Valor incorrecto ingresado: "+objeto.value);
                document.getElementById("txtTban").value = "";
                document.getElementById("txtTban").focus();            
                return;
            }
            guardaVariableSesion('respuestaConfirmacion',"");
            var parametros = {
                controlador: obtenControladorSesion(), //string        
                importe: objeto.value//string
            };
            validaImporteTban(parametros).done(function (respuesta) {
                try
                {
                    timeStampErroresTarjeta = Commons.getStampId(datosOperacion.wS);      
                    if (!isDefined(respuesta)) {
                        registraHistorial("El servicio de validaImporteTban no ha respondido, respuesta = "+JSON.stringify(respuesta, null, 4),timeStampErroresTarjeta,3);                                                
                        avisaError("No se ha obtenido respuesta del servicio de validación´de importe. </br>[Código de seguimiento:"+timeStampErroresTarjeta+"]");
                        return;
                    }
                    if (!isDefined(respuesta.RespuestaString)) {
                        registraHistorial("El servicio de validaImporteTban no ha respondido correctamente, respuesta = "+JSON.stringify(respuesta, null, 4),timeStampErroresTarjeta,3);                                                
                        avisaError("Ha ocurrido un problema al obtener la validación del importe. </br>[Código de seguimiento:"+timeStampErroresTarjeta+"]");
                        return;
                    }
                    if (isDefined(respuesta.Controlador)){
                        if(respuesta.Controlador !=="")
                            guardaControladorSesion(respuesta.Controlador);    
                    }
                    var informacionRespuesta = eval("(" + respuesta.RespuestaString + ")");
                    let errorRespuesta = BuscarErroresEnRespuesta(informacionRespuesta)
                    if (errorRespuesta !== "") {
                        document.getElementById("txtTban").value = "";
                        document.getElementById("txtTban").focus();
                        registraHistorial("El servicio de validaImporteTban ha respondido con código de error, respuesta= "+JSON.stringify(respuesta, null, 4),timeStampErroresTarjeta,3);                                                            
                        avisaError(errorRespuesta +"</br>[Código de seguimiento:"+timeStampErroresTarjeta+"]");
                        return
                    }
                    
                    if (!isDefined(respuesta.Controlador))
                    {
                        registraHistorial("El servicio de validaImporteTban no ha respondido correctamente, respuesta= "+JSON.stringify(respuesta, null, 4),timeStampErroresTarjeta,3);                                                            
                        avisaError("El servicio de validacion de importe no ha respondido correctamente. </br>[Código de seguimiento:"+timeStampErroresTarjeta+"]");
                        return;   
                    }

                    solicitaConfirmacionImporte(respuesta.RespuestaString);  //<-Procesa info            
                }
                catch (oError) {
                    timeStampErroresTarjeta = Commons.getStampId(datosOperacion.wS);      
                    registraHistorial("Ocurrió un error no controlado en validaImporteTban oError = "+JSON.stringify(oError, null, 4),timeStampErroresTarjeta,3);                                                
                    finalizarConError("Algo salio mal validando el importe, si el problema persiste favor de comunicarse a soporte. </br>[Código de seguimiento:"+timeStampErroresTarjeta+"]");
                    return;
                }
            });
            if (event.preventDefault) {
                event.preventDefault();
            }
        }
        else {
            objeto.style.background = "";
        }
    }
    catch (oError) {
        timeStampErroresTarjeta = Commons.getStampId(datosOperacion.wS);      
        registraHistorial("Ocurrió un error no controlado en eventValidaImporteTBan oError = "+JSON.stringify(oError, null, 4),timeStampErroresTarjeta,3);                                                
        finalizarConError("Algo salio mal validando el importe, si el problema persiste favor de comunicarse a soporte. </br>[Código de seguimiento:"+timeStampErroresTarjeta+"]");
        return;
    }
        
}


function eventConfirmaImporteTBan(event) { //Completar y verificar
    try
    {
        var keyCode;
        var objeto;
        // event passed as param in Firefox, not IE where it's defined as window.event
        if (!event) {
            event = window.event;
            keyCode = event.keyCode;
        }
        else { // ff
            keyCode = event.which;
        }
        objeto = document.getElementById("txtTbanConfirma");        
        if (keyCode == 13) {
            objeto.value = objeto.value.replace("$","");
            if(!(!!objeto.value.match(/(?=.)^(([1-9][0-9]{0,2}(,[0-9]{3})*)|[0-9]+)?(\.[0-9]{1,2})?$/)))
            {
                timeStampErroresTarjeta = Commons.getStampId(datosOperacion.wS);      
                registraHistorial("El usuario ha intentado ingresar un valor de importe invalido; "+JSON.stringify(objeto.value, null, 4),timeStampErroresTarjeta,3);                                                            
                avisaError("El importe ingresado es incorrecto realice la corrección pertinente e intente de nuevo. </br> Valor incorrecto ingresado: "+objeto.value);
                document.getElementById("txtTbanConfirma").value = "";
                document.getElementById("txtTbanConfirma").focus();            
                return;
            }
            folioIdentificacion = $('#txtfolioIdentificacion').val();
            if (folioIdentificacion === "") {
                avisaError("Se necesita indicar un Folio de identificación.");
                $.LoadingOverlay("hide");

                return;
            }
            importeVentaTarjeta = objeto.value;
            var parametros = {
                controlador: obtenControladorSesion(), //string        
                importe: importeVentaTarjeta//string
            };
            validaImporteConfirmaTban(parametros).done(function (respuesta) {
                try
                {
                    timeStampErroresTarjeta = Commons.getStampId(datosOperacion.wS);                              
                    if (!isDefined(respuesta)) {
                        registraHistorial("El servicio de validaImporteConfirmaTban no ha respondido, respuesta = "+JSON.stringify(respuesta, null, 4),timeStampErroresTarjeta,3);                                                
                        avisaError("No se ha obtenido respuesta del servicio de confirmación de importe. </br>[Código de seguimiento:"+timeStampErroresTarjeta+"]");
                        return;
                    }
                    if (!isDefined(respuesta.RespuestaString)) {
                        registraHistorial("El servicio de validaImporteConfirmaTban no ha respondido correctamente, respuesta = "+JSON.stringify(respuesta, null, 4),timeStampErroresTarjeta,3);                                                
                        avisaError("El servicio de confirmación de importe no ha respondido correctamente. </br>[Código de seguimiento:"+timeStampErroresTarjeta+"]");
                        return;
                    }
                    if (isDefined(respuesta.Controlador)){
                        if(respuesta.Controlador !=="")
                            guardaControladorSesion(respuesta.Controlador);    
                    }
                
                    var informacionRespuesta = eval("(" + respuesta.RespuestaString + ")");
                    let errorRespuesta = BuscarErroresEnRespuesta(informacionRespuesta);
                    if (errorRespuesta !== "") {
                        registraHistorial("El servicio de validaImporteConfirmaTban ha respondido con código de error, informacionRespuesta = "+JSON.stringify(informacionRespuesta, null, 4),timeStampErroresTarjeta,3);                                                
                        avisaError(errorRespuesta+"</br>[Código de seguimiento:"+timeStampErroresTarjeta+"]");
                        return
                    }

                    if (!isDefined(respuesta.Controlador))
                    {
                        timeStampErroresTarjeta = Commons.getStampId(datosOperacion.wS);      
                        registraHistorial("El servicio de validaImporteConfirmaTban no ha respondido correctamente, respuesta= "+JSON.stringify(respuesta, null, 4),timeStampErroresTarjeta,3);                                                            
                        avisaError("El servicio de confirmación de importe no ha respondido correctamente. </br>[Código de seguimiento:"+timeStampErroresTarjeta+"]");
                        return;   
                    }

                    let e = document.getElementById("slcTipoIdentificacion");
                    identificacionSeleccionada = e.options[e.selectedIndex].value;            
                    guardaVariableSesion('respuestaConfirmacion',respuesta.RespuestaString);
                    onConfirmaImporteTBanComplete(respuesta.RespuestaString);  //<-Procesa info            
                }
                catch (oError) {
                    timeStampErroresTarjeta = Commons.getStampId(datosOperacion.wS);      
                    registraHistorial("Ocurrió un error no controlado en validaImporteConfirmaTban oError = "+JSON.stringify(oError, null, 4),timeStampErroresTarjeta,3);                                                
                    finalizarConError("Algo salio mal confirmando el importe, si el problema persiste favor de comunicarse a soporte. </br>[Código de seguimiento:"+timeStampErroresTarjeta+"]");
                    return;
                }
            });
            if (event.preventDefault) {
                event.preventDefault();
            }
        }
        else {
            objeto.style.background = "";
            objeto.style.opacity = "1";
        }
    }
    catch (oError) {
        timeStampErroresTarjeta = Commons.getStampId(datosOperacion.wS);      
        registraHistorial("Ocurrió un error no controlado en eventConfirmaImporteTBan oError = "+JSON.stringify(oError, null, 4),timeStampErroresTarjeta,3);                                                
        finalizarConError("Algo salio mal confirmando el importe, si el problema persiste favor de comunicarse a soporte. </br>[Código de seguimiento:"+timeStampErroresTarjeta+"]");
        return;
    }
}

function eventIdentificacionFolio(event) { //Completar y verificar
    try
    {
        var keyCode;
        var objeto;
        // event passed as param in Firefox, not IE where it's defined as window.event
        if (!event) {
            event = window.event;
            keyCode = event.keyCode;
        }
        else { // ff
            keyCode = event.which;
        }
        objeto = document.getElementById("txtfolioIdentificacion");
        if (keyCode == 9 || keyCode ==0) {
            event.preventDefault();
            $('#txtTban').focus();        
        }
        else {
            if (objeto.value === "") {
                disableElements($('#txtTban'))
            }
            else {
                enableElements($('#txtTban'))
            }
            if(!((keyCode>=97 && keyCode <=122) ||(keyCode>=65 && keyCode <=90) || (keyCode>=48 && keyCode<=57) || (keyCode == 127 ) || (keyCode==8) ||(keyCode == 9) || (keyCode ==0)))
            {                
                event.preventDefault();
            }
        }
    }
    catch (oError) {
        timeStampErroresTarjeta = Commons.getStampId(datosOperacion.wS);      
        registraHistorial("Ocurrió un error no controlado en eventIdentificacionFolio oError = "+JSON.stringify(oError, null, 4),timeStampErroresTarjeta,3);                                                
        finalizarConError("Algo salio mal al validar el folio de la identificación, si el problema persiste favor de comunicarse a soporte. </br>[Código de seguimiento:"+timeStampErroresTarjeta+"]");
        return;
    }
}

function validaInformacionIdentificacion() {
    try
    {
        var txt = $("#txtfolioIdentificacion").val();
        tipoIdentificacionSeleccionada()
    }
    catch (oError) {
        timeStampErroresTarjeta = Commons.getStampId(datosOperacion.wS);      
        registraHistorial("Ocurrió un error no controlado en validaInformacionIdentificacion oError = "+JSON.stringify(oError, null, 4),timeStampErroresTarjeta,3);                                                
        finalizarConError("Algo salio mal al validar la información de la identificación, si el problema persiste favor de comunicarse a soporte. </br>[Código de seguimiento:"+timeStampErroresTarjeta+"]");
        return;
    }
}


function tipoIdentificacionSeleccionada() {
    try{
        let e = document.getElementById("slcTipoIdentificacion");
        identificacionSeleccionada = e.options[e.selectedIndex].value;
        if (identificacionSeleccionada != "-1") {        
            enableElements($('#txtfolioIdentificacion'));
        }
        else {
            disableElements($('#txtTban'));
            $('#txtTban').val("");
            disableElements($('#txtfolioIdentificacion'));
            $('#txtfolioIdentificacion').val("");
        }
    }
    catch (oError) {
        timeStampErroresTarjeta = Commons.getStampId(datosOperacion.wS);      
        registraHistorial("Ocurrió un error no controlado en tipoIdentificacionSeleccionada oError = "+JSON.stringify(oError, null, 4),timeStampErroresTarjeta,3);                                                
        finalizarConError("Algo salio mal al validar el tipo de identificación, si el problema persiste favor de comunicarse a soporte. </br>[Código de seguimiento:"+timeStampErroresTarjeta+"]");
        return;
    }
}


function eventReintentarPagoTarjeta() {
    try
    {
        var respuestaConfirmacion = obtenVariableSesion('respuestaConfirmacion');
        onConfirmaImporteTBanComplete(respuestaConfirmacion, identificacionSeleccionada, folioIdentificacion);  //<-Procesa info            
    }
    catch (oError) {
        timeStampErroresTarjeta = Commons.getStampId(datosOperacion.wS);      
        registraHistorial("Ocurrió un error no controlado en eventReintentarPagoTarjeta oError = "+JSON.stringify(oError, null, 4),timeStampErroresTarjeta,3);                                                
        finalizarConError("Algo salio mal al volver a intentar el pago con tarjeta, si el problema persiste favor de comunicarse a soporte. </br>[Código de seguimiento:"+timeStampErroresTarjeta+"]");
        return;
    }
}

function eventValidaOptionMSI(){
    try{
        let e = document.getElementById("cboPlazos");
        let b = document.getElementById("btnMsi");    
        mesesSeleccionado = e.options[e.selectedIndex].value;    
        
        if(isDefined(mesesSeleccionado))
        {
            b.style.visibility = "visible";
        }
        else
        {
            b.style.visibility = "hidden";
        }
    }
    catch (oError) {
        timeStampErroresTarjeta = Commons.getStampId(datosOperacion.wS);      
        registraHistorial("Ocurrió un error no controlado en eventValidaOptionMSI oError = "+JSON.stringify(oError, null, 4),timeStampErroresTarjeta,3);                                                
        finalizarConError("Algo salio mal al validar la opción de meses sin intereses elegida, si el problema persiste favor de comunicarse a soporte. </br>[Código de seguimiento:"+timeStampErroresTarjeta+"]");
        return;
    }
}

function cancelaOperacionAntesAfectacion(){
    cancelaOperacionPinpad(parametros).done(function (respuesta) {
        try{
            $('#barraPorcentaje > .verde').width("95%");
            if (!isDefined(respuesta)) {
                timeStampErroresTarjeta = Commons.getStampId(datosOperacion.wS);      
                registraHistorial("El servicio de validaPromociones no ha respondido, respuesta= "+JSON.stringify(respuesta, null, 4),timeStampErroresTarjeta,3);                                                            
                finalizarPinpadLecturaError("No se obtuvo respuesta del servicio de validación de promociones al cerrar las dependencias. </br>[Código de seguimiento:"+timeStampErroresTarjeta+"]");
                return;
            }
            
            if (respuesta.Estatus != "8") {
                registraHistorial("El servicio de cancelaOperacionAntesAfectacion ha respondido con codigo de error, respuesta= "+JSON.stringify(respuesta, null, 4),timeStampErroresTarjeta,3);
                finalizarPinpadLecturaError("La operación no ha podido ser cancelada correctamente, si el problema persiste favor de comunicase a soporte.</br>[Código de seguimiento:"+timeStampErroresTarjeta+"]");
                return
            }
            cerrarModal();
            FuncionesTarjeta.limpiaPantalla();
            manejaFinalizadoPinPad();            
        }
        catch (oError) {
            manejaExcepcionLecturaPinpad(oError);
        }
    });
}

function alertaCancelacionAntesAfectacion(){
    FuncionesTarjeta.mostrarModal("avisoCancelacionAntesAfectacion");
}

function preguntaAutorizacionCliente(){
    FuncionesTarjeta.mostrarModal("autorizacionClienteCargo");
}
//# sourceURL=tarjeta.js