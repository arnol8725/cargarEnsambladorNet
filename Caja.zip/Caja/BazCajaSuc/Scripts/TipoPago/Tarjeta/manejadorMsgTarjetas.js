﻿/*
* @Author: jagonzalezu
* @Date:   2018-01-12 11:43:49
* @Last Modified by:   jagonzalezu
* @Last Modified time: 2018-03-07 12:11:53
*/
var ManejadorMsgTarjetas ={
    getContent:function getContent(caseMessage) {
        content = "";
        switch (caseMessage) {
            case "confimeImporte":
                content = '<div class="cuadro3">\
                                <a style="visibility: hidden" href="#" class=" simplemodal-close" id="botonCerrar">\
                                    <img src="../../Imgs/cerrar.png" class="cerrar">\
                                </a>\
                                <div class="titModal tCenter">Tarjeta bancaria</div>\
                                <div class="clear"></div><br>\
                                <div class="texto1">\
                                    Por favor, confirme el importe\
                                </div>\
                                <div class="botones1"><a href="#" onclick="cerrarModal()" class="btnV w48">Aceptar</a></td></div>\
                                <br>\
                            </div>'
            break;
            case "procesandoPinPad":
                content = '<div class="cuadro2">\
                                <a style="visibility:hidden" href="#" class=" simplemodal-close" id="botonCerrar">\
                                    <img src="../../Imgs/cerrar.png" class="cerrar">\
                                </a>\
                                <div class="titModal">Procesando petición PinPad</div>\
                                <div class="clear"></div><br><br>\
                                <div class="texto1">\
                                    Si la tarjeta tiene chip, <strong>introducir </strong>en el PinPad y <strong>no la retire </strong> hasta<br>\
                                    que se le indique. Puede solicitarse teclear el Pin.<br><br>\
                                    Si no tiene chip, <strong>solo deslizarla</strong>. Puede solicitarse teclear el CVV.\
                                    <br><br>\
                                    <div id="barraPorcentaje" class="porcentaje"><div class="verde" style="width: 75%"></div></div>\
                                </div>\
                                <div class="tCenter"><img src="../../Imgs/TiposPago/pin.jpg" class="imgPin"></div>\
                                <div class="texto1"><strong>Siga las instrucciones del Pinpad y espere por favor</strong></div>\
                                </br>\
                                <div id="numIntentos" class="texto1"><strong> </strong></div>\
                                <div style="visibility:hidden" class="botones1"><a href="#" onclick="cerrarModal()" class="btnV w48">Aceptar</a></div>\
                                <br>\
                            </div>'
            break;
            case "autorizacionClienteCargo":
                content = '<div class="cuadro2">\
                                <a style="visibility:hidden" href="#" class=" simplemodal-close" id="botonCerrar">\
                                    <img src="../../Imgs/cerrar.png" class="cerrar">\
                                </a>\
                                <div class="titModal tCenter">Envío de solicitud de autorización al banco</div>\
                                <div class="clear"></div>\
                                <div class="texto1">\
                                    <br>\
                                    En este momento se enviará la solicitud de autorización al banco emisor<br>\
                                    de la tarjeta, ¿el cliente está de acuerdo en que se le haga el cargo regular?\
                                </div>\
                                <div class="botones w50">\
                                    <a onclick="eventProcesaSolicitudAutorizacion()" href="#" class="btnB w48">Sí</a>\
                                    <a onclick="alertaCancelacionAntesAfectacion()" href="#" class="btnV w48">No</a>\
                                </div>\
                                <div class="clear"></div><br>\
                            </div>'
            break;
            case "avisoCancelacionAntesAfectacion":
                content = '<div class="cuadro2">\
                                <a style="visibility:hidden" href="#" class=" simplemodal-close" id="botonCerrar">\
                                    <img src="../../Imgs/cerrar.png" class="cerrar">\
                                </a>\
                                <div class="titModal tCenter">Aviso de cancelación.</div>\
                                <div class="clear"></div>\
                                <div class="texto1">\
                                    <br>\
                                    Al cancelar se perderán los datos de la  tarjeta actual.<br>\
                                    ¿Realmente desea cancelar?\
                                </div>\
                                <div class="botones w50">\
                                    <a onclick="cancelaOperacionAntesAfectacion()" href="#" class="btnB w48">Sí</a>\
                                    <a onclick="preguntaAutorizacionCliente()" href="#" class="btnV w48">No</a>\
                                </div>\
                                <div class="clear"></div><br>\
                            </div>'
            break;
            case "solicitandoAutorizacionBanco":
                content = '<div class="cuadro1">\
                                <a style="visibility:hidden" href="#" class=" simplemodal-close" id="botonCerrar">\
                                    <img src="../../Imgs/cerrar.png" class="cerrar">\
                                </a>\
                                <div class="titModal">Tarjeta bancaria</div>\
                                <div class="clear"></div>\
                                <div class="texto1">\
                                    Solicitando autorización, espere un momento.<br>\
                                    No retire la tarjeta hasta terminar la operación.\
                                    <br>\
                                </div>\
                                <div class="tCenter"><img src="../../Imgs/TiposPago/Antena.gif" class="imgAntena"></div>\
                                <br>\
                            </div>'
            break;
            case "espereInstruccionesPinpad":
                content = '<div class="cuadro1">\
                                <a style="visibility:hidden" href="#" class=" simplemodal-close" id="botonCerrar">\
                                    <img src="../../Imgs/cerrar.png" class="cerrar">\
                                </a>\
                                <div class="titModal">Tarjeta bancaria</div>\
                                <div class="clear"></div>\
                                <div class="texto1">\
                                    Atienda las instrucciones del PinPad.<br>\
                                    <br>\
                                </div>\
                                <br>\
                            </div>'
            break;
            case "retireTarjeta":
                content = '<div class="cuadro2">\
                                <a href="#" class=" simplemodal-close" id="botonCerrar">\
                                    <img src="../../Imgs/cerrar.png" class="cerrar">\
                                </a>\
                                <div class="titModal">Procesando petición PinPad</div>\
                                <div class="clear"></div><br>\
                                <div class="texto1">\
                                    Retire la tarjeta y espere por favor.\
                                    <br><br>\
                                    <div class="porcentaje"><div class="verde" style="width: 100%"></div></div>\
                                </div>\
                                <br>\
                            </div>'
            break;
            case "pagoAutorizadoSinFirma":
                content = '<div class="cuadro2">\
                                <a style="visibility:hidden" href="#" class=" simplemodal-close" id="botonCerrar">\
                                    <img src="../../Imgs/cerrar.png" class="cerrar">\
                                </a>\
                                <div class="titModal">Tarjeta bancaria</div>\
                                <div class="clear"></div><br>\
                                <div class="texto1">\
                                    El pago con tarjeta bancaria se autorizó correctamente,<br>\
                                    <br><br>\
                                    <div class="botones1"><a onclick="cerrarModal()" href="#" class="btnV w48">Aceptar</a></td></div>\
                                </div>\
                                <br>\
                            </div>'
            break;
            case "pagoAutorizadoConFirma":
                content = '<div class="cuadro2">\
                                <a style="visibility:hidden" href="#" class=" simplemodal-close" id="botonCerrar">\
                                    <img src="../../Imgs/cerrar.png" class="cerrar">\
                                </a>\
                                <div class="titModal">Tarjeta bancaria</div>\
                                <div class="clear"></div><br>\
                                <div class="texto1">\
                                    El pago con tarjeta bancaria se autorizó correctamente,<br>\
                                    <i>Al finalizar se solicitará la firma del cliente</i>\
                                    <br><br>\
                                    <div class="botones1"><a onclick="procesaGuardadoFirma()" href="#" class="btnV w48">Aceptar</a></td></div>\
                                </div>\
                                <br>\
                            </div>'
            break;
            case "reintentoFirmaCliente":
                content = '<div class="cuadro">\
                                <a style="visibility:hidden" href="#" class=" simplemodal-close" id="botonCerrar">\
                                    <img src="../../Imgs/cerrar.png" class="cerrar">\
                                </a>\
                                <div class="titModal">Tarjeta bancaria</div>\
                                <div class="clear"></div><br>\
                                <div class="texto1">\
                                    <label id="lblError"></label>\
                                    <br><br>\
                                    <div class="botones1"><a onclick="procesaGuardadoFirma()" href="#" class="btnV w48">Volver a solicitar firma</a>\</td></div>\
                                </div>\
                                <br><br><br>\
                            </div>'
            break;
            case "firmaClienteCoincide":
                content = '<div class="cuadro">\
                                <a style="visibility:hidden" href="#" class=" simplemodal-close" id="botonCerrar">\
                                    <img src="../../Imgs/cerrar.png" class="cerrar">\
                                </a>\
                                <div class="titModal">Tarjeta bancaria</div>\
                                <div class="clear"></div><br>\
                                <div class="texto1">\
                                    ¿La imagen de la firma digital coincide con la firma del cliente?<br>\
                                    <label id="lblImg"></label>\
                                    <br><br>\
                                </div>\
                                <div class="botones w50">\
                                        <a onclick="procesaGuardadoFirma()" href="#" class="btnB w48">Volver a solicitar firma</a>\
                                        <a onclick="SubeImgenServidor()" href="#" class="btnV w48">Continuar</a>\
                                </div>\
                                <br><br><br>\
                            </div>'
            break;
            case "cancelandoOperacion":
                content = '<div class="cuadro2">\
                                <a href="#" class=" simplemodal-close" id="botonCerrar">\
                                    <img src="../../Imgs/cerrar.png" class="cerrar">\
                                </a>\
                                <div class="titModal">Procesando petición PinPad</div>\
                                <div class="clear"></div><br>\
                                <div class="texto1">\
                                    Cancelando operación, espere un momento por favor.\
                                    <br><br>\
                                    <div class="porcentaje"><div class="verde" style="width: 60%"></div></div>\
                                </div>\
                                <br>\
                            </div>'
            break;            
            case "solicitandoReverso":
                content = '<div class="cuadro1">\
                                <a style="visibility:hidden" href="#" class=" simplemodal-close" id="botonCerrar">\
                                    <img src="../../Imgs/cerrar.png" class="cerrar">\
                                </a>\
                                <div class="titModal">Tarjeta bancaria</div>\
                                <div class="clear"></div>\
                                <div class="texto1">\
                                    Solicitando reverso, espere un momento.\
                                    <br>\
                                </div>\
                                <div class="tCenter"><img src="../../Imgs/TiposPago/Antena.gif" class="imgAntena"></div>\
                                <br>\
                            </div>'
            break;
            case "reversoExitoso":
                content = '<div class="cuadro1">\
                                <a style="visibility:hidden" href="#" class=" simplemodal-close" id="botonCerrar">\
                                    <img src="../../Imgs/cerrar.png" class="cerrar">\
                                </a>\
                                <div class="titModal">Tarjeta bancaria</div>\
                                <div class="clear"></div>\
                                <div class="texto1">\
                                    <br>\
                                    Se concretó satisfactoriamente el Reverso de pago con tarjeta<br>\
                                    bancaria, por favor verificar la operación con el banco emisor.<br>\
                                    <br>\
                                </div>\
                                <div class="botones1"><a onclick="onReversoExitoso()" href="#" class="btnV w48">Aceptar</a></div>\
                                <br>\
                            </div>'
            break;
            case "importeNoCorresponde":
                content = '<div class="cuadro1">\
                                <a href="#" class=" simplemodal-close" id="botonCerrar">\
                                    <img src="../../Imgs/cerrar.png" class="cerrar">\
                                </a>\
                                <div class="titModal">Tarjeta bancaria</div>\
                                <div class="clear"></div>\
                                <div class="texto1">\
                                    <br>\
                                    El importe capturado no corresponde al primer importe.<br>\
                                    <br>\
                                </div>\
                                <div class="botones1"><a href="#" class="btnV w48">Aceptar</a></div>\
                                <br>\
                            </div>'
            break;
            case "participaMSI":
                content = '<div class="cuadro2">\
                                <a style="visibility:hidden" href="#" class=" simplemodal-close" id="botonCerrar">\
                                    <img src="../../Imgs/cerrar.png" class="cerrar">\
                                </a>\
                                <div class="titModal tCenter">Promoción meses sin intereses</div>\
                                <div class="clear"></div>\
                                <div class="texto1">\
                                    <br>\
                                    El presupuesto y tarjeta participan para Meses sin Interesese con:\
                                    <br>\
                                    <br>\
                                    <select tabindex="1" class="normal_select" onchange="eventValidaOptionMSI()" id="cboPlazos">\
                                    <option value="0">No hay plazos disponibles</option>\
                                    </select>\
                                </div>\
                                <div style = "visibility:hidden" id = "btnMsi" class="botones1"><a href="#" onclick="solicitaAutorizacionCliente()" class="btnV w48">Aceptar</a></td></div>\
                                <div class="clear"></div><br>\
                            </div>'
            break;
            case "solicitandoLlaves":
                content = '<div class="cuadro1">\
                                <a style="visibility:hidden" href="#" class=" simplemodal-close" id="botonCerrar">\
                                    <img src="../../Imgs/cerrar.png" class="cerrar">\
                                </a>\
                                <div class="titModal">Tarjeta bancaria</div>\
                                <div class="clear"></div>\
                                <div class="texto1">\
                                    Solicitando llaves de la PinPad, espere un momento.<br>\
                                    No desconecte la PinPad, ni apague el equipo.\
                                    <br>\
                                </div>\
                                <div class="tCenter"><img src="../../Imgs/TiposPago/Antena.gif" class="imgAntena"></div>\
                                <br>\
                            </div>'
            break;
            case "llavesExito":
                content = '<div class="cuadro3">\
                                <a style="visibility: hidden;" href="#" class=" simplemodal-close" id="botonCerrar">\
                                    <img src="../../Imgs/cerrar.png" class="cerrar">\
                                </a>\
                                <div class="titModal tCenter">Tarjeta bancaria</div>\
                                <div class="clear"></div><br>\
                                <div class="texto1">\
                                    Se cargo correctamente las llaves de la PinPad, puede continuar usando la PinPad\
                                </div>\
                                <div class="botones1"><a href="#" onclick="cerrarModal()" class="btnV w48">Aceptar</a></td></div>\
                                <br>\
                            </div>'
            break;
            case "guardaFirmaExito":
                content = '<div class="cuadro3">\
                                <a style="visibility: hidden;" href="#" class=" simplemodal-close" id="botonCerrar">\
                                    <img src="../../Imgs/cerrar.png" class="cerrar">\
                                </a>\
                                <div class="titModal tCenter">Tarjeta bancaria</div>\
                                <div class="clear"></div><br>\
                                <div class="texto1">\
                                    Se guardo con éxito la firma en el Pin Pad\
                                </div>\
                                <div class="botones1"><a href="#" onclick="cerrarModal()" class="btnV w48">Aceptar</a></td></div>\
                                <br>\
                            </div>'
            break;            
            default:
                content = '<p>No se eligío un mensaje valido para mostrar<\p>'
            break;
        }
        return content;
    }
}