/*
* @Author: jagonzalezu
* @Date:   2018-01-12 12:00:24
* @Last Modified by:   jagonzalezu
* @Last Modified time: 2018-03-07 11:45:23
*/
var nombreImagen;
function solicitaConfirmacionImporte(respuesta) {
    try {
        $('#txtTbanImporte').html('<input id="txtTbanConfirma" type="text" onkeypress="eventConfirmaImporteTBan(event)" placeholder="$0.0" class="tLeft">');
        disableElements($('#slcTipoIdentificacion'));
        disableElements($('#txtfolioIdentificacion')); 
        FuncionesTarjeta.mostrarModal('confimeImporte');
        document.getElementById("txtTbanImporte").focus();    
    }
    catch (oError) {
        timeStampErroresTarjeta = Commons.getStampId(datosOperacion.wS);      
        registraHistorial("Ocurrió un error no controlado en solicitaConfirmacionImporte oError = "+JSON.stringify(oError, null, 4),timeStampErroresTarjeta,3);                                                
        finalizarConError("Algo salio mal, si el problema persiste favor de comunicarse a soporte." + " </br>[Código de seguimiento:"+timeStampErroresTarjeta+"]");
        return;
    }
}

function onConfirmaImporteTBanComplete(respuesta) {
    try {       
        FuncionesTarjeta.mostrarModal("procesandoPinPad");
        $('#barraPorcentaje > .verde').width("0%");
        let e = document.getElementById("modal00").querySelector("#numIntentos");
        if(ReadAttemptsChip >= 3)
            e.innerHTML = "Se ha excedido el intentos de lectura por chip. Utilice la banda de la tarjeta.";
        else
            e.innerHTML = "Intento "+(FailedAttempts+1) + " de 4";            
        verificaServiciosPinpadParaVenta();        
    }
    catch (oError) {
        manejaExcepcionLecturaPinpad(oError);
    }
}

function verificaServiciosPinpadParaVenta()
{
    try
    {
//--------------------------------------------------------------------------------------------------------------------------------------//
//--------------------------------------------------------------------------------------------------------------------------------------//
//-----------------------------------------Verificar que esto este BIEN-----------------------------------------------------------------//
//--------------------------------------------------------------------------------------------------------------------------------------//
//--------------------------------------------------------------------------------------------------------------------------------------//
        var parametrosIniciar = {
            aplicacion: "Caja64", //string        
            negocio: "1"//string
        };
        
//--------------------------------------------------------------------------------------------------------------------------------------//
//--------------------------------------------------------------------------------------------------------------------------------------//
//-----------------------------------------Verificar que esto este BIEN-----------------------------------------------------------------//
//--------------------------------------------------------------------------------------------------------------------------------------//
//--------------------------------------------------------------------------------------------------------------------------------------//

       if(!isServicePinPadOn)
        {
            $('#barraPorcentaje > .verde').width("15%")
            iniciarPinpad(parametrosIniciar).done(function (respuesta) {
                try{                   
                    timeStampErroresTarjeta = Commons.getStampId(datosOperacion.wS);                              
                    $('#barraPorcentaje > .verde').width("25%")
                    if (!isDefined(respuesta)) {
                        registraHistorial("El servicio de iniciarPinpad no ha respondido, respuesta= "+JSON.stringify(respuesta, null, 4),timeStampErroresTarjeta,3);                                                            
                        avisaError("No se obtuvo respuesta del servicio para iniciar el PinPad. </br>[Código de seguimiento:"+timeStampErroresTarjeta+"]");
                        isServicePinPadOn = false;
                        return;
                    }
                    if (respuesta.Estatus != 1) {
                        registraHistorial("El servicio de iniciarPinpad ha respondido con codigo de error, respuesta= "+JSON.stringify(respuesta, null, 4),timeStampErroresTarjeta,3);                                                            
                        finalizarPinpadLecturaError("No se pudo inicializar la PinPad </br>[Código de seguimiento:"+timeStampErroresTarjeta+"]");
                        return
                    }            
                    verificaPinpadConectado();                    
                    //actualizaImportes(informacionDocumentos);    
                }
                catch (oError) {
                    manejaExcepcionLecturaPinpad(oError);
                }
            });
        }
        else
        {
            verificaPinpadConectado();                    
        }
    }
    catch (oError) {
        manejaExcepcionLecturaPinpad(oError);
    }
}

function verificaPinpadConectado()
{

    dispositivoConectado().done(function (respuesta) {
        try
        {
            timeStampErroresTarjeta = Commons.getStampId(datosOperacion.wS);                      
            $('#barraPorcentaje > .verde').width("30%")
            if (!isDefined(respuesta)) {
                registraHistorial("El servicio de dispositivoConectado no ha respondido, respuesta= "+JSON.stringify(respuesta, null, 4),timeStampErroresTarjeta,3);                                                            
                avisaError("Error en el servicio de la PinPad no ha respondido la verificación de conexión. </br>[Código de seguimiento:"+timeStampErroresTarjeta+"]");
                isServicePinPadOn = false;
                return;
            }
            if (respuesta.Estatus != 1) {
                registraHistorial("El servicio de leerChipEMVCifrado no ha respondido, respuesta= "+JSON.stringify(respuesta, null, 4),timeStampErroresTarjeta,3);                                                            
                finalizarPinpadLecturaError("El dispositivo no se encuentra conectado </br>[Código de seguimiento:"+timeStampErroresTarjeta+"]");
                return
            }   
            disableElements($('#txtTbanConfirma'));                            
            $('#barraPorcentaje > .verde').width("40%")
            
            lecturaDeTarjeta();

            $.LoadingOverlay("hide");
        }
        catch (oError) {
            manejaExcepcionLecturaPinpad(oError);
        }
    });
}

function lecturaDeTarjeta(){
    try
    {
        var parametrosLectura = {
            monto: importeVentaTarjeta, //string        
            tipoVenta: datosOperacion.tipoVenta//string
        };
        leerChipEMVCifrado(parametrosLectura).done(function (respuesta) {  
            try
            {       
                timeStampErroresTarjeta = Commons.getStampId(datosOperacion.wS);      
                $('#barraPorcentaje > .verde').width("55%")
                if (!isDefined(respuesta)) {
                    registraHistorial("El servicio de leerChipEMVCifrado no ha respondido, respuesta= "+JSON.stringify(respuesta, null, 4),timeStampErroresTarjeta,3);                                                            
                    finalizarPinpadLecturaError("Error en el servicio de la PinPad, no ha respondido al intentar leer el chip. </br>[Código de seguimiento:"+timeStampErroresTarjeta+"]");
                    return;
                }
                if (respuesta.Estatus != 0) {
                    registraHistorial("El servicio de leerChipEMVCifrado ha respondido con código de error, respuesta= "+JSON.stringify(respuesta, null, 4),timeStampErroresTarjeta,3);                                                            
                    manejaErroresLecturaPinpad(respuesta.Estatus);
                    return
                }

                var parametros = {
                    controlador: obtenControladorSesion(), //string        
                    pAN: respuesta.PAN, //string
                    tOKENS_EZ_EY_ES: respuesta.TOKENS_EZ_EY_ES, //string
                    c55: respuesta.C55, //string
                    c55_Len: respuesta.C55Len, //string
                    esTarjetaConChip: respuesta.EsTarjetaConChip, //string
                    isFallBack: isFallBack, //string
                    folioIdentificacion: folioIdentificacion, //string
                    tipoIdentificacion: identificacionSeleccionada //string
                };
                
                vpEsTarjetaConChip = respuesta.EsTarjetaConChip;
                vpPAN = respuesta.PAN;
                vpCardHolder= respuesta.CardHolder;
                vpTOKENS_EZ_EY_ES= respuesta.TOKENS_EZ_EY_ES;
                vpC55= respuesta.vpC55;
                vpC55Len= respuesta.C55Len;

                $('#barraPorcentaje > .verde').width("60%")
                
                procesaValidacionChip(parametros);
            }
            catch (oError) {
                manejaExcepcionLecturaPinpad(oError);
            }   
        });
    }
    catch (oError) {
        manejaExcepcionLecturaPinpad(oError);
    }
}

function procesaValidacionChip(parametros){
    validaChip(parametros).done(function (respuesta) {
        try
        {
            timeStampErroresTarjeta = Commons.getStampId(datosOperacion.wS);                      
            $('#barraPorcentaje > .verde').width("75%");
            if (!isDefined(respuesta)) {
                registraHistorial("El servicio de validaChip no ha respondido, respuesta= "+JSON.stringify(respuesta, null, 4),timeStampErroresTarjeta,3);                                                            
                finalizarPinpadLecturaError("No se obtuvo respuesta del servicio de validación del chip. </br>[Código de seguimiento:"+timeStampErroresTarjeta+"]");
                return;
            }
            if (!isDefined(respuesta.RespuestaString)) {
                registraHistorial("El servicio de validaChip no ha respondido correctamente, respuesta= "+JSON.stringify(respuesta, null, 4),timeStampErroresTarjeta,3);                                                            
                finalizarPinpadLecturaError("El servicio de validación del chip no ha respondido correctamente. </br>[Código de seguimiento:"+timeStampErroresTarjeta+"]");
                return;
            }
            if(isDefined(respuesta.Controlador))
            {
                if(respuesta.Controlador !=="")
                    guardaControladorSesion(respuesta.Controlador);
            }   
            var informacionRespuesta = eval("(" + respuesta.RespuestaString + ")");
            let errorRespuesta = BuscarErroresEnRespuesta(informacionRespuesta);
            if (errorRespuesta!=="") {
                registraHistorial("El servicio de validaChip ha respondido con codigo de error, informacionRespuesta= "+JSON.stringify(informacionRespuesta, null, 4),timeStampErroresTarjeta,3);                                                            
                avisaError(errorRespuesta+"</br>[Código de seguimiento:"+timeStampErroresTiposPago+"]");                
                return;
            }

            if (!isDefined(respuesta.Controlador))
            {
                registraHistorial("El servicio de validaChip no ha respondido correctamente, respuesta= "+JSON.stringify(respuesta, null, 4),timeStampErroresTiposPago,3);                                                            
                avisaError("El servicio de validación de chip no ha respondido correctamente. </br>[Código de seguimiento:"+timeStampErroresTiposPago+"]");
                return;   
            }    
            obtienePromocionesMesesSinIntereses();
        }
        catch (oError) {
            manejaExcepcionLecturaPinpad(oError);
        }
    });    
}


function obtienePromocionesMesesSinIntereses(){
    try
    {
        var parametros = {
            controlador: obtenControladorSesion()//string
        };
        $('#barraPorcentaje > .verde').width("80%");
        validaPromocionesPresupuestoMSI(parametros).done(function (respuesta) {
            try
            {
                timeStampErroresTarjeta = Commons.getStampId(datosOperacion.wS);                          
                $('#barraPorcentaje > .verde').width("85%");
                if (!isDefined(respuesta)) {
                    registraHistorial("El servicio de validaPromocionesPresupuestoMSI no ha respondido, respuesta= "+JSON.stringify(respuesta, null, 4),timeStampErroresTarjeta,3);                                                            
                    finalizarPinpadLecturaError("No se obtuvo respuesta del servicio para validar promociones a meses sin intereses. </br>[Código de seguimiento:"+timeStampErroresTarjeta+"]");
                    return;
                }
                if (!isDefined(respuesta.RespuestaString)) {
                    registraHistorial("El servicio de validaPromocionesPresupuestoMSI no ha respondido correctamente, respuesta= "+JSON.stringify(respuesta, null, 4),timeStampErroresTarjeta,3);                                                            
                    finalizarPinpadLecturaError("No se obtuvo una respuesta correcta del servicio para validar promociones a meses sin intereses. </br>[Código de seguimiento:"+timeStampErroresTarjeta+"]");
                    return;
                }
                if (isDefined(respuesta.Controlador)){
                    if(respuesta.Controlador !=="")
                        guardaControladorSesion(respuesta.Controlador);    
                }
                var informacionRespuesta = eval("(" + respuesta.RespuestaString + ")");
                let errorRespuesta = BuscarErroresEnRespuesta(informacionRespuesta);
                if (errorRespuesta !== "") {
                    registraHistorial("El servicio de validaPromocionesPresupuestoMSI ha respondido con codigo de error, informacionRespuesta= "+JSON.stringify(informacionRespuesta, null, 4),timeStampErroresTarjeta,3);                                                            
                    finalizarPinpadLecturaError(errorRespuesta+"</br>[Código de seguimiento:"+timeStampErroresTarjeta+"]");
                    return
                }
                
                if (!isDefined(respuesta.Controlador))
                {
                    registraHistorial("El servicio de eventConfirmaImporteTBan no ha respondido correctamente, respuesta= "+JSON.stringify(respuesta, null, 4),timeStampErroresTarjeta,3);                                                            
                    finalizarPinpadLecturaError("El servicio de confirmación de importe no ha respondido correctamente. </br>[Código de seguimiento:"+timeStampErroresTarjeta+"]");
                    return;   
                }
                procesaRespuestaPromociones(informacionRespuesta);
            }
            catch (oError) {
                manejaExcepcionLecturaPinpad(oError);
            }
        });
    }
    catch (oError) {
        manejaExcepcionLecturaPinpad(oError);
    }
}

function procesaRespuestaPromociones(formatoRespuesta) {
    try
    {
        var nombreBanco = "";
        var cboPlazos;    
        $('#barraPorcentaje > .verde').width("90%");                
        if (formatoRespuesta.valor.length >= 2) {
            var item;
            var index = 0;
            FuncionesTarjeta.mostrarModal('participaMSI');

            cboPlazos = document.getElementById("cboPlazos");

            for (index = 0; index < formatoRespuesta.valor.length; index++) {
                item = formatoRespuesta.valor[index];
                cboPlazos.options[index] = new Option(item.texto, item.valor);
                nombreBanco = item.banco;
            }
            cboPlazos.selectedIndex = 0;
        }
        else {
            var parametros = {
                controlador : obtenControladorSesion()
            }
            validaPromociones(parametros).done(function (respuesta) {
                try{
                    $('#barraPorcentaje > .verde').width("95%");
                    if (!isDefined(respuesta)) {
                        timeStampErroresTarjeta = Commons.getStampId(datosOperacion.wS);      
                        registraHistorial("El servicio de validaPromociones no ha respondido, respuesta= "+JSON.stringify(respuesta, null, 4),timeStampErroresTarjeta,3);                                                            
                        finalizarPinpadLecturaError("No se obtuvo respuesta del servicio de validación de promociones al cerrar las dependencias. </br>[Código de seguimiento:"+timeStampErroresTarjeta+"]");
                        return;
                    }
                    if (!isDefined(respuesta.RespuestaString)) {
                        timeStampErroresTarjeta = Commons.getStampId(datosOperacion.wS);      
                        registraHistorial("El servicio de validaPromociones no ha respondido correctamente, respuesta= "+JSON.stringify(respuesta, null, 4),timeStampErroresTarjeta,3);                                                            
                        finalizarPinpadLecturaError("El servicio de validación de promociones no ha respondido correctamente. </br>[Código de seguimiento:"+timeStampErroresTarjeta+"]");
                        return;
                    }
                    if (isDefined(respuesta.Controlador)){
                        if(respuesta.Controlador !=="")
                            guardaControladorSesion(respuesta.Controlador);    
                    }

                    var informacionRespuesta = eval("(" + respuesta.RespuestaString + ")");
                    let errorRespuesta  = BuscarErroresEnRespuesta(informacionRespuesta);
                    if (errorRespuesta !=="") {
                        registraHistorial("El servicio de validaPromociones ha respondido con codigo de error, respuesta= "+JSON.stringify(respuesta, null, 4),timeStampErroresTarjeta,3);
                        finalizarPinpadLecturaError(errorRespuesta+"</br>[Código de seguimiento:"+timeStampErroresTarjeta+"]");
                        return
                    }

                    if (!isDefined(respuesta.Controlador))
                    {
                        registraHistorial("El servicio de validaPromociones no ha respondido correctamente, respuesta= "+JSON.stringify(respuesta, null, 4),timeStampErroresTarjeta,3);                                                            
                        finalizarPinpadLecturaError("El servicio de validación de promociones no ha respondido correctamente. </br>[Código de seguimiento:"+timeStampErroresTarjeta+"]");
                        return;   
                    }

                    solicitaAutorizacionCliente();
                    //                
                }
                catch (oError) {
                    manejaExcepcionLecturaPinpad(oError);
                }
            });
        }            
    }
    catch (oError) {
        manejaExcepcionLecturaPinpad(oError);
    }
}


function solicitaAutorizacionCliente(){
    try
    {
        let e = document.getElementById("cboPlazos");
        let mesesSeleccionado = 0;
        if(isDefined(e)){  
            mesesSeleccionado = e.options[e.selectedIndex].value;    
        }
        parametros = {
            controlador: obtenControladorSesion(),
            parametroString: mesesSeleccionado
        };
        guardaVariableSesion('parametrosDeAutorizacion',parametros); 
        $('#barraPorcentaje > .verde').width("100%")

        FuncionesTarjeta.mostrarModal("autorizacionClienteCargo"); //eventProcesaSolicitudAutorizacion()        
    }
    catch (oError) {
        manejaExcepcionLecturaPinpad(oError);
    }
}

function eventProcesaSolicitudAutorizacion()
{   
    try
    {
        FuncionesTarjeta.mostrarModal("solicitandoAutorizacionBanco");
        entrada = obtenVariableSesion('parametrosDeAutorizacion'); 
        procesaSolicitudAutorizacion(entrada).done(function (respuesta) {
            try
            {
                timeStampErroresTarjeta = Commons.getStampId(datosOperacion.wS);                          
                if (!isDefined(respuesta)) {
                    registraHistorial("El servicio para procesaSolicitudAutorizacion no ha respondido, respuesta= "+JSON.stringify(respuesta, null, 4),timeStampErroresTarjeta,3);                                                
                    finalizarPinpadLecturaError("No se obtuvo respuesta del servicio de Autorizacion.  </br>[Código de seguimiento:"+timeStampErroresTarjeta+"]");
                    return;
                }
                if (!isDefined(respuesta.RespuestaString)) {
                    registraHistorial("El servicio para procesaSolicitudAutorizacion no ha respondido correctamente, respuesta= "+JSON.stringify(respuesta, null, 4),timeStampErroresTarjeta,3);                                                
                    finalizarPinpadLecturaError("El servicio de autorizacion no ha podido procesar la autorización</br>[Código de seguimiento:"+timeStampErroresTarjeta+"]");
                    return;
                }
                if (isDefined(respuesta.Controlador)){
                    if(respuesta.Controlador !=="")
                        guardaControladorSesion(respuesta.Controlador);    
                }
                
                var respuestaValidacion = eval("(" + respuesta.RespuestaString + ")");
                let errorRespuesta = BuscarErroresEnRespuesta(respuestaValidacion);
                if (errorRespuesta !=="") {
                    registraHistorial("El servicio de procesaSolicitudAutorizacion ha respondido con codigo de error, respuestaValidacion= "+JSON.stringify(respuestaValidacion, null, 4),timeStampErroresTarjeta,3);
                    finalizarPinpadLecturaError(errorRespuesta+"</br>[Código de seguimiento:"+timeStampErroresTarjeta+"]");
                    return;
                } 
                
                registraHistorial("El servicio para procesaSolicitudAutorizacion ha respondido correctamente, respuesta= "+JSON.stringify(respuesta, null, 4),timeStampErroresTarjeta,1);                                                
                
                if (!isDefined(respuesta.Controlador))
                {
                    registraHistorial("El servicio de procesaSolicitudAutorizacion no ha respondido correctamente, respuesta= "+JSON.stringify(respuesta, null, 4),timeStampErroresTarjeta,3);
                    finalizarPinpadLecturaError("El servicio para procesar la solicitud de autorización no ha respondido correctamente. </br>[Código de seguimiento:"+timeStampErroresTarjeta+"]");
                    return;   
                }
                if (!(respuestaValidacion.CodigoRespuesta.length > 0 && respuestaValidacion.NumeroAutorizacion.length > 0))
                {
                    registraHistorial("El servicio de procesaSolicitudAutorizacion ha respondido con datos incompletos, respuesta= "+JSON.stringify(respuesta, null, 4),timeStampErroresTarjeta,3);
                    finalizarPinpadLecturaError("No se puede Terminar la venta, no se enviaron algunos valores requeridos. Consulte a su banco emisor.. </br>[Código de seguimiento:"+timeStampErroresTarjeta+"]");
                    return;      
                }
                var auxc55 = respuestaValidacion.c55.split(' ').join('%20');
                auxc55 = auxc55.split('&').join('@');
                vpCodigoAuth = respuestaValidacion.NumeroAutorizacion;
                parametros = {
                    responseCode : respuestaValidacion.CodigoRespuesta,
                    authorizationCode : respuestaValidacion.NumeroAutorizacion,
                    respHost : respuestaValidacion.strRespHost,
                    c63 : auxc55,
                    esAMEX : respuestaValidacion.esAMEX,
                    esTarjetaConChip : vpEsTarjetaConChip
                }

                vpEsAmex = respuestaValidacion.esAMEX;
                
                finalizaTransaccionCifradoPinpad(parametros);            
            }
            catch (oError) {
                manejaExcepcionLecturaPinpad(oError);
            }
        }); 
        $.LoadingOverlay("hide");
    }
    catch (oError) {
        manejaExcepcionLecturaPinpad(oError);
    }
}


function finalizaTransaccionCifradoPinpad(parametros){
    try
    {
        FuncionesTarjeta.mostrarModal("espereInstruccionesPinpad");
        terminandoTransaccionCifrado(parametros).done(function (respuesta) {
            try
            {
                timeStampErroresTarjeta = Commons.getStampId(datosOperacion.wS);      
                if (!isDefined(respuesta)) {
                    registraHistorial("El servicio para terminandoTransaccionCifrado no ha respondido, respuesta= "+JSON.stringify(respuesta, null, 4),timeStampErroresTarjeta,3);                                                
                    finalizarPinpadLecturaError("No se obtuvo respuesta del servicio de PinPad para terminar la venta. </br>[Código de seguimiento:"+timeStampErroresTarjeta+"]");
                    return;
                }
                if (!isDefined(respuesta.EstatusGrabadoChip)) {
                    registraHistorial("El servicio para terminandoTransaccionCifrado no ha respondido correctamente, respuesta= "+JSON.stringify(respuesta, null, 4),timeStampErroresTarjeta,3);                                                
                    finalizarPinpadLecturaError("El servicio de PinPad para procesar la autorización</br>[Código de seguimiento:"+timeStampErroresTarjeta+"]");
                    return;
                }

                let terminadoTransaccion = "false";
                if (isDefined(respuesta.Error) && (respuesta.Error === "" || respuesta.Error === 0 || respuesta.Error === "0"))
                {
                    terminadoTransaccion = "true";
                }            
                var parametros = {
                    controlador : obtenControladorSesion(), //string        
                    terminadoTransaccion : terminadoTransaccion, //string
                    grabadoChip : respuesta.EstatusGrabadoChip , //string
                    status :respuesta.Estatus, //string
                    pan : vpPAN//string
                };
                validaTerminadoVenta(parametros);
            }
            catch (oError) {
                manejaExcepcionLecturaPinpad(oError);
            }
        });         
    }
    catch (oError) {
        manejaExcepcionLecturaPinpad(oError);
    }
}


function validaTerminadoVenta(parametros){
    validaTerminarVenta(parametros).done(function (respuesta) {
        try
        {
            timeStampErroresTarjeta = Commons.getStampId(datosOperacion.wS);      
            if (!isDefined(respuesta)) {
                registraHistorial("El servicio de validaTerminarVenta no ha respondido, respuesta = "+JSON.stringify(respuesta, null, 4),timeStampErroresTarjeta,3);                                                
                finalizarPinpadLecturaError("No se ha obtenido respuesta del servicio para terminar la venta. </br>[Código de seguimiento:"+timeStampErroresTarjeta+"]");
                return;
            }
            if (!isDefined(respuesta.RespuestaString)) {
                registraHistorial("El servicio de validaTerminarVenta no ha respondido correctamente, respuesta = "+JSON.stringify(respuesta, null, 4),timeStampErroresTarjeta,3);
                finalizarPinpadLecturaError("Ha ocurrido un problema al procesar la terminación de la venta. </br>[Código de seguimiento:"+timeStampErroresTarjeta+"]");
                return;
            }
            if (isDefined(respuesta.Controlador)){
                if(respuesta.Controlador !=="")
                    guardaControladorSesion(respuesta.Controlador);    
            }
            var informacionRespuesta = eval("(" + respuesta.RespuestaString + ")");
            if (informacionRespuesta.error != 0) {  
                registraHistorial("El servicio de validaTerminarVenta ha respondido con codigo de error, respuesta = "+JSON.stringify(respuesta, null, 4),timeStampErroresTarjeta,3);                

                var respuestaReverso = eval("(" + informacionRespuesta.valor + ")");

                if (respuestaReverso.error != 0)
                    finalizarPinpadLecturaError(informacionRespuesta.descripcionError+" </br>El reverso se realizó correctamente.")
                else
                    finalizarPinpadLecturaError(informacionRespuesta.descripcionError + " </br>" + respuestaReverso.descripcionError)   
                return               
            }   

            if (!isDefined(respuesta.Controlador))
            {
                timeStampErroresTarjeta = Commons.getStampId(datosOperacion.wS);      
                registraHistorial("El servicio de procesaSolicitudAutorizacion no ha respondido correctamente, respuesta= "+JSON.stringify(respuesta, null, 4),timeStampErroresTarjeta,3);                                                            
                finalizarPinpadLecturaError("El servicio para procesar la solicitud de autorización no ha respondido correctamente. </br>[Código de seguimiento:"+timeStampErroresTarjeta+"]");
                return;   
            }

            validaFirmaElectronica();
        }
        catch (oError) {
            manejaExcepcionLecturaPinpad(oError);
        }
    });
}

function validaFirmaElectronica(){
    try
    {
        var parametros = {
            controlador: obtenControladorSesion(), //string        
            parametroString: vpPAN //string
        };
        conFirmaElectronica(parametros).done(function (respuesta) {
            try
            {
                timeStampErroresTarjeta = Commons.getStampId(datosOperacion.wS);                          
                esConFirmaElectronica = false;
                puedeValidarLlaves = true;
                if (!isDefined(respuesta)) {
                    registraHistorial("El servicio de conFirmaElectronica no ha respondido, respuesta = "+JSON.stringify(respuesta, null, 4),timeStampErroresTarjeta,3);                                                
                    avisaError("No se ha obtenido respuesta del servicio para validar firma electrónica. </br>[Código de seguimiento:"+timeStampErroresTarjeta+"]");
                    return;
                }
                if (!isDefined(respuesta.RespuestaString)) {
                    registraHistorial("El servicio de conFirmaElectronica no ha respondido correctamente, respuesta = "+JSON.stringify(respuesta, null, 4),timeStampErroresTarjeta,3);                                                
                    avisaError("Ha ocurrido un problema al procesar la terminación de la venta. </br>[Código de seguimiento:"+timeStampErroresTarjeta+"]");
                    return;
                }
                if (isDefined(respuesta.Controlador)){
                    if(respuesta.Controlador !=="")
                        guardaControladorSesion(respuesta.Controlador);    
                }

                var informacionRespuesta = eval("(" + respuesta.RespuestaString + ")");
                let errorRespuesta = BuscarErroresEnRespuesta(informacionRespuesta);
                if (errorRespuesta !== "") {
                    registraHistorial("El servicio de conFirmaElectronica ha respondido con código de error, respuesta = "+JSON.stringify(respuesta, null, 4),timeStampErroresTarjeta,3);                                                
                    finalizarPinpadLecturaError(errorRespuesta+"</br>[Código de seguimiento:"+timeStampErroresTarjeta+"]");
                    return
                }
                
                if (!isDefined(respuesta.Controlador))
                {
                    timeStampErroresTarjeta = Commons.getStampId(datosOperacion.wS);      
                    registraHistorial("El servicio de validaFirmaElectronica no ha respondido correctamente, respuesta= "+JSON.stringify(respuesta, null, 4),timeStampErroresTarjeta,3);                                                            
                    finalizarPinpadLecturaError("El servicio para procesar la firma electrónica no ha respondido correctamente. </br>[Código de seguimiento:"+timeStampErroresTarjeta+"]");
                    return;   
                }                
                if (informacionRespuesta.valor.toString() == "True"){ 
                    FuncionesTarjeta.mostrarModal("pagoAutorizadoConFirma");                                    
                }
                else
                {
                    FuncionesTarjeta.mostrarModal("pagoAutorizadoSinFirma");
                    procesaFinalizadoVentaTarjeta();                    
                }

            }
            catch (oError) {
                manejaExcepcionLecturaPinpad(oError);
            }
        });
    }
    catch (oError) {
        manejaExcepcionLecturaPinpad(oError);
    }
}


function procesaGuardadoFirma(){
    cerrarModal();
    $.LoadingOverlay("show");
    
    var nombreImagen = "firmaElectronicaClte"; 
       
    let entrada = {
        nombreRutaImagen:nombreImagen,
        tiempoEspera:20
    };

    guardarFirmaCliente(entrada).done(function (respuesta) {
        try
        {
            $.LoadingOverlay("hide");
            timeStampErroresTarjeta = Commons.getStampId(datosOperacion.wS);      
            if (!isDefined(respuesta)) {
                registraHistorial("El servicio de guardarFirmaCliente no ha respondido, respuesta = "+JSON.stringify(respuesta, null, 4),timeStampErroresTarjeta,3);
                FuncionesTarjeta.mostrarModal("reintentoFirmaCliente");
                msg= "No se ha obtenido respuesta del servicio para guardar la Firma."
                let e = document.getElementById("modal00").querySelector("#lblError");
                e.innerHTML = msg;                
                return;
            }
            if (!isDefined(respuesta.Estatus)) {
                registraHistorial("El servicio de guardarFirmaCliente no ha respondido correctamente, respuesta = "+JSON.stringify(respuesta, null, 4),timeStampErroresTarjeta,3);                                                
                FuncionesTarjeta.mostrarModal("reintentoFirmaCliente");
                msg= "Ha ocurrido un problema al procesar la Firma del cliente."
                let e = document.getElementById("modal00").querySelector("#lblError");
                e.innerHTML = msg;                
                return;
            }
            if(respuesta.Estatus != 0)
            {
                var msgErrorFirma = ""
                switch (respuesta.Estatus) {
                    case 6:
                        registraHistorial("El servicio de guardarFirmaCliente ha respondido con código de error, respuesta = "+JSON.stringify(respuesta, null, 4),timeStampErroresTarjeta,3);                                                                
                        msgErrorFirma= "Se ha agotado el tiempo, por favor vuelva a intentarlo."                    
                    break;
                    case 7:
                        registraHistorial("El servicio de guardarFirmaCliente ha respondido con código de error, respuesta = "+JSON.stringify(respuesta, null, 4),timeStampErroresTarjeta,3);                                                                
                        msgErrorFirma= "El usuario cancelo la firma, por favor vuelva a intentarlo."
                    break;
                    default:
                        registraHistorial("El servicio de guardarFirmaCliente ha respondido con código de error, respuesta = "+JSON.stringify(respuesta, null, 4),timeStampErroresTarjeta,3);                                                                
                        msgErrorFirma= "Guardado de la firma ha fallado."+ " </br>[Código de seguimiento:"+timeStampErroresTarjeta+"]";
                    break;
                }
                FuncionesTarjeta.mostrarModal("reintentoFirmaCliente");
                let e = document.getElementById("modal00").querySelector("#lblError");
                e.innerHTML = msgErrorFirma;                
                return;
            }
                        
            procesaObtencionFirma();
        }
        catch (oError) {
            timeStampErroresTarjeta = Commons.getStampId(datosOperacion.wS); 
            registraHistorial("Ha ocurrido un error no controlado en procesaGuardadoFirma, respuesta = "+JSON.stringify(oError, null, 4),timeStampErroresTarjeta,3);
            FuncionesTarjeta.mostrarModal("reintentoFirmaCliente");
            msg= "Ha ocurrido un error no controlado al procesar la obtención de la firma dígital del cliente." + " </br>[Código de seguimiento:"+timeStampErroresTarjeta+"]";
            let e = document.getElementById("modal00").querySelector("#lblError");
            e.innerHTML = msg;   
        }
    });       
}

function procesaObtencionFirma()
{
    let entrada = ""

    obtenerFirmaCliente(entrada).done(function (respuesta) {
        try
        {
            timeStampErroresTarjeta = Commons.getStampId(datosOperacion.wS);      
            if (!isDefined(respuesta)) {
                registraHistorial("El servicio de obtenerFirmaCliente no ha respondido, respuesta = "+JSON.stringify(respuesta, null, 4),timeStampErroresTarjeta,3);
                FuncionesTarjeta.mostrarModal("reintentoFirmaCliente");
                msg= "No se ha obtenido respuesta del servicio para obtener la Firma."
                let e = document.getElementById("modal00").querySelector("#lblError");
                e.innerHTML = msg;                
                return;
            }
            if (!isDefined(respuesta.Estatus)) {
                registraHistorial("El servicio de obtenerFirmaCliente no ha respondido correctamente, respuesta = "+JSON.stringify(respuesta, null, 4),timeStampErroresTarjeta,3);                                                
                FuncionesTarjeta.mostrarModal("reintentoFirmaCliente");
                msg= "Ha ocurrido un problema al procesar la Firma del cliente."
                let e = document.getElementById("modal00").querySelector("#lblError");
                e.innerHTML = msg;                
                return;
            }
            if(respuesta.Estatus != 0)
            {
                var msgErrorFirma = ""
                switch (respuesta.Estatus) {
                    case 1:
                        registraHistorial("El servicio de obtenerFirmaCliente ha respondido con código de error, respuesta = "+JSON.stringify(respuesta, null, 4),timeStampErroresTarjeta,3);                                                                
                        msgErrorFirma= "No se ha encontrado la firma en el registro, por favor vuelva a intentarlo."                    
                    break;
                    case 2:
                        registraHistorial("El servicio de obtenerFirmaCliente ha respondido con código de error, respuesta = "+JSON.stringify(respuesta, null, 4),timeStampErroresTarjeta,3);                                                                
                        msgErrorFirma= "Ha ocurrido un problema en el guardado del archivo de la firma dígital."+ " </br>[Código de seguimiento:"+timeStampErroresTarjeta+"]";
                    break;
                    default:
                        registraHistorial("El servicio de obtenerFirmaCliente ha respondido con código de error, respuesta = "+JSON.stringify(respuesta, null, 4),timeStampErroresTarjeta,3);                                                                
                        msgErrorFirma= "Obtención de la firma ha fallado."+ " </br>[Código de seguimiento:"+timeStampErroresTarjeta+"]";
                    break;
                }
                FuncionesTarjeta.mostrarModal("reintentoFirmaCliente");
                let e = document.getElementById("modal00").querySelector("#lblError");
                e.innerHTML = msgErrorFirma;                
                return;
            }
            vpRutaImagenFirma = respuesta.RutaImagen;
            procesaMarcaAgua(respuesta.RutaImagen)
            //Marca de agua...
        }
        catch (oError) {
            timeStampErroresTarjeta = Commons.getStampId(datosOperacion.wS); 
            registraHistorial("Ha ocurrido un error no controlado en procesaObtencionFirma, respuesta = "+JSON.stringify(oError, null, 4),timeStampErroresTarjeta,3);
            FuncionesTarjeta.mostrarModal("reintentoFirmaCliente");
            msg= "Ha ocurrido un error no controlado al procesar la obtención de la firma dígital del cliente." + " </br>[Código de seguimiento:"+timeStampErroresTarjeta+"]";
            let e = document.getElementById("modal00").querySelector("#lblError");
            e.innerHTML = msg;   
        }
    });    
}


function procesaMarcaAgua(rutaImagenFirma)
{
    let entrada = {
        ruta:rutaImagenFirma,
        fecha:Commons.getDateDDMMYYYY(),
        hora:Commons.getHourHHmm(),
        noOperacion:vpCodigoAuth,
        color:45
    };

    crearMarcaAgua(entrada).done(function (respuesta) {
        try
        {
            timeStampErroresTarjeta = Commons.getStampId(datosOperacion.wS);      
            if (!isDefined(respuesta)) {
                registraHistorial("El servicio de crearMarcaAgua no ha respondido, respuesta = "+JSON.stringify(respuesta, null, 4),timeStampErroresTarjeta,3);
                FuncionesTarjeta.mostrarModal("reintentoFirmaCliente");
                msg= "No se ha obtenido respuesta del servicio para generar la marca de agua." + " </br>[Código de seguimiento:"+timeStampErroresTarjeta+"]";
                let e = document.getElementById("modal00").querySelector("#lblError");
                e.innerHTML = msg;                
                return;
            }
            if (!isDefined(respuesta.Estatus)) {
                registraHistorial("El servicio de crearMarcaAgua no ha respondido correctamente, respuesta = "+JSON.stringify(respuesta, null, 4),timeStampErroresTarjeta,3);                                                
                FuncionesTarjeta.mostrarModal("reintentoFirmaCliente");
                msg= "Ha ocurrido un problema al procesar la marca de agua." + " </br>[Código de seguimiento:"+timeStampErroresTarjeta+"]";
                let e = document.getElementById("modal00").querySelector("#lblError");
                e.innerHTML = msg;                
                return;
            }
            if(respuesta.Estatus != 1)
            {
                registraHistorial("El servicio de crearMarcaAgua ha respondido con codigo de error, respuesta = "+JSON.stringify(respuesta, null, 4),timeStampErroresTarjeta,3);                                                
                FuncionesTarjeta.mostrarModal("reintentoFirmaCliente");
                msg= "Ha ocurrido un problema al procesar la marca de agua." + " </br>[Código de seguimiento:"+timeStampErroresTarjeta+"]";
                let e = document.getElementById("modal00").querySelector("#lblError");
                e.innerHTML = msg;                
                return;
            }
            vpRutaImagenBase64 = respuesta.ImgBase64;
            FuncionesTarjeta.mostrarModal("firmaClienteCoincide"); //Continua en SubeImgenServidor()
            msg= '<img src="data:image/png;base64, '+vpRutaImagenBase64+'" alt="firmaCliente" />';
            let e = document.getElementById("modal00").querySelector("#lblImg");
            e.innerHTML = msg;                            
        }
        catch (oError) {
            timeStampErroresTarjeta = Commons.getStampId(datosOperacion.wS); 
            registraHistorial("Ha ocurrido un error no controlado en procesaMarcaAgua, respuesta = "+JSON.stringify(oError, null, 4),timeStampErroresTarjeta,3);
            FuncionesTarjeta.mostrarModal("reintentoFirmaCliente");
            msg= "Ha ocurrido un error no controlado al procesar la obtención de la firma dígital del cliente." + " </br>[Código de seguimiento:"+timeStampErroresTarjeta+"]";
            let e = document.getElementById("modal00").querySelector("#lblError");
            e.innerHTML = msg;   
        }
    });    
}

function SubeImgenServidor(){
    let entrada = {
        pan: vpPAN, //string        
        idSesion: datosOperacion.idSesion, //string        
        imagenBase64: vpRutaImagenBase64, //string        
        controlador: obtenControladorSesion() //string
    };

    uploadFirmaElectronica(entrada).done(function (respuesta) {
        try
        {
            timeStampErroresTarjeta = Commons.getStampId(datosOperacion.wS);      
            if (!isDefined(respuesta)) {
                registraHistorial("El servicio de uploadFirmaElectronica no ha respondido, respuesta = "+JSON.stringify(respuesta, null, 4),timeStampErroresTarjeta,3);
                FuncionesTarjeta.mostrarModal("reintentoFirmaCliente");
                msg= "No se ha obtenido respuesta del servicio para guardar la imagen digital de la firma." + " </br>[Código de seguimiento:"+timeStampErroresTarjeta+"]";
                let e = document.getElementById("modal00").querySelector("#lblError");
                e.innerHTML = msg;                
                return;
            }
            if (!isDefined(respuesta.RespuestaString)) {
                registraHistorial("El servicio de uploadFirmaElectronica no ha respondido correctamente, respuesta = "+JSON.stringify(respuesta, null, 4),timeStampErroresTarjeta,3);                                                
                FuncionesTarjeta.mostrarModal("reintentoFirmaCliente");
                msg= "Ha ocurrido un problema al procesar la marca de agua." + " </br>[Código de seguimiento:"+timeStampErroresTarjeta+"]";
                let e = document.getElementById("modal00").querySelector("#lblError");
                e.innerHTML = msg;                
                return;
            }
            if(isDefined(respuesta.Controlador))
            {
                if (respuesta.Controlador !== "")
                    guardaControladorSesion(respuesta.Controlador);
            }
            var respuestaProcesada = eval("(" + respuesta.RespuestaString + ")");
                
            let errorRespuesta = BuscarErroresEnRespuesta(respuestaProcesada)
            if (errorRespuesta!=="") {
                registraHistorial("El servicio de uploadFirmaElectronica ha respondido con codigo de error, respuesta = "+JSON.stringify(respuesta, null, 4),timeStampErroresTarjeta,3);                                                
                FuncionesTarjeta.mostrarModal("reintentoFirmaCliente");
                msg= "Ha ocurrido un problema al procesar la subida al servidor." + " </br>[Código de seguimiento:"+timeStampErroresTarjeta+"]";
                let e = document.getElementById("modal00").querySelector("#lblError");
                e.innerHTML = msg;             
                return;
            }
            
            procesaFinalizadoVentaTarjeta();
            //Marca de agua...
        }
        catch (oError) {
            timeStampErroresTarjeta = Commons.getStampId(datosOperacion.wS); 
            registraHistorial("Ha ocurrido un error no controlado en SubeImgenServidor, respuesta = "+JSON.stringify(oError, null, 4),timeStampErroresTarjeta,3);
            FuncionesTarjeta.mostrarModal("reintentoFirmaCliente");
            msg= "Ha ocurrido un error no controlado al procesar la obtención de la firma dígital del cliente." + " </br>[Código de seguimiento:"+timeStampErroresTarjeta+"]";
            let e = document.getElementById("modal00").querySelector("#lblError");
            e.innerHTML = msg;   
        }
    }); 
}

function procesaFinalizadoVentaTarjeta(){
    cerrarModal();
    actualizaVistaDetallePagos();                
    manejaFinalizadoPinPad();
    FuncionesTarjeta.limpiaPantalla();

}


var FuncionesTarjeta = {
    mostrarModal: function mostrarModal(tipo) {
        let html = ManejadorMsgTarjetas.getContent(tipo);
        muestraModal(html);
    },
    permiteReintentoLectura: function permiteReintentoLectura()
    {
        $('#txtTbanImporte').html('<input id="txtTban" tabindex="3" type="text" onkeypress="eventValidaImporteTBan(event)" placeholder="$0.0" class="tLeft" disabled="" style="opacity: 0.3;">');
        enableElements($('#txtTban'));
        enableElements($('#txtfolioIdentificacion'));
        enableElements($('#slcTipoIdentificacion'));    
    },
    limpiaPantalla: function limpiaPantalla(){
        isFallBack = false;
        FailedAttempts = 0;
        ReadAttemptsChip = 0;
        isServicePinPadOn = false;
        vpEsTarjetaConChip = "";
        vpPAN = "";
        vpCardHolder= "";
        vpTOKENS_EZ_EY_ES= "";
        vpC55= "";
        vpC55Len= "";
        vpEsAmex = ""; 
        vpCodigoAuth = "";
        $('#txtTbanImporte').html('<input id="txtTban" tabindex="3" type="text" onkeypress="eventValidaImporteTBan(event)" placeholder="$0.0" class="tLeft">');
        enableElements($('#slcTipoIdentificacion')); 
        let e = document.getElementById("slcTipoIdentificacion");
        e.selectedIndex= 0; 
        document.getElementById('txtfolioIdentificacion').value = "";
        disableElements($('#txtTban'));
        disableElements($('#txtfolioIdentificacion'));
    }   
         
};
//# sourceURL= funcionesTarjeta.js