﻿/*
* @Author: jagonzalezu
* @Date:   2018-02-10 20:07:40
* @Last Modified by:   jagonzalezu
* @Last Modified time: 2018-03-20 18:54:47
*/
var timeStampErroresCommons;
var sesionRandomId = "";
var modalContent;
var keyIsDown; 
var loadingOverLayShowed
$(document).ready(function () {   
    let e = document.getElementById("modal00");
    if(e === null || e === undefined || e === "")
    {
        $("body").append('<div id="modal00" class="modal"> </div>');        
    }       
    e = document.getElementById("whiteOverlay");
    if(e === null || e === undefined || e === "")
    {
        $("body").append('<div id="whiteOverlay"></div>');  
        $("<style type='text/css'> #whiteOverlay { background-color: rgba(255,255,255, 1); z-index: 999; position: absolute; left: 0; top: 0; width: 100%; height: 100%; display: none;} </style>").appendTo("head");                
    }                 
    e = document.getElementById("transparentOverlay");
    if(e === null || e === undefined || e === "")
    {
        $("body").append('<div id="transparentOverlay"></div>');  
        $("<style type='text/css'> #transparentOverlay { background-color: rgba(255,255,255, 0.5); z-index: 999; position: absolute; left: 0; top: 0; width: 100%; height: 100%; display: none;} </style>").appendTo("head");                
    }                     
});

function generaHeader(noEmpleado,ws){
    let e = document.getElementsByClassName("header");
    if(e === null || e === undefined || e === "")
    {   
        return;   
    }
    if(e.length<=0){
        return;
    }
    contenido = '<div class="tblHeader">\
                    <div class="headerLogo">\
                        <a href="#">\
                            <img src="../../Imgs/logo-baz.svg"  id="imgLogo">\
                        </a>\
                    </div>\
                    <div class="headerUser">\
                            <div class="name">\
                            <b id="tagNoEmpleado"></b><span id="tagEmpNombre"></span><br>\
                            <b id="tagPuesto"></b><span id="tagEmpDescripcion"></span><br>\
                            <b id="tagEstrab"></b><span id="tagEstacion"></span><br>\
                        </div>\
                        <div class="pic-name">\
                        </div>\
                            <div class="fecha">\
                            <b id="tagFecha"></b><br>\
                            <span id="tagHora"></span> | <span id="tagPais"></span>\
                        </div>\
                    </div>\
                </div>'
    e[0].innerHTML = contenido;
    entrada = {
        noEmpleado : noEmpleado
    }
    datosUsuario(entrada).done(function(obj){
        if(!isDefined(obj)){
            timeStampErroresCommons = Commons.getStampId();      
            registraHistorial("El servicio de datosUsuario de caja comun no respondio correctamente: obj = "+JSON.stringify(obj, null, 4),timeStampErroresCommons,3);
            avisaError("El servicio de datos común no respondió correctamente. No se mostrará los datos del usuario en el encabezado de la pagina.")
            return;
        }
        if(obj.NoError!=0){
            timeStampErroresCommons = Commons.getStampId();      
            registraHistorial("El servicio de datosUsuario de caja comun respondio con codigo de error: obj = "+JSON.stringify(obj, null, 4),timeStampErroresCommons,3);
            avisaError("El servicio de datos común no respondió correctamente. No se mostrará los datos del usuario en el encabezado de la pagina.")
            return;
        }
        var date = new Date();
        $('#tagHora').html(date.getHours() + ":" + date.getMinutes() + " Hrs.");
        let mes = MesLetra ((date.getMonth() + 1));
        $('#tagFecha').html(date.getDate() + "/" + mes + "/" + date.getFullYear()); 
        $('#tagNoEmpleado').html(obj.InformacionInicial.NoEmpleado);
        $('#tagEmpNombre').html(" - " + obj.InformacionInicial.NombreEmpleado);
        $('#tagPuesto').html(obj.InformacionInicial.PuestoBase);
        $('#tagEmpDescripcion').html(" - " + obj.InformacionInicial.DescripcionPBase);
        $('#tagEstrab').html("ESTACIÓN: ");
        $('#tagEstacion').html(ws);
        empleadoPuesto = obj.InformacionInicial.PuestoRol;
        $('#tagPais').html(obj.InformacionInicial.DescripcionPais);
        
        try{
            $('#tagNumTienda').html(obj.InformacionInicial.NoTienda);
            $('#tagNombreTienda').html(obj.InformacionInicial.NombreTienda);    
        }
        catch(oError){
            return;
        }                
    });
}
function MesLetra(mes) {
    var mesLetra = "";
    switch (mes) {
        case 1: 
            mesLetra = "Ene";
        break;
        case 2:
            mesLetra = "Feb";
        break;
        case 3:
            mesLetra = "Mar";
        break;
        case 4:
            mesLetra = "Abr";
        break;
        case 5:
            mesLetra = "May";
        break;
        case 6:
            mesLetra = "Jun";
        break;
        case 7:
            mesLetra = "Jul";
        break;
        case 8:
            mesLetra = "Ago";
        break;
        case 9:
            mesLetra = "Sep";
        break;
        case 10:
            mesLetra = "Oct";
        break;
        case 11:
            mesLetra = "Nov";
        break;
        case 12:
            mesLetra = "Dic";
        break;
        }
    return mesLetra;
}
function ocultarElementosPantalla(){
    $('#whiteOverlay').show();
}

function mostrarElementosPantalla(){
    $('#whiteOverlay').hide();
}

function deshabilitarPantalla(){
    $('#transparentOverlay').show();    
}

function habilitarPantalla(){
    $('#transparentOverlay').hide();    
}

function muestraModal(html)
{
    cerrarModal();        
    $('#modal00').empty();
    $('#modal00').append(html);
    $('#modal00').modal({escClose:false});   
}

function doJsonPost(urlServicio, parmsIn, closeOnError=false,aliasServicio = "") {
    substring = "RegistraHistorial";    
    if(urlServicio.indexOf(substring) === -1){
        timeStampErroresCommons = Commons.getStampId();      
        registraHistorial("Se ha realizado un doJsonPost urlServicio= " + JSON.stringify(urlServicio, null, 4) + " Parametros de entrada: " + JSON.stringify(parmsIn, null, 4) + "\n closeOnError = "+ JSON.stringify(closeOnError, null, 4),timeStampErroresCommons,0);            
    }
    return $.ajax({
        type: 'POST',
        url: urlServicio,
        data: JSON.stringify(parmsIn),
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        crossDomain: true,
        aliasServicio: aliasServicio,
        beforeSend: function(jqXHR, settings) {
            jqXHR.url = settings.url;        
        },
        success: function(result,status,jqXHR){
            timeStampErroresCommons = Commons.getStampId();      
            registraHistorial("doJsonPost ha respondido result= " + JSON.stringify(result, null, 4)+" \n"+" jqXHR.url= " + JSON.stringify(jqXHR.url, null, 4),timeStampErroresCommons,0);                            
        },
        error: function (jqXHR, exception) {
            timeStampErroresCommons = Commons.getStampId();      
            registraHistorial("Ha ocurrido un error en doJsonPost jqXHR= " + JSON.stringify(jqXHR, null, 4)+" \n exception= " + JSON.stringify(exception, null, 4),timeStampErroresCommons,3);
            var msgError = "Ha ocurrido un problema con el servicio "
            var msgAliasServicio ="";
            if(this.aliasServicio!="" && isDefined(this.aliasServicio)){                
                msgAliasServicio = "de "+this.aliasServicio;
            }
            if (closeOnError)
            {
                finalizarConError(msgError+msgAliasServicio+" y se cerrará la ventana, en caso de que el problema persista contacte a soporte: </br>[Código de seguimiento:"+timeStampErroresCommons+"]");
            }
            else
            {
                avisaError(msgError+msgAliasServicio+", en caso de que el problema persista contacte a soporte: </br>[Código de seguimiento:"+timeStampErroresCommons+"]");
            }
        },
    })
}


function doHistorialPost(urlServicio, parmsIn, closeOnError) {    
    let parmsEntrada = JSON.stringify(parmsIn, null, 4)               
    var stringControlador = parmsEntrada.match(/"([^"]*(?=A{3}).*?)"/);
    if(!(stringControlador === "" || stringControlador === null ||stringControlador ===undefined))
    {
        $.each(stringControlador, function( index, value ) {
            parmsEntrada = parmsEntrada.replace(value, value.substring(0, 30)+ '..."')
        });
    }
    if(isDefined(parmsIn.NivelSeveridad))
    {
        var entrada = {
        Mensaje:parmsEntrada,
        NivelSeveridad:parmsIn.NivelSeveridad
        } 
    }
    else
    {
        var entrada = {
            Mensaje:parmsEntrada            
        } 
    }
    return $.ajax({
        type: 'POST',
        url: urlServicio,
        data: JSON.stringify(entrada),
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        crossDomain: true,
        error: function (jqXHR, exception) {
            var msg = '';
            timeStampErroresCommons = Commons.getStampId();      
            if (jqXHR.status === 0) {
                msg = 'No hay conexión o el servicio no se encuentra disponible.\n Verifique la red.';
            }
            else if (exception === 'timeout') {
                msg = 'La conexión a tardado demasiado en responder.';
            } else {
                msg = 'Error no identificado: \n' + jqXHR.responseText;
            }
            alert(msg);
        },
    })
}


function doUrlPost(urlServicio, closeOnError,aliasServicio="") {
    substring = "RegistraHistorial";    
    if(urlServicio.indexOf(substring) === -1){
        timeStampErroresCommons = Commons.getStampId();      
        registraHistorial("Se ha realizado un doUrlPost urlServicio= " + JSON.stringify(urlServicio, null, 4) + "\n closeOnError = "+ JSON.stringify(closeOnError, null, 4),timeStampErroresCommons,0);            
    }
    return $.ajax({
        type: 'POST',
        url: urlServicio,
        //contentType: "application/json",
        //dataType: "json",
        crossDomain: true,
        aliasServicio:aliasServicio,
        beforeSend: function(jqXHR, settings) {
            jqXHR.url = settings.url;
        },
        success: function(result,status,jqXHR){
            timeStampErroresCommons = Commons.getStampId();      
            registraHistorial("doUrlPost ha respondido result= " + JSON.stringify(result, null, 4)+" \n jqXHR.url= " + JSON.stringify(jqXHR.url, null, 4),timeStampErroresCommons,0);                
        },                
        error: function (jqXHR, exception) {            
            timeStampErroresCommons = Commons.getStampId();      
            registraHistorial("Ha ocurrido un error en doUrlPost jqXHR= " + JSON.stringify(jqXHR, null, 4)+" \n exception= " + JSON.stringify(exception, null, 4),timeStampErroresCommons,3);    
            var msgError = "Ha ocurrido un problema con el servicio "
            var msgAliasServicio ="";
            if(this.aliasServicio!="" && isDefined(this.aliasServicio)){                
                msgAliasServicio = "de "+this.aliasServicio;
            }
            if (closeOnError)
            {
                finalizarConError(msgError+msgAliasServicio+" y se cerrará la ventana, en caso de que el problema persista contacte a soporte: </br>[Código de seguimiento:"+timeStampErroresCommons+"]");
            }
            else
            {
                avisaError(msgError+msgAliasServicio+", en caso de que el problema persista contacte a soporte: </br>[Código de seguimiento:"+timeStampErroresCommons+"]");
            }
        },
    })
}


function cerrarModal() {
    try
    {
        let el = document.getElementById('botonCerrar');
        if(el === undefined ||el === ""  || el === null )
            return;
        let etype = 'click';

        if (el.fireEvent) {
            el.fireEvent('on' + etype);
        } else {
            let evObj = document.createEvent('Events');
            evObj.initEvent(etype, true, false);
            el.dispatchEvent(evObj);
        }    
    }
    catch (oError) {
        timeStampErroresCommons = Commons.getStampId();      
        registraHistorial("Ocurrió un error no controlado en cerrarModal oError = "+JSON.stringify(oError, null, 4),timeStampErroresCommons);                                                
        finalizarConError("Algo salio mal cerrando un mensaje modal, si el problema persiste favor de comunicarse a soporte." + " </br>[Código de seguimiento:"+timeStampErroresCommons+"]");
        return;
    }
}

function finalizarConError(msg) {
    FuncionesCommons.mostrarModal('errorFin');
    let e = document.getElementById("modal00").querySelector("#lblError");
    e.innerHTML = msg;
    $.LoadingOverlay("hide");
}

function avisaError(msg) {
    FuncionesCommons.mostrarModal('error');
    let e = document.getElementById("modal00").querySelector("#lblError");
    e.innerHTML = msg;
    $.LoadingOverlay("hide");
}

var Commons = {
    getStampId:function getStampId(sesion){
        if(!isDefined(sesion))
        {
            if(sesionRandomId === "")
                 sesionRandomId = (Math.floor(10000 + Math.random() * 90000)).toString()
            sesion = sesionRandomId;
        }
        let timeStamp = Date.now();
        let stamp = "";
        stamp = sesion + "#" + timeStamp;        
        return stamp;
    },    
    sendResponseFromIframe:function sendResponseFromIframe(objeto) {    
        timeStampErroresCommons = Commons.getStampId();      
        respuesta=JSON.stringify(objeto)
        registraHistorial("Se ha enviado de respuesta al parent IFRAME: "+respuesta,timeStampErroresCommons,1);
        parent.postMessage(respuesta,"*");
    },
    getDateDDMMYYYY:function getDateDDMMYYYY(){
        var d = new Date();
        var dia = ""+d.getDate();
        var pad = "00";
        var diaProcesado = pad.substring(0, pad.length - dia.length) + dia;

        var mes = ""+(d.getMonth()+1);
        var pad = "00";
        var mesProcesado = pad.substring(0, pad.length - mes.length) + mes;

        var anio = ""+d.getFullYear();
        
        var fecha = diaProcesado+"/"+mesProcesado+"/"+anio
        return fecha;
    },
    getHourHHmm:function getHourHHmm(){
        var d = new Date();
        var horas = ""+d.getHours();
        var pad = "00";
        var horasProcesado = pad.substring(0, pad.length - horas.length) + horas;

        var minutos = ""+d.getMinutes();
        var pad = "00";
        var minutosProcesado = pad.substring(0, pad.length - minutos.length) + minutos;

        var segundos = ""+d.getSeconds();
        var pad = "00";
        var segundosProcesado = pad.substring(0, pad.length - segundos.length) + segundos;

        
        var tiempo = horasProcesado+":"+minutosProcesado+":"+segundosProcesado;
        return tiempo;
    }
}

/**////////////////////////////////////////////////////////////////////////////////////////////////////////////**/   
/**///Esta funcionalidad es para que los excepciones puedan ser convertidas a string mediante JSON.stringify  /**/
/**/if (!('toJSON' in Error.prototype))                                                                       /**/
/**/Object.defineProperty(Error.prototype, 'toJSON', {                                                        /**/
/**/    value: function () {                                                                                  /**/
/**/        var alt = {};                                                                                     /**/
/**/        Object.getOwnPropertyNames(this).forEach(function (key) {                                         /**/
/**/            alt[key] = this[key];                                                                         /**/
/**/        }, this);                                                                                         /**/
/**/        return alt;                                                                                       /**/
/**/    },                                                                                                    /**/
/**/    configurable: true,                                                                                   /**/
/**/    writable: true                                                                                        /**/
/**/});                                                                                                       /**/
/**////////////////////////////////////////////////////////////////////////////////////////////////////////////**/
