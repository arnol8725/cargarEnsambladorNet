/*
* @Author: jagonzalezu
* @Date:   2017-11-24 10:40:26
* @Last Modified by:   jagonzalezu
* @Last Modified time: 2018-02-14 16:46:12
*/
var ManejadorMsgPinpad ={
    getContent:function getContent(caseMessage) {
        content = "";
        switch (caseMessage) {
            case "errorReintento":
                content = '<div class="cuadro3">\
                                <a style="visibility: hidden;" href="#" class=" simplemodal-close" id="botonCerrar">\
                                    <img src="../../Imgs/cerrar.png" class="cerrar">\
                                </a>\
                                <div class="titModal tCenter">Procesando PinPad</div>\
                                <div class="clear"></div><br>\
                                <div id="lblError" class="texto1">\
                                </div>\
                                <div class="botones1"><a href="#" onclick="eventReintentarPagoTarjeta()" class="btnV w48">Aceptar</a></td></div>\
                                <br>\
                            </div>';
            break;
            default:
                content = '<p>No se eligió un mensaje valido para mostrar<\p>'
            break;
        }
        return content;
    }
}