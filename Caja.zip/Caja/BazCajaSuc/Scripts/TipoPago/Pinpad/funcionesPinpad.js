/*
* @Author: jagonzalezu
* @Date:   2017-11-24 10:47:33
* @Last Modified by:   jagonzalezu
* @Last Modified time: 2018-03-14 13:22:27
*/
var timeStampErroresPinpad

var FuncionesPinpad = {
    mostrarModal: function mostrarModal(tipo) {
        let html = ManejadorMsgPinpad.getContent(tipo);
        muestraModal(html);
    }
};

function manejaErroresLecturaPinpad(status){
    try{

        let msgErrorPinpad="";
        FailedAttempts++;    
        if (FailedAttempts > 3) {
        	finalizarPinpadLecturaError("Se ha alcanzado el máximo de intentos permitidos."); 
            return;
        }
        if (status == "-12") {
            //"Tarjeta Declinada EMV, no se podrá realizar el pago"
            msgErrorPinpad = "La tarjeta fue declinada, no se podrá realizar el pago.";
            
        }
        else if (status == "10") {
            //"Falla en CHIP reintente","Retire Tarjeta"
            ReadAttemptsChip++;
            if (ReadAttemptsChip >= 3) {
                isFallBack = "true";
                msgErrorPinpad = "Se ha alcanzado el máximo de intentos permitidos, deslice la tarjeta en el PinPad.";
        
            }
            else {
                msgErrorPinpad = "No se pudo leer el chip de la tarjeta por favor vuelva a intentar.";
            }
        }
        else if (status == "24") {
            //"La tarjeta esta bloqueada , no se podrá realizar el pago"
            msgErrorPinpad = "La tarjeta está bloqueada, no se podrá realizar el pago."; 
        }
        else if (status == "62") {
            avisaError("Se va a inicializar su PinPad, retire la tarjeta y espere por favor.");
            //"PinPad sin llaves, solicitando Llaves"
            solicitarLlaves();
            return;
        }
        else if (status == "99" || status == "8") {
            //"Cancelando Operación" !!!!!!!!!!!!!!!!!!!!!!
            finalizarPinpadLecturaError("Cancelando operación."); 
            return;       
        }
        else if (status == "-13"){    //"Hay una tarjeta insertada, Retire Tarjeta"
            msgErrorPinpad = "Retire la tarjeta del PinPad";
        }
        else if (status == "6") {
            //"Se agoto el Tiempo de Espera"
            msgErrorPinpad = "Se agoto el tiempo de espera, vuelva a intentarlo.";
        }
        else {
            msgErrorPinpad = "Se agoto el tiempo de espera";
        }

        FuncionesPinpad.mostrarModal("errorReintento");
    	let e = document.getElementById("modal00").querySelector("#lblError");
    	e.innerHTML = msgErrorPinpad;
    }
    catch (oError) {
        timeStampErroresPinpad = Commons.getStampId(datosOperacion.wS);      
        registraHistorial("Ocurrió un error no controlado en manejaErroresLecturaPinpad oError = "+JSON.stringify(oError, null, 4),timeStampErroresPinpad,3);                                                
        finalizarConError("Algo salio mal, si el problema persiste favor de comunicarse a soporte." + " </br>[Código de seguimiento:"+timeStampErroresPinpad+"]");
        return;
    }
}

function manejaExcepcionLecturaPinpad(oError)
{
    try
    {
        timeStampErroresPinpad = Commons.getStampId(datosOperacion.wS);      
        registraHistorial("Ocurrió una error no controlado durante el flujo del PinPad, oError= "+JSON.stringify(oError, null, 4),timeStampErroresPinpad,4);
        avisaError("Lo sentimos algo salio mal, si el problema persiste favor de comunicarse a soporte." + " </br>[Código de seguimiento:"+timeStampErroresPinpad+"]");    
        actualizaVistaDetallePagos();
        cancelaOperacionPinpad().done(function (respuesta) {
            try
            {
                $('#barraPorcentaje > .verde').width("95%")
                timeStampErroresPinpad = Commons.getStampId(datosOperacion.wS);                      
                if (!isDefined(respuesta)) {
                    registraHistorial("El servicio de cancelaOperacionPinpad no ha respondido, respuesta= "+JSON.stringify(respuesta, null, 4),timeStampErroresPinpad,3);
                    avisaError("No se obtuvo respuesta del servicio de la PinPad al cancelar la operación. </br>[Código de seguimiento:"+timeStampErroresPinpad+"]");
                    return;
                }
                if (respuesta.Estatus != 8) {
                    registraHistorial("El servicio de cancelaOperacionPinpad ha respondido con codigo de error, respuesta= "+JSON.stringify(respuesta, null, 4),timeStampErroresPinpad);                                                            
                    avisaError("Ocurrio un error al cancelar la operación de la PinPad  </br>[Código de seguimiento:"+timeStampErroresPinpad+"]");
                    return
                }
                onManejaExcepcionLecturaPinpad();
            }
            catch (oError) {
                timeStampErroresPinpad = Commons.getStampId(datosOperacion.wS);      
                registraHistorial("Ocurrió un error no controlado en cancelaOperacionPinpad oError = "+JSON.stringify(oError, null, 4),timeStampErroresPinpad,4);
                finalizarConError("Algo salio mal, si el problema persiste favor de comunicarse a soporte." + " </br>[Código de seguimiento:"+timeStampErroresPinpad+"]");
                return;
            }
        });
        
    }
    catch (oError) {
        timeStampErroresPinpad = Commons.getStampId(datosOperacion.wS);      
        registraHistorial("Ocurrió un error no controlado en manejaExcepcionLecturaPinpad oError = "+JSON.stringify(oError, null, 4),timeStampErroresPinpad,4);                                                
        finalizarConError("Algo salio mal, si el problema persiste favor de comunicarse a soporte." + " </br>[Código de seguimiento:"+timeStampErroresPinpad+"]");
        return;
    }
}

function onManejaExcepcionLecturaPinpad(){
    try
    {
        finalizarPinpad().done(function (respuesta) {
            try
            {
                $('#barraPorcentaje > .verde').width("100%")
                timeStampErroresPinpad = Commons.getStampId(datosOperacion.wS);                      
                if (!isDefined(respuesta)) {
                    registraHistorial("El servicio de finalizarPinpad no ha respondido, respuesta= "+JSON.stringify(respuesta, null, 4),timeStampErroresPinpad,3);                                                            
                    avisaError("No se obtuvo respuesta del servicio de la PinPad al cerrar las dependencias. </br>[Código de seguimiento:"+timeStampErroresPinpad+"]");
                    return;
                }
                if (respuesta.Estatus != 1) {
                    registraHistorial("El servicio de finalizarPinpad ha respondido con codigo de error, respuesta= "+JSON.stringify(respuesta, null, 4),timeStampErroresPinpad,3);                                                            
                    avisaError("Ocurrio un error al desconectar la PinPad  </br>[Código de seguimiento:"+timeStampErroresPinpad+"]");
                    return
                }
                
                FuncionesTarjeta.permiteReintentoLectura();
            }
            catch (oError) {
                timeStampErroresPinpad = Commons.getStampId(datosOperacion.wS);      
                registraHistorial("Ocurrió un error no controlado en finalizarPinpad oError = "+JSON.stringify(oError, null, 4),timeStampErroresPinpad,4);                                                
                finalizarConError("Algo salio mal, si el problema persiste favor de comunicarse a soporte." + " </br>[Código de seguimiento:"+timeStampErroresPinpad+"]");
                return;
            }
        });
        
    }
    catch (oError) {
        timeStampErroresPinpad = Commons.getStampId(datosOperacion.wS);      
        registraHistorial("Ocurrió un error no controlado en onManejaExcepcionLecturaPinpad oError = "+JSON.stringify(oError, null, 4),timeStampErroresPinpad,4);                                                
        finalizarConError("Algo salio mal, si el problema persiste favor de comunicarse a soporte." + " </br>[Código de seguimiento:"+timeStampErroresPinpad+"]");
        return;
    }
}

function manejaFinalizadoPinPad()
{    
    finalizarPinpad().done(function (respuesta) {
        try
        {
            $('#barraPorcentaje > .verde').width("100%")
            timeStampErroresPinpad = Commons.getStampId(datosOperacion.wS);                      
            if (!isDefined(respuesta)) {
                registraHistorial("El servicio de finalizarPinpad no ha respondido, respuesta= "+JSON.stringify(respuesta, null, 4),timeStampErroresPinpad,3);                                                            
                avisaError("No se obtuvo respuesta del servicio de la PinPad al cerrar las dependencias. </br>[Código de seguimiento:"+timeStampErroresPinpad+"]");
                return;
            }
            if (respuesta.Estatus != 1) {
                registraHistorial("El servicio de finalizarPinpad ha respondido con codigo de error, respuesta= "+JSON.stringify(respuesta, null, 4),timeStampErroresPinpad,3);
                avisaError("Ocurrio un error al desconectar la PinPad  </br>[Código de seguimiento:"+timeStampErroresPinpad+"]");
                return
            }            
        }
        catch (oError) {
            timeStampErroresPinpad = Commons.getStampId(datosOperacion.wS);      
            registraHistorial("Ocurrió un error no controlado en manejaExcepcionLecturaPinpad oError = "+JSON.stringify(oError, null, 4),timeStampErroresPinpad,4);                                                
            finalizarConError("Algo salio mal, si el problema persiste favor de comunicarse a soporte." + " </br>[Código de seguimiento:"+timeStampErroresPinpad+"]");
            return;
        }
    });
}

function finalizarPinpadLecturaError(msg) {
    try
    {
        registraHistorial("Ha ocurrido un problema durante el flujo del pinpad, msg= "+JSON.stringify(msg, null, 4),timeStampErroresPinpad,3);        
        avisaError(msg);
        actualizaVistaDetallePagos();
        cancelaOperacionPinpad().done(function (respuesta) {
            try
            {
                $('#barraPorcentaje > .verde').width("95%")
                timeStampErroresPinpad = Commons.getStampId(datosOperacion.wS);                      
                if (!isDefined(respuesta)) {
                    registraHistorial("El servicio de cancelaOperacionPinpad no ha respondido, respuesta= "+JSON.stringify(respuesta, null, 4),timeStampErroresPinpad,3);                                                            
                    avisaError("No se obtuvo respuesta del servicio de la PinPad al cerrar las dependencias. </br>[Código de seguimiento:"+timeStampErroresPinpad+"]");
                    return;
                }
                if (respuesta.Estatus != 8) {
                    registraHistorial("El servicio de cancelaOperacionPinpad ha respondido con codigo de error, respuesta= "+JSON.stringify(respuesta, null, 4),timeStampErroresPinpad,3);
                    avisaError("Ocurrio un error al desconectar la PinPad  </br>[Código de seguimiento:"+timeStampErroresPinpad+"]");
                    return
                }
                onFinalizarPinpadLecturaError();                
            }
            catch (oError) {
                timeStampErroresPinpad = Commons.getStampId(datosOperacion.wS);      
                registraHistorial("Ocurrió un error no controlado en cancelaOperacionPinpad oError = "+JSON.stringify(oError, null, 4),timeStampErroresPinpad,4);                                                
                finalizarConError("Algo salio mal, si el problema persiste favor de comunicarse a soporte." + " </br>[Código de seguimiento:"+timeStampErroresPinpad+"]");
                return;
            }
        });
        
    }
    catch (oError) {
        timeStampErroresPinpad = Commons.getStampId(datosOperacion.wS);      
        registraHistorial("Ocurrió un error no controlado en finalizarPinpadLecturaError oError = "+JSON.stringify(oError, null, 4),timeStampErroresPinpad,4);                                                
        finalizarConError("Algo salio mal, si el problema persiste favor de comunicarse a soporte." + " </br>[Código de seguimiento:"+timeStampErroresPinpad+"]");
        return;
    }           
}

function onFinalizarPinpadLecturaError(){
    try
    {
        finalizarPinpad().done(function (respuesta) {
            try
            {
                $('#barraPorcentaje > .verde').width("100%")
                timeStampErroresPinpad = Commons.getStampId(datosOperacion.wS);                      
                if (!isDefined(respuesta)) {
                    registraHistorial("El servicio de finalizarPinpad no ha respondido, respuesta= "+JSON.stringify(respuesta, null, 4),timeStampErroresPinpad,3);                                                            
                    avisaError("No se obtuvo respuesta del servicio de la PinPad al cerrar las dependencias. </br>[Código de seguimiento:"+timeStampErroresPinpad+"]");
                    return;
                }
                if (respuesta.Estatus != 1) {
                    registraHistorial("El servicio de finalizarPinpad ha respondido con codigo de error, respuesta= "+JSON.stringify(respuesta, null, 4),timeStampErroresPinpad,3);
                    avisaError("Ocurrio un error al desconectar la PinPad  </br>[Código de seguimiento:"+timeStampErroresPinpad+"]");
                    return
                }                
                FuncionesTarjeta.permiteReintentoLectura();    
            }
            catch (oError) {
                timeStampErroresPinpad = Commons.getStampId(datosOperacion.wS);      
                registraHistorial("Ocurrió un error no controlado en finalizarPinpad oError = "+JSON.stringify(oError, null, 4),timeStampErroresPinpad,4);
                finalizarConError("Algo salio mal, si el problema persiste favor de comunicarse a soporte." + " </br>[Código de seguimiento:"+timeStampErroresPinpad+"]");
                return;
            }
        });        
    }
    catch (oError) {
        timeStampErroresPinpad = Commons.getStampId(datosOperacion.wS);      
        registraHistorial("Ocurrió un error no controlado en onFinalizarPinpadLecturaError oError = "+JSON.stringify(oError, null, 4),timeStampErroresPinpad,4);                                                
        finalizarConError("Algo salio mal, si el problema persiste favor de comunicarse a soporte." + " </br>[Código de seguimiento:"+timeStampErroresPinpad+"]");
        return;
    } 
}

function solicitarLlaves(){
    cargaLlave().done(function (respuesta) {
        try
        {
            timeStampErroresPinpad = Commons.getStampId(datosOperacion.wS);                      
            $('#barraPorcentaje > .verde').width("100%")
            if (!isDefined(respuesta)) {
                registraHistorial("Ocurrió una error en cargaLlave, respuesta = "+JSON.stringify(respuesta, null, 4),timeStampErroresPinpad,3);                                                                       
                finalizarPinpadLecturaError("No se obtuvo respuesta del servicio de PinPad.");            
                return;
            }
            if (respuesta.Estatus != 1) {
                registraHistorial("cargaLlave respondió con código de error, respuesta = "+JSON.stringify(respuesta, null, 4),timeStampErroresPinpad,3);                                                                       
                finalizarPinpadLecturaError("Error durante la carga de llaves: "+respuesta.Mensaje); //Alerta            
                return;
            }
            FuncionesPinpad.mostrarModal("errorReintento");
            let e = document.getElementById("modal00").querySelector("#lblError");
            e.innerHTML = "Las llaves de la PinPad se han cargado correctamente, vuelva a intentar la venta";      
        }
        catch(oError)
        {
            timeStampErroresPinpad = Commons.getStampId(datosOperacion.wS);      
            registraHistorial("Ocurrió un error no controlado en solicitarLlaves oError = "+JSON.stringify(oError, null, 4),timeStampErroresPinpad,4);
            finalizarConError("Algo salio mal, si el problema persiste favor de comunicarse a soporte." + " </br>[Código de seguimiento:"+timeStampErroresPinpad+"]");
            return;
        }
    });
}
