﻿/*
* @Author: jagonzalezu
* @Date:   2017-11-20 11:34:21
* @Last Modified by:   jagonzalezu
* @Last Modified time: 2018-03-20 18:41:35
*/
var ManejadorMsgTiposPago ={
    getContent: function getContent(caseMessage) {
        content = "";
        switch (caseMessage) {            
            case "preguntaSalirSinAfectaciones":
                content = '<div class="cuadro2">\
                                <a style="visibility:hidden" href="#" class=" simplemodal-close" id="botonCerrar">\
                                    <img src="../../Imgs/cerrar.png" class="cerrar">\
                                </a>\
                                <div class="titModal tCenter">Tipos de pagos</div>\
                                <div class="clear"></div>\
                                <div class="texto1">\
                                    <br>\
                                    ¿Desea cancelar el registro de los tipos de pago?<br>\
                                    Si cancela la operación perdera toda la información capturada.\
                                </div>\
                                <div class="botones w50">\
                                    <a onclick="salirSinAfectaciones()" href="#" class="btnB w48">Sí</a>\
                                    <a onclick="cerrarModal()" href="#" class="btnV w48">No</a>\
                                </div>\
                                <div class="clear"></div><br>\
                            </div>'
            break;
            case "advertenciaCancelacionConTarjetaAfectada":
                content = '<div class="cuadro">\
                                <a href="#" class=" simplemodal-close" id="botonCerrar" id="botonCerrar">\
                                    <img src="../../Imgs/cerrar.png" class="cerrar">\
                                </a>\
                                <div class="titModal">Tipos de pago</div>\
                                <div class="clear"></div>\
                                <div class="texto1">\
                                    ¿Desea <strong>cancelar</strong> el registro de los tipos de pago?, si cancela la operación<br>\
                                    se perderá toda la información capturada.<br><br>\
                                    Informe al cliente que tiene <b id = numTarjetas>n</b> tarjeta(s) bancaria(s) <strong>ya autorizada(s)</strong>, si cancela<br>\
                                    el proceso, la(s) cuenta(s) del cliente se verá(n) afectada(s) sin haber marcado<br>\
                                    la venta y su saldo será restituido por su banco hasta el día siguiente.\
                                    <br><br>\
                                    <table class="tblPieModal1" id="tablaDetalleTarjetasAfectadas">\
                                        <tbody>\
                                            <tr>\
                                                <td colspan="2" class="h20">Tarjetas autorizadas:<br></td>\
                                            </tr>\
                                        </tbody>\
                                    </table>\
                                </div>\
                                <div class="botones w50">\
                                    <a href="#" onclick = "reversaPago()" class="btnB w48">Sí</a>\
                                    <a href="#" onclick = "cerrarModal()" class="btnV w48">No</a>\
                                </div>\
                                <br><br><br>\
                            </div>'
            break;
            case "solicitandoReverso":
                content = '<div class="cuadro1">\
                                <a style="visibility:hidden" href="#" class=" simplemodal-close" id="botonCerrar">\
                                    <img src="../../Imgs/cerrar.png" class="cerrar">\
                                </a>\
                                <div class="titModal">Tarjeta bancaria</div>\
                                <div class="clear"></div>\
                                <div class="texto1">\
                                    Solicitando reverso, espere un momento.\
                                    <br>\
                                </div>\
                                <div class="tCenter"><img src="../../Imgs/TiposPago/Antena.gif" class="imgAntena"></div>\
                                <br>\
                            </div>'
            break;
            case "reversoExitoso":
                content = '<div class="cuadro1">\
                                <a style="visibility:hidden" href="#" class=" simplemodal-close" id="botonCerrar">\
                                    <img src="../../Imgs/cerrar.png" class="cerrar">\
                                </a>\
                                <div class="titModal">Tarjeta bancaria</div>\
                                <div class="clear"></div>\
                                <div class="texto1">\
                                    <br>\
                                    Se concretó satisfactoriamente el Reverso de pago con tarjeta<br>\
                                    bancaria, por favor verificar la operación con el banco emisor.<br>\
                                    <br>\
                                </div>\
                                <div class="botones1"><a onclick="onReversoExitoso()" href="#" class="btnV w48">Aceptar</a></div>\
                                <br>\
                            </div>'
            break;
            case "errorFin":
                content = '<div class="cuadro">\
                                <a href="#" class="simplemodal-close" id="botonCerrar">\
                                    <img src="../../Imgs/cerrar.png" onclick="procesaCerradoConError()" class="cerrar">\
                                </a>\
                                <div class="titModal">Tipos de Pago</div>\
                                <div class="clear"></div><br>\
                                <div class="texto1">\
                                    <label id="lblError"></label>\
                                    <br><br><br>\
                                </div>\
                                <br>\
                            </div>'
            break;
            default:
                content = '<p>No se eligío un mensaje valido para mostrar<\p>'
            break;

        }
        return content;
    }
};