﻿/*
* @Author: jagonzalezu
* @Date:   2018-01-07 16:11:50
* @Last Modified by:   jagonzalezu
* @Last Modified time: 2018-02-16 13:16:11
*/
function onValidaImporteComplete(respuesta) {
    var objeto;


    objeto = document.getElementById("txtImporteEfectivo");

    objeto.value = "";
    objeto.focus();
    actualizaVistaDetallePagos();

}

function procesaImporteEfectivo(importeValor) {
    if (!(!!importeValor.match(/(?=.)^(([1-9][0-9]{0,2}(,[0-9]{3})*)|[0-9]+)?(\.[0-9]{1,2})?$/))) {
        timeStampErroresEfectivo = Commons.getStampId(datosOperacion.wS);
        registraHistorial("El usuario ha intentado ingresar un valor de importe invalido; " + JSON.stringify(importeValor, null, 4), timeStampErroresEfectivo,2);
        avisaError("El importe ingresado es incorrecto realice la corrección pertinente e intente de nuevo. </br> Valor incorrecto ingresado: " + importeValor);
        document.getElementById("txtImporteEfectivo").value = "";
        document.getElementById("txtImporteEfectivo").focus();
        return;
    }

    var parametros = {
        controlador: obtenControladorSesion(), //string        
        importe: importeValor//string
    };
    validaImporteEfectivo(parametros).done(function (respuesta) {
        try {
            timeStampErroresEfectivo = Commons.getStampId(datosOperacion.wS);
            if (!isDefined(respuesta)) {
                registraHistorial("El servicio de validaImporteEfectivo no ha respondido, respuesta = " + JSON.stringify(respuesta, null, 4), timeStampErroresEfectivo,3);
                avisaError("No se ha obtenido respuesta del servicio de validación´de importe. </br>[Código de seguimiento:" + timeStampErroresEfectivo + "]");
                return;
            }
            if (!isDefined(respuesta.RespuestaString)) {
                registraHistorial("El servicio de validaImporteEfectivo no ha respondido correctamente, respuesta = " + JSON.stringify(respuesta, null, 4), timeStampErroresEfectivo,3);
                avisaError("Ha ocurrido un problema al obtener la validación del importe. </br>[Código de seguimiento:" + timeStampErroresEfectivo + "]");
                return;
            }
            if (isDefined(respuesta.Controlador)) {
                if (respuesta.Controlador !== "")
                    guardaControladorSesion(respuesta.Controlador);
            }
            var informacionRespuesta = eval("(" + respuesta.RespuestaString + ")");
            let errorRespuesta = BuscarErroresEnRespuesta(informacionRespuesta)
            if (errorRespuesta !== "") {
                document.getElementById("txtImporteEfectivo").value = "";
                document.getElementById("txtImporteEfectivo").focus();
                registraHistorial("El servicio de validaImporteEfectivo ha respondido con código de error, respuesta= " + JSON.stringify(respuesta, null, 4), timeStampErroresEfectivo,3);
                avisaError(errorRespuesta + "</br>[Código de seguimiento:" + timeStampErroresEfectivo + "]");
                return;
            }

            if (!isDefined(respuesta.Controlador)) {
                registraHistorial("El servicio de validaImporteEfectivo no ha respondido correctamente, respuesta= " + JSON.stringify(respuesta, null, 4), timeStampErroresEfectivo,3);
                avisaError("El servicio de validacion de importe no ha respondido correctamente. </br>[Código de seguimiento:" + timeStampErroresEfectivo + "]");
                return;
            }

            onValidaImporteComplete(informacionRespuesta);  //<-Procesa info 
        }

        catch (oError) {
            timeStampErroresEfectivo = Commons.getStampId(datosOperacion.wS);
            registraHistorial("Ocurrió un error no controlado en validaImporteEfectivo oError = " + JSON.stringify(oError, null, 4), timeStampErroresEfectivo,3);
            finalizarConError("Algo salio mal validando el importe, si el problema persiste favor de comunicarse a soporte. </br>[Código de seguimiento:" + timeStampErroresEfectivo + "]");
            return;
        }
    });
}