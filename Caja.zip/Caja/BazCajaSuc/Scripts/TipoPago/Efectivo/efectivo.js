﻿/*
* @Author: jagonzalezu
* @Date:   2017-12-21 17:11:30
* @Last Modified by:   jagonzalezu
* @Last Modified time: 2018-02-16 13:16:11
*/
//se va a tener toda la funcionalidad del front 
let importeVentaEfectivo; //Cnatidad de dinero que se esta manejando para la transaccion de tarjeta
let timeStampErroresEfectivo; //Variable para los codigos de errores de la funcionalidad de tarjetas

function eventClickValidaImporteEfectivo() {
    var objeto = document.getElementById("txtImporteEfectivo");       
    procesaImporteEfectivo(objeto.value);
}

function eventOnKeyPressValidaImporteEfectivo(event) {
    try
    {
        if (!event) {
           event = window.event;
           keyCode = event.keyCode;
        }
        else { 
            keyCode = event.which;
        }

        var  objeto = document.getElementById("txtImporteEfectivo");
        if (keyCode == 13) {
            procesaImporteEfectivo(objeto.value);
            if (event.preventDefault) {
                event.preventDefault();
            }
        }
        else {
            objeto.style.background = "";
        }
    }
    catch (oError) {
        timeStampErroresEfectivo = Commons.getStampId(datosOperacion.wS);      
        registraHistorial("Ocurrió un error no controlado en eventvalidaImporteEfectivo oError = "+JSON.stringify(oError, null, 4),timeStampErroresEfectivo,3);                                                
        finalizarConError("Algo salio mal validando el importe, si el problema persiste favor de comunicarse a soporte. </br>[Código de seguimiento:"+timeStampErroresEfectivo+"]");
        return;
    }
        
}


