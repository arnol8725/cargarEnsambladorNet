﻿/*
* @Author: jagonzalezu
* @Date:   2018-01-18 16:46:25
* @Last Modified by:   jagonzalezu
* @Last Modified time: 2018-02-16 13:16:10
*/
var FuncionesBonos = {
    mostrarModal: function mostrarModal(tipo) {
        let html = ManejadorMsgBonos.getContent(tipo);
        muestraModal(html);
    }
    
};

function solicitaConfirmacionCodigoBonos(respuesta) {
    try {
        $('#divCodigoBonos').html('<input id="txtCodigoBonos" onkeypress="eventValidaCodigoBonos(event)" type="text" placeholder="0.00">');
        FuncionesBonos.mostrarModal('bonoExitoso');
        document.getElementById("txtCodigoBonos").focus();
        
    }      
    catch (oError) {
        timeStampErroresBonos = Commons.getStampId(datosOperacion.wS);
        registraHistorial("Ocurrió un error no controlado en solicitaConfirmacionImporte oError = " + JSON.stringify(oError, null, 4), timeStampErroresBonos,3);
        finalizarConError("Algo salio mal, si el problema persiste favor de comunicarse a soporte." + " </br>[Código de seguimiento:" + timeStampErroresBonos + "]");
        return;
    }
}

function errorBono(respuesta)
{
    try {
        $('#divCodigoBonos').html('<input id="txtCodigoBonos" onkeypress="eventValidaCodigoBonos(event)" type="text" placeholder="0.00">');
        FuncionesBonos.mostrarModal('errorValidarBono');
        document.getElementById("txtCodigoBonos").focus();
    
    }
    catch (oError) {
        timeStampErroresBonos = Commons.getStampId(datosOperacion.wS);
        registraHistorial("Ocurrió un error no controlado en solicitaConfirmacionImporte oError = " + JSON.stringify(oError, null, 4), timeStampErroresBonos,3);
        finalizarConError("Algo salio mal, si el problema persiste favor de comunicarse a soporte." + " </br>[Código de seguimiento:" + timeStampErroresBonos + "]");
        return;
    }
}

function errorSpCtaBono(respuesta) {
    try {
        $('#divCodigoBonos').html('<input id="txtCodigoBonos" onkeypress="eventValidaCodigoBonos(event)" type="text" placeholder="0.00">');
        FuncionesBonos.mostrarModal('errorEjecutarSpCtaBono');
        document.getElementById("txtCodigoBonos").focus();

    }
    catch (oError) {
        timeStampErroresBonos = Commons.getStampId(datosOperacion.wS);
        registraHistorial("Ocurrió un error no controlado en solicitaConfirmacionImporte oError = " + JSON.stringify(oError, null, 4), timeStampErroresBonos,3);
        finalizarConError("Algo salio mal, si el problema persiste favor de comunicarse a soporte." + " </br>[Código de seguimiento:" + timeStampErroresBonos + "]");
        return;
    }
}

function onValidaCodigoBonos(respuesta) {
    var objeto;
    objeto = document.getElementById("txtCodigoBonos");
    objeto.value = "";
    objeto.focus();
    FuncionesBonos.mostrarModal("bonoExitoso");
 
}