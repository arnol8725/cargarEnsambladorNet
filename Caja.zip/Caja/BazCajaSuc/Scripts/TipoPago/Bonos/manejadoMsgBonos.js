﻿/*
* @Author: jagonzalezu
* @Date:   2018-01-18 16:46:26
* @Last Modified by:   jagonzalezu
* @Last Modified time: 2018-02-14 16:45:27
*/
var ManejadorMsgBonos = {
    getContent: function getContent(caseMessage) {
        content = "";
        switch (caseMessage) {
            case "bonoExitoso":
                content = '<div id="modalExito" class="modal simplemodal-data" style="display: block;" >\
                             <div class="cuadro1"> <a href="#" class=" simplemodal-close" id="botonCerrar"> <img src="../../Imgs/cerrar.png" class="cerrar"></a>\
                             <div class="titModal">Tipos de pagos</div> <div class="clear"></div><br>\
                             <div class="texto1">El bono fue ingresado con éxito, ¿desea agregar otro?</div><br>\
                             <div class="botones1">\
                                <a onclick="actualizaVistaDetallePagos()" href="#" class="btnB w48 simplemodal-close">No</a>\
                                <a onclick="actualizaVistaDetallePagos()" href="#" class="btnV w48 simplemodal-close">Sí</a>\
                             </div><br>\
                             </div>\
                            </div>'
                break;

            case "errorValidarBono":
                content = '<div id="modalError2" class="modal simplemodal-data" style="display: block;">\
                            <div class="cuadro1"><a href="#" class=" simplemodal-close" id="botonCerrar"><img src="../../Imgs/cerrar.png" class="cerrar"></a>\
                            <div class="titModal">Tipos de pagos</div>\
                            <div class="clear"></div><br>\
                            <div class="texto1">Error al validar el bono con la promoción.</div><br>\
                            <div class="botones1"><a href="#" class="btnV w48  simplemodal-close">Aceptar</a></div><br>\
                            </div>\
                            </div>'
                break;

            case "errorEjecutarSpCtaBono":
                content = '<div id="modalError1" class="modal simplemodal-data" style="display: block;">\
                            <div class="cuadro1"><a href="#" class=" simplemodal-close" id="botonCerrar"><img src="../../Imgs/cerrar.png" class="cerrar"></a>\
                            <div class="titModal">Tipos de pagos</div>\
                            <div class="clear"></div><br>\
                            <div class="texto1">Error al ejecutar <strong>spCtaBono</strong><br> El presupuesto no tiene productos válidos para el canje.</div><br>\
                            <div class="botones1"><a href="#" class="btnV w48  simplemodal-close">Aceptar</a></div><br>\
                            </div>\
                            </div>'

                break;
        default:
            content = '<p>No se eligío un mensaje valido para mostrar<\p>'
            break;
        }
        return content;
    }
}