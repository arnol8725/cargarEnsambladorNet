﻿/*
* @Author: jagonzalezu
* @Date:   2018-01-18 16:46:25
* @Last Modified by:   jagonzalezu
* @Last Modified time: 2018-02-16 13:16:10
*/
//function onValidaCodigoBonos(respuesta) {
//    var objeto;


//    objeto = document.getElementById("txtCodigoBonos");

//    objeto.value = "";
//    objeto.focus();
//    actualizaVistaDetallePagos();
//    FuncionesBonos.mostrarModal("bonoExitoso");

//}


function eventValidaCodigoBonos(event) {
    try {
        var keyCode;
        var objeto;

        if (!event) {
            event = window.event;
            keyCode = event.keyCode;
        }
        else {
            keyCode = event.which;
        }
        objeto = document.getElementById("txtCodigoBonos");
        if (keyCode == 13) {
            if (!(!!objeto.value.match(/(?=.)^(([1-9][0-9]{0,2}(,[0-9]{3})*)|[0-9]+)?(\.[0-9]{1,2})?$/))) {
                timeStampErroresBonos = Commons.getStampId(datosOperacion.wS);
                registraHistorial("El usuario ha intentado ingresar un valor de importe invalido; " + JSON.stringify(objeto.value, null, 4), timeStampErroresBonos,2);
                avisaError("El importe ingresado es incorrecto realice la corrección pertinente e intente de nuevo. </br> Valor incorrecto ingresado: " + objeto.value);
                document.getElementById("txtCodigoBonos").value = "";
                document.getElementById("txtCodigoBonos").focus();
                return;
            }
            guardaVariableSesion('respuestaConfirmacion', "");

            var parametros = {
                controlador: obtenControladorSesion(),
                parametroString: objeto.value
                 
            };

            // var parametros = {
            //     controlador: obtenControladorSesion(), //string        
            //     importe: objeto.value//string
            // };

            solicitaAplicarBono(parametros).done(function (respuesta) {
                try {
                    timeStampErroresBonos = Commons.getStampId(datosOperacion.wS);
                    if (!isDefined(respuesta)) {
                        registraHistorial("El servicio de validaImporteBonos no ha respondido, respuesta = " + JSON.stringify(respuesta, null, 4), timeStampErroresBonos,3);
                        avisaError("No se ha obtenido respuesta del servicio de validación de importe. </br>[Código de seguimiento:" + timeStampErroresBonos + "]");
                        return;
                    }
                    if (!isDefined(respuesta.RespuestaString)) {
                        registraHistorial("El servicio de validaImporteBonos no ha respondido correctamente, respuesta = " + JSON.stringify(respuesta, null, 4), timeStampErroresBonos,3);
                        avisaError("Ha ocurrido un problema al obtener la validación del importe. </br>[Código de seguimiento:" + timeStampErroresBonos + "]");
                        FuncionesBonos.mostrarModal("errorEjecutarSpCtaBono");
                        return;
                    }
                    if (isDefined(respuesta.Controlador)) {
                        if (respuesta.Controlador !== "")
                            guardaControladorSesion(respuesta.Controlador);
                    }
                    var informacionRespuesta = eval("(" + respuesta.RespuestaString + ")");
                    let errorRespuesta = BuscarErroresEnRespuesta(informacionRespuesta);

                    if (informacionRespuesta.error === 1) {
                        FuncionesBonos.mostrarModal("errorValidarBono");
                    }

                    if (errorRespuesta !== "") {
                        document.getElementById("txtCodigoBonos").value = "";
                        document.getElementById("txtCodigoBonos").focus();
                        registraHistorial("El servicio de validaImporteBonos ha respondido con código de error, respuesta= " + JSON.stringify(respuesta, null, 4), timeStampErroresBonos,3);
                        return;
                    } 

                    if (!isDefined(respuesta.Controlador)) {
                        registraHistorial("El servicio de validaImporteBonos no ha respondido correctamente, respuesta= " + JSON.stringify(respuesta, null, 4), timeStampErroresBonos,3);
                        avisaError("El servicio de validacion de importe no ha respondido correctamente. </br>[Código de seguimiento:" + timeStampErroresBonos + "]");
                        return;
                    }

                    onValidaCodigoBonos(respuesta.RespuestaString);  //<-Procesa info 
                    //solicitaConfirmacionImporte(respuesta.RespuestaString);  //<-Procesa info   


                     
                }
                catch (oError) {
                    timeStampErroresBonos = Commons.getStampId(datosOperacion.wS);
                    registraHistorial("Ocurrió un error no controlado en validaImporteCheque oError = " + JSON.stringify(oError, null, 4), timeStampErroresBonos,3);
                    finalizarConError("Algo salio mal validando el importe, si el problema persiste favor de comunicarse a soporte. </br>[Código de seguimiento:" + timeStampErroresBonos + "]");
                    return;
                }
            });
            if (event.preventDefault) {
                event.preventDefault();
            }
        }
        else {
            objeto.style.background = "";
        }
    }
    catch (oError) {
        timeStampErroresBonos = Commons.getStampId(datosOperacion.wS);
        registraHistorial("Ocurrió un error no controlado en eventValidaImporteBonos oError = " + JSON.stringify(oError, null, 4), timeStampErroresBonos,3);
        finalizarConError("Algo salio mal validando el importe, si el problema persiste favor de comunicarse a soporte. </br>[Código de seguimiento:" + timeStampErroresBonos + "]");
        return;
    }

}