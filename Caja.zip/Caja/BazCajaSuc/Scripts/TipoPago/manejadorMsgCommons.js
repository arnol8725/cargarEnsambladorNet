/*
* @Author: jagonzalezu
* @Date:   2017-11-27 19:06:25
* @Last Modified by:   jagonzalezu
* @Last Modified time: 2018-02-19 10:03:57
*/
var ManejadorMsgCommons ={
    getContent: function getContent(caseMessage) {
        content = "";
        switch (caseMessage) {
            case "error":
                content = '<div class="cuadro">\
                                <a style="visibility:hidden;" href="#" class=" simplemodal-close" id="botonCerrar">\
                                    <img src="../../Imgs/cerrar.png" class="cerrar">\
                                </a>\
                                <div class="titModal">Tipos de Pago</div>\
                                <div class="clear"></div><br>\
                                <div class="texto1">\
                                    <label id="lblError"></label>\
                                    <br>\
                                    <div class="botones1"><a href="#" onclick="cerrarModal()" class="btnV w48">Aceptar</a></div>\
                                    <br><br>\
                                </div>\
                            </div>\
                            <br>';
                break;
            case "errorFin":
                content = '<div class="cuadro">\
                                <a href="#" class="simplemodal-close" id="botonCerrar">\
                                    <img src="../../Imgs/cerrar.png" onclick="procesaCerradoConError()" class="cerrar">\
                                </a>\
                                <div class="titModal">Tipos de Pago</div>\
                                <div class="clear"></div><br>\
                                <div class="texto1">\
                                    <label id="lblError"></label>\
                                    <br><br><br>\
                                </div>\
                                <br>\
                            </div>'
            break;
            default:
                content = '<p>No se eligío un mensaje valido para mostrar<\p>'
            break;

        }
        return content;
    }
};