/*
* @Author: jagonzalezu
* @Date:   2017-11-14 13:00:05
* @Last Modified by:   jagonzalezu
* @Last Modified time: 2018-05-14 17:55:53
*/

$(".datosTarjeta").hide();

$('#selectTipoPago').change(function() {
	if($('#selectTipoPago option:selected').val() == 2) {
		$(".datosTarjeta").show();
	}
});


function guardaControladorSesion(control) {
    sessionStorage.setItem('controladorWeb', JSON.stringify(control));
}

function obtenControladorSesion() {
    var controladorSesion = obtenVariableSesion('controladorWeb');
    if(!isDefined(controladorSesion) || controladorSesion === "")
    {
        timeStampErroresTiposPago = Commons.getStampId(datosOperacion.wS);
        registraHistorial("El controlador ha fallado en cargase, guardase o la sesión a finalizado, verificar el porque... controlador = " + JSON.stringify(controladorSesion, null, 4)+" ;",timeStampErroresTiposPago,4);                
        finalizarConError("Ha ocurrido un problema en sesión, por favor cierre esta ventana y vuelva a intentarlo. </br>[Código de seguimiento:"+timeStampErroresTiposPago+"]");
    }
    return controladorSesion;
}

function inicializaInterfaz() {    
    try{
        inicializaControlador(datosOperacion).done(function (controlador) {
            try{
                timeStampErroresTiposPago = Commons.getStampId(datosOperacion.wS);      
                if (!isDefined(controlador)) {
                    registraHistorial("El servicio para la creación de la instancia del controlador no ha respondido; controlador = "+JSON.stringify(controlador, null, 4),timeStampErroresTiposPago,4);
                    finalizarConError("Ha ocurrido un problema al instanciar el controlador. </br>[Código de seguimiento:"+timeStampErroresTiposPago+"]");
                    return;
                }
                if (!isDefined(controlador.RespuestaString)) {
                    registraHistorial("Ha fallado la creación de la instancia del controlador el servicio ha respondido con los datos incorrectos; controlador = "+JSON.stringify(controlador, null, 4),timeStampErroresTiposPago,4);
                    finalizarConError("Ha ocurrido un problema al instanciar el controlador. </br>[Código de seguimiento:"+timeStampErroresTiposPago+"]");
                    return;
                }
                guardaControladorSesion(controlador.RespuestaString);
                
                obtieneInfoComboTiposPago()
            }   
            catch (oError) {
                timeStampErroresTiposPago = Commons.getStampId(datosOperacion.wS);      
                registraHistorial("Ocurrió un error no controlado en la respuesta de inicializaControlador oError = "+JSON.stringify(oError, null, 4),timeStampErroresTiposPago,4);                                                
                finalizarConError("Algo salio mal, si el problema persiste favor de comunicarse a soporte." + " </br>[Código de seguimiento:"+timeStampErroresTiposPago+"]");
                return;
            }
        });
    }
    catch (oError) {
        timeStampErroresTiposPago = Commons.getStampId(datosOperacion.wS);      
        registraHistorial("Ocurrió un error no controlado en inicializaInterfaz oError = "+JSON.stringify(oError, null, 4),timeStampErroresTiposPago,4);                                                
        finalizarConError("Algo salio mal, si el problema persiste favor de comunicarse a soporte." + " </br>[Código de seguimiento:"+timeStampErroresTiposPago+"]");
        return;
    }
}


function obtieneInfoComboTiposPago(){
    try{
        var entradaControlador = {
            controlador: obtenControladorSesion()
        }
        obtieneListadoTiposPagoEpos(entradaControlador).done(function (listadoItems) {
            try
            {
                timeStampErroresTiposPago = Commons.getStampId(datosOperacion.wS);                          
                if (!isDefined(listadoItems)) {
                    registraHistorial("El servicio para el listado de tipos de pagos obtieneListadoTiposPagoEpos no ha podido respondido, valor devuelto: listadoItems= "+JSON.stringify(listadoItems, null, 4),timeStampErroresTiposPago,4);            
                    finalizarConError("Ha ocurrido un problema al inicializar el listado de pagos. </br>[Código de seguimiento:"+timeStampErroresTiposPago+"]");
                    return;
                }
                if (!isDefined(listadoItems.RespuestaString)) {
                    registraHistorial("El servicio para el listado de tipos de pagos obtieneListadoTiposPagoEpos ha respondido con los datos incorrectos;  listadoItems= "+JSON.stringify(listadoItems, null, 4),timeStampErroresTiposPago,4);                            
                    finalizarConError("Ha ocurrido un problema al obtener el listado de pagos. </br>[Código de seguimiento:"+timeStampErroresTiposPago+"]");
                    return;
                }
                if(isDefined(listadoItems.Controlador))
                {
                    if (listadoItems.Controlador !== "")
                        guardaControladorSesion(listadoItems.Controlador);
                }
                var tiposPagoList = [{ "identificador": 0, "nombre": "Seleccione una opción" }];            
                tiposPagoList = eval("(" + listadoItems.RespuestaString + ")");
                let errorRespuesta = BuscarErroresEnRespuesta(tiposPagoList)
                if (errorRespuesta!=="") {
                    registraHistorial("El servicio para el listado de tipos de pagos ha respondido con un código de error;  tiposPagoList= "+JSON.stringify(tiposPagoList, null, 4),timeStampErroresTiposPago,4);                                                
                    finalizarConError(errorRespuesta+"</br>[Código de seguimiento:"+timeStampErroresTiposPago+"]");                
                    return;
                }
                if(!isDefined(listadoItems.Controlador)){
                    registraHistorial("El servicio para el listado de tipos de pagos obtieneListadoTiposPagoEpos ha respondido con los datos incorrectos;  listadoItems= "+JSON.stringify(listadoItems, null, 4),timeStampErroresTiposPago,4);                            
                    finalizarConError("Ha ocurrido un problema al obtener el listado de pagos. </br>[Código de seguimiento:"+timeStampErroresTiposPago+"]");
                    return;
                }

                var options = $("#selectTipoPago");
                $.each(tiposPagoList, function () {
                    options.append($("<option />").val(this.identificador).text(this.nombre));
                });
                
                actualizaVistaDetallePagos();
            }
            catch (oError) {
                timeStampErroresTiposPago = Commons.getStampId(datosOperacion.wS);      
                registraHistorial("Ocurrió un error no controlado en la respuesta de obtieneListadoTiposPagoEpos oError = "+JSON.stringify(oError, null, 4),timeStampErroresTiposPago,4);                                                
                finalizarConError("Algo salio mal, si el problema persiste favor de comunicarse a soporte." + " </br>[Código de seguimiento:"+timeStampErroresTiposPago+"]");
                return;
            }
        });
    }
        catch (oError) {
            timeStampErroresTiposPago = Commons.getStampId(datosOperacion.wS);      
            registraHistorial("Ocurrió un error no controlado oError = "+JSON.stringify(oError, null, 4),timeStampErroresTiposPago,4);
            finalizarConError("Algo salio mal, si el problema persiste favor de comunicarse a soporte." + " </br>[Código de seguimiento:"+timeStampErroresTiposPago+"]");
            return;
    }
}

function actualizaVistaDetallePagos(){
    try{

        var entradaControlador = {
            controlador: obtenControladorSesion()
        }
        obtieneInformacionActualizada(entradaControlador).done(function (infoActualizada) {
            try{                
                timeStampErroresTiposPago = Commons.getStampId(datosOperacion.wS);      
                if (!isDefined(infoActualizada)) {
                    registraHistorial("El servicio para obtieneInformacionActualizada no ha respondido, infoActualizada= "+JSON.stringify(infoActualizada, null, 4),timeStampErroresTiposPago,3);                                                
                    finalizarConError("Ha ocurrido un problema al inicializar información actualizada.  </br>[Código de seguimiento:"+timeStampErroresTiposPago+"]");
                    return;
                }
                if (!isDefined(infoActualizada.RespuestaString)) {
                    registraHistorial("El servicio para obtieneInformacionActualizada ha respondido con un código de error; infoActualizada= "+JSON.stringify(infoActualizada, null, 4),timeStampErroresTiposPago,3);                                                
                    finalizarConError("Ha ocurrido un problema al obtener información actualizada.  </br>[Código de seguimiento:"+timeStampErroresTiposPago+"]");
                    return;
                }

                var informacionDocumentos = eval("(" + infoActualizada.RespuestaString + ")");
                
                let errorRespuesta = BuscarErroresEnRespuesta(informacionDocumentos)
                if (errorRespuesta!=="") {
                    registraHistorial("El servicio para obtieneInformacionActualizada ha respondido con un código de error;  informacionDocumentos= "+JSON.stringify(informacionDocumentos, null, 4),timeStampErroresTiposPago,3);                                                
                    finalizarConError(errorRespuesta+"</br>[Código de seguimiento:"+timeStampErroresTiposPago+"]");                
                    return;
                }
                informacionPagosActualizada = informacionDocumentos
                actualizaTablasImportes(informacionDocumentos);
            }
            catch (oError) {
                timeStampErroresTiposPago = Commons.getStampId(datosOperacion.wS);      
                registraHistorial("Ocurrió un error no controlado en la respuesta de obtieneInformacionActualizada oError = "+JSON.stringify(oError, null, 4),timeStampErroresTiposPago,3);                                                
                finalizarConError("Algo salio mal al actualizar el detalle de los pagos, si el problema persiste favor de comunicarse a soporte." + " </br>[Código de seguimiento:"+timeStampErroresTiposPago+"]");
                return;
            }
        });
    }
    catch (oError) {
        timeStampErroresTiposPago = Commons.getStampId(datosOperacion.wS);      
        registraHistorial("Ocurrió un error no controlado en actualizaVistaDetallePagos oError = "+JSON.stringify(oError, null, 4),timeStampErroresTiposPago,3);                                                
        finalizarConError("Algo salio mal al actualizar el detalle de los pagos, si el problema persiste favor de comunicarse a soporte." + " </br>[Código de seguimiento:"+timeStampErroresTiposPago+"]");
        return;
    }
}

function actualizaTablasImportes(informacionDocumentos){
        if(datosOperacion.esDeposito == "true")
        {
            actualizaParaDeposito(informacionDocumentos);
        }
        else
        {
            actualizaParaVenta(informacionDocumentos);            
        }
}

function actualizaParaDeposito(informacionDocumentos){
    try
    {
        document.getElementById("resumenParaDeposito").style.display = "block";
        listadoDocumentosRespuesta = [];
        var listadoAuxDocumento = {
            numeroDocumento: "",
            importeDocumento: informacionDocumentos.importes.importeEfectivo,
            tipoPago: "Efectivo"
        }
        listadoDocumentosRespuesta.push(listadoAuxDocumento);

        $("#lblTotalPagadoDeposito").html(informacionDocumentos.importes.TotalPagado);
        $("#lblTotalOtrosDeposito").html(informacionDocumentos.importes.importeDocumentos);
        $("#lblTotalEfectivoDeposito").html(informacionDocumentos.importes.importeEfectivo);        
        
        llenaTablaDetallesOtrosTiposPago(informacionDocumentos);
    }
    catch (oError) {
        timeStampErroresTiposPago = Commons.getStampId(datosOperacion.wS);      
        registraHistorial("Ocurrió un error no controlado en actualizaParaDeposito oError = "+JSON.stringify(oError, null, 4),timeStampErroresTiposPago,3);                                                
        finalizarConError("Algo salio mal al mostrar el detalle de los pagos, si el problema persiste favor de comunicarse a soporte." + " </br>[Código de seguimiento:"+timeStampErroresTiposPago+"]");
        return;
    }
}

function actualizaParaVenta(informacionDocumentos){
    try
    {
        document.getElementById("resumenParaVenta").style.display = "block";
        listadoDocumentosRespuesta = [];
        var listadoAuxDocumento = {
            numeroDocumento: "",
            importeDocumento: informacionDocumentos.importes.importeEfectivo,
            tipoPago: "Efectivo"
        }
        listadoDocumentosRespuesta.push(listadoAuxDocumento);

        $("#lblTotalPagado").html(informacionDocumentos.importes.TotalPagado);
        $("#lblTotalOtros").html(informacionDocumentos.importes.importeDocumentos);
        $("#lblTotalVenta").html(informacionDocumentos.importes.importeTotalOperacion);
        $("#lblTotalEfectivo").html(informacionDocumentos.importes.importeEfectivo);        
        if (informacionDocumentos.importes.resumen.indicadorColor == 1) {
            document.getElementById("lblTotalFaltaPagar").style.color = "#7E0308";
            $("#lblTotalFaltaPagar").html(informacionDocumentos.importes.resumen.importe);
            $("#lblTotalCambioEfectivo").html("$0.00");    
            
        }
        else {
            document.getElementById("lblTotalFaltaPagar").style.color = "#459b3c";
            $("#lblTotalFaltaPagar").html("$0.00");
            $("#lblTotalCambioEfectivo").html(informacionDocumentos.importes.resumen.importe);                                
        }        
        
        llenaTablaDetallesOtrosTiposPago(informacionDocumentos);
        
    }
    catch (oError) {
        timeStampErroresTiposPago = Commons.getStampId(datosOperacion.wS);      
        registraHistorial("Ocurrió un error no controlado en actualizaParaVenta oError = "+JSON.stringify(oError, null, 4),timeStampErroresTiposPago,3);                                                
        finalizarConError("Algo salio mal al mostrar el detalle de los pagos, si el problema persiste favor de comunicarse a soporte." + " </br>[Código de seguimiento:"+timeStampErroresTiposPago+"]");
        return;
    }
}

function llenaTablaDetallesOtrosTiposPago(informacionDocumentos){
    try{
        let filaNueva;
        let tipoPagoDesc;    
        $('#tablaDetalleTiposPago').html('<tbody>\
                                                    <tr>\
                                                        <th>Tipo de documento</th>\
                                                        <th>Documento</th>\
                                                        <th>Importe</th>\
                                                    </tr>\
                                                </tbody>');
                
        $.each(informacionDocumentos.tiposDePago, function () {
            var listadoAuxDocumento = {
                numeroDocumento:"",
                importeDocumento: 0,
                tipoPago:""
            }
            if (this.conteoDocumentos > 0) {
                tipoPagoDesc = this.nombreTipoPago                
                if (this.idTipoPago == 2) {
                    if (this.detalle != null) {
                        $.each(this.detalle, function () { 
                            hayTarjetas = true;
                            numeroTarjeta = 'XXXXXXXXXXXX'+this.numeroDocumento.substring(this.numeroDocumento.length - 4, this.numeroDocumento.length);
                            filaNueva = '<tr>\
                                            <td>'+tipoPagoDesc+'</td>\
                                            <td>'+numeroTarjeta+'</td>\
                                            <td>'+ this.importeDocumento +'</td>\
                                        </tr>';   
                            listadoAuxDocumento.tipoPago = tipoPagoDesc;
                            listadoAuxDocumento.numeroDocumento = numeroTarjeta;
                            listadoAuxDocumento.importeDocumento = this.importeDocumento;
                            listadoDocumentosRespuesta.push(listadoAuxDocumento);            

                            $('#tablaDetalleTiposPago tr:last').after(filaNueva);
                        });
                    }
                }
                else if (this.idTipoPago > 2 && this.idTipoPago != 3) {
                    if (this.detalle != null) {
                        $.each(this.detalle, function () {                        
                            filaNueva = '<tr>\
                                            <td>'+tipoPagoDesc+'</td>\
                                            <td>'+this.numeroDocumento+'</td>\
                                            <td>'+this.importeDocumento +'</td>\
                                        </tr>';   
                            listadoAuxDocumento.tipoPago = tipoPagoDesc;
                            listadoAuxDocumento.numeroDocumento = this.numeroDocumento;
                            listadoAuxDocumento.importeDocumento = this.importeDocumento;                                
                            listadoDocumentosRespuesta.push(listadoAuxDocumento);
                        
                            $('#tablaDetalleTiposPago tr:last').after(filaNueva);
                        });
                    }
                }
                else if(this.idTipoPago == 3)
                {
                    if (this.detalle != null) {
                        $.each(this.detalle, function () {                        
                            filaNueva = '<tr>\
                                            <td>'+tipoPagoDesc+'</td>\
                                            <td>'+this.numeroDocumento+'</td>\
                                            <td>'+this.importeDocumento +'</td>\
                                        </tr>';   
                            var listadoAuxDocumento = {
                                    bco:this.bco,
                                    caveTran:this.caveTran,
                                    codSeg:this.codSeg,
                                    digInter:this.digInter,
                                    importeDocumento:this.importeDocumento,
                                    numCta:this.numCta,
                                    numero:this.numero,
                                    numeroDocumento:this.numeroDocumento,
                                    plaComp:this.plaComp,
                                    preMarc:this.preMarc,
                                    tipoPago:tipoPagoDesc,
                                    nombre:this.nombre,
                                    apPat:this.apPat,
                                    apMat:this.apMat
                                };
                            listadoDocumentosRespuesta.push(listadoAuxDocumento);
                        
                            $('#tablaDetalleTiposPago tr:last').after(filaNueva);
                        });
                    }                                                                        
                }
            }
        });
        
        $('#selectTipoPago').val("0");
        $('#selectTipoPago').trigger('change');
    }
    catch (oError) {
        timeStampErroresTiposPago = Commons.getStampId(datosOperacion.wS);      
        registraHistorial("Ocurrió un error no controlado en llenaTablaDetallesOtrosTiposPago oError = "+JSON.stringify(oError, null, 4),timeStampErroresTiposPago,3);                                                
        finalizarConError("Algo salio mal al mostrar el detalle de los pagos, si el problema persiste favor de comunicarse a soporte." + " </br>[Código de seguimiento:"+timeStampErroresTiposPago+"]");
        return;
    }
}

function onGuardaPagoComplete(respuestaValidacion) {
    try{

        var objeto;
        var descripcionError = "";
        if (respuestaValidacion.error == 0) {

            var entrada = {
                idSesion : datosOperacion.idSesion,//string
                nombreAplicacion : datosOperacion.nombreAplicacion,//string
                controlador : obtenControladorSesion()//string
            };
            guardaSesion(entrada).done(function (salida) {
                try{     

                    timeStampErroresTiposPago = Commons.getStampId(datosOperacion.wS);      
                    if (!isDefined(salida)) {
                        registraHistorial("El servicio para guardaSesion no ha respondido, salida= "+JSON.stringify(salida, null, 4),timeStampErroresTiposPago,3);                                                
                        finalizarConError("Ha ocurrido un problema al guardar la información de sesión.  </br>[Código de seguimiento:"+timeStampErroresTiposPago+"]");
                        return;
                    }    
                    if (salida.CodigoError!=="0") {
                        registraHistorial("El servicio para guardaSesion ha respondido con un código de error;  salida= "+JSON.stringify(salida, null, 4),timeStampErroresTiposPago,3);                                                
                        avisaError(salida.Mensaje +"</br>[Código de seguimiento:"+timeStampErroresTiposPago+"]");                
                        return;
                    }       
                    datosRespuestaOperacion.Aplicacion=datosOperacion.nombreAplicacion;
                    datosRespuestaOperacion.EstatusExito = true;
                    datosRespuestaOperacion.Mensaje = "Exitoso";
                    datosRespuestaOperacion.ListaDocumentos = listadoDocumentosRespuesta;                        
                    datosRespuestaOperacion.IdSesion = datosOperacion.idSesion
                    Commons.sendResponseFromIframe(datosRespuestaOperacion);  
                    FuncionesTiposPago.enviarMensajeDektop();  
                    cerrarModal();
                    finalizarAplicativo();
                        
                }
                catch (oError) {
                    timeStampErroresTiposPago = Commons.getStampId(datosOperacion.wS);      
                    registraHistorial("Ocurrió un error no controlado en la respuesta de guardaSesion oError = "+JSON.stringify(oError, null, 4),timeStampErroresTiposPago,3);                                                
                    finalizarConError("Algo salio mal al procesar el guardado de sesión, si el problema persiste favor de comunicarse a soporte." + " </br>[Código de seguimiento:"+timeStampErroresTiposPago+"]");
                    return;
                }
            });            
        }
        else {  
            timeStampErroresTiposPago = Commons.getStampId(datosOperacion.wS);      
            registraHistorial("Ocurrió un error en onGuardaPagoComplete respuestaValidacion = "+JSON.stringify(respuestaValidacion, null, 4),timeStampErroresTiposPago,3);                                                
            finalizarConError("Hubo un problema al grabar los pagos, si el problema persiste favor de comunicarse a soporte." + " </br>[Código de seguimiento:"+timeStampErroresTiposPago+"]");            
        }
    }
    catch (oError) {
        timeStampErroresTiposPago = Commons.getStampId(datosOperacion.wS);      
        registraHistorial("Ocurrió un error no controlado en onGuardaPagoComplete oError = "+JSON.stringify(oError, null, 4),timeStampErroresTiposPago,3);                                                
        finalizarConError("Algo salio mal al responder el detalle de los pagos, si el problema persiste favor de comunicarse a soporte." + " </br>[Código de seguimiento:"+timeStampErroresTiposPago+"]");
        return;
    }
}

function BuscarErroresEnRespuesta(informacionRespuesta)
{
    let respuestaBusqueda = "";
     if (isDefined(informacionRespuesta.error) && informacionRespuesta.error != 0) {
        if (isDefined(informacionRespuesta.descripcionError) && informacionRespuesta.descripcionError === "")
            respuestaBusqueda = (informacionRespuesta.valor);
        else if(isDefined(informacionRespuesta.valor) && (informacionRespuesta.valor ===""||informacionRespuesta.valor ==="0"))
            respuestaBusqueda = (informacionRespuesta.descripcionError);
        else if(!isDefined(informacionRespuesta.valor) && isDefined(informacionRespuesta.descripcionError) && informacionRespuesta.descripcionError !== "")
            respuestaBusqueda =(informacionRespuesta.descripcionError);        
        else if(isDefined(informacionRespuesta.valor) && (informacionRespuesta.valor !==""||informacionRespuesta.valor ==="0"))
            respuestaBusqueda =(informacionRespuesta.valor); 
        if (isDefined(informacionRespuesta.descripcionError) && isDefined(informacionRespuesta.valor)){
            if(informacionRespuesta.descripcionError !=="" && informacionRespuesta.valor!=="")       {
                if(informacionRespuesta.descripcionError.length > informacionRespuesta.valor.length)
                    respuestaBusqueda =(informacionRespuesta.descripcionError); 
            }
        }
    }
    return respuestaBusqueda;
}
var intentosCerradoError = 0;
function procesaCerradoConError(){
    if(intentosCerradoError == 0)
    {
        intentosCerradoError = 1;
        let rowsCount = document.getElementById('tablaDetalleTiposPago').getElementsByTagName("tbody")[0].getElementsByTagName("tr").length;
        if(rowsCount >= 2)
        {
            if(intentosReverso != 1){
                var ocurrioError = true;
                reversaPago(ocurrioError);
            }
            return;
        }          
        intentosCerradoError = 1;
        datosRespuestaOperacion.Aplicacion=datosOperacion.nombreAplicacion;
        datosRespuestaOperacion.EstatusExito = false;
        datosRespuestaOperacion.Mensaje = "Problema en tipos de pago";
        datosRespuestaOperacion.ListaDocumentos = null;    
        datosRespuestaOperacion.IdSesion = datosOperacion.idSesion
        Commons.sendResponseFromIframe(datosRespuestaOperacion);   
        FuncionesTiposPago.enviarMensajeDektop();
        cerrarModal();
        finalizarAplicativo();
    }
    else
    {
        intentosCerradoError = 1;
        datosRespuestaOperacion.Aplicacion=datosOperacion.nombreAplicacion;
        datosRespuestaOperacion.EstatusExito = false;
        datosRespuestaOperacion.Mensaje = "Problema en tipos de pago";
        datosRespuestaOperacion.ListaDocumentos = null;            
        datosRespuestaOperacion.IdSesion = datosOperacion.idSesion
        Commons.sendResponseFromIframe(datosRespuestaOperacion);   
        FuncionesTiposPago.enviarMensajeDektop();
        cerrarModal();
        finalizarAplicativo();
    }
}

var FuncionesTiposPago = {
    mostrarModal: function mostrarModal(tipo) {
        html = ManejadorMsgTiposPago.getContent(tipo);
        muestraModal(html);
    },
    validaGet: function validaGet() {
        let result = false;
        try {
            timeStampErroresTiposPago = Commons.getStampId(datosOperacion.wS);
            registraHistorial("Los datos para procesar la operación son: " + JSON.stringify(datosOperacion, null, 4)+" ;",timeStampErroresTiposPago,0);                                    
            if(datosOperacion.esDeposito){
                datosOperacion.impTotal = "79228162514264337593543950335"; //Maximo valor decimal
            }
            if (datosOperacion.impTotal != "" || datosOperacion.noEmpleado != "" || datosOperacion.ref != "" || datosOperacion.tMovto != "" || datosOperacion.tOP != "" || datosOperacion.wS != "" || datosOperacion.presupuesto != "" || datosOperacion.tipoVenta != "" || datosOperacion.idSesion != "" || datosOperacion.concepto != "" || datosOperacion.nombreAplicacion != "") {
                if (datosOperacion.impTotal === undefined || datosOperacion.noEmpleado === undefined || datosOperacion.ref === undefined || datosOperacion.tMovto === undefined || datosOperacion.tOP == undefined || datosOperacion.wS == undefined || datosOperacion.presupuesto == undefined || datosOperacion.tipoVenta == undefined || datosOperacion.idSesion == undefined || datosOperacion.concepto == undefined || datosOperacion.nombreAplicacion == undefined) {
                                
                    registraHistorial("Los datos para procesar la operación ha llegado incompletos, no declarados o indefinidos; " + JSON.stringify(datosOperacion, null, 4)+" ;",timeStampErroresTiposPago,3);                
                    finalizarConError("No se han mandado los parámetros correctos. </br>[Código de seguimiento:"+timeStampErroresTiposPago+"]");
                }
                else if (datosOperacion.impTotal <= 0) {
                    registraHistorial("Se ha mandado un importe erróneo a la pagina; datosOperacion.impTotal = " + JSON.stringify(datosOperacion.impTotal, null, 4),timeStampErroresTiposPago,3);
                    finalizarConError("El importe a pagar no puede ser menor o igual a cero, verifique. </br>[Código de seguimiento:"+timeStampErroresTiposPago+"]");
                }
                else {
                    result = true;
                }
            }
        }
        catch (err) {
            timeStampErroresTiposPago = Commons.getStampId(datosOperacion.wS);      
            registraHistorial("Ocurrió un error no controlado durante la inicializacion de la pagina; oError = "+JSON.stringify(oError, null, 4),timeStampErroresTiposPago,3);                                                
            finalizarConError("Algo salio mal, si el problema persiste favor de comunicarse a soporte." + " </br>[Código de seguimiento:"+timeStampErroresTiposPago+"]");        
        }
        finally {
            return result;
        }
    },
    enviarMensajeDektop: function enviarMensajeDektop(){
        try
        {
            if(datosOperacion.idSesion.startsWith("Cfaf~pt9a")){
                var entrada = {
                    objetoRespuestaCheques:datosRespuestaOperacion,
                    idSesion:datosRespuestaOperacion.IdSesion
                };
                operacionesCheques(entrada);
            }
        }
        catch (err) {
            timeStampErroresTiposPago = Commons.getStampId(datosOperacion.wS);      
            registraHistorial("Ocurrió un error no controlado durante enviarMensaje de operacionesCheques; oError = "+JSON.stringify(oError, null, 4),timeStampErroresTiposPago,3);                                                            
        }

        
    }

};