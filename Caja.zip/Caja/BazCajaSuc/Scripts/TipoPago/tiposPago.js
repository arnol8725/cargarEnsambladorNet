/*
* @Author: jagonzalezu
* @Date:   2018-02-10 21:04:25
* @Last Modified by:   jagonzalezu
* @Last Modified time: 2018-03-27 19:53:03
*/
let confirmaSalida = false;
var parametrosUrl = getUrlVars();
let timeStampBitacoraTiposPago;
let timeStampErroresTiposPago;
let informacionPagosActualizada;
let pagoSeleccionadoPrevio;
let listadoDocumentosRespuesta = [];
var hayTarjetas = false;
var datosOperacion = {
impTotal: getUrlVars()["ImpTotal"],
noEmpleado: getUrlVars()["NoEmpleado"],
ref: getUrlVars()["Ref"],
tMovto: getUrlVars()["TMovto"],
tOP: getUrlVars()["TOP"],
wS: getUrlVars()["WS"],
presupuesto: getUrlVars()["Presupuesto"],
tipoVenta: getUrlVars()["TipoVenta"],
idSesion: getUrlVars()["IdSesion"],
concepto: getUrlVars()["Concepto"],
nombreAplicacion: getUrlVars()["NombreApp"],
esDeposito: getUrlVars()["EsDeposito"]
}

let datosRespuestaOperacion = 
{
    EstatusExito: false,
    Mensaje: "",
    Aplicacion:"",
    ListaDocumentos: listadoDocumentosRespuesta,
    IdSesion:""
}

//**********Ejemplo de estructura de listaDocumentos********************
// var listadoDocumentosRespuesta = {
//     {numeroDocumento:"", importeDocumento:0,tipoPago:""}
// }
//**********************************************************************

//Datos "falsos"
// var datosOperacion = {
//    impTotal: "5000",
//    noEmpleado: "T333333",
//    ref: "64654261",
//    tMovto: "1",
//    tOP: "32",
//    wS: "WS_003",
//    presupuesto: "999999",
//    tipoVenta: "1",
//    idSesion: "mysesion",
//    concepto: "1",
//    nombreAplicacion:"/test"
// }

// Datos "reales"
// var datosOperacion = {
//    impTotal: "15999",
//    noEmpleado: "T558955",
//    ref: "VentaServicioWeb",
//    tMovto: "1",
//    tOP: "274",
//    wS: "EKT173026",
//    // presupuesto: "770859",       
//    presupuesto: "775077",
//    tipoVenta: "1",
//    idSesion: "testPruebaCheques",
//    concepto: "15999",
//    nombreAplicacion: "Caja64"
// }

$(document).ready(function () {       
    try
    {
        if (FuncionesTiposPago.validaGet()) {
            var parametros = {
                idSesion:datosOperacion.idSesion,//string
                nombreAplicacion: datosOperacion.nombreAplicacion//string
            };
            timeStampBitacoraTiposPago = Commons.getStampId(datosOperacion.wS) //Esta va a servir para los eventos que no son errores
            validaSiExisteSesion(parametros).done(function (respuesta) { 
                try
                {
                    timeStampErroresTiposPago = Commons.getStampId(datosOperacion.wS);                          
                    if (!isDefined(respuesta)) {
                        registraHistorial("El servicio de validaSiExisteSesion no ha respondido, respuesta= "+JSON.stringify(respuesta, null, 4),timeStampErroresTiposPago,4);                                                            
                        finalizarConError("No se obtuvo respuesta del servicio de validación de sesión. </br>[Código de seguimiento:"+timeStampErroresTiposPago+"]");
                        return;
                    }
                    if (!isDefined(respuesta.Respuesta)) {
                        registraHistorial("El servicio de validaSiExisteSesion no ha respondido correctamente, respuesta= "+JSON.stringify(respuesta, null, 4),timeStampErroresTiposPago,4);                                                            
                        finalizarConError("El servicio de validación de sesión no ha respondido correctamente. </br>[Código de seguimiento:"+timeStampErroresTiposPago+"]");
                        return;
                    }
                    if (respuesta.CodigoError != "0") {
                        registraHistorial("El servicio de validaSiExisteSesion ha respondido con codigo de error, respuesta= "+JSON.stringify(respuesta, null, 4),timeStampErroresTiposPago,4);                                                            
                        finalizarConError("Se ha generado un problema: "+respuesta.Mensaje+". </br>[Código de seguimiento:"+timeStampErroresTiposPago+"]");
                        return;
                    }
                    if(respuesta.Respuesta.toLowerCase() == "true")
                    {
                        registraHistorial("El id de sesión ya fue utilizado, respuesta= "+JSON.stringify(respuesta, null, 4) + "Id sesion = "+ datosOperacion.idSesion,timeStampErroresTiposPago,3);                                                            
                        finalizarConError("El id de sesión ya fue utilizado. Verifique su información. </br>[Código de seguimiento:"+timeStampErroresTiposPago+"]");
                        return;                
                    }

                    inicializaInterfaz();    
                }            
                catch (oError) {
                    timeStampErroresTiposPago = Commons.getStampId();      
                    registraHistorial("Ocurrió un error no controlado en ready oError = "+JSON.stringify(oError, null, 4),timeStampErroresTiposPago,4);                                                
                    finalizarConError("Algo salio mal durante el inicio del aplicativo, si el problema persiste favor de comunicarse a soporte." + " </br>[Código de seguimiento:"+timeStampErroresTiposPago+"]");
                    return;
                }            
            });    
        }
    }
    catch (oError) {
        timeStampErroresTiposPago = Commons.getStampId();      
        registraHistorial("Ocurrió un error no controlado en tipoPagoSeleccionado oError = "+JSON.stringify(oError, null, 4),timeStampErroresTiposPago,4);                                                
        finalizarConError("Algo salio mal seleccionando el tipo de pago, si el problema persiste favor de comunicarse a soporte." + " </br>[Código de seguimiento:"+timeStampErroresTiposPago+"]");
        return;
    }
});

function tipoPagoSeleccionado() {
    try{

        let e = document.getElementById("selectTipoPago");
        let pagoSeleccionado = e.options[e.selectedIndex].value;
        if (pagoSeleccionado === pagoSeleccionadoPrevio) {
            return;
        } else {
            pagoSeleccionadoPrevio = pagoSeleccionado;
        }
        //alert(pagoSeleccionado);
        switch (pagoSeleccionado) {
        case "1":

            $("#divSeccionPago").load("../../Fronts/TipoPago/Efectivo/efectivo.html", function (responseTxt, statusTxt, xhr) {
                if (statusTxt == "success") {
                    //disableElements($('#txtTban'));
                    //disableElements($('#txtfolioIdentificacion'));
                    //disableElements($('#btnReintentarPagoTarjeta'));
                }
            });
            break;

            case "2":
                
                $("#divSeccionPago").load("../../Fronts/TipoPago/Tarjeta/tarjeta.html", function (responseTxt, statusTxt, xhr) {
                    if (statusTxt == "success") {
                        isFallBack = false;
                        FailedAttempts = 0;
                        ReadAttemptsChip = 0;
                        isServicePinPadOn = false;
                        vpEsTarjetaConChip = "";
                        vpPAN = "";
                        vpCardHolder= "";
                        vpTOKENS_EZ_EY_ES= "";
                        vpC55= "";
                        vpC55Len= "";
                        vpEsAmex = ""; 
                        vpCodigoAuth = "";
                        vpRutaImagenFirma = "";
                        vpRutaImagenBase64 = "";
                        disableElements($('#txtTban'));
                        disableElements($('#txtfolioIdentificacion'));
                        disableElements($('#btnReintentarPagoTarjeta'));                    
                    }
                });          
                break;
            case "3":
                
                $("#divSeccionPago").load("../../Fronts/TipoPago/Cheque/Cheque.html", function (responseTxt, statusTxt, xhr) {
                    if (statusTxt == "success") {
                        disableElements($('#txtImporteCheque')); 
                        disableElements($('#selectBeneficiario'));
                        $('#lblPropio').hide();
                        $('#lblVerificacionPropio').hide();
                        $('#lblSBC').hide();
                        $('#tdImporteCheque').hide();
                        $('#lblFecha').hide();
                        $('#lblAvisoNominativo').hide();
                        eventAvisoCheque();
                    }
                });          
                break;

            case "4":
                $("#divSeccionPago").load("../../Fronts/TipoPago/Vale/Vale.html", function (responseTxt, statusTxt, xhr) {
                    if (statusTxt == "success") {
                        eventOptineTiposVale();
                        $('#lblNumeroVale').hide();
                        $('#tbNoVale').hide();
                        $('#lbMontoVale').hide();
                        $('#tbMontoVale').hide();
                        $('#lbSaldoVale').hide();
                        $('#tbSaldoVale').hide();
                        $('#lblSaldo').hide();
                        // disableElements($('#btnAceptarVale'));   
                        // disableElements($('#btnCancelarVale'));     
                    }
                });          
            
                break;

        case "5":

            $("#divSeccionPago").load("../../Fronts/TipoPago/Bonos/bonos.html", function (responseTxt, statusTxt, xhr) {
                if (statusTxt == "success") {
                    //disableElements($('#txtTban'));
                    //disableElements($('#txtfolioIdentificacion'));
                    //disableElements($('#btnReintentarPagoTarjeta'));
                }
            });
            break;

            default:
                document.getElementById("divSeccionPago").innerHTML = "";
                break;
        }
    }
    catch (oError) {
        timeStampErroresTiposPago = Commons.getStampId(datosOperacion.wS);      
        registraHistorial("Ocurrió un error no controlado en tipoPagoSeleccionado oError = "+JSON.stringify(oError, null, 4),timeStampErroresTiposPago,3);                                                
        finalizarConError("Algo salio mal seleccionando el tipo de pago, si el problema persiste favor de comunicarse a soporte." + " </br>[Código de seguimiento:"+timeStampErroresTiposPago+"]");
        return;
    }
}

function eventGuardaPago() {  
    try
    {
        let rowsCount = document.getElementById('tablaDetalleTiposPago').getElementsByTagName("tbody")[0].getElementsByTagName("tr").length;
        if(rowsCount < 1)
        {
            avisaError("No se ha ingresado ningún tipo de pago para grabar pago.");
            return
        }      
        var parametros = {
            esDeposito:datosOperacion.esDeposito, //string        
            idSesion:datosOperacion.idSesion, //string
            controlador:  obtenControladorSesion() //string
        };
        
        guardaPago(parametros).done(function (respuesta) { 
            try
            {       
                timeStampErroresTiposPago = Commons.getStampId(datosOperacion.wS);                          
                if (!isDefined(respuesta)) {
                    registraHistorial("El servicio de guardaPago no ha respondido, respuesta= "+JSON.stringify(respuesta, null, 4),timeStampErroresTiposPago,3);                                                            
                    finalizarConError("No se obtuvo respuesta del servicio de guardado de pagos. </br>[Código de seguimiento:"+timeStampErroresTiposPago+"]");
                    return;
                }
                if (!isDefined(respuesta.RespuestaString)) {
                    registraHistorial("El servicio de guardaPago no ha respondido correctamente, respuesta= "+JSON.stringify(respuesta, null, 4),timeStampErroresTiposPago,3);                                                            
                    finalizarConError("El servicio de guardado de pagos no ha respondido correctamente. </br>[Código de seguimiento:"+timeStampErroresTiposPago+"]");
                    return;
                }
                if (isDefined(respuesta.Controlador)){
                    if(respuesta.Controlador !=="")
                        guardaControladorSesion(respuesta.Controlador);    
                }

                var informacionRespuesta = eval("(" + respuesta.RespuestaString + ")");
                let errorRespuesta = BuscarErroresEnRespuesta(informacionRespuesta)
                if (errorRespuesta!=="") {
                    registraHistorial("El servicio de validaImporteTban ha respondido con código de error, informacionRespuesta = "+JSON.stringify(informacionRespuesta, null, 4),timeStampErroresTiposPago,3);                                                
                    avisaError(errorRespuesta+"</br>[Código de seguimiento:"+timeStampErroresTiposPago+"]");                
                    return;
                }

                if (!isDefined(respuesta.Controlador))
                {
                    registraHistorial("El servicio de guardaPago no ha respondido correctamente, respuesta= "+JSON.stringify(respuesta, null, 4),timeStampErroresTiposPago,3);                                                            
                    finalizarConError("El servicio de guardado de pagos no ha respondido correctamente. </br>[Código de seguimiento:"+timeStampErroresTiposPago+"]");
                    return;   
                }
                
                onGuardaPagoComplete(informacionRespuesta);
                
            }
            catch (oError) {
                timeStampErroresTiposPago = Commons.getStampId(datosOperacion.wS);      
                registraHistorial("Ocurrió un error no controlado en guardaPago oError = "+JSON.stringify(oError, null, 4),timeStampErroresTiposPago,3);                                                
                finalizarConError("Algo salio mal guardando los pagos, si el problema persiste favor de comunicarse a soporte." + " </br>[Código de seguimiento:"+timeStampErroresTiposPago+"]");
                return;
            }
        });
     }
    catch (oError) {
        timeStampErroresTiposPago = Commons.getStampId(datosOperacion.wS);      
        registraHistorial("Ocurrió un error no controlado en eventGuardaPago oError = "+JSON.stringify(oError, null, 4),timeStampErroresTiposPago,3);                                                
        finalizarConError("Algo salio mal guardando los pagos, si el problema persiste favor de comunicarse a soporte." + " </br>[Código de seguimiento:"+timeStampErroresTiposPago+"]");
        return;
    }
}

function finalizarAplicativo(){
    cerrarModal();
    cerrarControl();
    ocultarElementosPantalla()
}

function salirSinAfectaciones(){
    
    datosRespuestaOperacion.Aplicacion=datosOperacion.nombreAplicacion;
    datosRespuestaOperacion.EstatusExito = false;
    datosRespuestaOperacion.Mensaje = "Operación cancelada";
    datosRespuestaOperacion.ListaDocumentos = null;
    datosRespuestaOperacion.IdSesion = datosOperacion.idSesion    
    Commons.sendResponseFromIframe(datosRespuestaOperacion);    
    FuncionesTiposPago.enviarMensajeDektop();
    cerrarModal();
    finalizarAplicativo();
}

function salirSinAfectacionesError(){
    
    datosRespuestaOperacion.Aplicacion=datosOperacion.nombreAplicacion;
    datosRespuestaOperacion.EstatusExito = false;
    datosRespuestaOperacion.Mensaje = "Problema en tipos de pago, sin operaciones pendientes de reversar";
    datosRespuestaOperacion.ListaDocumentos = null;
    datosRespuestaOperacion.IdSesion = datosOperacion.idSesion    
    Commons.sendResponseFromIframe(datosRespuestaOperacion);   
    FuncionesTiposPago.enviarMensajeDektop(); 
    cerrarModal();
    finalizarAplicativo();
}


function preguntaReversaPago()
{ 
    let rowsCount = document.getElementById('tablaDetalleTiposPago').getElementsByTagName("tbody")[0].getElementsByTagName("tr").length;
    if(hayTarjetas)
    {
        FuncionesTiposPago.mostrarModal("advertenciaCancelacionConTarjetaAfectada");
        let contadorTarjetas= 0;
        $.each(informacionPagosActualizada.tiposDePago, function () {
            if (this.conteoDocumentos > 0) {
                tipoPagoDesc = this.nombreTipoPago
                if (this.idTipoPago == 2) {
                    if (this.detalle != null) {
                        $.each(this.detalle, function () {     
                            contadorTarjetas++;
                            filaNueva = '<tr>\
                                            <td>Tarjeta: XXXXXXXXXXXX'+this.numeroDocumento.substring(this.numeroDocumento.length - 4, this.numeroDocumento.length)+'</td>\
                                            <td>Importe: '+ this.importeDocumento +'</td>\
                                        </tr>';                        
                            $('#tablaDetalleTarjetasAfectadas tr:last').after(filaNueva);
                        });
                    }
                }                
            }
        });
        let e = document.getElementById("modal00").querySelector("#numTarjetas");
        e.innerHTML = contadorTarjetas;        
    }      
    else
    {
        FuncionesTiposPago.mostrarModal("preguntaSalirSinAfectaciones");       
    }

}

var intentosReverso = 0;
var huboErrorTiposPago = false;
function reversaPago(huboError = false) {  
    try
    {
        huboErrorTiposPago = huboError;
        var parametros = {            
            controlador: obtenControladorSesion() //string
        };
        FuncionesTiposPago.mostrarModal("solicitandoReverso");
        reversaOperacion(parametros).done(function (respuesta) {        
            try
            {
                timeStampErroresTiposPago = Commons.getStampId(datosOperacion.wS);      
                if (!isDefined(respuesta)) {
                    intentosReverso = 1;
                    registraHistorial("El servicio de reversaPago no ha respondido, respuesta= "+JSON.stringify(respuesta, null, 4),timeStampErroresTiposPago,3);                                                            
                    finalizarConError("No se obtuvo respuesta del servicio de reverso de pagos. </br>[Código de seguimiento:"+timeStampErroresTiposPago+"]");
                    return;
                }
                if (!isDefined(respuesta.Controlador))
                {
                    intentosReverso = 1;
                    registraHistorial("El servicio de reversaPago no ha respondido correctamente, respuesta= "+JSON.stringify(respuesta, null, 4),timeStampErroresTiposPago,3);                                                            
                    finalizarConError("El servicio de reverso de pagos no ha respondido correctamente. </br>[Código de seguimiento:"+timeStampErroresTiposPago+"]");
                    return;   
                }
                if(respuesta.Controlador !=="")
                    guardaControladorSesion(respuesta.Controlador);   

                FuncionesTiposPago.mostrarModal("reversoExitoso"); //->Continuar en onReversoExitoso                        
            }
            catch (oError) {
                intentosReverso = 1;
                timeStampErroresTiposPago = Commons.getStampId(datosOperacion.wS);      
                registraHistorial("Ocurrió un error no controlado en reversaOperacion oError = "+JSON.stringify(oError, null, 4),timeStampErroresTiposPago,3);                                                
                finalizarConError("Algo salio mal reversando los pagos, si el problema persiste favor de comunicarse a soporte." + " </br>[Código de seguimiento:"+timeStampErroresTiposPago+"]");
                return;
            }                
        });
    }
    catch (oError) {
        intentosReverso = 1;
        timeStampErroresTiposPago = Commons.getStampId(datosOperacion.wS);      
        registraHistorial("Ocurrió un error no controlado en eventGuardaPago oError = "+JSON.stringify(oError, null, 4),timeStampErroresTiposPago,3);                                                
        finalizarConError("Algo salio mal reversando los pagos, si el problema persiste favor de comunicarse a soporte." + " </br>[Código de seguimiento:"+timeStampErroresTiposPago+"]");
        return;
    }
}

function onReversoExitoso(){
    try
    {
        if(!huboErrorTiposPago){
            salirSinAfectaciones();
        }
        else{
            salirSinAfectacionesError();   
        }
    }
    catch (oError) {
        intentosReverso = 1;
        timeStampErroresTiposPago = Commons.getStampId(datosOperacion.wS);      
        registraHistorial("Ocurrió un error no controlado en reversaOperacion oError = "+JSON.stringify(oError, null, 4),timeStampErroresTiposPago,3);                                                
        finalizarConError("Algo salio mal reversando los pagos, si el problema persiste favor de comunicarse a soporte." + " </br>[Código de seguimiento:"+timeStampErroresTiposPago+"]");
        return;
    }   
}
