/*
* @Author: jagonzalezu
* @Date:   2018-02-10 21:04:25
* @Last Modified by:   jagonzalezu
* @Last Modified time: 2018-03-28 11:16:12
*/
function solicitaConfirmacionImporte(respuesta) {
    try {
        $('#divImporteCheque').html('<input id="txtImporteCheque" onkeypress="eventConfirmaImporteCheque(event)" type="text" placeholder="0.00" class="importeCheque">');

        FuncionesCheque.mostrarModal('confimeImporte');
        document.getElementById("txtImporteCheque").focus();    
    }
    catch (oError) {
        timeStampErroresTarjeta = Commons.getStampId(datosOperacion.wS);      
        registraHistorial("Ocurrió un error no controlado en solicitaConfirmacionImporte oError = "+JSON.stringify(oError, null, 4),timeStampErroresTarjeta,3);                                                
        avisaError("Algo salio mal, si el problema persiste favor de comunicarse a soporte." + " </br>[Código de seguimiento:"+timeStampErroresTarjeta+"]");
        return;
    }
}

var FuncionesCheque = {
    mostrarModal: function mostrarModal(tipo) {
        let html = ManejadorMsgCheque.getContent(tipo);
        muestraModal(html);
    },
    limpiaPantalla: function limpiaPantalla(){
        $('#divImporteCheque').html('<input id="txtImporteCheque" onkeypress="eventValidaImporteCheque(event)" type="text" placeholder="0.00" class="importeCheque">');
        disableElements($('#txtImporteCheque')); 
        disableElements($('#selectBeneficiario')); 
        let e = document.getElementById("selectBeneficiario");
        e.selectedIndex = 0; 
        $('#lblAvisoNominativo').hide();
        $('#lblSBC').hide();
        document.getElementById('tbCodeAutorizacion').value = "";
        document.getElementById('tbAgencia').value = "";
        document.getElementById('tbNoCuenta').value = "";
        document.getElementById('tnNoCheque').value = "";
        document.getElementById('tbCodeSeg').value = "";
    }    
};