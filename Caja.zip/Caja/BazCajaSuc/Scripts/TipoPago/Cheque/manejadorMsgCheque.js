/*
* @Author: jagonzalezu
* @Date:   2018-01-24 16:20:10
* @Last Modified by:   B182380
* @Last Modified time: 2018-02-23 17:07:57
*/
var ManejadorMsgCheque ={
    getContent: function getContent(caseMessage) {
        content = "";
        switch (caseMessage) {
            case "DatosIniciales":
                content = '<div class="cuadro2">\
                                <a style="visibility: hidden" href="#" class=" simplemodal-close" id="botonCerrar">\
                                    <img src="../../Imgs/cerrar.png"  class="cerrar">\
                                </a>\
                                <div class="titModal">Revisa los datos del cheque</div>\
                                <div class="clear"></div><br>\
                                <table class="tblBullets">\
                                  <tbody>\
                                    <tr>\
                                      <td>\
                                        <ul class="ulDatos">\
                                            <li>La palabra <strong><i>cheque</i></strong> impresa.</li>\
                                            <li>Lugar y fecha de expedición.</li>\
                                            <li>Orden incondicional de pago.</li>\
                                            <li>Nombre del librado (banco).</li>\
                                            <li>Firma del librador</li>\
                                            <li>Monto con número y letra, <br>que sean iguales.</li>\
                                        </ul>\
                                      </td>\
                                      <td>\
                                        <strong>Verifica que el cheque:</strong>\
                                        <ul class="ulDatos">\
                                            <li>No esté tachado</li>\
                                            <li>No esté roto</li>\
                                            <li>No tenga corrector</li>\
                                            <li>No tenga cinta adhesiva</li>\
                                            <li>No tenga raspaduras o enmendaduras</li>\
                                        </ul>\
                                      </td>\
                                    </tr>\
                                  </tbody>\
                                </table>\
                                <br>\
                                <div class="botones1"><a href="#" class="btnV w48  simplemodal-close" onclick="eventEstadoDigitalizado()";>Aceptar</a></div><br>\
                            </div>';
            break;
            case "VisordeCheques":
                content = '<div class="cuadro">\
                                <a href="#" class=" simplemodal-close" id="botonCerrar">\
                                    <img src="../../Imgs/cerrar.png" class="cerrar">\
                                </a>\
                                <div class="titModal">Visor de imágenes digitalizadas</div>\
                                <div class="clear"></div><br>\
                                <table class="tblBullets">\
                                  <tbody>\
                                      <tr><td><strong>Anverso del cheque</strong></td></tr>\
                                      <tr><td><img src="../../Imgs/Cheque/Cheque01.png" id="imgChequeFrente" height="200" width="700"><br></td></tr>\
                                      <tr><td><strong>Reverso del cheque</strong></td></tr>\
                                      <tr><td><img src="../../Imgs/Cheque/Cheque02.png" id="imgChequeReverso" height="200" width="700"><br></td></tr>\
                                  </tbody>\
                                </table><br>\
                                <br>\
                                <div class="botones1"><a href="#" class="btnV w48 simplemodal-close" >Salir</a></div>\
                            </div>';
            break;  
            case "AyudaCheque":
                content = '<div class="cuadro">\
                                <a href="#" class=" simplemodal-close" id="botonCerrar">\
                                    <img src="../../Imgs/cerrar.png" class="cerrar">\
                                </a>\
                                <div class="titModal">Ayuda para captura de datos de un cheque salvo buen cobro (SBC)</div>\
                                <div class="clear"></div><br>\
                                <div class="texto1">\
                                    <img src="../../Imgs/Cheque/ayuda.jpg"><br>\
                                </div>\
                                <div class="contModal tLeft">\
                                    <div class="texto tLeft">Datos adicionales del cheque</div>\
                                    <table class="tblEfectivo">\
                                      <tbody>\
                                          <tr>\
                                              <td class="w40">Nombre(s) que aparece(n) en el cheque<br><input type="text" placeholder="ENNIN" class="tLeft"></td>\
                                              <td class="w30">Apellido paterno<br><input type="text" placeholder="JUAREZ" class="tLeft"></td>\
                                              <td class="w30">Apellido materno<br><input type="text" placeholder="MARTINEZ" class="tLeft"></td>\
                                          </tr>\
                                          <tr>\
                                              <td>Importe del cheque<br><input type="text" placeholder="5000"></td>\
                                              <td>Tipo de pago con cheque<br><input type="text" placeholder="NOMINATIVO" class="tLeft"></td>\
                                              <td>Fecha<br><input type="text"></td>\
                                          </tr>\
                                      </tbody>\
                                    </table><br>\
                                    <div class="t12">\
                                        <div class="col001">\
                                        <ol type="1" class="olBillets">\
                                            <li>Ubica los números a capturar en el cheque SBC</li>\
                                            <li>Identifica por área cada uno de los números a capturar</li>\
                                            <li>Una vez identificados, captura los datos en pantalla</li>\
                                        </ol>\
                                        </div>\
                                        <div class="col002">Existen caracteres de separación, los cuales no se capturan, solo ingresa los números como se muestra arriba. Recuerda que debes capturar correctamente los datos ya que el sistema controla el número de intentos por cheque SBC.</div>\
                                    </div>\
                                    <div class="clear"></div>\
                                    <br>\
                                    <div class="botones1 tCenter">\
                                    <a href="#" class="btnV w48 simplemodal-close" >Salir</a>\
                                </div><br>\
                                </div>\
                                <br>\
                            </div>';
            break;
            case "confimeImporte":
                content = '<div class="cuadro3">\
                                <a style="visibility: hidden" href="#" class=" simplemodal-close" id="botonCerrar">\
                                    <img src="../../Imgs/cerrar.png" class="cerrar">\
                                </a>\
                                <div class="titModal tCenter">Cheques</div>\
                                <div class="clear"></div><br>\
                                <div class="texto1">\
                                    Por favor, confirme el importe\
                                </div>\
                                <div class="botones1"><a href="#" onclick="cerrarModal()" class="btnV w48">Aceptar</a></td></div>\
                                <br>\
                            </div>'
            break;      
            default:
                content = '<p>No se eligió un mensaje valido para mostrar<\p>'
            break;
        }
        return content;
    }
};



