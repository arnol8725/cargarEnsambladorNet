/*
* @Author: jagonzalezu
* @Date:   2018-02-10 21:04:25
* @Last Modified by:   jagonzalezu
* @Last Modified time: 2018-02-16 13:16:12
*/
let timeStampErroresVale;
let posicionVale;
let consultaVale;


function eventOptineTiposVale() {    
    try{
        var entrada = {
            controlador:  obtenControladorSesion()
        };

        obtieneListadoTiposVales(entrada).done(function (respuesta) {
            try
            {
                timeStampErroresVale = Commons.getStampId(datosOperacion.wS);      
                if (!isDefined(respuesta)) {
                    registraHistorial("El servicio para el listado de vales obtieneListadoTiposVales no ha podido responder, valor devuelto: respuesta= "+JSON.stringify(respuesta, null, 4),timeStampErroresVale,3);            
                    finalizarConError("Ha ocurrido un problema al obtener el saldo del Vales. </br>[Código de seguimiento:"+timeStampErroresVale+"]");
                    return;
                }
                if (!isDefined(respuesta.RespuestaString)) {
                    registraHistorial("El servicio para el listado de vales obtieneListadoTiposVales ha respondido con los datos incorrectos;  respuesta= "+JSON.stringify(respuesta, null, 4),timeStampErroresVale,3);                            
                    finalizarConError("Ha ocurrido un problema al obtener el listado de Vales. </br>[Código de seguimiento:"+timeStampErroresVale+"]");
                    return;
                }
                tiposValesList = eval("(" + respuesta.RespuestaString + ")");
                let errorRespuesta = BuscarErroresEnRespuesta(tiposValesList)
                if (errorRespuesta !== "") {
                    registraHistorial("El servicio para el listado de tipos de pagos ha respondido con un código de error;  tiposValesList= "+JSON.stringify(tiposValesList, null, 4),timeStampErroresVale,3);                                                
                    finalizarConError(errorRespuesta + " </br>[Código de seguimiento:"+timeStampErroresVale+"]");
                    return
                }

                var options = $("#selectTipoVale");
                $.each(tiposValesList, function () {
                    options.append($("<option />").val(this.valor).text(this.texto));
                });
            }
            catch (oError) {
                timeStampErroresVale = Commons.getStampId(datosOperacion.wS);      
                registraHistorial("Ocurrió un error no controlado en obtieneListadoTiposVales oError = "+JSON.stringify(oError, null, 4),timeStampErroresVale,3);                                                
                finalizarConError("Algo salio mal obteniendo la lista de tipos de vale, si el problema persiste favor de comunicarse a soporte." + " </br>[Código de seguimiento:"+timeStampErroresVale+"]");
                return;
            }
        });
    }
    catch (oError) {
        timeStampErroresVale = Commons.getStampId(datosOperacion.wS);      
        registraHistorial("Ocurrió un error no controlado en eventOptineTiposVale oError = "+JSON.stringify(oError, null, 4),timeStampErroresVale,3);                                                
        finalizarConError("Algo salio mal obteniendo la lista de tipos de vale, si el problema persiste favor de comunicarse a soporte." + " </br>[Código de seguimiento:"+timeStampErroresVale+"]");
        return;
    }
}

function eventSeleccionaTipoVale(){
    try
    {
        var e = document.getElementById("selectTipoVale");
        var valeSeleccionado = e.options[e.selectedIndex].text;   
        let indexValeSeleccionado = e.options[e.selectedIndex].value; 

        var parametros = {
            parametroEntero: indexValeSeleccionado, //string        
            controlador: obtenControladorSesion() //string
        }

        validaRecepcionVale(parametros).done(function (respuesta) {
            try
            {
                timeStampErroresVale = Commons.getStampId(datosOperacion.wS);      
                if (!isDefined(respuesta)) {
                    registraHistorial("El servicio consultaSaldoVale para la consulta de saldo de vales no ha respondido, valor devuelto: respuesta= "+JSON.stringify(respuesta, null, 4),timeStampErroresVale,3);            
                    finalizarConError("Ha ocurrido un problema al consultar el valor del Vale. </br>[Código de seguimiento:"+timeStampErroresVale+"]");
                    return;
                }
                if (!isDefined(respuesta.RespuestaString)) {
                    registraHistorial("El servicio de consultaSaldoVale no ha respondido correctamente, respuesta= "+JSON.stringify(respuesta, null, 4),timeStampErroresVale,3);                                                            
                    avisaError("Ha ocurrido un problema al consultar el valor del Vale. </br>[Código de seguimiento:"+timeStampErroresVale+"]");
                    return;
                }
                if (isDefined(respuesta.Controlador)){
                    if(respuesta.Controlador !=="")
                        guardaControladorSesion(respuesta.Controlador);    
                }

                var recepcionoVale = eval("(" + respuesta.RespuestaString + ")");
                let errorRespuesta = BuscarErroresEnRespuesta(recepcionoVale);
                if (errorRespuesta !== "") {
                    registraHistorial("El servicio para la consulta de saldo del vale no respondió;  recepcionoVale= "+JSON.stringify(recepcionoVale, null, 4),timeStampErroresVale,3);                                                
                    finalizarConError(errorRespuesta+" </br>[Código de seguimiento:"+timeStampErroresVale+"]");
                    return
                }

                if (!isDefined(respuesta.Controlador))
                {
                    registraHistorial("El servicio de consultaSaldoVale no ha respondido correctamente, respuesta= "+JSON.stringify(respuesta, null, 4),timeStampErroresVale,3);                                                            
                    avisaError("Ha ocurrido un problema al consultar el valor del Vale. </br>[Código de seguimiento:"+timeStampErroresVale+"]");
                    return;
                }

                switch (valeSeleccionado) {
                    case "Elektravale": 
                        $('#lblNumeroVale').show();
                        $('#tbNoVale').show();
                        $('#lbMontoVale').hide();
                        $('#tbMontoVale').hide();
                        $('#lbSaldoVale').hide();
                        $('#tbSaldoVale').hide();
                    break;
                    case "Todito":
                        $('#lblNumeroVale').show();
                        $('#tbNoVale').show();
                        $('#lbMontoVale').hide();
                        $('#tbMontoVale').hide();
                        $('#lbSaldoVale').hide();
                        $('#tbSaldoVale').hide();
                    break;
                    case "EdenRed Accord": 
                        $('#lblNumeroVale').show();
                        $('#tbNoVale').show();
                        $('#lbMontoVale').hide();
                        $('#tbMontoVale').hide();
                        $('#lbSaldoVale').hide();
                        $('#tbSaldoVale').hide();
                    break;
                    case "SIVALE":    
                        $('#lblNumeroVale').show();
                        $('#tbNoVale').show();
                        $('#lbMontoVale').hide();
                        $('#tbMontoVale').hide();
                        $('#lbSaldoVale').hide();
                        $('#tbSaldoVale').hide();
                    break;
                    case "EFECTIVALE":    
                        $('#lblNumeroVale').show();
                        $('#tbNoVale').show();
                        $('#lbMontoVale').hide();
                        $('#tbMontoVale').hide();
                        $('#lbSaldoVale').hide();
                        $('#tbSaldoVale').hide();
                    break;
                    case "Sodexo":    
                        $('#lblNumeroVale').show();
                        $('#tbNoVale').show();
                        $('#lbMontoVale').hide();
                        $('#tbMontoVale').hide();
                        $('#lbSaldoVale').hide();
                        $('#tbSaldoVale').hide();
                    break;
                    default:
                        $('#lblNumeroVale').hide();
                        $('#tbNoVale').hide();
                        $('#lbMontoVale').hide();
                        $('#tbMontoVale').hide();
                        $('#lbSaldoVale').hide();
                        $('#tbSaldoVale').hide();
                    break;
                }
            }
            catch (oError) {
                timeStampErroresVale = Commons.getStampId(datosOperacion.wS);      
                registraHistorial("Ocurrió un error no controlado en validaRecepcionVale oError = "+JSON.stringify(oError, null, 4),timeStampErroresVale,3);                                                
                finalizarConError("Algo salio mal seleccionando el tipo de vale, si el problema persiste favor de comunicarse a soporte." + " </br>[Código de seguimiento:"+timeStampErroresVale+"]");
                return;
            }  
        });
    }
    catch (oError) {
        timeStampErroresVale = Commons.getStampId(datosOperacion.wS);      
        registraHistorial("Ocurrió un error no controlado en eventSeleccionaTipoVale oError = "+JSON.stringify(oError, null, 4),timeStampErroresVale,3);                                                
        finalizarConError("Algo salio mal seleccionando el tipo de vale, si el problema persiste favor de comunicarse a soporte." + " </br>[Código de seguimiento:"+timeStampErroresVale+"]");
        return;
    }  
}


function eventConsultaVale(event) {    
    try
    {
        let keyCode;
        let objetoVale;
        if (!event) {
            event = window.event;
            keyCode = event.keyCode;
        }
        else { 
            keyCode = event.which;
        }
        
        if (keyCode == 13) {

            let e = document.getElementById("selectTipoVale");
            let indexValeSeleccionado = e.options[e.selectedIndex].value;
            objetoVale = document.getElementById("tbNoVale");

            let comparaVale = $("#tablaVale td:contains(" + objetoVale.value + ")")

            if (comparaVale.length > 0){
                avisaError("El vale ya fue agregado anteriormente");
                return;
            }


            if (objetoVale.value.length !== 16 ){
                FuncionesVale.mostrarModal('caracterInsuficientes');
                document.getElementById("tbNoVale").value = "";
                return;
            }

            var parametros = {
                controlador: obtenControladorSesion(), //string        
                indexVale: indexValeSeleccionado,
                numeroVale: objetoVale.value, //string
                tipoLectura: 1 //int
            }

            consultaSaldoVale(parametros).done(function (respuesta) {
                try
                {
                    timeStampErroresVale = Commons.getStampId(datosOperacion.wS);      
                    if (!isDefined(respuesta)) {
                        registraHistorial("El servicio consultaSaldoVale para la consulta de saldo de vales no ha respondido, valor devuelto: respuesta= "+JSON.stringify(respuesta, null, 4),timeStampErroresVale,3);            
                        finalizarConError("Ha ocurrido un problema al consultar el valor del Vale. </br>[Código de seguimiento:"+timeStampErroresVale+"]");
                        return;
                    }
                    if (!isDefined(respuesta.RespuestaString)) {
                        registraHistorial("El servicio de consultaSaldoVale no ha respondido correctamente, respuesta= "+JSON.stringify(respuesta, null, 4),timeStampErroresVale,3);                                                            
                        avisaError("Ha ocurrido un problema al consultar el valor del Vale. </br>[Código de seguimiento:"+timeStampErroresVale+"]");
                        return;
                    }
                    if (isDefined(respuesta.Controlador)){
                        if(respuesta.Controlador !=="")
                            guardaControladorSesion(respuesta.Controlador);    
                    }

                    consultaVale = eval("(" + respuesta.RespuestaString + ")");
                    let errorRespuesta = BuscarErroresEnRespuesta(consultaVale);
                    if (errorRespuesta !== "") {
                        registraHistorial("El servicio para la consulta de saldo del vale no respondió;  consultaVale= "+JSON.stringify(consultaVale, null, 4),timeStampErroresVale,3);                                                
                        avisaError(errorRespuesta+" </br>[Código de seguimiento:"+timeStampErroresVale+"]");
                        return
                    }

                    if (!isDefined(respuesta.Controlador))
                    {
                        registraHistorial("El servicio de consultaSaldoVale no ha respondido correctamente, respuesta= "+JSON.stringify(respuesta, null, 4),timeStampErroresVale,3);                                                            
                        avisaError("Ha ocurrido un problema al consultar el valor del Vale. </br>[Código de seguimiento:"+timeStampErroresVale+"]");
                        return;
                    }

                    $('#lbMontoVale').show();
                    $('#tbMontoVale').show();
                    $('#lbSaldoVale').show();
                    $('#tbSaldoVale').show();
                    $('#tbMontoVale').show();
                    $('#lblSaldo').show();
                    $('#tbMontoValido').show();
                    document.getElementById('lblSaldo').innerHTML = consultaVale.mensaje.saldoDisponible;
                    
                    
                    if(indexValeSeleccionado == 1){
                        $('#tbMontoValido').val(consultaVale.mensaje.saldoDisponible);
                        $('#tbMontoValido').hide();
                        $('#tablaVale tr:last').after('\
                          <tr>\
                             <td><img src="../../Imgs/TiposPago/ok.png" class="imgOk"></td>\
                             <td>' + consultaVale.mensaje.numeroVale + '</td>\
                             <td>' + consultaVale.mensaje.saldoDisponible + '</td>\
                             <td>Validado</td>\
                         </tr>');

                        enableElements($('#btnAceptarVale'));
                        enableElements($('#btnCancelarVale'));
                    }
                }
                catch (oError) {
                    timeStampErroresVale = Commons.getStampId(datosOperacion.wS);      
                    registraHistorial("Ocurrió un error no controlado en consultaSaldoVale oError = "+JSON.stringify(oError, null, 4),timeStampErroresVale,3);                                                
                    finalizarConError("Algo salio mal consultando el vale, si el problema persiste favor de comunicarse a soporte." + " </br>[Código de seguimiento:"+timeStampErroresVale+"]");
                    return;
                }  
            });
        }
    }
    catch (oError) {
        timeStampErroresVale = Commons.getStampId(datosOperacion.wS);      
        registraHistorial("Ocurrió un error no controlado en eventConsultaVale oError = "+JSON.stringify(oError, null, 4),timeStampErroresVale,3);                                                
        finalizarConError("Algo salio mal consultando el vale, si el problema persiste favor de comunicarse a soporte." + " </br>[Código de seguimiento:"+timeStampErroresVale+"]");
        return;
    }  
}

function eventAgregarPromoVale(){
    let keyCode;
    let montoValePago;
    let montoaComparar;

    try{
        montoValePago = document.getElementById("tbMontoValido");

        montoaComparar = consultaVale.mensaje.saldoDisponible.split("$").join("");
        montoaComparar = montoaComparar.split(",").join("");

        if (parseInt(montoValePago.value) > parseInt(montoaComparar)){
            avisaError("El monto a aplicar no puede ser mayor al saldo disponible.");
            return;
        }
        else {

            var parametros = {
                parametroString: montoValePago.value, //string        
                controlador: obtenControladorSesion() //string
            }

            solicitaAplicarMonto(parametros).done(function (respuesta) {
                try{
                    timeStampErroresVale = Commons.getStampId(datosOperacion.wS);                              
                    if (!isDefined(respuesta)) {
                        registraHistorial("El servicio consultaSaldoVale para la consulta de saldo de vales no ha respondido, valor devuelto: respuesta= "+JSON.stringify(respuesta, null, 4),timeStampErroresVale,3);            
                        finalizarConError("Ha ocurrido un problema al consultar el valor del Vale. </br>[Código de seguimiento:"+timeStampErroresVale+"]");
                        return;
                    }
                    if (!isDefined(respuesta.RespuestaString)) {
                        registraHistorial("El servicio de consultaSaldoVale no ha respondido correctamente, respuesta= "+JSON.stringify(respuesta, null, 4),timeStampErroresVale,3);                                                            
                        avisaError("Ha ocurrido un problema al consultar el valor del Vale. </br>[Código de seguimiento:"+timeStampErroresVale+"]");
                        return;
                    }
                    if (isDefined(respuesta.Controlador)){
                        if(respuesta.Controlador !=="")
                            guardaControladorSesion(respuesta.Controlador);    
                    }

                    var aplicamontoVale = eval("(" + respuesta.RespuestaString + ")");
                    let errorRespuesta = BuscarErroresEnRespuesta(aplicamontoVale);
                    if (errorRespuesta !== "") {
                        registraHistorial("El servicio para la consulta de saldo del vale no respondió;  aplicamontoVale= "+JSON.stringify(aplicamontoVale, null, 4),timeStampErroresVale,3);                                                
                        finalizarConError(errorRespuesta + " </br>[Código de seguimiento:"+timeStampErroresVale+"]");
                        return
                    }

                    if (!isDefined(respuesta.Controlador))
                    {
                        timeStampErroresVale = Commons.getStampId(datosOperacion.wS);      
                        registraHistorial("El servicio de consultaSaldoVale no ha respondido correctamente, respuesta= "+JSON.stringify(respuesta, null, 4),timeStampErroresVale,3);                                                            
                        avisaError("Ha ocurrido un problema al consultar el valor del Vale. </br>[Código de seguimiento:"+timeStampErroresVale+"]");
                        return;
                    }

                    $('#tablaVale tr:last').after('\
                      <tr>\
                         <td><img src="../../Imgs/TiposPago/ok.png" class="imgOk"></td>\
                         <td>' + consultaVale.mensaje.numeroVale + '</td>\
                         <td>' + montoValePago.value + '</td>\
                         <td>Validado</td>\
                     </tr>');

                    $('#tbNoVale').val('');
                    $('#tbMontoValido').val('');
                    document.getElementById('lblSaldo').innerHTML = "$0.00";

                    $('#tbMontoValido').hide();
                    $('#lblSaldo').hide();
                    $('#lbSaldoVale').hide();
                    $('#lbMontoVale').hide();

                    enableElements($('#btnAceptarVale'));
                    enableElements($('#btnCancelarVale'));
                }
                catch (oError) {
                    timeStampErroresVale = Commons.getStampId(datosOperacion.wS);      
                    registraHistorial("Ocurrió un error no controlado en solicitaAplicarMonto oError = "+JSON.stringify(oError, null, 4),timeStampErroresVale,3);                                                
                    finalizarConError("Algo salio mal agregando el vale, si el problema persiste favor de comunicarse a soporte." + " </br>[Código de seguimiento:"+timeStampErroresVale+"]");
                    return;
                } 
            });
        }
    }
    catch (oError) {
        timeStampErroresVale = Commons.getStampId(datosOperacion.wS);      
        registraHistorial("Ocurrió un error no controlado en eventAgregarVale oError = "+JSON.stringify(oError, null, 4),timeStampErroresVale,3);                                                
        finalizarConError("Algo salio mal agregando el vale, si el problema persiste favor de comunicarse a soporte." + " </br>[Código de seguimiento:"+timeStampErroresVale+"]");
        return;
    }  
}

function eventAgregarVale(){
    try
    {
        let keyCode;
        let montoValePago;
        let montoaComparar;

        if (!event) {
            event = window.event;
            keyCode = event.keyCode;
        }
        else { 
            keyCode = event.which;
        }

        if (keyCode == 13) {
            montoValePago = document.getElementById("tbMontoValido");

            montoaComparar = consultaVale.mensaje.saldoDisponible.split("$").join("");
            montoaComparar = montoaComparar.split(",").join("");

            if (parseInt(montoValePago.value) > parseInt(montoaComparar)){
                avisaError("El monto a aplicar no puede ser mayor al saldo disponible.");
                return;
            }
            else {

                var parametros = {
                    parametroString: montoValePago.value, //string        
                    controlador: obtenControladorSesion() //string
                }

                solicitaAplicarMonto(parametros).done(function (respuesta) {
                    try
                    {
                        timeStampErroresVale = Commons.getStampId(datosOperacion.wS);                                  
                        if (!isDefined(respuesta)) {
                            registraHistorial("El servicio consultaSaldoVale para la consulta de saldo de vales no ha respondido, valor devuelto: respuesta= "+JSON.stringify(respuesta, null, 4),timeStampErroresVale,3);            
                            finalizarConError("Ha ocurrido un problema al consultar el valor del Vale. </br>[Código de seguimiento:"+timeStampErroresVale+"]");
                            return;
                        }
                        if (!isDefined(respuesta.RespuestaString)) {
                            registraHistorial("El servicio de consultaSaldoVale no ha respondido correctamente, respuesta= "+JSON.stringify(respuesta, null, 4),timeStampErroresVale,3);                                                            
                            finalizarConError("Ha ocurrido un problema al consultar el valor del Vale. </br>[Código de seguimiento:"+timeStampErroresVale+"]");
                            return;
                        }
                        if (isDefined(respuesta.Controlador)){
                            if(respuesta.Controlador !=="")
                                guardaControladorSesion(respuesta.Controlador);    
                        }

                        var aplicamontoVale = eval("(" + respuesta.RespuestaString + ")");
                        let errorRespuesta = BuscarErroresEnRespuesta(aplicamontoVale);
                        if (errorRespuesta !== "") {
                            registraHistorial("El servicio para la consulta de saldo del vale no respondió;  aplicamontoVale= "+JSON.stringify(aplicamontoVale, null, 4),timeStampErroresVale,3);                                                
                            avisaError(errorRespuesta+" </br>[Código de seguimiento:"+timeStampErroresVale+"]");
                            return
                        }

                        if (!isDefined(respuesta.Controlador))
                        {
                            registraHistorial("El servicio de consultaSaldoVale no ha respondido correctamente, respuesta= "+JSON.stringify(respuesta, null, 4),timeStampErroresVale,3);                                                            
                            avisaError("Ha ocurrido un problema al consultar el valor del Vale. </br>[Código de seguimiento:"+timeStampErroresVale+"]");
                            return;
                        }

                        $('#tablaVale tr:last').after('\
                          <tr>\
                             <td><img src="../../Imgs/TiposPago/ok.png" class="imgOk"></td>\
                             <td>' + consultaVale.mensaje.numeroVale + '</td>\
                             <td>' + montoValePago.value + '</td>\
                             <td>Validado</td>\
                         </tr>');

                        $('#tbNoVale').val('');
                        $('#tbMontoValido').val('');
                        document.getElementById('lblSaldo').innerHTML = "$0.00";

                        $('#tbMontoValido').hide();
                        $('#lblSaldo').hide();
                        $('#lbSaldoVale').hide();
                        $('#lbMontoVale').hide();

                        enableElements($('#btnAceptarVale'));
                        enableElements($('#btnCancelarVale'));
                    }
                    catch (oError) {
                        timeStampErroresVale = Commons.getStampId(datosOperacion.wS);      
                        registraHistorial("Ocurrió un error no controlado en solicitaAplicarMonto oError = "+JSON.stringify(oError, null, 4),timeStampErroresVale,3);                                                
                        finalizarConError("Algo salio mal agregando el vale, si el problema persiste favor de comunicarse a soporte." + " </br>[Código de seguimiento:"+timeStampErroresVale+"]");
                        return;
                    }  
                });
            }            
        }
    }
    catch (oError) {
        timeStampErroresVale = Commons.getStampId(datosOperacion.wS);      
        registraHistorial("Ocurrió un error no controlado en eventAgregarVale oError = "+JSON.stringify(oError, null, 4),timeStampErroresVale,3);                                                
        finalizarConError("Algo salio mal agregando el vale, si el problema persiste favor de comunicarse a soporte." + " </br>[Código de seguimiento:"+timeStampErroresVale+"]");
        return;
    }  
}


function eventEntragarValeaTiposPagos(){
    try{
        actualizaVistaDetallePagos();
        FuncionesVale.limpiaPantalla();
    }
    catch (oError) {
        timeStampErroresVale = Commons.getStampId(datosOperacion.wS);      
        registraHistorial("Ocurrió un error no controlado en eventEntragarValeaTiposPagos oError = "+JSON.stringify(oError, null, 4),timeStampErroresVale,3);                                                
        finalizarConError("Algo salio mal, si el problema persiste favor de comunicarse a soporte." + " </br>[Código de seguimiento:"+timeStampErroresVale+"]");
        return;
    }
}


function eventSeleccionarFila(){
    try{
        $("#tablaVale tr").click(function(){
            posicionVale = this.rowIndex;
            alert (posicionVale);

        });
    }
    catch (oError) {
        timeStampErroresVale = Commons.getStampId(datosOperacion.wS);      
        registraHistorial("Ocurrió un error no controlado en eventSeleccionarFila oError = "+JSON.stringify(oError, null, 4),timeStampErroresVale,3);                                                
        finalizarConError("Algo salio mal, si el problema persiste favor de comunicarse a soporte." + " </br>[Código de seguimiento:"+timeStampErroresVale+"]");
        return;
    }
}




function eventBorrarTablaVale(){
    try{
        $("#tablaVale").find("tr:gt(0)").remove();
    }
    catch (oError) {
        timeStampErroresVale = Commons.getStampId(datosOperacion.wS);      
        registraHistorial("Ocurrió un error no controlado en eventBorrarTablaVale oError = "+JSON.stringify(oError, null, 4),timeStampErroresVale,3);                                                
        finalizarConError("Algo salio mal, si el problema persiste favor de comunicarse a soporte." + " </br>[Código de seguimiento:"+timeStampErroresVale+"]");
        return;
    }
}


