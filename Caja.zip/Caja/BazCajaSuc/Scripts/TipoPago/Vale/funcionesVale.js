/*
* @Author: jagonzalezu
* @Date:   2018-02-10 21:04:25
* @Last Modified by:   jagonzalezu
* @Last Modified time: 2018-02-14 16:47:04
*/
var FuncionesVale = {
    mostrarModal: function mostrarModal(tipo) {
        let html = ManejadorMsgVale.getContent(tipo);
        muestraModal(html);
    },
    limpiaPantalla: function limpiaPantalla(){
        let e = document.getElementById("selectTipoVale");
        e.selectedIndex = 0; 
        $('#lblNumeroVale').hide();
        $('#tbNoVale').hide();
        $('#lbSaldoVale').hide();
        $('#lbMontoVale').hide();
        $('#lblSaldo').hide();
        document.getElementById('tbNoVale').value = "";
		document.getElementById('lblSaldo').value = "$ 0.00";
        $("#tablaVale").find("tr:gt(0)").remove();
    }  
};

