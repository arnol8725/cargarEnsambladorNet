/*
* @Author: jagonzalezu
* @Date:   2017-12-27 10:58:30
* @Last Modified by:   jagonzalezu
* @Last Modified time: 2018-02-14 16:47:04
*/
var ManejadorMsgVale ={
    getContent: function getContent(caseMessage) {
        content = "";
        switch (caseMessage) {
            case "noConexionWS":
                content = '<div class="cuadro2">\
                                <a href="#" class=" simplemodal-close" id = "botonCerrar">\
                                    <img src="../../Imgs/cerrar.png" class="cerrar">\
                                </a>\
                                <div class="titModal">Promo vale</div>\
                                <div class="clear"></div>\
                                <div class="texto1"><br>\
                                    No fue posible establecer comunicación con el servicio de Promo Vales,<br>\
                                    favor de llamar a <strong>soporte técnico.</strong>\
                                </div><br>\
                                <div class="botones1"><a href="#" class="btnV w48 simplemodal-close" >Aceptar</a></div>\
                                <div class="clear"></div><br>\
                            </div>';
            break;
            case "caracterInsuficientes":
                content = '<div class="cuadro2">\
                                <a href="#" class=" simplemodal-close" id = "botonCerrar">\
                                    <img src="../../Imgs/cerrar.png" class="cerrar">\
                                </a>\
                                <div class="titModal">Promo vale</div>\
                                <div class="clear"></div>\
                                <div class="texto1"><br >\
                                    El número de vale es incorrecto. Recuerde que debe capturar<br>\
                                    los <strong>16 números</strong> del vale.\
                                </div><br>\
                                <div class="botones1"><a href="#" class="btnV w48 simplemodal-close" >Aceptar</a></div>\
                                <div class="clear"></div><br>\
                            </div>';
            break;
            case "valeEspirado":
                content = '<div class="cuadro3">\
                                <a href="#" class=" simplemodal-close" id = "botonCerrar">\
                                    <img src="../../Imgs/cerrar.png" class="cerrar">\
                                </a>\
                                <div class="titModal">Promo vale</div>\
                                <div class="clear"></div><br>\
                                <div class="texto1">\
                                    Respuesta del web service:<br>\
                                    <strong>La vigencia del vale expiró.</strong>\
                                </div><br>\
                                <div class="botones1"><a href="#" class="btnV w48 simplemodal-close" >Aceptar</a></div>\
                                <br>\
                            </div>'
            break;
            case "confirmarVale":
                content = '<div class="cuadro2">\
                                <a href="#" class=" simplemodal-close" id = "botonCerrar">\
                                    <img src="../../Imgs/cerrar.png" class="cerrar">\
                                </a>\
                                <div class="titModal">Promo vale</div>\
                                <div class="clear"></div>\
                                <div class="texto1"><br>\
                                    ¿Confirma realizar el pago con los vales validados?\
                                </div><br>\
                                <div class="botones w50">\
                                    <a href="#" class="btnB w48 simplemodal-close" >No</a>\
                                    <a href="#" class="btnV w48 simplemodal-close" >Sí</a>\
                                </div>\
                                <div class="clear"></div><br>\
                            </div>'
            break; 
            case "montoVariable":
                content = '<div class="cuadro">\
                                <a href="#" class=" simplemodal-close" id = "botonCerrar">\
                                    <img src="../../Imgs/cerrar.png" class="cerrar">\
                                </a>\
                                <div class="titModal">Promo vale</div>\
                                <div class="clear"></div>\
                                <div class="texto1">\
                                    Capture el monto a aplicar del promo vale.<br><br>\
                                    \
                                    <table class="tblGeneral1 w90">\
                                        <tbody>\
                                            <tr>\
                                              <td>Número de promo vale:</td>\
                                              <td><input type="text"  placeholder="$0.0"></td>\
                                            </tr>\
                                            <tr>\
                                              <td>Importe aplicado de otros promo vales:</td>\
                                              <td><input type="text"  placeholder="$0.0"></td>\
                                            </tr>\
                                            <tr>\
                                              <td>Saldo disponible:</td>\
                                              <td><input type="text"  placeholder="$0.0"></td>\
                                            </tr>\
                                            <tr>\
                                              <td>Importe total de la venta:</td>\
                                              <td><input type="text"  placeholder="$0.0"></td>\
                                            </tr>\
                                            <tr>\
                                              <td>Importe faltante para completar la venta:</td>\
                                              <td><input type="text"  placeholder="$0.0"></td>\
                                            </tr>\
                                            <tr>\
                                              <td class="texto">Importe total de la venta:</td>\
                                              <td><input type="text"  placeholder="$0.0" class="inTotal"></td>\
                                            </tr>\
                                        </tbody>\
                                    </table>\
                                    \
                                    \
                                \
                                </div>\
                                        <div class="botones w50">\
                                            <a href="#" class="btnB w48 simplemodal-close" >Cancelar</a>\
                                            <a href="#" class="btnV w48 simplemodal-close" >Aceptar</a>\
                                        </div>\
                                <br><br><br>\
                            </div>'
            break;                             
            default:
                content = '<p>No se eligió un mensaje valido para mostrar<\p>'
            break;
        }
        return content;
    }
};