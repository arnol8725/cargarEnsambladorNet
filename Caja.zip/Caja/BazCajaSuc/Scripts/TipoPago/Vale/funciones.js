/*
* @Author: jagonzalezu
* @Date:   2017-12-01 19:23:37
* @Last Modified by:   jagonzalezu
* @Last Modified time: 2018-02-14 16:47:03
*/

// Select
$( ".normal_select").dropkick({
	mobile: true
});

//vale
$(".trElektravale").hide();
$('#tipoVale').change(function() {
	if($('#tipoVale option:selected').val() == 1) {
		$(".trElektravale").show();
		$(".tdElektravale").show();
		$(".tdMonto").hide();
	}
});

$('#tipoVale').change(function() {
	if($('#tipoVale option:selected').val() == 2) {
		$(".trElektravale").show();
		$(".tdElektravale").hide();
		$(".tdMonto").show();
	}
});


var altomax = 0;  
		$('.mismoalto').each(function(){  
			if($(this).height() > altomax){  
				altomax = $(this).height();  
			}  
		});  
		$('.mismoalto').height(altomax + 20) ;