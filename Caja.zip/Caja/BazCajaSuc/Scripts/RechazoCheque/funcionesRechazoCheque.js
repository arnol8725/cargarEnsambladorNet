function guardaControladorSesion(control) {
    sessionStorage.setItem('controladorWeb', JSON.stringify(control));
}

function obtenControladorSesion() {
    var controladorSesion = obtenVariableSesion('controladorWeb');
    if(!isDefined(controladorSesion) || controladorSesion === "")
    {
        timeStampErroresTiposPago = Commons.getStampId(datosOperacion.wS);
        registraHistorial("El controlador ha fallado en cargase, guardase o la sesión a finalizado, verificar el porque... controlador = " + JSON.stringify(controladorSesion, null, 4)+" ;",timeStampErroresTiposPago,4);                
        finalizarConError("Ha ocurrido un problema en sesión, por favor cierre esta ventana y vuelva a intentarlo. </br>[Código de seguimiento:"+timeStampErroresTiposPago+"]");
    }
    return controladorSesion;
}

function BuscarErroresEnRespuesta(informacionRespuesta)
{
    let respuestaBusqueda = "";
     if (isDefined(informacionRespuesta.error) && informacionRespuesta.error != 0) {
        if (isDefined(informacionRespuesta.descripcionError) && informacionRespuesta.descripcionError === "")
            respuestaBusqueda = (informacionRespuesta.valor);
        else if(isDefined(informacionRespuesta.valor) && (informacionRespuesta.valor ===""||informacionRespuesta.valor ==="0"))
            respuestaBusqueda = (informacionRespuesta.descripcionError);
        else if(!isDefined(informacionRespuesta.valor) && isDefined(informacionRespuesta.descripcionError) && informacionRespuesta.descripcionError !== "")
            respuestaBusqueda =(informacionRespuesta.descripcionError);        
        else if(isDefined(informacionRespuesta.valor) && (informacionRespuesta.valor !==""||informacionRespuesta.valor ==="0"))
            respuestaBusqueda =(informacionRespuesta.valor);        
    }
    return respuestaBusqueda;
}

function avisaError(msg) {
    FuncionesRechazoCheque.mostrarModal('error');
    let e = document.getElementById("modal00").querySelector("#lblError");
    e.innerHTML = msg;
    $.LoadingOverlay("hide");
}

var FuncionesRechazoCheque = {
    mostrarModal: function mostrarModal(tipo) {
        let html = ManejadorMsgRechazoCheque.getContent(tipo);
        muestraModal(html);
    },

    limpiaPantalla: function limpiaPantalla(){
        document.getElementById('tbCodAutorizacion').value = "";
        document.getElementById('tbCodtransito').value = "";
        document.getElementById('tbNoCuenta').value = "";
        document.getElementById('tbNoCheque').value = "";
    },

    validaGet: function validaGet() {
        let result = false;
        try {
            timeStampErroresTiposPago = Commons.getStampId(datosOperacion.wS);
            registraHistorial("Los datos para procesar la operación son: " + JSON.stringify(datosOperacion, null, 4)+" ;",timeStampErroresTiposPago,0);                                    
            if (datosOperacion.ref != "" ||datosOperacion.cuentaCheque != "" ||datosOperacion.bandaCheque != "" ||datosOperacion.impTotal != "" || datosOperacion.noEmpleado != "" || datosOperacion.wS != "" || datosOperacion.idSesion != "" || datosOperacion.nombreAplicacion != "") {
                if (datosOperacion.ref === undefined ||datosOperacion.cuentaCheque === undefined ||datosOperacion.bandaCheque === undefined ||datosOperacion.impTotal === undefined || datosOperacion.noEmpleado === undefined || datosOperacion.wS == undefined || datosOperacion.idSesion == undefined || datosOperacion.nombreAplicacion == undefined) {
                                
                    registraHistorial("Los datos para procesar la operación ha llegado incompletos, no declarados o indefinidos; " + JSON.stringify(datosOperacion, null, 4)+" ;",timeStampErroresTiposPago,3);                
                    finalizarConError("No se han mandado los parámetros correctos. </br>[Código de seguimiento:"+timeStampErroresTiposPago+"]");
                }
                else if (datosOperacion.impTotal <= 0) {
                    registraHistorial("Se ha mandado un importe erróneo a la pagina; datosOperacion.impTotal = " + JSON.stringify(datosOperacion.impTotal, null, 4),timeStampErroresTiposPago,3);
                    finalizarConError("El importe a pagar no puede ser menor o igual a cero, verifique. </br>[Código de seguimiento:"+timeStampErroresTiposPago+"]");
                }
                else {
                    result = true;
                }
            }
        }
        catch (oError) {
            timeStampErroresTiposPago = Commons.getStampId(datosOperacion.wS);      
            registraHistorial("Ocurrió un error no controlado durante la inicializacion de la pagina; oError = "+JSON.stringify(oError, null, 4),timeStampErroresTiposPago,3);                                                
            finalizarConError("Algo salio mal, si el problema persiste favor de comunicarse a soporte." + " </br>[Código de seguimiento:"+timeStampErroresTiposPago+"]");        
        }
        finally {
            return result;
        }
    },

    enviarMensajeDesktop: function enviarMensajeDesktop(){
        try
        {
            if(datosOperacion.idSesion.startsWith("Cfaf~pt9a")){
                var entrada = {
                    objetoRespuestaCheques:datosRespuestaOperacion,
                    idSesion:datosRespuestaOperacion.IdSesion
                };
                operacionesCheques(entrada);
            }
        }
        catch (oError) {
            timeStampErroresTiposPago = Commons.getStampId(datosOperacion.wS);      
            registraHistorial("Ocurrió un error no controlado durante enviarMensaje de operacionesCheques; oError = "+JSON.stringify(oError, null, 4),timeStampErroresTiposPago,3);                                                            
        }

        
    }
};