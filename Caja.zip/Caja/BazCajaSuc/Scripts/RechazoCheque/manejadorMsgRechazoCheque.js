/*
* @Author: jagonzalezu
* @Date:   2018-01-24 16:20:10
* @Last Modified by:   B182380
* @Last Modified time: 2018-02-27 16:48:07
*/
var ManejadorMsgRechazoCheque ={
    getContent: function getContent(caseMessage) {
        content = "";
        switch (caseMessage) {
            case "VisordeCheques":
                content = '<div class="cuadro">\
                                <a href="#" class=" simplemodal-close" id="botonCerrar">\
                                    <img src="../../Imgs/cerrar.png" class="cerrar">\
                                </a>\
                                <div class="titModal">Visor de imágenes digitalizadas</div>\
                                <div class="clear"></div><br>\
                                <table class="tblBullets">\
                                  <tbody>\
                                      <tr><td><strong>Anverso del cheque</strong></td></tr>\
                                      <tr><td><img src="../../Imgs/Cheque/Cheque01.png" id="imgChequeFrente" height="200" width="700"><br></td></tr>\
                                      <tr><td><strong>Reverso del cheque</strong></td></tr>\
                                      <tr><td><img src="../../Imgs/Cheque/Cheque02.png" id="imgChequeReverso" height="200" width="700"><br></td></tr>\
                                  </tbody>\
                                </table><br>\
                                <br>\
                                <div class="botones1"><a href="#" class="btnV w48 simplemodal-close" >Salir</a></div>\
                            </div>';
            break;
            case "error":
                content = '<div class="cuadro">\
                                <a style="visibility:hidden;" href="#" class=" simplemodal-close" id="botonCerrar">\
                                    <img src="../../Imgs/cerrar.png" class="cerrar">\
                                </a>\
                                <div class="titModal">Devolución de Cheques</div>\
                                <div class="clear"></div><br>\
                                <div class="texto1">\
                                    <label id="lblError"></label>\
                                    <br>\
                                    <div class="botones1"><a href="#" onclick="cerrarModal()" class="btnV w48">Aceptar</a></div>\
                                    <br><br>\
                                </div>\
                            </div>\
                            <br>';
                break;
            case "errorFin":
                content = '<div class="cuadro">\
                                <a href="#" class="simplemodal-close" id="botonCerrar">\
                                    <img src="../../Imgs/cerrar.png" onclick="procesaCerradoConError()" class="cerrar">\
                                </a>\
                                <div class="titModal">Devolución de Cheques</div>\
                                <div class="clear"></div><br>\
                                <div class="texto1">\
                                    <label id="lblError"></label>\
                                    <br><br><br>\
                                </div>\
                                <br>\
                            </div>'
            break;    
            case "devolucionCorrecta":
                content = '<div class="cuadro3">\
                                <a style="visibility: hidden" href="#" class=" simplemodal-close" id="botonCerrar">\
                                    <img src="../../Imgs/cerrar.png" class="cerrar">\
                                </a>\
                                <div class="titModal tCenter">Devolución de Cheques</div>\
                                <div class="clear"></div><br>\
                                <div class="texto1">\
                                    La devolución del cheque se realizo correctamente\
                                </div>\
                                <div class="botones1"><a href="#" onclick="devolucionCorrecta();" class="btnV w48">Aceptar</a></td></div>\
                                <br>\
                            </div>'
            break;      
            default:
                content = '<p>No se eligió un mensaje valido para mostrar<\p>'
            break;
        }
        return content;
    }
};



