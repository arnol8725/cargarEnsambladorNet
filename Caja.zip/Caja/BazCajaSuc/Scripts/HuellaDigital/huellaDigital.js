if ($j === undefined) { var $j = jQuery.noConflict(true); console.log($().jquery); console.log($j().jquery); }
var resultado = null;
var tiempoRestante;
var refFuncionCont;
var validarEmp = null;
var validarAut = null;
var tipo = null;
var aplicacion = null;
var trxHD = null;
var ws = null;
var afectaBitHd = null;
var topOperacion = null;
var empAutenticado="";
var perfiles = null;
var descBitHD = "";
var fecha = null;
var ventanaHuellaAbierta = false;
var callback = undefined;

//url constantes para las URL de los servicios, scripts y pagina
const tmrEspera = 3;
const noIntentosHD = 3;
const HUrlValidaEmpleado = "Comun/WsCajaComun.svc/wsConsultaInformacionInicial";
const HPaginaModal = "Fronts/HuellaDigital/ModalHuella.html";
const HUrlBitAutorizacion = "Comun/WsCajaComun.svc/wsRegistraBitacoraHuella";
const HUrlDescPerfiles = "wsUtileriaCaja/wsUtileria.svc/wsDescPerfiles";

function getUrlHuella(servicio) {
    var url = "";
    if (window.location.hostname == "localhost") {
        url = "http://10.54.28.226:9014/Caja/Servicios/" + servicio;
    } else {
        url = "http://" + window.location.hostname + ":9014/Caja/Servicios/" + servicio;
    }
    return url;
}

function getUrlBase() {
    arrurl = window.location.href.split("/");
    var url = "";
    for (var i = 0 ; i < (arrurl.length - 1) ; i++) {
        if (arrurl[i] == "Fronts")
            break;
        url += arrurl[i] + "/";
    }
    return url;
}

$(document).ready(function () {
    var host = getUrlBase();
    $("#ventanaHuella").load(host + HPaginaModal);
});

function getTrxHD() {
    var d = new Date();
    var s = null;
    try {
        s = (d.getFullYear() +
            ("00" + (d.getMonth() + 1)).slice(-2) +
            ("00" + d.getDate()).slice(-2) +
            ("00" + d.getHours()).slice(-2) +
            ("00" + d.getMinutes()).slice(-2) +
            ("00" + d.getSeconds()).slice(-2) +
            ("00" + d.getMilliseconds()).slice(-2));

    }
    catch (err) {
        s = "000000000000";
    }
    return s;
}

function getDatosEntrada(jsin) {
    rstStatus = new Boolean(false);
    try {

        if (jsin.afectaHD == undefined || jsin.afectaHD == "")
            afectaBitHd = true;
        else
            afectaBitHd = jsin.afectaHD;

        if ((jsin.validarEmp === undefined || jsin.validarAut === undefined || jsin.tipo === undefined || jsin.app === undefined || jsin.ws == undefined || jsin.top === undefined || jsin.perfiles === undefined) ||
            (jsin.validarEmp == "" || jsin.validarAut == "" || jsin.tipo == "" || jsin.app == "" || jsin.ws == "" || jsin.top == "" || jsin.perfiles == "")) {
            
            GuardarResultado(false, "Error: Faltan parámetros de entrada en el JSON.");            
            if (callback == undefined) RecibirResultadoHuella(resultado);
            else callback(resultado);
        }
        else {
            rstStatus = true;
            validarEmp = jsin.validarEmp;
            validarAut = jsin.validarAut;
            tipo = jsin.tipo;
            aplicacion = jsin.app;
            trxHD = getTrxHD();
            ws = jsin.ws;
            topOperacion = jsin.top;
            perfiles = jsin.perfiles;
            empAutenticado = validarEmp;            
        }
    }
    catch (err) {
        GuardarResultado(false, "Error: Faltan parámetros de entrada en el JSON.");
        //RecibirResultadoHuella(resultado);
        if (callback == undefined) RecibirResultadoHuella(resultado);
        else callback(resultado);
    }

    return rstStatus;
}

function AutenticacionHuella(jsonEntrada, metodo) {
    if(metodo!=undefined)callback=metodo;

    if (getDatosEntrada(jsonEntrada) == true) {
        $('#reemplazo').show();
        $j('#modalHuella').modal();
        ventanaHuellaAbierta = true;
        try {
            document.getElementById("huellaAviso").innerHTML = "Componente de huella digital. Espere mientras se carga el componente.";
        } catch (err) {
            GuardarResultado(false, "No se cargó correctamente el modal de Huella Digital.");
        }

        if (tipo == 1) { //autenticar empleado(s)
            var res = null;
            if (validarAut.split(",").length > 1) { //muchos empleados
                document.getElementById("huellaTag1").innerHTML = "Perfiles Autorizadores:";

                var strempleados = "";
                var obj = svrPerfilEmpleados(perfiles);
                if (obj.Estatus != 0)
                    strempleados += "<td>" + perfiles + "</td>";
                else
                    for (var i = 0; i < obj.ltsPerfiles.length ; i++)
                        strempleados += "<BR>" + obj.ltsPerfiles[i].Perfil + " - " + obj.ltsPerfiles[i].Descripcion + "";

                document.getElementById("huellaTag2").innerHTML = strempleados;
                var cadenajson = ConstruirJsonHuella(validarAut, 1);
                document.getElementById("huellaAviso").innerHTML = "Componente Cargado.<br>Siga las indicaciones en pantalla.";
                setTimeout(function () { EjecutaPlugin(cadenajson); }, 1000);

            } else { //un empleado
                res = ServConsultaEmpleado(validarAut);
                if (res.NoError == 0) {
                    document.getElementById("huellaTag1").innerHTML = "Nombre: " + res.InformacionInicial.NombreEmpleado;
                    document.getElementById("huellaTag2").innerHTML = "<td>Puesto: " + res.InformacionInicial.PuestoRol + " - " + res.InformacionInicial.NombreCortoEmpleado + "</td><td>Numero: " + res.InformacionInicial.NoEmpleado + "</td>";
                    document.getElementById("huellaAviso").innerHTML = "Componente Cargado.<br>Siga las indicaciones en pantalla.";
                    var cadenajson = ConstruirJsonHuella(validarAut, 1);
                    setTimeout(function () { EjecutaPlugin(cadenajson); }, 1000);
                } else {
                    //GuardarResultado(false, res.Descripcion);
                    document.getElementById("huellaTag1").innerHTML = "Autenticación del empleado: ";
                    document.getElementById("huellaTag2").innerHTML = validarAut;
                    document.getElementById("huellaAviso").innerHTML = "Componente Cargado.<br>Siga las indicaciones en pantalla.";
                    var cadenajson = ConstruirJsonHuella(validarAut, 1);
                    setTimeout(function () { EjecutaPlugin(cadenajson); }, 1000);
                }
            }
        } else if (tipo == 2) { //autenticar cliente(s)
            document.getElementById("huellaTag1").innerHTML = "Autenticación del cliente.";
            document.getElementById("huellaTag2").innerHTML = "";
            var cadenajson = ConstruirJsonHuella(validarAut, 2);
            if (validarAut.split(",").length > 1) {
                document.getElementById("huellaAviso").innerHTML = "Componente Cargado.<br>Siga las indicaciones en pantalla.";
                setTimeout(function () { EjecutaPlugin(cadenajson); }, 1000);
            } else { //un cliente
                document.getElementById("huellaAviso").innerHTML = "Componente Cargado.<br>Siga las indicaciones en pantalla.";
                setTimeout(function () { EjecutaPlugin(cadenajson); }, 1000);
            }
        } else {
            GuardarResultado(false, "Error en los parámetros del Método AutenticacionHuella:<br>Argumento Tipo inválido.");
        }
    }
}

function svrPerfilEmpleados(perfiles) {
    var objRespuesta = { Estatus: null, msjError: null };
    var url = getUrlHuella(HUrlDescPerfiles);
    $.ajax({
        url: "" + url,
        contentType: "application/json; charset=UTF-8",
        type: "POST",
        async: false,
        data: JSON.stringify({
            "opc": "" + 102,
            "perfiles": "" + perfiles
        }),
        dataType: 'json',
        crossDomain: true,
        success: function (data) {
            objRespuesta = data;
        },
        error: function () {
            objRespuesta.Estatus = 1;
            objRespuesta.msjError = "Error: No se pudo contactar al servicio de validacion de perfiles.";
        }
    });
    return objRespuesta;
}

function ServConsultaEmpleado(empleado) {
    var objRespuesta = { NoError: null, Descripcion: null};
    var url = getUrlHuella(HUrlValidaEmpleado);
    $.ajax({
        url: "" + url,
        contentType: "application/json; charset=UTF-8",
        type: "POST",
        async: false,
        data: JSON.stringify({
            "NoEmpleado": "" + empleado
        }),
        dataType: 'json',
        crossDomain: true,
        success: function (data) {
            objRespuesta = data;
        },
        error: function () {
            objRespuesta.NoError = 1;
            objRespuesta.Descripcion = "Error: No se pudo contactar al servicio de validacion de empleado.";
        }
    });
    return objRespuesta;
}

function getRegistraBitacora() {
    try {

        var url = getUrlHuella(HUrlBitAutorizacion);
        var fecha = new Date();

        var s = (fecha.getFullYear() + "/" + ("00" + (fecha.getMonth() + 1)).slice(-2) + "/" + ("00" + fecha.getDate()).slice(-2));

        $.ajax({
            url: "" + url,
            contentType: "application/json; charset=UTF-8",
            type: "POST",
            async: false,
            data: JSON.stringify({
                "EmpleadoOpera": "" + validarEmp,
                "EmpleadoValida": "" + empAutenticado,
                "FechaOpera": "" + s,
                "FechaValida": "" + s,
                "TerminalOpera": "" + ws,
                "TerminalValida": "" + ws,
                "TipoOperacion": topOperacion,
                "Transaccion": 0
            }),
            dataType: 'json',
            crossDomain: true,
            success: function (data) {
                if (data.NoError == 0) {
                    descBitHD = "Se registro correctamente en wsRegistraBitacoraHuella";
                } else {
                    descBitHD = "Error: No se registró en wsRegistraBitacoraHuella  -  Problemas al registrarlo. ";
                }
            },
            error: function () {
                descBitHD = "Error: Al consumir el servicio wsRegistraBitacoraHuella";
            }
        });
    }
    catch (err) {
        descBitHD = "Con error " + err;
    }

}

function ConstruirJsonHuella(ids, tipo, coordenadas) {
    var json = '';
    if (ids.split(",").length > 1) {
        json += '{"collection":[' + ids;
        json += '],"settings":{"numberAttempts": ' + noIntentosHD;
    }
    else {
        if (tipo == 1)
            json += '{"employee":{"numberEmployee":';
        else
            json += '{"client":{"numberClient":';
        json += '"' + ids.replace(new RegExp("'", 'g'), "") + '"},"settings":{"numberAttempts": ' + noIntentosHD;
    }
    if (coordenadas !== undefined)
        json += ',"location":[' + coordenadas[0] + ',' + coordenadas[1] + ']';
    json += '}}';
	
	alert ("Autorizador para HD"  + json);
	
    return json;
}

function EjecutaPlugin(cadenajson) {
	
	alert("Validar huellas del empleado ");
	mensaje = "";
	descBitHD = "";
	empAutenticado = "222222";
	
	GuardarResultado(true, "Autenticación Correcta" + mensaje + " <br> descBitHD -" + descBitHD);
	
	return;
	
    var objetoRespuesta = null;
    try {
        var msg = CJSGlobalObject.JSCallEnviaMensaje('standard', cadenajson);
        objetoRespuesta = JSON.parse(msg);

    } catch (err) {
		GuardarResultado(true, "Autenticación Correcta" + mensaje + " <br> descBitHD -" + descBitHD);
        //GuardarResultado(false, "No se pudo iniciar el componente de autenticación de huellas digitales" +  "<br>Error: " + err);
        //CerrarVentana(true);
        return;
    }

    var mensaje = "";
    if (objetoRespuesta.PluginResponse.processDetail != "")
        mensaje += '<br>' + objetoRespuesta.PluginResponse.processDetail;
    if (objetoRespuesta.PluginResponse.authenticated == 1) {

        try {
            if (objetoRespuesta.PluginResponse.coincidence != "") {
                
                empAutenticado = objetoRespuesta.PluginResponse.coincidence;
            }
        }
        catch(err){
            descBitHD = "Error en la lectura del personal autenticado";
        }


        if (afectaBitHd == true) {
            getRegistraBitacora();
        } else {
            descBitHD = "El front cancelo el registro de bitacora.";
        }


        GuardarResultado(true, "Autenticación Correcta" + mensaje + " <br> descBitHD -" + descBitHD);


    } else {
        if (objetoRespuesta.Issue.detail.message != "")
            mensaje += "<br>" + objetoRespuesta.Issue.detail.message;

		GuardarResultado(true, "Autenticación Correcta" + mensaje + " <br> descBitHD -" + descBitHD);
        //GuardarResultado(false, "Autenticación Incorrecta" + mensaje);
    }

    
}

function GuardarResultado(exito, descripcion) {
    $('#reemplazo').hide();
    var objJson = "";

    if (exito)
        objJson += '{"Status":1';
    else
        objJson += '{"Status":0';
    objJson += ',"Descripcion":"' + descripcion + '", "trxHD":"' + trxHD + '", "Autorizo":"' + empAutenticado + '", "DescSvrBitacora":"' + descBitHD + '"}';
    resultado = JSON.parse(objJson);
    try {
        if (ventanaHuellaAbierta) {
            document.getElementById("huellaAviso").innerHTML = resultado.Descripcion;
            iniciarTimer();
        }
    } catch (err) { }
}

function iniciarTimer() {
    tiempoRestante = tmrEspera;
    timerEspera();
    refFuncionCont = setInterval(function () { timerEspera() }, 1000);
}

function timerEspera() {
    document.getElementById("huellaTimer").innerHTML = "Tiempo de espera (" + (tiempoRestante) + ")";
    if (tiempoRestante > 0) {
        tiempoRestante -= 1;
    }
    else {
        CerrarVentana(true);
    }
}

function eventFire(el, etype) {
    if (el.fireEvent) {
        el.fireEvent('on' + etype);
    } else {
        var evObj = document.createEvent('Events');
        evObj.initEvent(etype, true, false);
        el.dispatchEvent(evObj);
    }
}

function CerrarVentana(cerrarTimer) {
    if (ventanaHuellaAbierta) {
        clearInterval(refFuncionCont);

        try{
            document.getElementById("ImporteAutorizar").innerHTML = "";
        }
        catch(err){
            console.log(err);
        }

        if (resultado == null)
            GuardarResultado(false, "Error: La autenticación no se completó.");
        if (cerrarTimer) {
            ventanaHuellaAbierta = false;
            eventFire(document.getElementById('huellaBotonCerrar'), 'click');
        }
        //RecibirResultadoHuella(resultado);
        if (callback == undefined) RecibirResultadoHuella(resultado);
        else callback(resultado);
    }
}

function setHuellaMsgImporte(infoHtml){
    try{
        document.getElementById("ImporteAutorizar").innerHTML = infoHtml;
    }
    catch(err){
        console.log(err);
    }
}