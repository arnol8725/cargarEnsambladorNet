﻿/*QA*/
var urlValidaFondeo = "Servicios/FondeoAutomatico/FondeoAutomatico.svc/wsFondeoValidaSaldo";
var urlAfectaCajaFondeo = "Servicios/FondeoAutomatico/FondeoAutomatico.svc/wsFondeoAfectacionCaja";
var urlUtileria = "Servicios/wsUtileriaCaja/wsUtileria.svc/wsTiendaEmpleado"; //empleado
var urlUtileriaFondeo = "Servicios/Comun/WsCajaComun.svc/wsConsultaInformacionInicial";
var urlPerfilesAutorizador = "Servicios/wsUtileriaCaja//wsUtileria.svc/wsPerfilAutorizador"; //empleado

//arqueo
var urlDivisas = "Servicios/Comun/WsCajaComun.svc/wsconsultaDivisa";
var urlDenominaciones = "Servicios/Arqueo/WsCajaArqueo.svc/wsConsultaDenominacion";

var urlElemArquear = "";

//huellas
var urlComponenteHuellas = "Fronts/HuellaDigital/HuellaDigital.html";

//TRASPASOS
var urlTraspDenominaciones = "Servicios/Traspasos/Traspasos.svc/wsConsultaDenominacion";
var urlConfiguraMenu = "Servicios/Traspasos/Traspasos.svc/wsConfiguraMenu";

var urlConsultaConcentracionSaldosACaja = "Servicios/Traspasos/Traspasos.svc/wsConsultaConcentracionSaldosACaja";
var urlConsultaHistorialTraspasos = "Servicios/Traspasos/Traspasos.svc/wsConsultaHistorialTraspasos";
var urlConsultaTraspasosSaldosACajeros = "Servicios/Traspasos/Traspasos.svc/wsConsultaTraspasosSaldosACajeros";
var urlConsultaFondeoEfecCajaACajero = "Servicios/Traspasos/Traspasos.svc/wsConsultaFondeoEfecCajaACajero";
var urlRealizaConcentracion = "Servicios/Traspasos/Traspasos.svc/wsRealizaConcentracion";
var urlConfirmaConcentracion = "Servicios/Traspasos/Traspasos.svc/wsConfirmaConcentracion";
var urlCancelaTraspaso = "Servicios/Traspasos/Traspasos.svc/wsCancelaTraspaso";
var urlGeneraCartaFaltante = "Servicios/Traspasos/Traspasos.svc/wsGeneraCartaFaltante";

//CONFIRMACION
var urlConsultaTiposdePago = "Servicios/Traspasos/Traspasos.svc/wsConsultaTiposdePago";
var urlConsultaEgresos = "Servicios/Traspasos/Traspasos.svc/wsConsultaEgresos";
var urlConsultaConfirmacionPendientes = "Servicios/Traspasos/Traspasos.svc/wsConsultaConfirmacionPendientes";
var urlConsultaRecepcionConcentracionSaldosCajeroaCaja = "Servicios/Traspasos/Traspasos.svc/wsConsultaRecepcionConcentracionSaldosCajeroaCaja";
var urlSolicitarFondeo = "Servicios/Traspasos/Traspasos.svc/wsSolicitarFondeo";
var urlEgresaTraspaso = "Servicios/Traspasos/Traspasos.svc/wsEgresaTraspaso";

//IMPRESION
var urlDefaulTicket = "http://localhost:9001/WSDesTecAppsLocal/EstablecerDefaultTicket";
var urlGeneraTicket = "http://localhost:9001/WSDesTecAppsLocal/GenerarTickets";
var urlPreviewTicket = "http://localhost:9001/WSDesTecAppsLocal/PrevisualizarTickets?IdTicket=";
var urlImprimirTicket = "http://localhost:9001/WSDesTecAppsLocal/ImprimirTickets?idticket=";

var urlDefaultCarta = "http://localhost:9001/WSDesTecAppsLocal/EstablecerDefaultCarta";
var urlImprimirCarta = "http://localhost:9001/WSDesTecAppsLocal/ImprimirDocumentoPDFCarta";

//SEGURIDAD
var urlInsertaMedidaSeguridad = "Servicios/MediasSeguridad/MedidasSeguridadCaja.svc/wsInsertaMedidaSeguridad";
var urlObtieneMedidaSeguridad = "Servicios/MediasSeguridad/MedidasSeguridadCaja.svc/wsObtieneMedidaSeguridad";

//ADMINCAJA
var urlConsultaTareas = "Servicios/RutinasAperturaCierre/RutinasAperturaCierre.svc/wsConsultaTareas";

//Ingresos Diversos
var urlIngresosDisvr = "Servicios/IngresoDiverso/WSIngresoDiverso.svc/wsIngresos";
var urlArqueoDivsvr = "Servicios/Arqueo/WsCajaArqueo.svc/wsCstArqueo";