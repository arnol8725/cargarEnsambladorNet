﻿var ImpresionService = {
    getUrlServicio: function getUrlServicio(nombreServicio) {
        var protocolo = "http";
        var ipPuerto = "";
        var rutaAplicativo = "localhost:9001/WSDesTecAppsLocal"
        var urlBase = protocolo + "://" + ipPuerto + "/" + rutaAplicativo + "/";
        var r = urlBase + nombreServicio;
        return r;
    }
}

function generaTicket(parametros) {
    $.LoadingOverlay("show");
    var urlServicio = ImpresionService.getUrlServicio("GenerarTickets");
    var dfd = $.Deferred();
    doJsonPost(urlServicio, parametros, true).done(function (objResponse) {
        dfd.resolve(objResponse);
        $.LoadingOverlay("hide");
    }).fail(function () {
        $.LoadingOverlay("hide");
    });
    return dfd.promise();
}

function imprimirTicket(ticket) {
    $.LoadingOverlay("show");
    var urlServicio = ImpresionService.getUrlServicio("ImprimirTickets?idticket=");
    urlServicio += ticket;
    var parametros = {};
    var dfd = $.Deferred();
    doJsonPost(urlServicio, parametros, true).done(function (objResponse) {
        dfd.resolve(objResponse);
        $.LoadingOverlay("hide");
    }).fail(function () {
        $.LoadingOverlay("hide");
    });
    return dfd.promise();
}
