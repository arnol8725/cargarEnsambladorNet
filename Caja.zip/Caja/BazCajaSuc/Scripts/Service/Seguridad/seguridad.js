﻿//CONSULTA MEDIDAS DE SEGURIDAD

var SeguridadService = {
getUrlServicio:function getUrlServicio(nombreServicio) {
        var protocolo = "http";
        var ipPuerto = ""
        var rutaAplicativo = "";                    
        if(window.location.hostname == "localhost"){
            ipPuerto = "10.54.28.221:9014";
            rutaAplicativo = "Caja/Servicios/MediasSeguridad/MedidasSeguridadCaja.svc";
        }
        else{
            ipPuerto= window.location.host;
            rutaAplicativo = "Caja/Servicios/MediasSeguridad/MedidasSeguridadCaja.svc";
        }                    
        var urlBase = protocolo + "://" + ipPuerto + "/" + rutaAplicativo + "/";
        var r = urlBase + nombreServicio;
        return r;
    }
}

var InfEmpleadoService = {
    getUrlServicio: function getUrlServicio(nombreServicio) {
        var protocolo = "http";
        var ipPuerto = ""
        var rutaAplicativo = "";
        if (window.location.hostname == "localhost") {
            ipPuerto = "10.54.28.221:9014";
            rutaAplicativo = "Caja/Servicios/Comun/WsCajaComun.svc"; //wsConsultaInformacionInicial
        }
        else {
            ipPuerto = window.location.host;
            rutaAplicativo = "Caja/Servicios/Comun/WsCajaComun.svc";
        }
        var urlBase = protocolo + "://" + ipPuerto + "/" + rutaAplicativo + "/";
        var r = urlBase + nombreServicio;
        return r;
    }
}

function wsObtieneMedidaSeguridad(opcion) {
    $('#lblMensaje').html("");
    var consulta = {
        "IdProceso": opcion
    };
    $.ajax({
        url: SeguridadService.getUrlServicio("wsObtieneMedidaSeguridad"),
        type: "POST",
        data: JSON.stringify(consulta),
        cache: false,
        contentType: "application/json; charset=UTF-8",
        dataType: 'JSON',
        success: function (resp) {
            switch (resp.NoError) {
                case 0:
                    if (resp.LstMedSeg) {
                        if (resp.LstMedSeg.length > 0)
                            writeMedidasSeguridad(resp.LstMedSeg);
                        else {
                            mostrarCarga(false);
                            MostrarError(resp.descripcionError || "Parámetro incorrecto");
                        }
                    } else {
                        mostrarCarga(false);
                        MostrarError(resp.descripcionError || "Ocurrio un error en el servicio");
                    }
                    break;
                case 1:
                    mostrarCarga(false);
                    MostrarError(resp.descripcionError);
                    break;
            }
        },
        error: function () {
            mostrarCarga(false);
            MostrarError("Ocurrió un error en el servidor al consultar las medidas de seguridad");
        }
    });
}

//INSERTA MEDIDAS DE SEGURIDAD
function wsInsertaMedidaSeguridad(medidas) {
    $('#lblMensaje').html("");
    var consulta = {
        "LstMedSeg": medidas
    };
    $.ajax({
        url: SeguridadService.getUrlServicio("wsInsertaMedidaSeguridad"),
        type: "POST",
        data: JSON.stringify(consulta),
        cache: false,
        contentType: "application/json; charset=UTF-8",
        dataType: 'JSON',
        success: function (resp) {
            mostrarCarga(false);
            MostrarExito("Registro correcto, puede cerrar la ventana.");               
        },
        error: function () {
            mostrarCarga(false);
            MostrarError("Ocurrió un error en el servidor al ingresar las medidas de seguridad");
        }
    });
}

function getInfInicial(usuario) {
    var objRespuesta = { NoError: null, Descripcion: null };
    var consulta = {
        "NoEmpleado": usuario
    };
    return $.ajax({
        url: InfEmpleadoService.getUrlServicio("wsConsultaInformacionInicial"),
        type: "POST",
        data: JSON.stringify(consulta),
        cache: false,
        contentType: "application/json; charset=UTF-8",
        dataType: 'JSON',
        success: function (resp) {
            objRespuesta = resp;
        },
        error: function () {
            objRespuesta.NoError = 1;
            objRespuesta.Descripcion = "Error: No se pudo contactar al servicio de validación de empleado.";
        }
    });    
}