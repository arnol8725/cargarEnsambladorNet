﻿//Selecciona impresora por default
//Entrada: tipo=T (impresora de tickets), C=Impresora Carta.... disableMsg=true(mostrar mensaje), false(no mostrar mensaje)
//         callback: metodo de retorno.......isAsync= true(asincrono), false(no asincrono)
//Salida: true (exito) o false (false);
function selectDefault(tipo, disableMsg, isAsync, callback) {
    let result;
    let url=tipo=="T"?urlDefaulTicket:urlDefaultCarta;    
    $.ajax({
        url: url,
        type: "POST",
        async: isAsync,
        contentType: "application/json; charset=utf-8",
        dataType: 'json',
        success: function (data) {
            if(disableMsg){
                let status=data.EstatusExito?0:1;
                showMesagge(status, data.Detalle);
            }
            if (callback!=undefined) callback(data.EstatusExito);
            result=data.EstatusExito;
        },
        error: function (jqXHR, status, error) {
            if(disableMsg) showMesagge(1, jqXHR.Detalle || "Ocurrio un error al seleccionar la impresora default");
            if (callback!=undefined) callback(false);
            result=false;
       }
    });
    if(!isAsync) return result;
}

//Genera tickets
//Entrada: listaTickets=Lista de tickets a imprimir.... disableMsg=true(mostrar mensaje), false(no mostrar mensaje)
//         callback: metodo de retorno.......isAsync= true(asincrono), false(no asincrono)
//Salida: true (exito) o false (false);
function generaTicket(listaTickets, disableMsg, isAsync,callback) {        
    return $.ajax({
        url: urlGeneraTicket,
        type: "POST",           
        data: JSON.stringify(listaTickets),
        contentType: "application/json; charset=utf-8",
        dataType: 'json',
        success: function (data) {            
            if(disableMsg){
                let status=data.EstatusExito?0:1;
                showMesagge(status, data.Detalle);
            }
            if (callback!=undefined) callback(data);            
        },
        error: function (jqXHR, status, error) {
            if(disableMsg) showMesagge(1, jqXHR.Detalle || "Ocurrio un error al generar el ticket");            
            let esult={EstatusExito:false, Contenido:-1, Detalle:jqXHR.Detalle || "Ocurrio un error al generar el ticket"};
            if (callback!=undefined) callback(result);
        }
    });   
}

//Previsualiza tickets
//Entrada: id=Identificador devuelto en el metodo generaTicket.... disableMsg=true(mostrar mensaje), false(no mostrar mensaje)
//         callback: metodo de retorno.......isAsync= true(asincrono), false(no asincrono)
//Salida: Lista de imagenes en Base64, cuando es null, hubo un error;
function previsualizarTicket(id, disableMsg,isAsync, callback) { 
    let result;
    $.ajax({
        url: urlPreviewTicket+id,
        type: "POST",        
        contentType: "application/json; charset=utf-8",
        dataType: 'json',
        async: isAsync,
        success: function (data) {            
            if(disableMsg){
                let status=data.EstatusExito?0:1;
                showMesagge(status, data.Detalle);
            }
            if (callback!=undefined) callback(data.Contenido);
            result= data.Contenido;
        },
        error: function (jqXHR, status, error) {
            if(disableMsg) showMesagge(1, jqXHR.Detalle|| "Ocurrio un error al visualzar el ticket");            
            if (callback!=undefined) callback(null);
            result=null;
        }
    });
    if(!isAsync) return result;
}

//Imprime tickets
//Entrada: id=Identificador devuelto en el metodo generaTicket.... disableMsg=true(mostrar mensaje), false(no mostrar mensaje)
//         callback: metodo de retorno.......isAsync= true(asincrono), false(no asincrono)
//Salida: true (exito), false(error)
function imprimirTicket(id, disableMsg,isAsync, callback) {     
    return $.ajax({
        url: urlImprimirTicket+id,
        type: "POST",        
        contentType: "application/json; charset=utf-8",
        dataType: 'json',        
        success: function (data) {            
            if(disableMsg){
                let status=data.EstatusExito?0:1;
                showMesagge(status, data.Detalle);
            }
            if (callback!=undefined) callback(data);            
        },
        error: function (jqXHR, status, error) {
            if(disableMsg) showMesagge(1, jqXHR.Detalle || "Ocurrio un error al imprimir el ticket");
            let result={EstatusExito:false, Contenido:-1, Detalle:jqXHR.Detalle || "Ocurrio un error al imprimir el ticket"};
            if (callback!=undefined) callback(result);            
        }
    });    
}

//Imprime carta
//Entrada: ruta= ruta de donde se encuentra la Carta.... disableMsg=true(mostrar mensaje), false(no mostrar mensaje)
//         callback: metodo de retorno.......isAsync= true(asincrono), false(no asincrono)
//Salida: true (exito), false(error)
function imprimirCarta(ruta, disableMsg,isAsync, callback) {    
    let jsonValue = {"Ruta": ruta};
    return $.ajax({
        url: urlImprimirCarta,
        type: "POST",        
        data: JSON.stringify(jsonValue),
        contentType: "application/json; charset=utf-8",
        dataType: 'json',
        success: function (data) {            
            if(disableMsg){
                let status=data.EstatusExito?0:1;
                showMesagge(status, data.Detalle);
            }
            if (callback!=undefined) callback(data);            
        },
        error: function (jqXHR, status, error) {
            if(disableMsg) showMesagge(1, jqXHR.Detalle || "Ocurrio un error al imprimir carta");
            result={EstatusExito:false, Contenido:-1, Detalle:jqXHR.Detalle || "Ocurrio un error al imprimir carta"};
            if (callback!=undefined) callback(result);
        }
    });    
}