var CentrocanjeService = {
getUrlServicio:function getUrlServicio(nombreServicio) {
        var protocolo = "http";
        var ipPuerto = ""
        var rutaAplicativo = "";                    
        if(window.location.hostname == "localhost"){
            ipPuerto = "localhost:57561";
            rutaAplicativo = "CentroCanje.svc/CentroCanjeRest";
        }
        else{
            ipPuerto= window.location.host;
            rutaAplicativo = "Caja/Servicios/CentroCanje/CentroCanje.svc/CentroCanjeRest";
        }                    
        var urlBase = protocolo + "://" + ipPuerto + "/" + rutaAplicativo + "/";
        var r = urlBase + nombreServicio;
        return r;
    }
}

function centroCanjeAfectacionCaja(objeto){
	$.LoadingOverlay("show");
    var urlServicio = CentrocanjeService.getUrlServicio("CentroCanjeAfectacionCaja");
    var parametros = objeto;
    
    var dfd = $.Deferred();
    doJsonPost(urlServicio, parametros, false).done(function (objResponse) {
        dfd.resolve(objResponse);
        $.LoadingOverlay("hide");
    }).fail(function () {
        $.LoadingOverlay("hide");
    });
    return dfd.promise();

}

function optionAfectaCaja(){
		$.LoadingOverlay("show");
    var urlServicio = CentrocanjeService.getUrlServicio("OptionAfectaCaja");
    var parametros = {


    	
    };
    var dfd = $.Deferred();
    doJsonPost(urlServicio, parametros, false).done(function (objResponse) {
        dfd.resolve(objResponse);
        $.LoadingOverlay("hide");
    }).fail(function () {
        $.LoadingOverlay("hide");
    });
    return dfd.promise();

}

function denominaciones(){
		$.LoadingOverlay("show");
    var urlServicio = CentrocanjeService.getUrlServicio("Denominaciones");
    var dfd = $.Deferred();
    doJsonPost(urlServicio, '', false).done(function (objResponse) {
        dfd.resolve(objResponse);
        $.LoadingOverlay("hide");
    }).fail(function () {
        $.LoadingOverlay("hide");
    });
    return dfd.promise();

}

function denominacionesRetiro(){
		$.LoadingOverlay("show");
    var urlServicio = CentrocanjeService.getUrlServicio("DenominacionesRetiro");
    var dfd = $.Deferred();
    doJsonPost(urlServicio, '', false).done(function (objResponse) {
        dfd.resolve(objResponse);
        $.LoadingOverlay("hide");
    }).fail(function () {
        $.LoadingOverlay("hide");
    });
    return dfd.promise();

}