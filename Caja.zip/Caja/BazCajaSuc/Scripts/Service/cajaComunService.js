﻿/*
* @Author: jagonzalezu
* @Date:   2018-02-27 17:55:01
* @Last Modified by:   jagonzalezu
* @Last Modified time: 2018-02-27 19:02:03
*/
var CajaComunService = {
getUrlServicio:function getUrlServicio(nombreServicio) {        
        var protocolo = "http";
        var ipPuerto = ""
        var rutaAplicativo = "";                    
        if(window.location.hostname == "localhost"){
            ipPuerto = "10.54.28.222:9014";
            rutaAplicativo = "Caja/Servicios/Comun/WsCajaComun.svc";
        }
        else{
            ipPuerto= window.location.host; //<- Esto es posible para aplicaciones que se encuentren en el mismo puerto (Caja por ejemplo)
            rutaAplicativo = "Caja/Servicios/Comun/WsCajaComun.svc";
        }                    
        var urlBase = protocolo + "://" + ipPuerto + "/" + rutaAplicativo + "/";
        var r = urlBase + nombreServicio;
        return r;
    }
}

function datosUsuario(entrada) {
    $.LoadingOverlay("show");
    var urlServicio = CajaComunService.getUrlServicio("wsConsultaInformacionInicial");
    var parametros = {
        NoEmpleado: entrada.noEmpleado//string        
    };
    var dfd = $.Deferred();
    doJsonPost(urlServicio, parametros).done(function (objResponse) {
        dfd.resolve(objResponse);
        $.LoadingOverlay("hide");
    }).fail(function () {
        $.LoadingOverlay("hide");
    })
    return dfd.promise();
}
