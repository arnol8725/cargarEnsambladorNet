﻿function serviceFondeoValidaSaldo(divisa, monto, usuario, ws) {
    var url = getUrlFondeo(urlValidaFondeo);    
    $.ajax({
        url: "" + url,
        contentType: "application/json; charset=UTF-8",
        type: "POST",
        data: JSON.stringify({
            "Usuario": "" + usuario,
            "Monto": monto,
            "Divisa": divisa,
            "WS": "" + ws
        }),
        dataType: 'json',
        crossDomain: true,
        success: function (data) {
            //mostrarCarga(false);
            serviceRestValidaSaldo(data);
        },
        error: function () {
            //mostrarCarga(false);
            $("#lblMensaje").text("Ocurrió un error en el consumo del servicio");
            $('#ErrorFondeo').show();
        }
    });
}


function serviceAfectaCajaFondeo() {
    var url = getUrlFondeo(urlAfectaCajaFondeo);
    $.ajax({
        url: "" + url,
        contentType: "application/json; charset=UTF-8",
        type: "POST",
        data: JSON.stringify({
            "Usuario": "" + usuario,
            "Monto": montoTotal,
            "Divisa": divisa,
            "WS": "" + ws
        }),
        dataType: 'json',
        crossDomain: true,
        success: function (data) {
            mostrarCarga(false);
            serviceRestAfectaCaja(data);
        },
        error: function () {
            mostrarCarga(false);
            $('#content').show();
            document.getElementById("resultado").innerHTML = "Ocurrió un error en el consumo del servicio No se realizo el fondeo";
            document.getElementById("resultadoExito").innerHTML = "";
        }
    });
}

function getPerfilesAutorizador() {
    var url = getUrlFondeo(urlPerfilesAutorizador);
    try {

        $.ajax({
            url: "" + url,
            contentType: "application/json; charset=UTF-8",
            type: "POST",
            data: JSON.stringify({
                "opc": "" + "1",
                "IdModulo": "" + "27",
                "IdFolio": "" + "1",
                "Empleado": "" + usuario
            }),
            dataType: 'json',
            crossDomain: true,
            success: function (data) {
                
                if(data.EmpAutorizador == "'"||data.EmpAutorizador == ",")
                {
                    data.EmpAutorizador = ""   
                }

                if(puestoBaseId == 632|| puestoRolId == 632){
                    if(data.EmpAutorizador.length > 0){
                        data.EmpAutorizador=data.EmpAutorizador + ",'"+usuario+"'";
                    }
                    else{
                        data.EmpAutorizador=data.EmpAutorizador + "'"+usuario+"'";   
                    }                    
                }

                fnCargoPerfiles( data);
            },
            error: function () {
                mostrarCarga(false);
                $('#content').show();
                document.getElementById("resultado").innerHTML = "Ocurrió un error en el consumo del servicio NO se obtuvieron los perfiles Autorizadores";
                document.getElementById("resultadoExito").innerHTML = "";
            }
        });
    }
    catch (err) {
        mostrarCarga(false);
        $('#content').show();
        document.getElementById("resultado").innerHTML = "[getPerfilesAutorizador] - Ocurrió un error en el consumo del servicio *" + err.toString();
        document.getElementById("resultadoExito").innerHTML = "";
    }
    
}


function getUrlFondeo(servicio) {
    var url = "";
    url = "http://" + window.location.hostname + ":9014/Caja/" + servicio;
    return url;

}