/*
* @Author: B182380
* @Date:   2018-02-22 17:22:34
* @Last Modified by:   B182380
* @Last Modified time: 2018-02-23 11:55:35
*/
let erroresCount = 0; //Para evitar que se cicle
let bitacoraCountRegistro = 0; //Para evitar que se cicle el registro
var BitacoraService = {
getUrlServicio:function getUrlServicio(nombreServicio) {

        // var protocolo = "http"
        // var ipPuerto = "10.54.28.226:9014"
        // var rutaAplicativo = "BazCajaSuc/Servicios/TiposPago/TiposPago.svc"
        // var protocolo = "http";
        // var ipPuerto = "10.54.28.114:9014";
        // var rutaAplicativo = "BazCajaSuc/Servicios/TiposPago/TiposPago.svc";
        var protocolo = "http";
        var ipPuerto = ""
        var rutaAplicativo = "";                    
        if(window.location.hostname == "localhost"){
            ipPuerto = "localhost:62934";
            rutaAplicativo = "Cheques.svc/ChequesDevolucion";
        }
        else{
            ipPuerto= window.location.host;
            rutaAplicativo = "Caja/Servicios/RechazoCheque/Cheques.svc/ChequesDevolucion";
        }                    
        var urlBase = protocolo + "://" + ipPuerto + "/" + rutaAplicativo + "/";
        var r = urlBase + nombreServicio;
        return r;
    }
}

function registraHistorial(entrada,id,severidad=1) {  
    var urlServicio = BitacoraService.getUrlServicio("RegistraHistorial");
    var parametros = {
        Mensaje: "ID/BR["+id+"] "+entrada,//string
        NivelSeveridad: severidad
    };
    var dfd = $.Deferred();
    doHistorialPost(urlServicio, parametros, true).done(function (objResponse) {
        erroresCount = 0;
        dfd.resolve(objResponse);
    }).fail(function () {
        erroresCount += 1;
    })
    return dfd.promise();
} //RequestMensaje:void

/*
RequestMensaje = {
    Mensaje: mensaje
}

NIVEL DE SEVERIDAD:
    Debug = 0,
    Info = 1,
    Warning = 2,
    Error = 3,
    Fatal = 4
*/