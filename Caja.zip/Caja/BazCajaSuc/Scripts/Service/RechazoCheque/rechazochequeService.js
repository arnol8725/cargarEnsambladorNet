/*
* @Author: B182380
* @Date:   2018-02-22 16:54:41
* @Last Modified by:   B182380
* @Last Modified time: 2018-02-26 17:13:16
*/
var RechazoChequeService = {
getUrlServicio:function getUrlServicio(nombreServicio) {
        var protocolo = "http";
        var ipPuerto = ""
        var rutaAplicativo = "";                    
        if(window.location.hostname == "localhost"){
            ipPuerto = "localhost:62934";
            rutaAplicativo = "Cheques.svc/ChequesDevolucion";
        }        
        else{
            ipPuerto= window.location.host;
            rutaAplicativo = "Caja/Servicios/RechazoCheque/Cheques.svc/ChequesDevolucion";
        }                    
        var urlBase = protocolo + "://" + ipPuerto + "/" + rutaAplicativo + "/";
        var r = urlBase + nombreServicio;
        return r;
    }
}

function DigitalizarCheque(entrada) {
    $.LoadingOverlay("show");
    var urlServicio = RechazoChequeService.getUrlServicio("EscanearCheque");
    var parametros = {
        Controlador: entrada.controlador,
        Formato: entrada.formato 
    };
    var dfd = $.Deferred();
    doJsonPost(urlServicio, parametros, false).done(function (objResponse) {
        dfd.resolve(objResponse);
        $.LoadingOverlay("hide");
    }).fail(function () {
        $.LoadingOverlay("hide");
    });
    return dfd.promise();
} // ResponseStringControlador:RequestEscanerVale

function inicializaControlador(entrada) {
    $.LoadingOverlay("show");
    var urlServicio = RechazoChequeService.getUrlServicio("InicializaControlador");
    var parametros = {
        IdSesion: entrada.idSesion, //string
        ApplicationPath: entrada.nombreAplicacion,//string
        ImpTotal: entrada.impTotal,//string
        NoEmpleado: entrada.noEmpleado,//string
        Ref: entrada.ref,//string
        TMovto: entrada.tMovto,//string
        TOP: entrada.tOP,//string
        WS: entrada.wS,//string
        Presupuesto: entrada.presupuesto,//string
        TipoVenta: entrada.tipoVenta,//string
        Concepto: entrada.concepto//string
    };
    var dfd = $.Deferred();
    doJsonPost(urlServicio, parametros, true).done(function (objResponse) {
        dfd.resolve(objResponse);
        $.LoadingOverlay("hide");
    }).fail(function () {
        $.LoadingOverlay("hide");
    });
    return dfd.promise();
} //RequestOperacionInfo:ResponseString

function registraInformacionDevolucion(entrada) {
    $.LoadingOverlay("show");
    var urlServicio = RechazoChequeService.getUrlServicio("RegistraInformacionDevolucion");
    var parametros = {
        Controlador: entrada.controlador, //string
        CodAutenticidad: entrada.codAutenticidad,//string
        CodTransito: entrada.codTransito,//string
        NoCuenta: entrada.noCuenta,//string
        NoCheque: entrada.noCheque,//string
        WorkStation: entrada.workStation,//string
        Motivo: entrada.motivo,//string
        Importe: entrada.importe,//string
        Empleado: entrada.empleado,//string
        Seccion: entrada.seccion
    };
    var dfd = $.Deferred();
    doJsonPost(urlServicio, parametros, true).done(function (objResponse) {
        dfd.resolve(objResponse);
        $.LoadingOverlay("hide");
    }).fail(function () {
        $.LoadingOverlay("hide");
    });
    return dfd.promise();
} //RequestOperacionInfo:ResponseString


function obtieneListadoTiposPagos(entrada) {
    $.LoadingOverlay("show");
    var urlServicio = RechazoChequeService.getUrlServicio("ObtieneListadoTiposPagos");
    var parametros = {
        Controlador: entrada.controlador//string
    };
    var dfd = $.Deferred();
    doJsonPost(urlServicio, parametros, true).done(function (objResponse) {
        dfd.resolve(objResponse);
        $.LoadingOverlay("hide");
    }).fail(function () {
        $.LoadingOverlay("hide");
    })
    return dfd.promise();
} //RequestSoloControlador:ResponseStringControlador