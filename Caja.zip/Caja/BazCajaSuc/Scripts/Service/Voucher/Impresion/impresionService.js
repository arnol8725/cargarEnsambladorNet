var ImpresionService = {
getUrlServicio:function getUrlServicio(nombreServicio) {
        var protocolo = "http"
        var ipPuerto = "localhost:9001"
        var rutaAplicativo = "WSDesTecAppsLocal"
        var urlBase = protocolo + "://" + ipPuerto + "/" + rutaAplicativo + "/";
        var r = urlBase + nombreServicio;
        return r;
    }
}

function establecerDefaultTicket(entrada) {
    $.LoadingOverlay("show");
    var urlServicio = ImpresionService.getUrlServicio("EstablecerDefaultTicket");
    var parametros = "";
    var dfd = $.Deferred();
    doJsonPost(urlServicio, parametros, false).done(function (objResponse) {
        dfd.resolve(objResponse);
        $.LoadingOverlay("hide");
    }).fail(function () {
        $.LoadingOverlay("hide");
    });
    return dfd.promise();
} 

function generarTickets(entrada) {
    $.LoadingOverlay("show");
    var urlServicio = ImpresionService.getUrlServicio("GenerarTickets");
    var parametros = entrada;
    var dfd = $.Deferred();
    doJsonPost(urlServicio, parametros, false).done(function (objResponse) {
        dfd.resolve(objResponse);
        $.LoadingOverlay("hide");
    }).fail(function () {
        $.LoadingOverlay("hide");
    });
    return dfd.promise();
}

function imprimirTickets(entrada) {
    $.LoadingOverlay("show");
      var urlServicio = ImpresionService.getUrlServicio("ImprimirTickets");
      var parametros = "?idticket=" + entrada;
      var dfd = $.Deferred();
      doUrlPost(urlServicio + parametros, false).done(function (objResponse) {
          isFallBack = false;
          ReadAttemptsChip = 0;
          isServicePinPadOn = true;
          isTarjetaConChip = 0;
          dfd.resolve(objResponse);
          $.LoadingOverlay("hide");
      }).fail(function () {
          $.LoadingOverlay("hide");
      });
      return dfd.promise();
}


