﻿//Ruta del servidor
//var protocolo = "http"
//var ipProtocolo = "10.54.28.226:9014"
//var rutaAplicativo = "BazCajaSuc/Servicios/TiposPago/TiposPago.svc"

////Ruta local
// var protocolo = "http"
// var ipPuerto = "localhost:55677"
// var rutaAplicativo = "TiposPago.svc"
// var urlBase = protocolo + "://" + ipPuerto + "/" + rutaAplicativo + "/";

var VoucherService = {
getUrlServicio:function getUrlServicio(nombreServicio) {
        var protocolo = "http";
        var ipPuerto = ""
        var rutaAplicativo = "";                    
        if(window.location.hostname == "localhost"){
            ipPuerto = "localhost:55677";
            rutaAplicativo = "TiposPago.svc/Voucher";
        }
        else{
            ipPuerto= window.location.host;
            rutaAplicativo = "Caja/Servicios/TiposPago/TiposPago.svc/Voucher";
        }                    
        var urlBase = protocolo + "://" + ipPuerto + "/" + rutaAplicativo + "/";
        var r = urlBase + nombreServicio;
        return r;
    }
}


function consultaVoucher(entrada) {
    $.LoadingOverlay("show");
    var urlServicio = VoucherService.getUrlServicio("ConsultaVoucher");
    var parametros = {
        PeriodoTransaccion: entrada.periodoTransaccion, //int        
        Reimpresion: entrada.reimpresion //bool
    };
    var dfd = $.Deferred();
    doJsonPost(urlServicio, parametros, false,"Impresion").done(function (objResponse) {
        dfd.resolve(objResponse);
        $.LoadingOverlay("hide");
    }).fail(function () {
        $.LoadingOverlay("hide");
    });
    return dfd.promise();
} 

function validaNoReimpresion(entrada) {
     $.LoadingOverlay("show");
     var urlServicio = VoucherService.getUrlServicio("ValidaNoReimpresion");
     var parametros = {
         NoTarjeta: entrada.noTarjeta, //string
         NoTransac: entrada.noTransac, //int
         Operacion: entrada.operacion, //int
     };
     var dfd = $.Deferred();
    doJsonPost(urlServicio, parametros, false, "Impresion").done(function (objResponse) {
         dfd.resolve(objResponse);
         $.LoadingOverlay("hide");
     }).fail(function () {
         $.LoadingOverlay("hide");
     });
     return dfd.promise();
}
