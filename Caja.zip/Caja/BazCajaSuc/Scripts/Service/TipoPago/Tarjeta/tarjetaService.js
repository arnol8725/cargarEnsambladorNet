﻿/*
* @Author: jagonzalezu
* @Date:   2017-12-19 11:50:59
* @Last Modified by:   jagonzalezu
* @Last Modified time: 2018-03-08 18:50:17
*/
var TarjetaService = {
getUrlServicio:function getUrlServicio(nombreServicio) {

        // var protocolo = "http"
        // var ipPuerto = "10.54.28.226:9014"
        // var rutaAplicativo = "BazCajaSuc/Servicios/TiposPago/TiposPago.svc"
        var protocolo = "http";
        var ipPuerto = "";
        var rutaAplicativo = "";                    
        if(window.location.hostname == "localhost"){
            ipPuerto = "localhost:55677";
            rutaAplicativo = "TiposPago.svc/TiposPago";
        }
        else{
            ipPuerto= window.location.host;
            rutaAplicativo = "Caja/Servicios/TiposPago/TiposPago.svc/TiposPago";
        }                    
        var urlBase = protocolo + "://" + ipPuerto + "/" + rutaAplicativo + "/";
        var r = urlBase + nombreServicio;
        return r;
    }
}

function validaImporteTban(entrada) {
    $.LoadingOverlay("show");
    var urlServicio = TarjetaService.getUrlServicio("ValidaImporteTban");
    var parametros = {
        Controlador: entrada.controlador, //string        
        Importe: entrada.importe //string
    };
    var dfd = $.Deferred();
    doJsonPost(urlServicio, parametros, false, "Tipos de Pago: Tarjetas").done(function (objResponse) {
        dfd.resolve(objResponse);
        $.LoadingOverlay("hide");
    }).fail(function () {
        $.LoadingOverlay("hide");
    });
    return dfd.promise();
} //RequestValidaImporte:ResponseStringControlador

function validaImporteConfirmaTban(entrada) {
    $.LoadingOverlay("show");
    var urlServicio = TarjetaService.getUrlServicio("ValidaImporteConfirmaTban");
    var parametros = {
        Controlador: entrada.controlador, //string        
        Importe: entrada.importe //string
    };
    var dfd = $.Deferred();
    doJsonPost(urlServicio, parametros, false, "Tipos de Pago: Tarjetas").done(function (objResponse) {
        dfd.resolve(objResponse);
        $.LoadingOverlay("hide");
    }).fail(function () {
        $.LoadingOverlay("hide");
    });
    return dfd.promise();
} //RequestValidaImporte:ResponseStringControlador

function validaTerminarVenta(entrada) {
    $.LoadingOverlay("show");
    var urlServicio = TarjetaService.getUrlServicio("ValidaTerminarVenta");
    var parametros = {
        Controlador: entrada.controlador, //string        
        TerminadoTransaccion: entrada.terminadoTransaccion, //string
        GrabadoChip: entrada.grabadoChip, //string
        Status: entrada.status, //string
        Pan: entrada.pan //string
    };
    var dfd = $.Deferred();
    doJsonPost(urlServicio, parametros, false, "Tipos de Pago: Tarjetas").done(function (objResponse) {
        dfd.resolve(objResponse);
        $.LoadingOverlay("hide");
    }).fail(function () {
        $.LoadingOverlay("hide");
    });
    return dfd.promise();
} //RequestTerminaVenta:ResponseStringControlador

function conFirmaElectronica(entrada) {
    $.LoadingOverlay("show");
    var urlServicio = TarjetaService.getUrlServicio("ConFirmaElectronica");
    var parametros = {
        Controlador: entrada.controlador, //string        
        ParametroString: entrada.parametroString //string
    };
    var dfd = $.Deferred();
    doJsonPost(urlServicio, parametros, false, "Tipos de Pago: Tarjetas").done(function (objResponse) {
        dfd.resolve(objResponse);
        $.LoadingOverlay("hide");
    }).fail(function () {
        $.LoadingOverlay("hide");
    });
    return dfd.promise();
} //RequestStringControlador:ResponseStringControlador

function validaRenovacionLlaves(entrada) {
    $.LoadingOverlay("show");
    var urlServicio = TarjetaService.getUrlServicio("ValidaRenovacionLlaves");
    var parametros = {
        Controlador: entrada.controlador //string        
    };
    var dfd = $.Deferred();
    doJsonPost(urlServicio, parametros, false, "Tipos de Pago: Tarjetas").done(function (objResponse) {
        dfd.resolve(objResponse);
        $.LoadingOverlay("hide");
    }).fail(function () {
        $.LoadingOverlay("hide");
    });
    return dfd.promise();
} //RequestSoloControlador:ResponseStringControlador


function validaChip(entrada) {
    $.LoadingOverlay("show");
    var urlServicio = TarjetaService.getUrlServicio("ValidaChip");
    var parametros = {
        Controlador: entrada.controlador, //string        
        PAN: entrada.pAN, //string
        TOKENS_EZ_EY_ES: entrada.tOKENS_EZ_EY_ES, //string
        C55: entrada.c55, //string
        C55_Len: entrada.c55_Len, //string
        EsTarjetaConChip: entrada.esTarjetaConChip, //string
        isFallBack: entrada.isFallBack, //string
        folioIdentificacion: entrada.folioIdentificacion, //string
        tipoIdentificacion: entrada.tipoIdentificacion //string
    };
    var dfd = $.Deferred();
    doJsonPost(urlServicio, parametros, false, "Tipos de Pago: Tarjetas").done(function (objResponse) {
        dfd.resolve(objResponse);
        $.LoadingOverlay("hide");
    }).fail(function () {
        $.LoadingOverlay("hide");
    });
    return dfd.promise();
} //RequestValidaChip:ResponseStringControlador

function validaPromocionesPresupuestoMSI(entrada) {
    $.LoadingOverlay("show");
    var urlServicio = TarjetaService.getUrlServicio("ValidaPromocionesPresupuestoMSI");
    var parametros = {
        Controlador: entrada.controlador//string
    };
    var dfd = $.Deferred();
    doJsonPost(urlServicio, parametros, false, "Tipos de Pago: Tarjetas").done(function (objResponse) {
        dfd.resolve(objResponse);
        $.LoadingOverlay("hide");
    }).fail(function () {
        $.LoadingOverlay("hide");
    })
    return dfd.promise();
} //RequestSoloControlador:ResponseStringControlador

function validaPromociones(entrada) {
    $.LoadingOverlay("show");
    var urlServicio = TarjetaService.getUrlServicio("ValidaPromociones");
    var parametros = {
        Controlador: entrada.controlador//string
    };
    var dfd = $.Deferred();
    doJsonPost(urlServicio, parametros, false,"Tipos de Pago: Tarjetas").done(function (objResponse) {
        dfd.resolve(objResponse);
        $.LoadingOverlay("hide");
    }).fail(function () {
        $.LoadingOverlay("hide");
    })
    return dfd.promise();
} //RequestSoloControlador:ResponseStringControlador

function procesaSolicitudAutorizacion(entrada) {
    $.LoadingOverlay("show");
    var urlServicio = TarjetaService.getUrlServicio("ProcesaSolicitudAutorizacion");
    var parametros = {
        ParametroString: entrada.parametroString, //string        
        Controlador: entrada.controlador //string
    };
    var dfd = $.Deferred();
    doJsonPost(urlServicio, parametros, false,"Tipos de Pago: Tarjetas").done(function (objResponse) {
        dfd.resolve(objResponse);
        $.LoadingOverlay("hide");
    }).fail(function () {
        $.LoadingOverlay("hide");
    });
    return dfd.promise();
} //RequestStringControlador:ResponseStringControlador

function llavesCargadas(entrada) {
    $.LoadingOverlay("show");
    var urlServicio = TarjetaService.getUrlServicio("LlavesCargadas");
    var parametros = {
        ParametroString: entrada.parametroString, //string        
        Controlador: entrada.controlador //string
    };
    var dfd = $.Deferred();
    doJsonPost(urlServicio, parametros, false,"Tipos de Pago: Tarjetas").done(function (objResponse) {
        dfd.resolve(objResponse);
        $.LoadingOverlay("hide");
    }).fail(function () {
        $.LoadingOverlay("hide");
    });
    return dfd.promise();
} //RequestStringControlador:ResponseStringControlador

function uploadFirmaElectronica(entrada) {
    $.LoadingOverlay("show");
    var urlServicio = TarjetaService.getUrlServicio("UploadFirmaElectronica");
    var parametros = {
        Pan: entrada.pan, //string        
        IdSesion: entrada.idSesion, //string        
        ImagenBase64: entrada.imagenBase64, //string        
        Controlador: entrada.controlador //string
    };
    var dfd = $.Deferred();
    doJsonPost(urlServicio, parametros, false,"Tipos de Pago: Tarjetas").done(function (objResponse) {
        dfd.resolve(objResponse);
        $.LoadingOverlay("hide");
    }).fail(function () {
        $.LoadingOverlay("hide");
    });
    return dfd.promise();
} //RequestGuardaFirma:ResponseStringControlador


/*
RequestTerminaVenta
var parametros = {
        Controlador: entrada.controlador, //string        
        TerminadoTransaccion: entrada.terminadoTransaccion, //string
        GrabadoChip: entrada.grabadoChip, //string
        Status: entrada.status, //string
        Pan: entrada.pan //string
    };


RequestGuardaFirma
var parametros = {
        Pan: entrada.pan, //string        
        IdSesion: entrada.idSesion, //string        
        NombreImagen: entrada.nombreImagen, //string        
        Controlador: entrada.controlador //string
    };


RequestValidaImporte
var parametros = {
        Controlador: entrada.controlador, //string        
        Importe: entrada.importe //string
    };

RequestOperacionInfo    
var parametros = {
        IdSesion: entrada.idSesion, //string
        ApplicationPath: entrada.nombreAplicacion,//string
        ImpTotal: entrada.impTotal,//string
        NoEmpleado: entrada.noEmpleado,//string
        Ref: entrada.ref,//string
        TMovto: entrada.tMovto,//string
        TOP: entrada.tOP,//string
        WS: entrada.wS,//string
        Presupuesto: entrada.presupuesto,//string
        TipoVenta: entrada.tipoVenta,//string
        Concepto: entrada.concepto//string
    }; 

RequestSoloControlador
var parametros = {
        Controlador: entrada.controlador//string
    };

RequestStringControlador
var parametros = {
        ParametroString: entrada.parametroString, //string        
        Controlador: entrada.controlador //string
    };

RequestIntegerControlador
var parametros = {
        ParametroEntero: entrada.parametroEntero, //int        
        Controlador: entrada.controlador //string
    };

RequestValidaImporte
var parametros = {
        Controlador: entrada.controlador, //string        
        Importe: entrada.importe //string
    };


RequestConsultaSaldoVale
var parametros = {
        Controlador: entrada.controlador, //string        
        NumeroVale: entrada.numeroVale, //string
        TipoLectura: entrada.tipoLectura //int
    };

RequestValidaChip
var parametros = {
        Controlador: entrada.controlador, //string        
        PAN: entrada.pAN, //string
        TOKENS_EZ_EY_ES: entrada.tOKENS_EZ_EY_ES, //string
        C55: entrada.c55, //string
        C55_Len: entrada.c55_Len, //string
        EsTarjetaConChip: entrada.esTarjetaConChip, //string
        isFallBack: entrada.isFallBack, //string
        folioIdentificacion: entrada.folioIdentificacion, //string
        tipoIdentificacion: entrada.tipoIdentificacion //string
    };

RequestPeriodoTransaccion
var parametros = {
        PeriodoTransaccion: entrada.periodoTransaccion //int
    };

RequestVaucher
var parametros = {
        RequestVaucher: entrada.requestVaucher //int
    };
    Vaucher = {
        NumeroTransaccion: //int
        NumeroTarjeta:, //int 
        Titular:"", //string 
        Autorizacion:, //int 
        Monto:, //decimal 
        TipoTarjeta:, //int 
        Afiliacion:, //int 
        Pedido:, //int 
        Negocio:, //int 
        NumeroTienda:, //int 
        ClienteId:, //int 
        DigitoVerificador:, //int 
        TipoVenta: //int 
        };

ResponseListaTarjetas
obj.Vauchers[]
    ...
obj.Cliente
    ...

ResponseStringControlador
obj.RespuestaString 
obj.Controlador 

ResponseString
obj.RespuestaString

ResponseSoloControlador
obj.Controlador

//////////////Estos no sirven///////////
ResponseOption
    obj.mensajeOptionRes

    RequestOption
    var parametros = {
        mensajeOptionReq: entrada.mensajeOptionReq //string                
    };
////////////////////////////////////

*/

