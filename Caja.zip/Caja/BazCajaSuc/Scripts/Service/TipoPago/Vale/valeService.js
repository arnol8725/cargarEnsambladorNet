/*
* @Author: jagonzalezu
* @Date:   2017-12-08 13:39:47
* @Last Modified by:   B182380
* @Last Modified time: 2018-03-06 12:56:08
*/
var ValeService = {
getUrlServicio:function getUrlServicio(nombreServicio) {

                   // var protocolo = "http"
        // var ipPuerto = "10.54.28.226:9014"
        // var rutaAplicativo = "BazCajaSuc/Servicios/TiposPago/TiposPago.svc"
        var protocolo = "http";
        var ipPuerto = ""
        var rutaAplicativo = "";                    
        if(window.location.hostname == "localhost"){
            ipPuerto = "localhost:55677";
            rutaAplicativo = "TiposPago.svc/TiposPago";
        }
        else if(window.location.host.includes("114")){
            ipPuerto = window.location.host;
            rutaAplicativo = "BazCajaSuc/Servicios/TiposPago/TiposPago.svc/TiposPago";
        }
        else{
            ipPuerto= window.location.host;
            rutaAplicativo = "Caja/Servicios/TiposPago/TiposPago.svc/TiposPago";
        }                    
        var urlBase = protocolo + "://" + ipPuerto + "/" + rutaAplicativo + "/";
        var r = urlBase + nombreServicio;
        return r;
    }
}

function obtieneListadoTiposVales(entrada) {
    $.LoadingOverlay("show");
    var urlServicio = ValeService.getUrlServicio("ObtieneListadoTiposVales");
    var parametros = {
        Controlador: entrada.controlador//string
    };
    var dfd = $.Deferred();
    doJsonPost(urlServicio, parametros, false, "Tipos de Pago: Vales").done(function (objResponse) {
        dfd.resolve(objResponse);
        $.LoadingOverlay("hide");
    }).fail(function () {
        $.LoadingOverlay("hide");
    });

//    setTimeout(function() {
//        dfd.resolve("No se pudo obtener el listado de vales. El servicio no respondió." );
//    },8000);
    return dfd.promise();
} //RequestSoloControlador:ResponseString

function consultaSaldoVale(entrada) {
    $.LoadingOverlay("show");
    var urlServicio = ValeService.getUrlServicio("ConsultaSaldoVale");
    var parametros = {
        Controlador: entrada.controlador, //string        
        IndexVale: entrada.indexVale,
        NumeroVale: entrada.numeroVale, //string
        TipoLectura: entrada.tipoLectura //int
    };
    var dfd = $.Deferred();
    doJsonPost(urlServicio, parametros, false,"Tipos de Pago: Vales").done(function (objResponse) {
        dfd.resolve(objResponse);
        $.LoadingOverlay("hide");
    }).fail(function () {
        $.LoadingOverlay("hide");
    });


    return dfd.promise();
} //RequestConsultaSaldoVale:ResponseStringControlador

function solicitaAplicarMonto(entrada) {
    $.LoadingOverlay("show");
    var urlServicio = ValeService.getUrlServicio("SolicitaAplicarMonto");
    var parametros = {
        ParametroString: entrada.parametroString, //string        
        Controlador: entrada.controlador //string
    };
    var dfd = $.Deferred();
    doJsonPost(urlServicio, parametros, false,"Tipos de Pago: Vales").done(function (objResponse) {
        dfd.resolve(objResponse);
        $.LoadingOverlay("hide");
    }).fail(function () {
        $.LoadingOverlay("hide");
    });
    
    return dfd.promise();
} //RequestStringControlador:ResponseStringControlador

function validaRecepcionVale(entrada) {
    $.LoadingOverlay("show");
    var urlServicio = ValeService.getUrlServicio("ValidaRecepcion");
    var parametros = {
        ParametroEntero: entrada.parametroEntero, //string        
        Controlador: entrada.controlador //string
    };
    var dfd = $.Deferred();
    doJsonPost(urlServicio, parametros, false,"Tipos de Pago: Vales").done(function (objResponse) {
        dfd.resolve(objResponse);
        $.LoadingOverlay("hide");
    }).fail(function () {
        $.LoadingOverlay("hide");
    });

//    setTimeout(function() {
//        dfd.resolve("No se pudo obtener el listado de vales. El servicio no respondió." );
//    },8000);
    return dfd.promise();
} //RequestStringControlador:RequestIntegerControlador


/*
RequestTerminaVenta
var parametros = {
        Controlador: entrada.controlador, //string        
        TerminadoTransaccion: entrada.terminadoTransaccion, //string
        GrabadoChip: entrada.grabadoChip, //string
        Status: entrada.status, //string
        Pan: entrada.pan //string
    };


RequestValidaImporte
var parametros = {
        Controlador: entrada.controlador, //string        
        Importe: entrada.importe //string
    };

RequestOperacionInfo    
var parametros = {
        IdSesion: entrada.idSesion, //string
        ApplicationPath: entrada.nombreAplicacion,//string
        ImpTotal: entrada.impTotal,//string
        NoEmpleado: entrada.noEmpleado,//string
        Ref: entrada.ref,//string
        TMovto: entrada.tMovto,//string
        TOP: entrada.tOP,//string
        WS: entrada.wS,//string
        Presupuesto: entrada.presupuesto,//string
        TipoVenta: entrada.tipoVenta,//string
        Concepto: entrada.concepto//string
    }; 

RequestSoloControlador
var parametros = {
        Controlador: entrada.controlador//string
    };

RequestStringControlador
var parametros = {
        ParametroString: entrada.parametroString, //string        
        Controlador: entrada.controlador //string
    };

RequestIntegerControlador
var parametros = {
        ParametroEntero: entrada.parametroEntero, //int        
        Controlador: entrada.controlador //string
    };

RequestValidaImporte
var parametros = {
        Controlador: entrada.controlador, //string        
        Importe: entrada.importe //string
    };


RequestConsultaSaldoVale
var parametros = {
        Controlador: entrada.controlador, //string        
        NumeroVale: entrada.numeroVale, //string
        TipoLectura: entrada.tipoLectura //int
    };

RequestValidaChip
var parametros = {
        Controlador: entrada.controlador, //string        
        PAN: entrada.pAN, //string
        TOKENS_EZ_EY_ES: entrada.tOKENS_EZ_EY_ES, //string
        C55: entrada.c55, //string
        C55_Len: entrada.c55_Len, //string
        EsTarjetaConChip: entrada.esTarjetaConChip, //string
        isFallBack: entrada.isFallBack, //string
        folioIdentificacion: entrada.folioIdentificacion, //string
        tipoIdentificacion: entrada.tipoIdentificacion //string
    };

RequestPeriodoTransaccion
var parametros = {
        PeriodoTransaccion: entrada.periodoTransaccion //int
    };

RequestVaucher
var parametros = {
        RequestVaucher: entrada.requestVaucher //int
    };
    Vaucher = {
        NumeroTransaccion: //int
        NumeroTarjeta:, //int 
        Titular:"", //string 
        Autorizacion:, //int 
        Monto:, //decimal 
        TipoTarjeta:, //int 
        Afiliacion:, //int 
        Pedido:, //int 
        Negocio:, //int 
        NumeroTienda:, //int 
        ClienteId:, //int 
        DigitoVerificador:, //int 
        TipoVenta: //int 
        };

ResponseListaTarjetas
obj.Vauchers[]
    ...
obj.Cliente
    ...

ResponseStringControlador
obj.RespuestaString 
obj.Controlador 

ResponseString
obj.RespuestaString

ResponseSoloControlador
obj.Controlador

//////////////Estos no sirven///////////
ResponseOption
    obj.mensajeOptionRes

    RequestOption
    var parametros = {
        mensajeOptionReq: entrada.mensajeOptionReq //string                
    };
////////////////////////////////////

*/

