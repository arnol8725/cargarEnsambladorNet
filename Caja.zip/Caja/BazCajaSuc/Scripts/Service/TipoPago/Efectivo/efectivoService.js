﻿/*
* @Author: jagonzalezu
* @Date:   2018-02-09 14:02:03
* @Last Modified by:   B182380
* @Last Modified time: 2018-03-06 12:55:24
*/
//var EfectivoService = {
//    getUrlServicio: function getUrlServicio(nombreServicio) {

//        // var protocolo = "http"
//        // var ipPuerto = "10.54.28.226:9014"
//        // var rutaAplicativo = "BazCajaSuc/Servicios/TiposPago/TiposPago.svc"
//        var protocolo = "http";
//        var ipPuerto = "localhost:55677";
//        var rutaAplicativo = "TiposPago.svc";
//        var urlBase = protocolo + "://" + ipPuerto + "/" + rutaAplicativo + "/";
//        var r = urlBase + nombreServicio;
//        return r;
//    }
//}


var EfectivoService = {
    getUrlServicio: function getUrlServicio(nombreServicio) {

        var protocolo = "http";
        var ipPuerto = "";
        var rutaAplicativo = "";
        if (window.location.hostname == "localhost") {
            ipPuerto = "localhost:55677";
            rutaAplicativo = "TiposPago.svc/TiposPago";
        }
        else if (window.location.host.includes("114")) {
            ipPuerto = window.location.host;
            rutaAplicativo = "BazCajaSuc/Servicios/TiposPago/TiposPago.svc/TiposPago";
        }
        else {
            ipPuerto = window.location.host;
            rutaAplicativo = "Caja/Servicios/TiposPago/TiposPago.svc/TiposPago";
        }
        var urlBase = protocolo + "://" + ipPuerto + "/" + rutaAplicativo + "/";
        var r = urlBase + nombreServicio;
        return r;
    }
}

function validaImporteEfectivo(entrada) {
    $.LoadingOverlay("show");
    var urlServicio = EfectivoService.getUrlServicio("ValidaImporte");
    var parametros = {
        Controlador: entrada.controlador, //string        
        Importe: entrada.importe //string
    };
    var dfd = $.Deferred();
    doJsonPost(urlServicio, parametros, false, "Tipos de Pago: Efectivo").done(function (objResponse) {
        dfd.resolve(objResponse);
        $.LoadingOverlay("hide");
    }).fail(function () {
        $.LoadingOverlay("hide");
    });
    return dfd.promise();
} //RequestValidaImporte:ResponseStringControlador