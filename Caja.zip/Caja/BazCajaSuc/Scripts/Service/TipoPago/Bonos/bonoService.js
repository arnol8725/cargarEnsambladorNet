﻿/*
* @Author: jagonzalezu
* @Date:   2018-01-12 21:35:29
* @Last Modified by:   B182380
* @Last Modified time: 2018-03-06 12:55:24
*/
var BonoService = {
    getUrlServicio: function getUrlServicio(nombreServicio) {

        var protocolo = "http";
        var ipPuerto = "";
        var rutaAplicativo = "";
        if (window.location.hostname == "localhost") {
            ipPuerto = "localhost:55677";
            rutaAplicativo = "TiposPago.svc/TiposPago";
        }
        else {
            ipPuerto = window.location.host;
            rutaAplicativo = "Caja/Servicios/TiposPago/TiposPago.svc/TiposPago";
        }
        var urlBase = protocolo + "://" + ipPuerto + "/" + rutaAplicativo + "/";
        var r = urlBase + nombreServicio;
        return r;
    }
}

function solicitaAplicarBono(entrada) {
    $.LoadingOverlay("show");
    var urlServicio = BonoService.getUrlServicio("SolicitaAplicarBono"); //nombre del metodo del back que trae el servicio de bonos
    var parametros = {
         ParametroString: entrada.parametroString, 
         Controlador: entrada.controlador 
    };
    // var parametros = {
    //     Controlador: entrada.controlador, //string        
    //     Importe: entrada.importe //string
    // };
    var dfd = $.Deferred();
    doJsonPost(urlServicio, parametros, false, "Tipos de Pago: Bonos").done(function (objResponse) {
        dfd.resolve(objResponse);
        $.LoadingOverlay("hide");
    }).fail(function () {
        $.LoadingOverlay("hide");
    });
    return dfd.promise();
} //RequestValidaImporte:ResponseStringControlador