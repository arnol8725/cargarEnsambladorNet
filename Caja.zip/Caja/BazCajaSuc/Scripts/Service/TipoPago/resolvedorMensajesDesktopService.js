/*
* @Author: jagonzalezu
* @Date:   2018-02-21 11:46:14
* @Last Modified by:   jagonzalezu
* @Last Modified time: 2018-03-14 20:16:48
*/
var ResolvedorMensajesDesktop = {
getUrlServicio:function getUrlServicio(nombreServicio) {

        // var protocolo = "http"
        // var ipPuerto = "10.54.28.226:9014"
        // var rutaAplicativo = "BazCajaSuc/Servicios/TiposPago/TiposPago.svc"
        // var protocolo = "http";
        // var ipPuerto = "10.54.28.114:9014";
        // var rutaAplicativo = "BazCajaSuc/Servicios/TiposPago/TiposPago.svc";
        var protocolo = "http";
        var ipPuerto = ""
        var rutaAplicativo = "";                    
        if(window.location.hostname == "localhost"){
            ipPuerto = "10.54.28.114:9002";
            rutaAplicativo = "ADNCaptacion/Kernell/CAPOperacionesCheques.svc/RestCajaCheques";
        }
        else{
            ipPuerto= window.location.hostname+":9002";
            rutaAplicativo = "ADNCaptacion/Kernell/CAPOperacionesCheques.svc/RestCajaCheques";
        }                    
        var urlBase = protocolo + "://" + ipPuerto + "/" + rutaAplicativo + "/";
        var r = urlBase + nombreServicio;
        return r;
    }
}

function operacionesCheques(entrada) {
    $.LoadingOverlay("show");
    var urlServicio = ResolvedorMensajesDesktop.getUrlServicio("OperacionesCheques");
    var parametros = {
        objetoRespuestaCheques: entrada.objetoRespuestaCheques,//string
        IdSesion: entrada.idSesion
    };
    var dfd = $.Deferred();
    doJsonPost(urlServicio, parametros, false,"Captación").done(function (objResponse) {
        dfd.resolve(objResponse);
        $.LoadingOverlay("hide");
    }).fail(function () {
        $.LoadingOverlay("hide");
    })
    return dfd.promise();
}
