﻿/*
* @Author: jagonzalezu
* @Date:   2018-02-09 14:02:03
* @Last Modified by:   B182380
* @Last Modified time: 2018-03-06 12:56:08
*/
let erroresCount = 0; //Para evitar que se cicle
let bitacoraCountRegistro = 0; //Para evitar que se cicle el registro
var BitacoraService = {
getUrlServicio:function getUrlServicio(nombreServicio) {

        // var protocolo = "http"
        // var ipPuerto = "10.54.28.226:9014"
        // var rutaAplicativo = "BazCajaSuc/Servicios/TiposPago/TiposPago.svc"
        // var protocolo = "http";
        // var ipPuerto = "10.54.28.114:9014";
        // var rutaAplicativo = "BazCajaSuc/Servicios/TiposPago/TiposPago.svc";
        var protocolo = "http";
        var ipPuerto = ""
        var rutaAplicativo = "";                    
        if(window.location.hostname == "localhost"){
            ipPuerto = "localhost:55677";
            rutaAplicativo = "TiposPago.svc/TiposPago";
        }
        else{
            ipPuerto= window.location.host;
            rutaAplicativo = "Caja/Servicios/TiposPago/TiposPago.svc/TiposPago";
        }                    
        var urlBase = protocolo + "://" + ipPuerto + "/" + rutaAplicativo + "/";
        var r = urlBase + nombreServicio;
        return r;
    }
}

function registraHistorial(entrada,id,severidad=1) {  
    var urlServicio = BitacoraService.getUrlServicio("RegistraHistorial");
    var parametros = {
        Mensaje: "ID/BR["+id+"] "+entrada,//string
        NivelSeveridad: severidad
    };
    var dfd = $.Deferred();
    doHistorialPost(urlServicio, parametros, false, "Tipos de Pago: Bitacora").done(function (objResponse) {
        erroresCount = 0;
        dfd.resolve(objResponse);
    }).fail(function () {
        erroresCount += 1;
    })
    return dfd.promise();
} //RequestMensaje:void

/*
RequestMensaje = {
    Mensaje: mensaje
}

NIVEL DE SEVERIDAD:
    Debug = 0,
    Info = 1,
    Warning = 2,
    Error = 3,
    Fatal = 4
*/