/*
* @Author: jagonzalezu
* @Date:   2017-12-05 13:48:13
* @Last Modified by:   jagonzalezu
* @Last Modified time: 2018-03-07 12:24:55
*/
//Ruta local
var isFallBack;
var FailedAttempts;
var ReadAttemptsChip;
var isServicePinPadOn;
var vpEsTarjetaConChip;
var vpPAN;
var vpCardHolder;
var vpTOKENS_EZ_EY_ES;
var vpC55;
var vpC55Len;
var vpEsAmex;
var vpCodigoAuth
var vpRutaImagenFirma;
var vpRutaImagenBase64;

var PinPadService = {
getUrlServicio:function getUrlServicio(nombreServicio) {
        var protocolo = "http";
        var ipPuerto = "localhost:8010";
        var rutaAplicativo = "ServicioVerifone";
        var urlBase = protocolo + "://" + ipPuerto + "/" + rutaAplicativo + "/";
        var r = urlBase + nombreServicio;
        return r;
    }
}

function iniciarPinpad(entrada) {
    $.LoadingOverlay("show");
    var urlServicio = PinPadService.getUrlServicio("Iniciar");
    var parametros = "?aplicacion=" + entrada.aplicacion + "&Negocio=" + entrada.negocio;
    var dfd = $.Deferred();
    doUrlPost(urlServicio + parametros, false,"Verifone").done(function (objResponse) {
        isFallBack = false;
        ReadAttemptsChip = 0;
        FailedAttempts = 0;
        isServicePinPadOn = true;
        vpEsTarjetaConChip = "";
        vpPAN = "";
        vpCardHolder= "";
        vpTOKENS_EZ_EY_ES= "";
        vpC55= "";
        vpC55Len= "";
        vpEsAmex = "";
        vpCodigoAuth = "";
        vpRutaImagenFirma = "";
        vpRutaImagenBase64="";
        dfd.resolve(objResponse);
        $.LoadingOverlay("hide");
    }).fail(function (jqXHR,exception) {
        $.LoadingOverlay("hide");        
    });

    return dfd.promise();
} /*
in = {
aplicacion:"",
negocio:""
};

obj.Estatus
*/


function finalizarPinpad() {
    $.LoadingOverlay("show");
    var urlServicio = PinPadService.getUrlServicio("Finalizar");
    var dfd = $.Deferred();
    var parametros = "";
    doUrlPost(urlServicio + parametros, false,"Verifone").done(function (objResponse) {
        isServicePinPadOn = false;
        ReadAttemptsChip = 0;
        FailedAttempts = 0;
        isFallBack = false;     
        vpEsTarjetaConChip = "";
        vpPAN = "";
        vpCardHolder= "";
        vpTOKENS_EZ_EY_ES= "";
        vpC55= "";
        vpC55Len= "";
        vpEsAmex = "";
        vpCodigoAuth = "";
        vpRutaImagenFirma = "";
        vpRutaImagenBase64="";
        dfd.resolve(objResponse);
        $.LoadingOverlay("hide");
    }).fail(function () {
        $.LoadingOverlay("hide");
    });

    return dfd.promise();
}  /*
in = ""

obj.Estatus
*/

function dispositivoConectado() {
    $.LoadingOverlay("show");
    var urlServicio = PinPadService.getUrlServicio("DispositivoConectado");
    var parametros = "";
    var dfd = $.Deferred();
    doUrlPost(urlServicio + parametros, false,"Verifone").done(function (objResponse) {
        vpEsTarjetaConChip = "";
        vpPAN = "";
        vpCardHolder= "";
        vpTOKENS_EZ_EY_ES= "";
        vpC55= "";
        vpC55Len= "";
        vpEsAmex = "";
        vpCodigoAuth = "";
        vpRutaImagenFirma = "";
        vpRutaImagenBase64="";
        dfd.resolve(objResponse);
        $.LoadingOverlay("hide");
    }).fail(function () {
        $.LoadingOverlay("hide");
    });

    return dfd.promise();
}  /*
in = ""

obj.Estatus
*/

function leerChipEMVCifrado(entrada) {
    $.LoadingOverlay("show");
    var urlServicio = PinPadService.getUrlServicio("LeerChipEMVCifrado");
    var parametros = "?monto=" + entrada.monto + "&tipoVenta=" + entrada.tipoVenta;
    var dfd = $.Deferred();
    doUrlPost(urlServicio + parametros, false,"Verifone").done(function (objResponse) {        
        dfd.resolve(objResponse);
        $.LoadingOverlay("hide");
    }).fail(function () {
        $.LoadingOverlay("hide");
    });

    return dfd.promise();
}  /*
in = {
monto:"",
tipoVenta:""
};

{
"Estatus":"0",
"Error":"",
"EsTarjetaConChip":"1",
"PAN":"1234567891234567",
"CardHolder":"Miguel Perez",
"TOKENS_EZ_EY_ES":"13548",
"C55":"987654321",
"C55Len":"340"
}
*/

function terminandoTransaccionCifrado(entrada) {
    $.LoadingOverlay("show");
    var urlServicio = PinPadService.getUrlServicio("TerminandoTransaccionCifrado");
    var parametros = "?esAMEX=" + entrada.esAMEX + "&respHost=" + entrada.respHost + "&authorizationCode=" + entrada.authorizationCode + "&responseCode=" + entrada.responseCode + "&esTarjetaConChip=" + entrada.esTarjetaConChip + "&c63=" + entrada.c63;
    var dfd = $.Deferred();
    doUrlPost(urlServicio + parametros, false,"Verifone").done(function (objResponse) {
        dfd.resolve(objResponse);        
        $.LoadingOverlay("hide");
    }).fail(function () {
        $.LoadingOverlay("hide");
    });

    return dfd.promise();
}  /*
in = {
esAMEX:"",
respHost:"",
authorizationCode:"",
responseCode:"",
esTarjetaConChip:"",
c63:""
};

{
"Estatus":"0",
"EstatusGrabadoChip":"00",
"Error":""
}
*/


function obtenerFirmaCliente(entrada) {
    $.LoadingOverlay("show");
    var urlServicio = PinPadService.getUrlServicio("ObtenerFirmaCliente");
    var parametros = "";
    var dfd = $.Deferred();
    doUrlPost(urlServicio + parametros, false,"Verifone").done(function (objResponse) {
        dfd.resolve(objResponse);
        $.LoadingOverlay("hide");
    }).fail(function () {
        $.LoadingOverlay("hide");
    });

    return dfd.promise();
}  /*   
in = "";

{
"Estatus":"0",
"RutaImagen":"caja"
}
*/


function guardarFirmaCliente(entrada) {
    $.LoadingOverlay("show");
    var urlServicio = PinPadService.getUrlServicio("GuardarFirmaCliente");
    var parametros = "?nombreRutaImagen=" + entrada.nombreRutaImagen + "&tiempoEspera=" + entrada.tiempoEspera;
    var dfd = $.Deferred();
    doUrlPost(urlServicio + parametros, false,"Verifone").done(function (objResponse) {
        dfd.resolve(objResponse);
        $.LoadingOverlay("hide");
    }).fail(function () {
        $.LoadingOverlay("hide");
    });

    return dfd.promise();
}  /*
   esAMEX respHost authorizationCode responseCode esTarjetaConChip c63;
in = {
nombreRutaImagen:"",
tiempoEspera:""
};

{
"Estatus":"0"
}
*/

function cargaLlave(entrada) {
    $.LoadingOverlay("show");
    var urlServicio = PinPadService.getUrlServicio("CargaLlave");
    var parametros = "";
    var dfd = $.Deferred();
    doUrlPost(urlServicio + parametros, false,"Verifone").done(function (objResponse) {
        dfd.resolve(objResponse);
        $.LoadingOverlay("hide");
    }).fail(function () {
        $.LoadingOverlay("hide");
    });

    return dfd.promise();
}  /*
   esAMEX respHost authorizationCode responseCode esTarjetaConChip c63;
in = "";

{
"Estatus":"1"
"Mensaje":"Se cargo correctamente la llave"
}
*/

function crearMarcaAgua(entrada){
    $.LoadingOverlay("show");
    var urlServicio = PinPadService.getUrlServicio("CrearMarcaAgua");
    var parametros = "?ruta=" + entrada.ruta + "&fecha=" + entrada.fecha+ "&hora=" + entrada.hora+ "&noOperacion=" + entrada.noOperacion+ "&color=" + entrada.color;
    var dfd = $.Deferred();
    doUrlPost(urlServicio + parametros, false,"Verifone").done(function (objResponse) {
        dfd.resolve(objResponse);
        $.LoadingOverlay("hide");
    }).fail(function () {
        $.LoadingOverlay("hide");
    });

    return dfd.promise();
}
// in = {
// ruta:"",
// fecha:"",
// hora:"",
// noOperacion:"",
// color:""
// };


function cancelaOperacionPinpad() {
    $.LoadingOverlay("show");
    var urlServicio = PinPadService.getUrlServicio("CancelaOperacionPinpad");
    var parametros = "";
    var dfd = $.Deferred();
    doUrlPost(urlServicio + parametros, false,"Verifone").done(function (objResponse) {
        dfd.resolve(objResponse);
        $.LoadingOverlay("hide");
    }).fail(function () {
        $.LoadingOverlay("hide");
    });

    return dfd.promise();
} 
/*
{
"Estatus":"8" //Cancelado exitoso
}
*/