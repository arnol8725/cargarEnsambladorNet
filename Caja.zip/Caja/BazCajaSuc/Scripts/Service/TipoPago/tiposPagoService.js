﻿/*
* @Author: jagonzalezu
* @Date:   2018-02-09 14:02:03
* @Last Modified by:   jagonzalezu
* @Last Modified time: 2018-03-15 11:21:17
*/
//Esto se puede usar para ver la estructura de la respuesta del servicio
//var xhttp = new XMLHttpRequest();
//xhttp.onreadystatechange = function () {
//    if (this.readyState == 4 && this.status == 200) {
//        alert(this.responseText);
//    }
//};
//xhttp.open("POST", "http://localhost:55677/TiposPago.svc/MetodoTest", true);
//xhttp.setRequestHeader("Content-Type", "application/json");
//xhttp.send(JSON.stringify(order));

//Ruta del servidor

//Ruta local
var TiposPagoService = {
getUrlServicio:function getUrlServicio(nombreServicio) {
                   // var protocolo = "http"
        // var ipPuerto = "10.54.28.226:9014"
        // var rutaAplicativo = "BazCajaSuc/Servicios/TiposPago/TiposPago.svc"
        var protocolo = "http";
        var ipPuerto = ""
        var rutaAplicativo = "";                    
        if(window.location.hostname == "localhost"){
            ipPuerto = "localhost:55677";
            rutaAplicativo = "TiposPago.svc/TiposPago";
        }
        else{
            ipPuerto= window.location.host;
            rutaAplicativo = "Caja/Servicios/TiposPago/TiposPago.svc/TiposPago";
        }                    
        var urlBase = protocolo + "://" + ipPuerto + "/" + rutaAplicativo + "/";
        var r = urlBase + nombreServicio;
        return r;
    }
}

//function optionTiposPago(entrada) ES UN METODO AUXILIAR DE SERVICIOS

function obtieneListadoTiposPago(entrada) {
    $.LoadingOverlay("show");
    var urlServicio = TiposPagoService.getUrlServicio("ObtieneListadoTiposPago");
    var parametros = {
        Controlador: entrada.controlador//string
    };
    var dfd = $.Deferred();
    doJsonPost(urlServicio, parametros).done(function (objResponse) {
        dfd.resolve(objResponse);
        $.LoadingOverlay("hide");
    }).fail(function () {
        $.LoadingOverlay("hide");
    })
    return dfd.promise();
} //RequestSoloControlador:ResponseStringControlador

function obtieneListadoTiposPagoEpos(entrada) {
    $.LoadingOverlay("show");
    var urlServicio = TiposPagoService.getUrlServicio("ObtieneListadoTiposPagoEPOS");
    var parametros = {
        Controlador: entrada.controlador//string
    };
    var dfd = $.Deferred();
    doJsonPost(urlServicio, parametros, true).done(function (objResponse) {
        dfd.resolve(objResponse);
        $.LoadingOverlay("hide");
    }).fail(function () {
        $.LoadingOverlay("hide");
    })
    return dfd.promise();
} //RequestSoloControlador:ResponseStringControlador



function obtieneListadoTiposVales(entrada) {
    $.LoadingOverlay("show");
    var urlServicio = TiposPagoService.getUrlServicio("ObtieneListadoTiposVales");
    var parametros = {
        Controlador: entrada.controlador//string
    };
    var dfd = $.Deferred();
    doJsonPost(urlServicio, parametros, true).done(function (objResponse) {
        dfd.resolve(objResponse);
        $.LoadingOverlay("hide");
    }).fail(function () {
        $.LoadingOverlay("hide");
    });
    return dfd.promise();
} //RequestSoloControlador:ResponseString

function obtieneInformacionActualizada(entrada) {
    $.LoadingOverlay("show");
    var urlServicio = TiposPagoService.getUrlServicio("ObtieneInformacionActualizada");
    var parametros = {
        Controlador: entrada.controlador//string
    };
    var dfd = $.Deferred();
    doJsonPost(urlServicio, parametros, true).done(function (objResponse) {
        dfd.resolve(objResponse);
        $.LoadingOverlay("hide");
    }).fail(function () {
        $.LoadingOverlay("hide");
    });
    return dfd.promise();
} //RequestSoloControlador:ResponseString

function inicializaControlador(entrada) {
    $.LoadingOverlay("show");
    var urlServicio = TiposPagoService.getUrlServicio("InicializaControlador");
    var parametros = {
        IdSesion: entrada.idSesion, //string
        ApplicationPath: entrada.nombreAplicacion,//string
        ImpTotal: entrada.impTotal,//string
        NoEmpleado: entrada.noEmpleado,//string
        Ref: entrada.ref,//string
        TMovto: entrada.tMovto,//string
        TOP: entrada.tOP,//string
        WS: entrada.wS,//string
        Presupuesto: entrada.presupuesto,//string
        TipoVenta: entrada.tipoVenta,//string
        Concepto: entrada.concepto//string
    };
    var dfd = $.Deferred();
    doJsonPost(urlServicio, parametros, true,"Tipos de Pago").done(function (objResponse) {
        dfd.resolve(objResponse);
        $.LoadingOverlay("hide");
    }).fail(function () {
        $.LoadingOverlay("hide");
    });
    return dfd.promise();
} //RequestOperacionInfo:ResponseString

function guardaPago(entrada) {
    $.LoadingOverlay("show");
    var urlServicio = TiposPagoService.getUrlServicio("GuardaPago");
    var parametros = {
        EsDeposito: entrada.esDeposito, //string        
        IdSesion: entrada.idSesion, //string        
        Controlador: entrada.controlador //string
    };
    var dfd = $.Deferred();
    doJsonPost(urlServicio, parametros, true,"Tipos de Pago").done(function (objResponse) {
        dfd.resolve(objResponse);
        $.LoadingOverlay("hide");
    }).fail(function () {
        $.LoadingOverlay("hide");
    });
    return dfd.promise();
} //RequestGuardaPago:ResponseStringControlador

function reversaOperacion(entrada) {
    $.LoadingOverlay("show");
    var urlServicio = TiposPagoService.getUrlServicio("ReversaOperacion");
    var parametros = {
        Controlador: entrada.controlador//string
    };
    var dfd = $.Deferred();
    doJsonPost(urlServicio, parametros, true,"Tipos de Pago").done(function (objResponse) {
        dfd.resolve(objResponse);
        $.LoadingOverlay("hide");
    }).fail(function () {
        $.LoadingOverlay("hide");
    });
    return dfd.promise();
} //RequestSoloControlador:ResponseSoloControlador

function validaRecepcion(entrada) {
    $.LoadingOverlay("show");
    var urlServicio = TiposPagoService.getUrlServicio("ValidaRecepcion");
    var parametros = {
        ParametroEntero: entrada.parametroEntero, //int        
        Controlador: entrada.controlador //string
    };
    var dfd = $.Deferred();
    doJsonPost(urlServicio, parametros, true,"Tipos de Pago").done(function (objResponse) {
        dfd.resolve(objResponse);
        $.LoadingOverlay("hide");
    }).fail(function () {
        $.LoadingOverlay("hide");
    })
    return dfd.promise();
} //RequestIntegerControlador:ResponseStringControlador

function validaTrack(entrada) {
    $.LoadingOverlay("show");
    var urlServicio = TiposPagoService.getUrlServicio("ValidaTrack");
    var parametros = {
        ParametroString: entrada.parametroString, //string        
        Controlador: entrada.controlador //string
    };
    var dfd = $.Deferred();
    doJsonPost(urlServicio, parametros, true,"Tipos de Pago").done(function (objResponse) {
        dfd.resolve(objResponse);
        $.LoadingOverlay("hide");
    }).fail(function () {
        $.LoadingOverlay("hide");
    });
    return dfd.promise();
} //RequestStringControlador:ResponseStringControlador

function consultaSaldoVale(entrada) {
    $.LoadingOverlay("show");
    var urlServicio = TiposPagoService.getUrlServicio("ConsultaSaldoVale");
    var parametros = {
        Controlador: entrada.controlador, //string        
        NumeroVale: entrada.numeroVale, //string
        TipoLectura: entrada.tipoLectura //int
    };
    var dfd = $.Deferred();
    doJsonPost(urlServicio, parametros, true,"Tipos de Pago").done(function (objResponse) {
        dfd.resolve(objResponse);
        $.LoadingOverlay("hide");
    }).fail(function () {
        $.LoadingOverlay("hide");
    });
    return dfd.promise();
} //RequestConsultaSaldoVale:ResponseStringControlador

function solicitaAplicarMonto(entrada) {
    $.LoadingOverlay("show");
    var urlServicio = TiposPagoService.getUrlServicio("SolicitaAplicarMonto");
    var parametros = {
        ParametroString: entrada.parametroString, //string        
        Controlador: entrada.controlador //string
    };
    var dfd = $.Deferred();
    doJsonPost(urlServicio, parametros, true,"Tipos de Pago").done(function (objResponse) {
        dfd.resolve(objResponse);
        $.LoadingOverlay("hide");
    }).fail(function () {
        $.LoadingOverlay("hide");
    });
    return dfd.promise();
} //RequestStringControlador:ResponseStringControlador

//function solicitaAplicarBono(entrada) {
//    $.LoadingOverlay("show");
//    var urlServicio = TiposPagoService.getUrlServicio("SolicitaAplicarBono");
//    var parametros = {
//        ParametroString: entrada.parametroString, //string        
//        Controlador: entrada.controlador //string
//    };
//    var dfd = $.Deferred();
//    doJsonPost(urlServicio, parametros, true).done(function (objResponse) {
//        dfd.resolve(objResponse);
//        $.LoadingOverlay("hide");
//    }).fail(function () {
//        $.LoadingOverlay("hide");
//    });
//    return dfd.promise();
//} //RequestStringControlador:ResponseStringControlador

function reversaTarjeta(entrada) {
    $.LoadingOverlay("show");
    var urlServicio = TiposPagoService.getUrlServicio("ReversaTarjeta");
    var parametros = {
        ParametroString: entrada.parametroString, //string        
        Controlador: entrada.controlador //string
    };
    var dfd = $.Deferred();
    doJsonPost(urlServicio, parametros, true,"Tipos de Pago").done(function (objResponse) {
        dfd.resolve(objResponse);
        $.LoadingOverlay("hide");
    }).fail(function () {
        $.LoadingOverlay("hide");
    });
    return dfd.promise();
} //RequestStringControlador:ResponseStringControlador

function imprimeVaucher(entrada) {
    $.LoadingOverlay("show");
    var urlServicio = TiposPagoService.getUrlServicio("ImprimeVaucher");
    var parametros = {
        RequestVaucher: entrada.requestVaucher //int
    };
    var dfd = $.Deferred();
    doJsonPost(urlServicio, parametros, true,"Tipos de Pago").done(function (objResponse) {
        dfd.resolve(objResponse);
        $.LoadingOverlay("hide");
    }).fail(function () {
        $.LoadingOverlay("hide");
    });
    return dfd.promise();
} //RequestVaucher:ResponseString

function validaSiExisteSesion(entrada) {
    $.LoadingOverlay("show");
    var urlServicio = TiposPagoService.getUrlServicio("ValidaSiExisteSesion");
    var parametros = {
        IdSesion: entrada.idSesion,//string
        NombreAplicacion:entrada.nombreAplicacion//string
    };
    var dfd = $.Deferred();
    doJsonPost(urlServicio, parametros,true,"Tipos de Pago").done(function (objResponse) {
        dfd.resolve(objResponse);
        $.LoadingOverlay("hide");
    }).fail(function () {
        $.LoadingOverlay("hide");
    })
    return dfd.promise();
}//RequestSesionAplicacion/ResponseFuncionesSesion

function guardaSesion(entrada) {
    $.LoadingOverlay("show");
    var urlServicio = TiposPagoService.getUrlServicio("GuardaSesion");
    var parametros = {
        IdSesion: entrada.idSesion,//string
        NombreAplicacion:entrada.nombreAplicacion,//string
        Controlador: entrada.controlador//string
    };
    var dfd = $.Deferred();
    doJsonPost(urlServicio, parametros,true,"Tipos de Pago").done(function (objResponse) {
        dfd.resolve(objResponse);
        $.LoadingOverlay("hide");
    }).fail(function () {
        $.LoadingOverlay("hide");
    })
    return dfd.promise();
}//RequestSesionAplicacionControlador/ResponseFuncionesSesion


/*

RequestGuardaPago
var parametros = {
        EsDeposito: entrada.esDeposito, //string        
        IdSesion: entrada.idSesion, //string        
        Controlador: entrada.controlador //string
    };



RequestSesionAplicacionControlador
var parametros = {
        IdSesion: entrada.idSesion,//string
        NombreAplicacion:entrada.nombreAplicacion,//string
        Controlador: entrada.controlador//string
    };


RequestValidaImporte
var parametros = {
        Controlador: entrada.controlador, //string        
        Importe: entrada.importe //string
    };


RequestSesionAplicacion
var parametros = {
        IdSesion: entrada.idSesion,
        NombreAplicacion:entrada.nombreAplicacion//string
    };


RequestOperacionInfo    
var parametros = {
        IdSesion: entrada.idSesion, //string
        ApplicationPath: entrada.nombreAplicacion,//string
        ImpTotal: entrada.impTotal,//string
        NoEmpleado: entrada.noEmpleado,//string
        Ref: entrada.ref,//string
        TMovto: entrada.tMovto,//string
        TOP: entrada.tOP,//string
        WS: entrada.wS,//string
        Presupuesto: entrada.presupuesto,//string
        TipoVenta: entrada.tipoVenta,//string
        Concepto: entrada.concepto//string
    }; 

RequestSoloControlador
var parametros = {
        Controlador: entrada.controlador//string
    };

RequestStringControlador
var parametros = {
        ParametroString: entrada.parametroString, //string        
        Controlador: entrada.controlador //string
    };

RequestIntegerControlador
var parametros = {
        ParametroEntero: entrada.parametroEntero, //int        
        Controlador: entrada.controlador //string
    };

RequestValidaImporte
var parametros = {
        Controlador: entrada.controlador, //string        
        Importe: entrada.importe //string
    };


RequestConsultaSaldoVale
var parametros = {
        Controlador: entrada.controlador, //string        
        NumeroVale: entrada.numeroVale, //string
        TipoLectura: entrada.tipoLectura //int
    };

RequestValidaChip
var parametros = {
        Controlador: entrada.controlador, //string        
        PAN: entrada.pAN, //string
        TOKENS_EZ_EY_ES: entrada.tOKENS_EZ_EY_ES, //string
        C55: entrada.c55, //string
        C55_Len: entrada.c55_Len, //string
        EsTarjetaConChip: entrada.esTarjetaConChip, //string
        isFullBack: entrada.isFullBack, //string
        folioIdentificacion: entrada.folioIdentificacion, //string
        tipoIdentificacion: entrada.tipoIdentificacion //string
    };

RequestPeriodoTransaccion
var parametros = {
        PeriodoTransaccion: entrada.periodoTransaccion //int
    };

RequestVaucher
var parametros = {
        RequestVaucher: entrada.requestVaucher //int
    };
    Vaucher = {
        NumeroTransaccion: //int
        NumeroTarjeta:, //int 
        Titular:"", //string 
        Autorizacion:, //int 
        Monto:, //decimal 
        TipoTarjeta:, //int 
        Afiliacion:, //int 
        Pedido:, //int 
        Negocio:, //int 
        NumeroTienda:, //int 
        ClienteId:, //int 
        DigitoVerificador:, //int 
        TipoVenta: //int 
        };

ResponseListaTarjetas
obj.Vauchers[]
    ...
obj.Cliente
    ...

ResponseFuncionesSesion
obj.CodigoError

ResponseStringControlador
obj.RespuestaString 
obj.Controlador 

ResponseString
obj.RespuestaString

ResponseSoloControlador
obj.Controlador

//////////////Estos no sirven///////////
ResponseOption
    obj.mensajeOptionRes

    RequestOption
    var parametros = {
        mensajeOptionReq: entrada.mensajeOptionReq //string                
    };
////////////////////////////////////

*/

