/*
* @Author: jagonzalezu
* @Date:   2018-01-17 21:33:14
* @Last Modified by:   jagonzalezu
* @Last Modified time: 2018-03-28 14:09:37
*/
var ChequeService = {
getUrlServicio:function getUrlServicio(nombreServicio) {
        var protocolo = "http";
        var ipPuerto = ""
        var rutaAplicativo = "";                    
        if(window.location.hostname == "localhost"){
            ipPuerto = "localhost:55677";
            rutaAplicativo = "TiposPago.svc/TiposPago";
        }
        else{
            ipPuerto= window.location.host;
            rutaAplicativo = "Caja/Servicios/TiposPago/TiposPago.svc/TiposPago";
        }                    
        var urlBase = protocolo + "://" + ipPuerto + "/" + rutaAplicativo + "/";
        var r = urlBase + nombreServicio;
        return r;
    }
}

function EstadoDigitalizado(entrada) {
    $.LoadingOverlay("show");
    var urlServicio = ChequeService.getUrlServicio("EstadoDigitalizacion");
    var parametros = {
        Controlador: entrada.controlador, //string        
    };
    var dfd = $.Deferred();
    doJsonPost(urlServicio, parametros, false, "Tipos de Pago: Cheques").done(function (objResponse) {
        dfd.resolve(objResponse);
        $.LoadingOverlay("hide");
    }).fail(function () {
        $.LoadingOverlay("hide");
    });
    return dfd.promise();
} // ResponseStringControlador:RequestSoloControlador


function DigitalizarCheque(entrada) {
    $.LoadingOverlay("show");
    var urlServicio = ChequeService.getUrlServicio("EscanearCheque");
    var parametros = {
        Controlador: entrada.controlador,
        Formato: entrada.formato 
    };
    var dfd = $.Deferred();
    doJsonPost(urlServicio, parametros, false, "Tipos de Pago: Cheques").done(function (objResponse) {
        dfd.resolve(objResponse);
        $.LoadingOverlay("hide");
    }).fail(function () {
        $.LoadingOverlay("hide");
    });
    return dfd.promise();
} // ResponseStringControlador:RequestEscanerVale

function validaImporteCheque(entrada) {
    $.LoadingOverlay("show");
    var urlServicio = ChequeService.getUrlServicio("ValidaImporteCheque");
    var parametros = {
        Controlador: entrada.controlador, //string        
        Importe: entrada.importe //string
    };
    var dfd = $.Deferred();
    doJsonPost(urlServicio, parametros, false, "Tipos de Pago: Cheques").done(function (objResponse) {
        dfd.resolve(objResponse);
        $.LoadingOverlay("hide");
    }).fail(function () {
        $.LoadingOverlay("hide");
    });
    return dfd.promise();
} //RequestValidaImporte:ResponseStringControlador

function validaImporteConfirmaCheque(entrada) {
    $.LoadingOverlay("show");
    var urlServicio = ChequeService.getUrlServicio("ValidaImporteConfirmaCheque");
    var parametros = {
        Controlador: entrada.controlador, //string        
        Importe: entrada.importe //string
    };
    var dfd = $.Deferred();
    doJsonPost(urlServicio, parametros, false, "Tipos de Pago: Cheques").done(function (objResponse) {
        dfd.resolve(objResponse);
        $.LoadingOverlay("hide");
    }).fail(function () {
        $.LoadingOverlay("hide");
    });
    return dfd.promise();
} //RequestValidaImporte:ResponseStringControlador

function validaCheque(entrada) {
    $.LoadingOverlay("show");
    var urlServicio = ChequeService.getUrlServicio("ValidaCheque");
    var parametros = {
        Controlador: entrada.controlador, //string        
        CodAut: entrada.codAut, //string
        Agencia: entrada.agencia, //string
        NoCta: entrada.noCta, //string
        NoCheque: entrada.noCheque, //string
        Top: entrada.top, //string
        Empleado: entrada.empleado, //string
        Ws: entrada.ws, //string
        Seccion: entrada.seccion //string
    };
    var dfd = $.Deferred();
    doJsonPost(urlServicio, parametros, false, "Tipos de Pago: Cheques").done(function (objResponse) {
        dfd.resolve(objResponse);
        $.LoadingOverlay("hide");
    }).fail(function () {
        $.LoadingOverlay("hide");
    });
    return dfd.promise();
} //RequestValidarCheque:ResponseStringControlador


function tipoCheque(entrada) {
    $.LoadingOverlay("show");
    var urlServicio = ChequeService.getUrlServicio("TipoCheque");
    var parametros = {
        Controlador: entrada.controlador, //string        
        Top: entrada.top, //string
        Agencia: entrada.agencia, //string
    };
    var dfd = $.Deferred();
    doJsonPost(urlServicio, parametros, false, "Tipos de Pago: Cheques").done(function (objResponse) {
        dfd.resolve(objResponse);
        $.LoadingOverlay("hide");
    }).fail(function () {
        $.LoadingOverlay("hide");
    });
    return dfd.promise();
} //RequestTipoCheque:ResponseStringControlador

function guardarCheque(entrada) {
    $.LoadingOverlay("show");
    var urlServicio = ChequeService.getUrlServicio("GuardarCheque");
    var parametros = {
            Controlador: entrada.controlador, //string        
            Beneficiario: entrada.beneficiario, //string
            Importe: entrada.importe, //decimal
            CodAut: entrada.codaut, //decimal
            Agencia: entrada.agencia, //decimal
            NoCta: entrada.nocta, //decimal
            NoCheque: entrada.nocheque, //decimal
            TipoCheque: entrada.tipocheque, //decimal
            TipoLectura: entrada.tipolectura, //decimal
            Top: entrada.top, //string
            Ws: entrada.ws, //string
            Empleado: entrada.empleado, //string
            Base64Front: entrada.base64front, //string
            Base64Back: entrada.base64back //string
    };
    var dfd = $.Deferred();
    doJsonPost(urlServicio, parametros, false, "Tipos de Pago: Cheques").done(function (objResponse) {
        dfd.resolve(objResponse);
        $.LoadingOverlay("hide");
    }).fail(function () {
        $.LoadingOverlay("hide");
    });
    return dfd.promise();
} //RequestGuardarCheque:ResponseStringControlador

function validaChequePropio(entrada) {
    $.LoadingOverlay("show");
    var urlServicio = ChequeService.getUrlServicio("ValidaChequePropio");
    var parametros = {
        Controlador: entrada.controlador, //string   
        Ip: entrada.ip, //string    
        Empleado: entrada.empleado, //string
        WorkStation: entrada.ws, //string
        Cuenta: entrada.noCta, //string
        NumCheque: entrada.noCheque, //string
        CodigoSeguridad: entrada.codigoSeguridad
    };
    var dfd = $.Deferred();
    doJsonPost(urlServicio, parametros, false, "Tipos de Pago: Cheques").done(function (objResponse) {
        dfd.resolve(objResponse);
        $.LoadingOverlay("hide");
    }).fail(function () {
        $.LoadingOverlay("hide");
    });
    return dfd.promise();
} //RequestValidarCheque:ResponseStringControlador

// RequestStringControlador
// var parametros = {
//         ParametroString: entrada.parametroString, //string        
//         Controlador: entrada.controlador //string
//     };

// RequestValidaImporte
// var parametros = {
//         Controlador: entrada.controlador, //string        
//         Importe: entrada.importe //string
//     };

//RequestValidarCheque
// var parametros = {
//         Controlador: entrada.controlador, //string        
//         CodAut: entrada.codAut //string
//         Agencia: entrada.agencia //string
//         NoCta: entrada.noCta //string
//         NoCheque: entrada.noCheque //string
//         Top: entrada.top //string
//         WS: entrada.ws //string
//         Empleado: entrada.empleado //string
//         Seccion: entrada.seccion //string
//     };

//RequestTipoCheque
// var parametros = {
//         Controlador: entrada.controlador, //string        
//         Top: entrada.top //string
//         Agencia: entrada.agencia //string
//     };

//RequestGuardarCheque
// var parametros = {
//         Controlador: entrada.controlador, //string        
//         Beneficiario: entrada.beneficiario, //string
//         Importe: entrada.importe, //decimal
//         CodAut: entrada.codaut, //decimal
//         Agencia: entrada.agencia, //decimal
//         NoCta: entrada.nocta, //decimal
//         NoCheque: entrada.nocheque, //decimal
//         TipoCheque: entrada.tipocheque, //decimal
//         TipoLectura: entrada.tipolectura, //decimal
//         Top: entrada.top, //string
//         Ws: entrada.ws, //string
//         Empleado: entrada.empleado, //string
//         Base64Front: entrada.base64front, //string
//         Base64Back: entrada.base64back //string
//     };

//RequestSoloControlador
// var parametros = {
//         Controlador: entrada.controlador, //string        
//     };

//RequestChequePropio
//var parametros = {
//          Controlador: entrada.controlador, //string        
//          Ip: entrada.ip, //string
//          Empleado: entrada.empleado, //string
//          WorkStation: entrada.ws, //string
//          Cuenta: entrada.noCta, //string
//          NumCheque: entrada.noCheque //string
//};