﻿var empName="";
var sucNum="";
var sucName="";
var puesto="";
var puestoBaseId="";
var puestoRolId = "";

function serviceTiendaEmpleado() {
    var url = getUrl(urlUtileriaFondeo);
    $.ajax({
        url: "" + url,
        contentType: "application/json; charset=UTF-8",
        type: "POST",
        data: JSON.stringify({
            "NoEmpleado": "" + usuario
        }),
        dataType: 'json',
        crossDomain: true,
        success: function (data) {
            empName = data.InformacionInicial.NombreEmpleado == null ? "" : data.InformacionInicial.NombreEmpleado;
            sucNum = data.InformacionInicial.NoTienda == null ? "" : data.InformacionInicial.NoTienda;
            sucName = data.InformacionInicial.NombreTienda == null ? "" : data.InformacionInicial.NombreTienda;
            puesto = data.InformacionInicial.DescripcionPRol == null ? "" : data.InformacionInicial.DescripcionPRol;
            puestoBaseId = data.InformacionInicial.PuestoBase == null ? "" : data.InformacionInicial.PuestoBase;
            puestoRolId = data.InformacionInicial.PuestoRol == null ? "" : data.InformacionInicial.PuestoRol;

            $('#nombreEmpl').text(empName);
            var tienda = sucNum==""&&sucName==""?"": sucNum + " / " + sucName;
            $('#tienda').text(tienda);
            $('#puestoRol').text(puesto);
            mostrarCarga(false);             
        },
        error: function () {
            mostrarCarga(false);          
        }
    });
}

function serviceNombreEmpleado(noEmp) {
    var url = getUrl(urlUtileria);
    let nombreEmp="";
    $.ajax({
        url: "" + url,
        contentType: "application/json; charset=UTF-8",
        type: "POST",
        async:false,
        data: JSON.stringify({
            "Empleado": "" + noEmp
        }),
        dataType: 'json',
        crossDomain: true,
        success: function (data) {
            nombreEmp = data.EmpNombre == null ? "" : data.EmpNombre;            
            mostrarCarga(false);
        },
        error: function () {
            mostrarCarga(false);
        }
    });
    return nombreEmp;
}

//Consulta de divisas - Yadira JH
function wsConsultaDivisa() {
    $('#lblMensaje').html("");
    return $.ajax({
        url: getUrl(urlDivisas),
        type: "POST",
        cache: false,
        contentType: "application/json; charset=UTF-8",
        dataType: "JSON",
        success: function (resp) {            
            switch (resp.NoError){
                case 1:                    
                    showMesagge(resp.NoError, resp.Descripcion);
                    mostrarCarga(false);
                    break;
                case 0:
                    $('#nav').removeAttr("disabled");
                    serviceLecturaDivisa(resp.Divisas, 'selectValor');                    
                    break;                    
            }  
        },
        error: function (error) {            
            showMesagge(1, "Ocurrió un error al consultar divisas");
            mostrarCarga(false);
        }
    });
}

//Obtiene los perfiles autorizadores para el componente de Huella - Yadira JH
function getPerfilesAutorizador(opc, idModulo, idFolio) {
    let result;
    $.ajax({
        url: getUrl(urlPerfilesAutorizador),
        contentType: "application/json; charset=UTF-8",
        type: "POST",
        async: false, 
        data: JSON.stringify({
                "opc":opc,
                "IdModulo":idModulo,
                "IdFolio":idFolio,
                "Empleado":usuario                
              }),
        dataType: 'json',
        crossDomain: true,
        success: function (data) {
            result= data;
        },
        error: function () {
            result=undefined;
        }
    });
    return result;
}
