﻿//CONSULTA TIPOS DE PAGOS
function wsConsultaTiposdePago() {
    $('#lblMensaje').html("");
    var consulta = {
        "Divisa": divisa,
        "NoEmpleado": usuario};
    $.ajax({
        url: getUrl(urlConsultaTiposdePago),
        type: "POST",
        data: JSON.stringify(consulta),
        cache: false,
        contentType: "application/json; charset=UTF-8",
        dataType: 'JSON',
        success: function (resp) {
            switch (resp.NoError) {
                case 1:
                    showMesagge(resp.NoError, resp.Descripcion);
                    mostrarCarga(false);
                    break;
                case 0:
                    llenarTipoPago(resp.ListaTiposdePago);
                    break;
             }
         },
         error: function () {
            mostrarCarga(false);
            showMesagge(1, "Ocurrió un error en el servidor");
         }
    });    
}

//LLENA EL COMBOBOX TIPO PAGO
function llenarTipoPago(tipos) {    
    let $secondChoice = $("#tipoPago");
    $secondChoice.empty();
    $secondChoice.append('<option value="' + -1+ '">Elija una opción</option>');
    $.each(tipos, function (index, value) {
        $secondChoice.append('<option value="' + value.IdElemento + '">' + value.DescElemento + '</option>');
    });
    mostrarCarga(false);
}

//CONSULTA LOS EGRESOS
function wsConsultaEgresos(tipoPago, fechaIni, fechaFin, opcion) {
    $('#lblMensaje').html("");
    var consulta = {
        "NoEmpleado":usuario,
        "Divisa":divisa,
        "TipoPago":tipoPago,
        "Indicador":0,
        "FechaIni":fechaIni,
        "FechaFin":fechaFin, 
        "Opcion": opcion 
        };
    $.ajax({
        url: getUrl(urlConsultaEgresos),
        type: "POST",
        data: JSON.stringify(consulta),
        cache: false,
        contentType: "application/json; charset=UTF-8",
        dataType: 'JSON',
        success: function (resp) {
            switch (resp.NoError) {
                case 1:
                    showMesagge(resp.NoError, resp.Descripcion);
                    mostrarCarga(false);
                    break;
                case 0:
                    if(opcion=="4") llenaEgresosConsulta(resp.ListaEgresos);
                    else{                        
                        llenaSaldos(resp.Saldos, "", "");
                        llenaEgresos(resp.ListaEgresos)
                    }
                    break;
             }             
         },
         error: function () {
            mostrarCarga(false);
            showMesagge(1, "Ocurrió un error en el servidor");
         }
    });    
}

//CONSULTA LOS FONDEO DE CAJA
function wsConsultaConfirmacionPendientes(origen) {
    $('#lblMensaje').html("");
    var consulta = {
        "NoEmpleado":usuario,
        "Divisa":divisa,
        "Origen":origen       
        };
    $.ajax({
        url: getUrl(urlConsultaConfirmacionPendientes),
        type: "POST",
        data: JSON.stringify(consulta),
        cache: false,
        contentType: "application/json; charset=UTF-8",
        dataType: 'JSON',
        success: function (resp) {
            switch (resp.NoError) {
                case 1:
                    showMesagge(resp.NoError, resp.Descripcion);
                    mostrarCarga(false);
                    break;
                case 0:
                    let traspasos;
                    let isShow=false;
//                    if (origen=="T"){
//                         traspasos=separaTraspFondeoCajero(resp.ListaconfPendientes);
//                         isShow=true;
//                    }else 
                        traspasos=resp.ListaconfPendientes;
                    llenaTraspasosPendientes(traspasos, "traspasosTable", false, isShow, "");
                    llenaSaldos(resp.Saldo,"","");
                    mostrarCarga(false);
                    break;
             }
         },
         error: function () {
            mostrarCarga(false);
            showMesagge(1, "Ocurrió un error en el servidor");
         }
    });    
}

//Cancela traspaso
function cancelaTraspaso(concentracion) {
    $('#lblMensaje').html("");
    var consulta = {
            "NoEmpleado": usuario, 
            "Divisa": divisa,
            "NoTraspaso": concentracion
        };
    $.ajax({
        url: getUrl(urlCancelaTraspaso),
        type: "POST",
        data: JSON.stringify(consulta),
        cache: false,
        contentType: "application/json; charset=UTF-8",
        dataType: 'JSON',
        success: function (resp) {            
            switch (resp.NoError){
                case 1:                    
                    reloadContent();
                    showMesagge(resp.NoError, resp.descripcionError);                    
                    break;
                case 0:                    
                    reloadContent();
                    showMesagge(resp.NoError, resp.Descripcion);
                    break;                    
            }
        },
        error: function () {
            showMesagge(1, "Ocurrió un error en el servidor");
            mostrarCarga(false);
        }
    });
}

//CONSULTA LAS DENOMINACIONES PARA LA REALIZACION DEL TRASPASO
function consultarDenominacion() {
    $('#lblMensaje').html("");
    var consulta = {"Divisa": divisa};
    $.ajax({
        url: getUrl(urlTraspDenominaciones),
        type: "POST",
        data: JSON.stringify(consulta),
        cache: false,
        contentType: "application/json; charset=UTF-8",
        dataType: 'JSON',
        success: function (resp) {
            switch (resp.NoError){
                case 1:
                    showMesagge(resp.NoError, resp.Descripcion);
                    mostrarCarga(false);
                    break;
                case 0:
                    validaMorralla(resp.DetalleDenomina);                                        
                    break;                    
            }   
            
        },
        error: function () {
            mostrarCarga(false);
            showMesagge(1, "Ocurrió un error en el servidor");
        }
    });
}

//valida si se aceptan monedas
function validaMorralla(denominaciones){
    lstSrvDenominaciones=denominaciones;
    isMonedas=false;
    $.each(lstSrvDenominaciones, function (i, p) {
        isMonedas=isMonedas?isMonedas:p.DescDenominacion=="MORRALLA";        
    }); 
    mostrarCarga(false);
    if(tipoDivisas=="F")
        $j('#modal06').modal();
    else{
        tipoDivisas="C";
        openDenominaciones();
    }
}

//Confirma Concentraciones
function ConfirmaConcentraciones(consulta, concentracion, tipo) {  
    $('#lblMensaje').html("");  
    $.ajax({
        url: getUrl(urlConfirmaConcentracion),
        type: "POST",
        data: JSON.stringify(consulta),
        cache: false,
        contentType: "application/json; charset=UTF-8",
        dataType: 'JSON',
        success: function (resp) {            
            switch (resp.NoError){
                case 1:
                    reloadContent();
                    showMesagge(resp.NoError, resp.descripcionError);                    
                    break;
                case 0:
                    concentracionImpr=traspasoSelect.Concentracion;
                    transaccionImpr=resp.Descripcion;
                    mostrarCarga(false);
                    $j('#modal08').modal();
                    $('#lblConfirmacion').html("Se realizo correctamente la confirmación. Folio: "+resp.Descripcion);
                    break;
            }            
        },
        error: function () {
             showMesagge(1, "Ocurrió un error en el servidor");
             construirTicket("123454444",concentracion)
             mostrarCarga(false);
        }
    });
}

function ConfirmaTraspasoFondeo(consulta, concentracion, tipo) {  
    $('#lblMensaje').html("");  
    $.ajax({
        url: getUrl(urlConfirmaConcentracion),
        type: "POST",
        data: JSON.stringify(consulta),
        cache: false,
        contentType: "application/json; charset=UTF-8",
        dataType: 'JSON',
        success: function (resp) {            
            switch (resp.NoError){
                case 1:
                    reloadContent();
                    showMesagge(resp.NoError, resp.descripcionError);                    
                    break;
                case 0:        
                    tipoTraspaso = 'efectivo';                                    
                    transaccionImpr = resp.Descripcion;
                    concentracionImpr = resp.idConcentracion;
                    userAuto=usuario;
                    showMesagge(resp.NoError, resp.descripcionError+" "+resp.Descripcion);
                    $j('#modal08').modal();
                    $('#lblConfirmacion').html("Se realizo correctamente el fondeo por el importe de: "+ formatMoney(traspasoSelect.Importe)+". Número de operación: "+resp.Descripcion);
                    mostrarCarga(false);
                    break;                    
            }            
        },
        error: function () {
             showMesagge(1, "Ocurrió un error en el servidor");
             construirTicket("123454444",concentracion)
             mostrarCarga(false);
        }
    });
}

//CONSULTA CONCENTRACIONES CAJERO A CAJA
function wsConsultaRecepcionConcentracionSaldosCajeroaCaja(origen) {
    $('#lblMensaje').html("");
    var consulta = {
        "NoEmpleado":usuario,
        "Divisa":divisa,
        "Origen":origen       
        };
    $.ajax({
        url: getUrl(urlConsultaRecepcionConcentracionSaldosCajeroaCaja),
        type: "POST",
        data: JSON.stringify(consulta),
        cache: false,
        contentType: "application/json; charset=UTF-8",
        dataType: 'JSON',
        success: function (resp) {
            switch (resp.NoError) {
                case 1:
                    showMesagge(resp.NoError, resp.Descripcion);
                    mostrarCarga(false);
                    break;
                case 0:                    
                    llenaDocumentos(resp.Documentos.ListaconfPendientesDoc);
                    llenaSaldos(resp.Documentos.SaldosDocumentos, "", "Doc");
                    llenaTraspasosPendientes(resp.Efectivo.ListaconfPendientesEfectivo, "efectivotable", true, false, "Caja");
                    llenaSaldos(resp.Efectivo.SaldoCajero, "", "");
                    llenaSaldos(resp.Efectivo.SaldoCaja, "Caja", "");
                    mostrarCarga(false);                    
                    break;
             }
         },
         error: function () {
            mostrarCarga(false);
            showMesagge(1, "Ocurrió un error en el servidor");
         }
    });    
}

//LLENA LOS SALDOS CAJERO
function llenaSaldos(saldos, caja, doc){
    let saldoActual=doc==""?saldos.SaldoEfectivo:saldos.SaldoDocumentos;
    $('#saldoActual'+caja+doc+page_select).html(formatMoney(saldoActual));    
    $('#topeMax'+caja+doc+page_select).html(formatMoney(saldos.TopeMax));    
}

//llena la tabla que se muestra en la ventana de denominaciones
function llenarDenominacion() {
    var tabla = '';    
    let den=0;
    $.each(lstSrvDenominaciones, function (i, p) {        
        den=p.IdDenominacion.substring(0, p.IdDenominacion.length-3);;
        if(p.DescDenominacion!="MORRALLA")
        tabla += '<tr><td class="tRight">' + p.IdDenominacion + '</td>'+
                     '<td class="w100"><input onfocus="this.oldvalue = this.value;" id="den' + den + '" class="monto" onchange="totales('+ p.IdDenominacion +', this);this.oldvalue = this.value;" placeholder="0" onkeypress="return isNumberKey(event,false)"/></td>'+
                     '<td style="text-align: right;"><label id="total' + den + '" class="total">'+formatMoney(0)+'</label></td></tr>';
    });       
    $("#tableDenominacion > tbody").html(tabla);
    if(!isMonedas){
        $('#totalesDen > td:nth-child(1)').hide();
        $('#totalesDen > td:nth-child(2)').hide();
        $('#ipMorralla').hide();
        $('#lblMorralla').hide();
    }else{
        $('#ipMorralla').show();
        $('#lblMorralla').show();
    }
    mostrarCarga(false);
    $j('#modal01').modal();
}

//Confirma Concentraciones
function SolicitarFondeo(empAuto, importe) {  
    $('#lblMensaje').html("");  
    let consulta={
        "NoEmpleado": usuario,
        "NoEmpleadoAuto": empAuto,
        "Divisa": divisa,
        "Origen": "F",
        "UltTraspaso": 0,
        "Terminal": ws,
            "LstTipoPago": [{ 
   	            "Tipo_PagoId": 1, 
   	            "TipoPagoDesc":"Efectivo", 
   	            "SaldoTotal": importe,                
   	            "LstDocumento": [{ 
   		            "NoDocto": "0",
   		            "Importe": importe,
   		            "NoDeposito": "0",
   		            "NoOperacion": "0"
   	            }]
            }]
    };

    $.ajax({
        url: getUrl(urlSolicitarFondeo),
        type: "POST",
        data: JSON.stringify(consulta),
        cache: false,
        contentType: "application/json; charset=UTF-8",
        dataType: 'JSON',
        success: function (resp) {            
            switch (resp.NoError){
                case 1:
                    reloadContent();
                    showMesagge(resp.NoError, resp.descripcionError);                    
                    break;
                case 0:        
					tipoTraspaso = 'efectivo';                
					traspasoSelect={
						Importe:importe,
						NoCajero:""
					};
                    var splitRespuesta = resp.Descripcion.split('|');
					transaccionImpr = splitRespuesta[0];
                    concentracionImpr = splitRespuesta[1];
					showMesagge(resp.NoError, resp.descripcionError+" "+splitRespuesta[0]);
                    $j('#modal08').modal();
                    $('#lblConfirmacion').html("Se realizo correctamente el fondeo por el importe de: "+ formatMoney(importe)+". Número de operación: "+splitRespuesta[0]);
                    mostrarCarga(false);
                    break;                    
            }            
        },
        error: function () {
             showMesagge(1, "Ocurrió un error en el servidor");
             mostrarCarga(false);
        }
    });
}

//Cancela traspaso
function wsEgresaTraspaso(consulta) {
    $('#lblMensaje').html("");   
    $.ajax({
        url: getUrl(urlEgresaTraspaso),
        type: "POST",
        data: JSON.stringify(consulta),
        cache: false,
        contentType: "application/json; charset=UTF-8",
        dataType: 'JSON',
        success: function (resp) {            
            switch (resp.NoError){
                case 1:                    
                    reloadContent();
                    showMesagge(resp.NoError, resp.descripcionError);                    
                    break;
                case 0:                                   
                    reloadContent();
                    showMesagge(resp.NoError, resp.descripcionError + " " + resp.Descripcion);
                    break;
                case 2: //impresion de cheques
                    xmlTicketEgresoCheques=resp.descripcionError;
                    mostrarCarga(false);
                    $j('#modal08').modal();
                    $('#lblConfirmacion').html("Se egreso correctamente el documento. Folio " + " " + resp.Descripcion);
                    break;
            }
        },
        error: function () {
            showMesagge(1, "Ocurrió un error en el servidor");
            mostrarCarga(false);
        }
    });
}

