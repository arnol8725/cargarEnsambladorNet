﻿let ws = getUrlVars()["ws"];
let usuario = getUrlVars()["usuario"];

var ListaVoucher; //Almacena los vouchers de las tarjetas
var ListaTarjetas; //Almacena las Tarjetas de la Compra
let timeStampErroresImpresion; //Variable para los codigos de errores de la funcionalidad de tarjetas
let tarjetaActiva //Identifica Carpeta para imprimir su Voucher
let idVaoucher //id de Ticket para imprimir
var numTarjeta //numero de la tarjeta
var numTransaccion //numero de la transaccion

$(document).ready(function () {   
    generaHeader(usuario,ws);                    
});

function pad (n, length) {
    var  n = n.toString();
    while(n.length < length)
         n = "0" + n;
    return n;
}

function seleccionaTarjeta (filaId) {
    var filaP = filaId;

    for(i=0; i < document.getElementById("tablaId").rows.length-1; i++ ){
        var filacount = "id"+i;
        document.getElementById(filacount).className = "tblGeneralV";
    }
    document.getElementById(filaP).className = "tblGeneralV2";

    var fila = filaP.charAt(2);
    tarjetaActiva = ListaVoucher[fila];

    numTarjeta = ListaTarjetas[fila].NumeroTarjeta.toString().trim()
}

function TryParseInt(str,defaultValue) {
     var retValue = defaultValue;
     if(str !== null) {
         if(str.length > 0) {
             if (!isNaN(str)) {
                 retValue = parseInt(str);
                 if (retValue > 2147483647){
                    retValue=0;
                 }
             }
         }
     }
     return retValue;
}


function cargaDatos(event) {
    var keyCode;
    var objeto;
    // event passed as param in Firefox, not IE where it's defined as window.event
    if (!event) {
        event = window.event;
        keyCode = event.keyCode;
    }
    else { // ff
        keyCode = event.which;
    }
    if (keyCode == 13) {
    objeto = document.getElementById("NoTransac");

        var parametros = {
            periodoTransaccion:TryParseInt(objeto.value,0),
            reimpresion:true
        };
        consultaVoucher(parametros).done(function (respuesta) {

            timeStampErroresImpresion = Commons.getStampId(objeto.value);      
            if (respuesta.EstatusExito==="false"){
                registraHistorial("El usuario ha intentado consultar datos para reimprimir un voucher; "+JSON.stringify(respuesta, null, 4),timeStampErroresImpresion);                                                            
                avisaError("Ha ocurrido un problema al obtener los datos para la reimpresion: " + respuesta.Detalle + "</br>[Código de seguimiento:"+timeStampErroresImpresion+"]");
                return;
                location.reload();
            }
            if(isDefined(respuesta.Cliente)===false){
                registraHistorial("No se encuentra el Cliente en BD; "+JSON.stringify(respuesta, null, 4),timeStampErroresImpresion);                                                            
                avisaError("No hay informacion del cliente para el Numero de Pedido o Transaccion: " + objeto.value + "</br>[Código de seguimiento:"+timeStampErroresImpresion+"]");
                
                LimpiarPagina();
                return;
            }
            if (respuesta.Tarjetas.length === 0 ){
                registraHistorial("No se encuentra informacion con el Numero de Periodo o Transaccion (No hay rgistro de Tarjeta); "+JSON.stringify(respuesta, null, 4),timeStampErroresImpresion);                                                            
                avisaError("No se encuentra informacion con el Numero de Pedido o Transaccion: " + objeto.value + "</br>[Código de seguimiento:"+timeStampErroresImpresion+"]");
                
                LimpiarPagina();
                return;
            }
            if (respuesta.Vouchers.length === 0 ){
                registraHistorial("No se encuentra informacion con el Numero de Periodo o Transaccion (No hay rgistro de Voucher); "+JSON.stringify(respuesta, null, 4),timeStampErroresImpresion);                                                            
                avisaError("No se encuentra informacion con el Numero de Pedido o Transaccion: " + objeto.value + "</br>[Código de seguimiento:"+timeStampErroresImpresion+"]");
                return;
                location.reload();
            }

            document.getElementById("txtNo01").value = (respuesta.Tarjetas[0].Negocio.toString())+pad(respuesta.Tarjetas[0].NumeroTienda,4);
            document.getElementById("txtNo02").value = (respuesta.Tarjetas[0].ClienteId.toString())+(respuesta.Tarjetas[0].DigitoVerificador.toString());

            document.getElementById("txtNombre").value = respuesta.Cliente.Nombre;
            document.getElementById("txtApPaterno").value = respuesta.Cliente.APaterno;
            document.getElementById("txtApMaterno").value = respuesta.Cliente.AMaterno;
            document.getElementById("txtCalle").value = respuesta.Cliente.Calle;
            document.getElementById("txtNoExt").value = respuesta.Cliente.NumeroExt;
            document.getElementById("txtNoInt").value = respuesta.Cliente.NumeroInt;
            document.getElementById("txtColonia").value = respuesta.Cliente.Colonia;
            document.getElementById("txtCP").value = respuesta.Cliente.CP;

            // Llenado de Tabla
            var tablaApoyo = '<table><tbody>'+
                    '<tr>'+
                    '<th>Tarjeta</th>'+
                    '<th>Importe</th>'+
                    '<th>Autorización</th>'+
                    // '<th>Titular</th>'+
                    '<th>Tipo</th>'+
                    '</tr>';

            var tipoVentaDesc

            $.each(respuesta.Tarjetas,function(i,p){
                
                switch (respuesta.Tarjetas[i].TipoVenta.toString().trim()) {
                    case "1":
                        tipoVentaDesc = "VENTA CONTADO"
                        break;
                    case "2":
                        tipoVentaDesc = "VENTA CREDITO"
                        break; 
                    case "3":
                        tipoVentaDesc = "VENTA DE APARTADO"
                        break; 
                    case "4":
                        tipoVentaDesc = "VENTA MOSTRADOR"
                        break; 
                    case "5":
                        tipoVentaDesc = "VENTA COMODATO"
                        break; 
                    case "6":
                        tipoVentaDesc = "DISPOSICION DE EFECTIVO"
                        break;      
                    default:                           
                        break;
                }

                tablaApoyo +=
                '<tr id="id'+i+'" onclick="seleccionaTarjeta(id)" class = "tblGeneralV">' +
                    '<td id="fid'+i+'">'+mascara(respuesta.Tarjetas[i].NumeroTarjeta.toString().trim())+'</td>'+
                    '<td id="fid'+i+'">$ '+formatMoney(respuesta.Tarjetas[i].Monto.toString().trim())+'</td>'+
                    '<td id="fid'+i+'">'+respuesta.Tarjetas[i].Autorizacion.toString().trim() +'</td>'+
                    // '<td id="fid'+i+'">'+respuesta.Tarjetas[i].Titular.toString().trim() +'</td>'+
                    '<td id="fid'+i+'">'+tipoVentaDesc+'</td>'+
                '</tr>';
            });

            tablaApoyo += '<div class="clear"></div></tbody></table>';

            $('#tablaId').html(tablaApoyo);


            ListaVoucher=respuesta.Vouchers;
            ListaTarjetas = respuesta.Tarjetas;
            // numTarjeta = respuesta.Tarjetas[0].NumeroTarjeta.toString().trim()
            numTransaccion = respuesta.Tarjetas[0].NumeroTransaccion.toString().trim();

        });
        if (event.preventDefault) {
            event.preventDefault();
        }
    }
    else {
        // objeto.style.background = "";
    }
}

function mascara(numeroT){
    // string dato;=numeroT;
    var numMascara = "";
    var caracteres = (numeroT.substring(0,numeroT.length-4)).length;

    for (i = 0; i < caracteres; i++) { 
    numMascara += "X";
    }

    return numMascara + numeroT.substring(numeroT.length-4,numeroT.length)
}

function imprimeVoucher() {

    if (isDefined(tarjetaActiva)){
        FuncionesImpresion.mostrarModal('ConfirmaReimpresion');
        let e = document.getElementById("modal00").querySelector("#msgNoTarjeta");
        e.innerHTML = mascara(numTarjeta);

    }
    else{
        FuncionesImpresion.mostrarModal('errorSeleccionTarjeta');

    }
}

function validacionNoReimpresion(){

    var parametros = {
            noTarjeta:numTarjeta,
            noTransac:numTransaccion,
            operacion:0 //consulta
        };
    validaNoReimpresion(parametros).done(function(respuesta){
        if (!isDefined(respuesta)) {
            timeStampErroresImpresion = Commons.getStampId();      
            registraHistorial("El servicio de Impresion no encuentra el contador de reimpresiones, respuesta= "+JSON.stringify(respuesta2, null, 4) + '. No se obtuvo respuesta del servicio de reimprecion voucher metodo validaNoReimpresion.',timeStampErroresImpresion);                                                            
            FuncionesImpresion.mostrarModal('errorVoucher');
            return;
            }

        if (respuesta.RespuestaInt === 2){
             FuncionesImpresion.mostrarModal('ultimaReimpresion');
             let e = document.getElementById("modal00").querySelector("#msgOperacion");
             e.innerHTML = numTransaccion;

        }
        else if (respuesta.RespuestaInt >= 3){
             FuncionesImpresion.mostrarModal('bloqueoReimpresion');
        }
        else if (respuesta.RespuestaInt < 2){
            procesoImpresion();
        }
    });
}

function sumaNoReimpresion(){
    var parametros = {
            noTarjeta:numTarjeta,
            noTransac:numTransaccion,
            operacion:1 //aumenta
        };
    validaNoReimpresion(parametros).done(function(respuesta){
        if (!isDefined(respuesta)) {
            timeStampErroresImpresion = Commons.getStampId();      
            registraHistorial("El servicio de Impresion no puede aumentar el contador de reimpresiones, respuesta= "+JSON.stringify(respuesta2, null, 4) + '. No se obtuvo respuesta del servicio de reimprecion voucher metodo validaNoReimpresion.',timeStampErroresImpresion);                                                            
            FuncionesImpresion.mostrarModal('errorVoucher');
            return;
            }
        LimpiarPagina()
    });
}

 function procesoImpresion(){
    //Completa Vouchers
    var voucherTienda = tarjetaActiva+"<Usuario><TEXT ALIGNH = \"CENTER\" FONTSIZE = \"5\" FONTFAMILY = \"Courier New\">_______________ TIENDA _______________</TEXT></Usuario>";
    voucherTienda+="<TEXT></TEXT>";
    voucherTienda+="<Negociable><TEXT ALIGNH = \"CENTER\" FONTSIZE = \"5\" FONTFAMILY = \"Courier New\">No Negociable</TEXT></Negociable>";
    voucherTienda+="<TEXT></TEXT>";
    voucherTienda+="<TEXT></TEXT>";
    voucherTienda+="<COPIA><TEXT ALIGNH = \"CENTER\" FONTSIZE = \"5\" FONTFAMILY = \"Courier New\">COPIA</TEXT></COPIA>";
    voucherTienda+="</VOUCHER>";

    var voucherCliente = tarjetaActiva+"<Usuario><TEXT ALIGNH = \"CENTER\" FONTSIZE = \"5\" FONTFAMILY = \"Courier New\">_______________ CLIENTE _______________</TEXT></Usuario>";
    voucherCliente+="<TEXT></TEXT>";
    voucherCliente+="<Negociable><TEXT ALIGNH = \"CENTER\" FONTSIZE = \"5\" FONTFAMILY = \"Courier New\">No Negociable</TEXT></Negociable>";
    voucherCliente+="<TEXT></TEXT>";
    voucherCliente+="<TEXT></TEXT>";
    voucherCliente+="<COPIA><TEXT ALIGNH = \"CENTER\" FONTSIZE = \"5\" FONTFAMILY = \"Courier New\">COPIA</TEXT></COPIA>";
    voucherCliente+="</VOUCHER>";


    //Generar Ticket
        var entrada = {
            ListaTickets: [{
                Aplicacion: "Caja",//string,
                Contenido: voucherTienda,//xml
                NoCopias: 1//int
            },
            {
                Aplicacion: "Caja",//string,
                Contenido: voucherCliente,//xml
                NoCopias: 1//int
            }
            ]
        };
       var ent = JSON.stringify(entrada);
        generarTickets(entrada).done(function(respuesta2){
            timeStampErroresImpresion = Commons.getStampId();      
            if (!isDefined(respuesta2)) {
            registraHistorial("El servicio de Impresion no genera ticket, respuesta= "+JSON.stringify(respuesta2, null, 4) + '. No se obtuvo respuesta del servicio de impresion metodo generarTickets.',timeStampErroresImpresion);                                                            
            FuncionesImpresion.mostrarModal('errorVoucher');
            return;
            }
            if (!isDefined(respuesta2.Contenido)) {
            registraHistorial("El servicio de Impresion no ha respondido, respuesta= "+JSON.stringify(respuesta2, null, 4) + '. No se obtuvo respuesta del servicio de impresion metodo generarTickets.',timeStampErroresImpresion);
            FuncionesImpresion.mostrarModal('errorVoucher');
            return;
            }
            if (respuesta2.EstatusExito=== 'false') {
            registraHistorial("No se logra configurar la impresora, respuesta= "+JSON.stringify(respuesta2, null, 4) + '. No se obtuvo respuesta del servicio de impresion metodo generarTickets.',timeStampErroresImpresion);
            FuncionesImpresion.mostrarModal('errorVoucher');
            return;
            }

            idVaoucher=respuesta2.Contenido;

            //Imprime Ticket
            imprimirTickets(idVaoucher).done(function(respuesta3){
                timeStampErroresImpresion = Commons.getStampId();      
                if (!isDefined(respuesta2)) {
                registraHistorial("El servicio de Impresion no genera ticket, respuesta= "+JSON.stringify(respuesta2, null, 4),timeStampErroresImpresion);                                                            
                
                avisaError("No se obtuvo respuesta del servicio de impresion metodo generarTickets. </br>[Código de seguimiento:"+timeStampErroresImpresion+"]");
                return;
                }
                if (!isDefined(respuesta2.Contenido)) {
                registraHistorial("El servicio de Impresion no ha respondido, respuesta= "+JSON.stringify(respuesta2, null, 4),timeStampErroresImpresion);                                                            
                
                avisaError("No se obtuvo respuesta del servicio de impresion metodo generarTickets. </br>[Código de seguimiento:"+timeStampErroresImpresion+"]");
                return;
                }
                if (respuesta2.EstatusExito=== 'false') {
                registraHistorial("No se logra configurar la impresora, respuesta= "+JSON.stringify(respuesta2, null, 4),timeStampErroresImpresion);                                                            
                
                avisaError("No se obtuvo respuesta del servicio de impresion metodo generarTickets. </br>[Código de seguimiento:"+timeStampErroresImpresion+"]");
                return;
                }

                FuncionesImpresion.mostrarModal('confirmacion');
            });
        });        
    }

    function LimpiarPagina(){
        document.getElementById("txtNo01").value=""
        document.getElementById("txtNo02").value=""
        document.getElementById("txtNombre").value=""
        document.getElementById("txtApPaterno").value=""
        document.getElementById("txtApMaterno").value=""
        document.getElementById("txtCalle").value=""
        document.getElementById("txtNoExt").value=""
        document.getElementById("txtNoInt").value=""
        document.getElementById("txtColonia").value=""
        document.getElementById("txtCP").value=""

        tarjetaActiva = null;

        var tablaApoyo = '<table><tbody>'+
                    '<tr>'+
                    '<th>Tarjeta</th>'+
                    '<th>Importe</th>'+
                    '<th>Autorización</th>'+
                    '<th>Titular</th>'+
                    '<th>Tipo</th>'+
                    '</tr>'+
                    '<tr onclick="seleccionaTarjeta(id)" class = "tblGeneralV">' +
                    '</tr>'+
                    '<div class="clear"></div></tbody></table>';

        $('#tablaId').html(tablaApoyo);
    }

    function soloNumero(e){
    var key = window.Event ? e.which : e.keyCode 
    return ((key >= 48 && key <= 57) || (key==8)) 
    }

