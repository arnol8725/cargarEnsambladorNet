var ManejadorMsgVoucher ={
    getContentV: function getContentV(caseMessage) {
        content = "";
        switch (caseMessage) {
        	case "errorSeleccionTarjeta":
        		content = '	<div class="cuadro">\
        							<a  style="visibility:hidden;" href="#" class=" simplemodal-close">\
            							<img src="../../Imgs/Voucher/cerrar.png" class="cerrar"/>\
        							</a>\
        							<div class="titModal">Reimpresión de vouchers de tarjeta bancaria</div>\
									<div class="clear"></div><br>\
									<div class="texto1">\
    									Por favor, seleccione de la lista la tarjeta cuyo voucher desea reimprimir\
    									</div><br>\
    								<div class="botones1"><a href="#" class="btnV w48  simplemodal-close" id="modalImprimir2_view">Aceptar</a></td></div>\
    							</div>'
			break;

			case "ConfirmaReimpresion":
				content = '<div class="cuadro">\
        							<a style="visibility:hidden;" href="#" class=" simplemodal-close">\
            							<img src="../../Imgs/Voucher/cerrar.png" class="cerrar"/>\
        							</a>\
        							<div class="titModal">Reimpresión de vouchers de tarjeta bancaria</div>\
									<div class="clear"></div><br>\
									<div class="texto1">\
    									¿Está seguro de reimprimir el voucher de <strong>pago</strong> de la tarjeta número <strong id="msgNoTarjeta"></strong> ?\
    									</div><br>\
    								<div class="botones1">\
    								<a href="#" class="btnB w48 simplemodal-close">No</a>\
    								<a onclick="validacionNoReimpresion()" href="#" class="btnV w48 simplemodal-close" id="modalImprimir3_view">Sí</a>\
    								</div>\
    							</div>'
			break;

			case  "errorReimprecionVoucherVA":
				content = '<div class="cuadro">\
        							<a style="visibility:hidden;" href="#" class=" simplemodal-close">\
            							<img src="../../Imgs/Voucher/cerrar.png" class="cerrar"/>\
        							</a>\
        							<div class="titModal">Reimpresión de vouchers de tarjeta bancaria</div>\
									<div class="clear"></div><br>\
									<div class="texto1">\
    									No es permitida la reimpresión del voucher. Los voucher de<br>\
										VISA/AMEX solo se pueden imprimir al efectuar la venta.\
    								</div><br>\
    								<div class="botones1">\
    									<a href="#" class="btnV w48 simplemodal-close" id="modalImprimir4_view">Aceptar</a>\
    								</div>\
    							</div>'

			break;

			case  "errorVoucher":
				content = '<div class="cuadro">\
        							<a style="visibility:hidden;" href="#" class=" simplemodal-close">\
            							<img src="../../Imgs/Voucher/cerrar.png" class="cerrar"/>\
        							</a>\
        							<div class="titModal">Reimpresión de vouchers de tarjeta bancaria</div>\
									<div class="clear"></div><br>\
									<div class="texto1">\
    									El voucher de la tarjeta seleccionada no se pudo imprimir.\
    								</div><br>\
    								<div class="botones1">\
    									<a href="#" class="btnV w48 simplemodal-close" id="modalImprimir5_view">Aceptar</a>\
    								</div>\
    							</div>'
			break;

			case  "confirmacion":
				content = '<div class="cuadro">\
        							<a style="visibility:hidden;" href="#" class=" simplemodal-close">\
            							<img src="../../Imgs/Voucher/cerrar.png" class="cerrar"/>\
        							</a>\
        							<div class="titModal">Reimpresión de vouchers de tarjeta bancaria</div>\
									<div class="clear"></div><br>\
									<div class="texto1">\
    									¿Se imprimió correctamente el voucher?\
    								</div><br>\
    							<div class="botones1">\
    								<a onclick="procesoImpresion()" href="#" class="btnB w48 simplemodal-close" >No</a>\
    								<a onclick="sumaNoReimpresion()" href="#" class="btnV w48 simplemodal-close" >Sí</a>\
    							</div>\
    						</div>'
			break;

            case  "ultimaReimpresion":
                content = '<div class="cuadro">\
                                    <a style="visibility:hidden;" href="#" class=" simplemodal-close">\
                                        <img src="../../Imgs/cerrar.png" class="cerrar">\
                                    </a>\
                                    <div class="titModal">Reimpresión de vouchers de tarjeta bancaria</div>\
                                    <div class="clear"></div><br>\
                                    <div class="texto1">\
                                        <strong>Advertencia:</strong><br><br>\
                                        La siguiente reimpresión <strong>será la última permitida</strong> para el no. de operación <strong id="msgOperacion"></strong>,<br>\
                                        debido a que la venta ha sido autorizada no habrá reverso de la misma. Procure tener<br>\
                                        la impresora de ticket correctamente instalada y conectada.\
                                    </div><br>\
                                <div class="botones1">\
                                    <a onclick="procesoImpresion()" href="#" class="btnV w48 simplemodal-close"  id="modalImprimir7_view">Aceptar</a>\
                                </div>\
                            </div>'
            break;

            case  "bloqueoReimpresion":
                content = '<div class="cuadro">\
                                    <a style="visibility:hidden;" href="#" class=" simplemodal-close">\
                                        <img src="../../Imgs/cerrar.png" class="cerrar">\
                                    </a>\
                                    <div class="titModal">Reimpresión de vouchers de tarjeta bancaria</div>\
                                    <div class="clear"></div><br>\
                                    <div class="texto1">\
                                        No está permitida la reimpresión del voucher,<br>\
                                        se ha excedido el número autorizado de copias a imprimir.\
                                    </div><br>\
                                <div class="botones1">\
                                    <a href="#" class="btnV w48 simplemodal-close">Aceptar</a>\
                                </div>\
                            </div>'
            break;

            default:
                content = '<p>No se eligío un mensaje valido para mostrar<\p>'
            break;

        }
        return content;
    }
};