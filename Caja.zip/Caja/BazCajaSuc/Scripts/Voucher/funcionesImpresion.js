var FuncionesImpresion = {
    mostrarModal: function mostrarModal(tipo) {
        cerrarModal();
        html = ManejadorMsgVoucher.getContentV(tipo);
        $('#modal00').empty();
        $('#modal00').append(html);
        $('#modal00').modal();
    }
};
