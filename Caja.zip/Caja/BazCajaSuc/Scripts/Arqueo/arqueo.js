﻿if ($j === undefined) { var $j = jQuery.noConflict(true); console.log($().jquery); console.log($j().jquery); }

const AUrlValidaAcceso = "Arqueo/WsCajaArqueo.svc/wsValidaAccesoArqueo"; //
const AUrlValidaEmpleado = "Comun/WsCajaComun.svc/wsConsultaInformacionInicial"; //
const AUrlDivisas = "Comun/WsCajaComun.svc/wsconsultaDivisa"; //
const AUrlObjArquear = "Arqueo/WsCajaArqueo.svc/wsConsultaObjetosArqueo"; //
const AUrlDocsArqueo = "Arqueo/WsCajaArqueo.svc/wsConsultaDocumentosArqueo"; //
const AUrlDenominaciones = "Arqueo/WsCajaArqueo.svc/wsConsultaDenominacion"; //
const AUrlRegistraArqueo = "Arqueo/WsCajaArqueo.svc/wsRegistraArqueo"; //
const AUrlObtieneValidadores = "wsUtileriaCaja/wsUtileria.svc/wsPerfilAutorizador"; //
const AUrlConfirmaArqueo = "Arqueo/WsCajaArqueo.svc/wsConfirmaArqueo";
const AUrlGeneraPDF = "Arqueo/WsCajaArqueo.svc/wsGeneraDocumentoImpresion";
const AUrlBorraPDF = "Arqueo/WsCajaArqueo.svc/wsEliminaDocumentoImpresion";

const ServidorPrueba = "10.54.28.226";
const PuertoPrueba = "9014";
const AHostImpresion = "http://localhost:9001/";
const AUrlImprimeArqueo = "WSDesTecAppsLocal/ImprimirDocumentoPDFCarta";

const limitePiezas = 1000000000;
const limiteOnzas = 100000000;
const limiteImportes = 10000000000.0;

var pg_empleadoUser = null;
var pg_empleadoID = null;
var pg_empleadoPass = null;
var pg_cajaNombre = null;
var pg_noTienda = null;
var pg_tipoArqueo = null;
var pg_empleadoPuesto = null;
var pg_empleadosVal = null;
var pg_empleadosValPerfs = null;

var a_datosArqueo = null;
var a_indicesDivisas = [];
var a_divisaActual = null;
var a_objetoActual = null;
var a_datosRegistro = null;
var a_arqueoID = null;
var a_pideSoloUnaHuella = null;

var refFuncError = null;
var refFuncMensaje = null;
var refFuncAceptar = null;
var refFuncCancelar = null;

var validarOperador = null;
var pantallaCargada = false;

$(document).ready(function () {

    var date = new Date();
    $('#tagHora').html(date.getHours() + ":" + pad(date.getMinutes(), 2));
    $('#tagFecha').html(date.getDate() + "/" + (date.getMonth() + 1) + "/" + date.getFullYear());

    pg_empleadoUser = getUrlVars()["empleado"];
    pg_empleadoPass = getUrlVars()["pass"];
    pg_cajaNombre = getUrlVars()["ws"];
    pg_tipoArqueo = getUrlVars()["tipoarqueo"];
    if (pg_empleadoUser === undefined || pg_empleadoUser == ""
        || pg_empleadoPass === undefined || pg_empleadoPass == ""
        || pg_cajaNombre === undefined || pg_cajaNombre == ""
        || pg_tipoArqueo === undefined || pg_tipoArqueo == "") {
        DispararError("Los parámetros no son correctos.", 'parámetros de la URL', CerrarArqueo);
        return;
    }

    //parametro adicional en la URL para saber si se necesita solo una autenticacion de huella. Puede dejarse sin definir.
    let huella = getUrlVars()["unaAutorizacion"];
    if (huella === undefined)
        a_pideSoloUnaHuella = false
    else
        a_pideSoloUnaHuella = (huella == "1") ? true : false;

    switch (pg_tipoArqueo) {
        case "1":
            $('#tipoDeArqueo').append(" - Apertura");
            break;
        case "2":
            $('#tipoDeArqueo').append(" - Cierre");
            break;
        case "3":
            $('#tipoDeArqueo').append(" - Seguimiento");
            break;
        case "4":
            $('#tipoDeArqueo').append(" - Siniestro");
            break;
        case "5":
            $('#tipoDeArqueo').append(" - Deshonestidad");
            break;
        case "6":
            $('#tipoDeArqueo').append(" - Cajero por Liq. Anticipada");
            break;
        case "7":
            $('#tipoDeArqueo').append(" - General por Liq. Anticipada");
            break;
        case "8":
            $('#tipoDeArqueo').append(" - Saldo Global Excedido en Sucursal");
            break;
        case "9":
            $('#tipoDeArqueo').append(" - Depósitos excedidos en sucursal");
            break;
        case "10":
            $('#tipoDeArqueo').append(" - Sorpresa General");
            break;
        case "11":
            $('#tipoDeArqueo').append(" - Sorpresa Cajero");
            break;
    }

    pg_empleadoUser = pg_empleadoUser.toString().replace('#', '');
    pg_empleadoID = pg_empleadoUser.replace(/\D/g, '');
    pg_empleadoPass = pg_empleadoPass.toString().replace('#', '');
    pg_cajaNombre = pg_cajaNombre.toString().replace('#', '');
    pg_tipoArqueo = pg_tipoArqueo.toString().replace('#', '');
    //empieza a cargar los servicios de empleado y de acceso de estación
    mostrarCarga(true);

    setTimeout(function () {
        var obj = AServValidaAcceso(pg_cajaNombre);
        if (obj.NoError != 0) {
            DispararError(obj.Descripcion, 'consulta de estación de trabajo', CerrarArqueo);
            mostrarCarga(false);
            return;
        } else if (!obj.Acceso) {
            DispararError(obj.Descripcion, 'consulta de estación de trabajo', CerrarArqueo);
            mostrarCarga(false);
            return;
        }
        //MEJORAR, QUITAR LAS SIGUIENTES INSTRUCCIONES CUANDO HAYA SIDO IMPLEMENTADO LO DE LA CONSULTA DE LA HUELLA
        //a_pideSoloUnaHuella = false;
        obj = AServConsultaEmpleado(pg_empleadoID);
        if (obj.NoError != 0) {
            DispararError(obj.Descripcion, 'consulta de empleado', CerrarArqueo);
            mostrarCarga(false);
            return;
        }
        $('#tagEstacion').html(pg_cajaNombre + " -");
        $('#tagEmpNombre').html(obj.InformacionInicial.NombreEmpleado);
        $('#tagEmpDescripcion').html(obj.InformacionInicial.DescripcionPBase);
        pg_empleadoPuesto = obj.InformacionInicial.PuestoBase;
        $('#tagNumTienda').html(pg_noTienda = obj.InformacionInicial.NoTienda);
        $('#tagNombreTienda').html(obj.InformacionInicial.NombreTienda);
        $('#tagPais').html(obj.InformacionInicial.DescripcionPais);

        document.getElementById('textoObservaciones').value = ''; //vaciar comentarios
        LlenarSelectDivisas();

        //declarar comportamiento de elementos estáticos
        $('#selectDivisas').on('change', function () {
            AsignarEventosDenominaciones(a_divisaActual, a_objetoActual, false); //desasignar eventos antes de cambiar la divisa actual
            AsignarEventosDocumentos(a_divisaActual, false);
            a_divisaActual = $(this).val().toString();
            if (a_datosArqueo[a_divisaActual].ObjetosArqueo == null) {
                mostrarCarga(true);
                setTimeout(function () {
                    LlenarSelectObjetosArqueo(a_divisaActual, true);
                    LlenarTablaDocumentos(a_divisaActual, true);
                    mostrarCarga(false);
                }, 200)
            } else {
                LlenarSelectObjetosArqueo(a_divisaActual, true);
                LlenarTablaDocumentos(a_divisaActual, true);
            }
        });

        $('#selectObjetosArqueo').on('change', function () {
            AsignarEventosDenominaciones(a_divisaActual, a_objetoActual, false); //desasignar eventos antes de cambiar de objeto para arquear
            a_objetoActual = $(this).val();
            LlenarTablaDenominaciones(a_divisaActual, $(this).val(), true);
        });
        $('#textoObservaciones').keyup(function () {
            var raw_text = $(this).val();
            var return_text = raw_text.replace(/[^a-zA-Z0-9 ]/g, '');
            $(this).val(return_text);
            if ($(this).val().length > 70) {
                $(this).val($(this).val().substring(0, 70));
            }
        });
    }, 250);
});

/////////////////////////Funciones para rellenar las tablas//////////////////////////////////////////

//solo se ejecuta una sola vez, al principio
function LlenarSelectDivisas() {
    //consulta servicio de divisas
    var obj = ServConsultaDivisa();
    if (obj.NoError != 0) {
        DispararError(obj.Descripcion, 'consulta de divisas', CerrarArqueo);
        mostrarCarga(false);
        return;
    }
    var divisas = obj.Divisas;
    //llenar select grafico
    var opciones = "";
    var strSelected;
    for (var i = 0 ; i < divisas.length ; i++) {
        strSelected = (i == 0) ? "selected" : "";
        opciones += '<option value="' + divisas[i].Id + '" ' + strSelected + '>' + divisas[i].Descripcion + '</option>';
        a_indicesDivisas.push(divisas[i].Id);
    }
    $('#selectDivisas').html(opciones);
    //inicializar objeto para almacenar datos de las divisas, objetos de arqueo y documentos
    a_datosArqueo = {};
    //al acceder a los datos de una divisa, de debe usar un indice que sea STRING, no que sea numerico
    a_divisaActual = divisas[0].Id.toString();
    for (var i = 0 ; i < divisas.length ; i++) {
        //definir el objeto de divisas con indices que correspondan a su ID del servicio, no a su indice del arreglo
        Object.defineProperty(a_datosArqueo, divisas[i].Id.toString(), { enumerable: true, configurable: true, writable: true, value: divisas[i] });
        Object.defineProperty(a_datosArqueo[divisas[i].Id.toString()], "ObjetosArqueo", { enumerable: true, configurable: true, writable: true, value: null });
        Object.defineProperty(a_datosArqueo[divisas[i].Id.toString()], "Documentos", { enumerable: true, configurable: true, writable: true, value: null });
        Object.defineProperty(a_datosArqueo[divisas[i].Id.toString()], "Denominaciones", { enumerable: true, configurable: true, writable: true, value: null });
    }
    //si se cargan correctamente el select de objetos de arqueo y la tabla de documentos
    LlenarSelectObjetosArqueo(a_divisaActual, true);
    LlenarTablaDocumentos(a_divisaActual, true);
    mostrarCarga(false);
}

//este se ejecuta cada vez que cambian la divisa
function LlenarSelectObjetosArqueo(divisaID, llenarSelect) {
    //consultar servicio de objetos de arqueo
    divisaID = divisaID.toString(); //por si no está convertida
    var obj;
    //si el conjunto de objetos de arqueo de esta divisa no ha sido definido
    if (a_datosArqueo[divisaID].ObjetosArqueo == null) {
        //asignar el conjunto de objetos de arqueo ejecutando el servicio de objetos de arqueo
        obj = ServObjetosArqueo(divisaID);
        if (obj.NoError != 0) {
            DispararError(obj.Descripcion, 'consulta de objetos de arqueo');
            return false;
        }
        a_datosArqueo[divisaID].ObjetosArqueo = obj.ObjetosArqueo; //estos sí se asignan como vienen en su arreglo, sin ponerles indices
    }

    if (llenarSelect) {
        //elementos graficos del select de objetos de arqueo
        var opciones = "";
        var strSelected;
        for (var i = 0 ; i < a_datosArqueo[divisaID].ObjetosArqueo.length ; i++) {
            strSelected = (i == 0) ? "selected" : "";
            opciones += '<option value="' + a_datosArqueo[divisaID].ObjetosArqueo[i].Simbolo + '" ' + strSelected + '>' + a_datosArqueo[divisaID].ObjetosArqueo[i].Descripcion + '</option>';
        }
        $('#selectObjetosArqueo').html(opciones);
    }

    //define solo los DATOS de las denominaciones si no los tiene
    //no lo separo porque se necesita saber cuantas denominaciones hay para asignar el arreglo de valores de cada objeto de arqueo
    if (a_datosArqueo[divisaID].Denominaciones == null) {
        //asignar el conjunto de objetos de arqueo
        if (divisaID == "3") { //caso especifico para las divisas de onza de plata, su denominación se maneja distinto
            obj = {
                "ObjetoDenominacion":
                [
                    {
                        "AplicaCentavos": false,
                        "Divisa": 3,
                        "IdDenominacion": "danada"
                    },
                    {
                        "AplicaCentavos": false,
                        "Divisa": 3,
                        "IdDenominacion": "manchada"
                    },
                    {
                        "AplicaCentavos": false,
                        "Divisa": 3,
                        "IdDenominacion": "buena"
                    }
                ]
            };
        } else { //si no, simplemente se obtiene del servicio
            obj = ServDenominaciones(divisaID);
            if (obj.NoError != 0) {
                DispararError(obj.Descripcion, 'consulta de denominaciones');
                return false;
            }
        }
        a_datosArqueo[divisaID].Denominaciones = obj.ObjetoDenominacion;
        //asignar los nombres de etiquetas a las denominaciones
        var tagnombre;
        for (var i = 0 ; i < a_datosArqueo[divisaID].Denominaciones.length ; i++) {
            tagnombre = 'div' + a_datosArqueo[divisaID].Denominaciones[i].Divisa + '_' + a_datosArqueo[divisaID].Denominaciones[i].IdDenominacion.toString().replace(".", "-");
            Object.defineProperty(a_datosArqueo[divisaID].Denominaciones[i], "Etiqueta", { enumerable: true, configurable: true, writable: true, value: tagnombre });
        }
        //asignar a cada uno de los objetos a arquear su propio arreglo de valores numericos
        var arrValores;
        var total;
        for (var i = 0 ; i < a_datosArqueo[divisaID].ObjetosArqueo.length ; i++) {
            if (!a_datosArqueo[divisaID].ObjetosArqueo[i].Editable) { //no existe el caso en que sea denominado, pero no editable
                total = a_datosArqueo[divisaID].ObjetosArqueo[i].Saldo;
            } else {
                total = 0;
                if (a_datosArqueo[divisaID].ObjetosArqueo[i].Denominado || divisaID == "3") {
                    arrValores = [];
                    for (var j = 0 ; j < a_datosArqueo[divisaID].Denominaciones.length ; j++) {
                        arrValores.push(0);
                    }
                } else {
                    arrValores = [0];
                }
                Object.defineProperty(a_datosArqueo[divisaID].ObjetosArqueo[i], "ValorDenominaciones", { enumerable: true, configurable: true, writable: true, value: arrValores });
            }
            Object.defineProperty(a_datosArqueo[divisaID].ObjetosArqueo[i], "TotalDenominaciones", { enumerable: true, configurable: true, writable: true, value: total });
        }
    }

    //ahora a llenar los informes
    if (llenarSelect) {
        a_objetoActual = a_datosArqueo[divisaID].ObjetosArqueo[0].Simbolo;
        LlenarTablaDenominaciones(divisaID, a_datosArqueo[divisaID].ObjetosArqueo[0].Simbolo, true);
    }
}

//llenar la tabla izquierda, que tiene todos los valores editables y no editables de las denominaciones
function LlenarTablaDenominaciones(divisaID, simboloOBJ, definirEventos) {
    //poner elementos graficos, no se actualizan la tabla de datos todavia porque no es necesario, solo estamos jalando datos
    var tabla = '';
    var objArqueo = getObjArqueo(divisaID, simboloOBJ);
    if (!objArqueo.Editable) { //no editable
        tabla += '<tbody><th>Descripción</th><th>Total</th></tr>';
        tabla += '<tr><td>Saldo en ' + objArqueo.Descripcion + '</td><td>' + formatoDinero(objArqueo.TotalDenominaciones, divisaID) + '</td></tr>';
    } else {
        if (divisaID == "3") { //onzas
            tabla += '<tbody><tr><th>Piezas a capturar:</th><th>Piezas</th><th style="text-align:-moz-right">Total</th></tr>';
            var tagnombre;
            var arrStr = ["Piezas dañadas", "Piezas manchadas", "Piezas en buen estado"]
            for (var i = 0 ; i < objArqueo.ValorDenominaciones.length ; i++) {
                tagnombre = a_datosArqueo[divisaID].Denominaciones[i].Etiqueta;
                tabla += '<tr><td>' + arrStr[i] + '</td><td><b id="tag_' + tagnombre + '" style="display:block">' + Number(objArqueo.ValorDenominaciones[i]) + '</b><input id="in_' + tagnombre + '" value="' + Number(objArqueo.ValorDenominaciones[i]) + '" onkeypress="return isNumberKey(event)" style="display:none;text-align:-moz-center;width:80px;margin: 0 auto"></td><td id="out_' + tagnombre + '" style="text-align:-moz-right">' + formatoDinero(objArqueo.ValorDenominaciones[i], divisaID) + '</td></tr>';
            }
        } else if (objArqueo.Denominado) { //editable y denominado
            tabla += '<tbody><tr><th>Denominación</th><th>Piezas</th><th style="text-align:-moz-right">Total</th></tr>';
            var tagnombre;
            for (var i = 0 ; i < objArqueo.ValorDenominaciones.length ; i++) {
                tagnombre = a_datosArqueo[divisaID].Denominaciones[i].Etiqueta;
                tabla += '<tr><td id="val_' + tagnombre + '">' + Number(a_datosArqueo[divisaID].Denominaciones[i].IdDenominacion) + '</td><td><b id="tag_' + tagnombre + '" style="display:block">' + Number(objArqueo.ValorDenominaciones[i]) + '</b><input id="in_' + tagnombre + '" value="' + Number(objArqueo.ValorDenominaciones[i]) + '" onkeypress="return isNumberKey(event)" style="display:none;text-align:-moz-center;width:80px;margin: 0 auto"></td><td id="out_' + tagnombre + '" style="text-align:-moz-right">' + formatoDinero(a_datosArqueo[divisaID].Denominaciones[i].IdDenominacion * objArqueo.ValorDenominaciones[i], divisaID) + '</td></tr>';
            }
        } else { //editable pero no denominado
            tabla += '<tbody><th>Descripción</th><th style="text-align:-moz-right">Total</th></tr>';
            tabla += '<tr><td>Saldo en ' + objArqueo.Descripcion + '</td><td><b id="tag_nodenominado" style="display:block">' + formatoDinero(Number(objArqueo.ValorDenominaciones[0]), divisaID) + '</b><input id="in_nodenominado" value="' + toFixedJ(Number(objArqueo.ValorDenominaciones[0]), 2) + '" onkeypress="return isNumberDecimalKey(event)" style="display:none;text-align:-moz-center;width:80px;margin: 0 auto"></td></tr>';
        }
    }
    tabla += '</tbody>';
    $('#tablaDenominaciones').html(tabla);
    //lenar totales de arqueo e informes
    LlenarTotalesArqueo(divisaID, simboloOBJ);
    //ahora se asigna el comportamiento de las etiquetas, DESPUES de cargar la pagina
    AsignarEventosDenominaciones(divisaID, simboloOBJ, true);
}

//esta funcion se dispara cuando se actuliza algun valor, y actualiza los totales
function ActualizarTablaDenominaciones(divisaID, simboloOBJ) {
    var objArqueo = getObjArqueo(divisaID, simboloOBJ);
    var total;
    var valor;
    //no contamos el caso de editable = false porque no se puede disparar esta funcion en ese caso
    if (objArqueo.Denominado || divisaID == "3") {
        total = 0;
        for (var i = 0 ; i < objArqueo.ValorDenominaciones.length ; i++) {
            tagnombre = a_datosArqueo[divisaID].Denominaciones[i].Etiqueta;
            valor = Number(document.getElementById('in_' + tagnombre).value);
            valor = isNaN(valor) ? 0 : valor;
            valor = (divisaID == "3") ? ((valor > limiteOnzas) ? 0 : valor) : ((valor > limitePiezas) ? 0 : valor);
            let suma = (divisaID == "3") ? valor : a_datosArqueo[divisaID].Denominaciones[i].IdDenominacion * valor;
            if ((total + suma) >= limiteImportes) {
                valor = 0;
                DispararMensaje('El total de arqueo no puede exceder los ' + formatoDinero(limiteImportes, divisaID));
            }
            else
                total += suma;
            document.getElementById('in_' + tagnombre).value = objArqueo.ValorDenominaciones[i] = valor;
        }
        objArqueo.TotalDenominaciones = total;
    } else {
        valor = Number(document.getElementById('in_nodenominado').value);
        if (valor >= limiteImportes) DispararMensaje('El total de arqueo no puede exceder los ' + formatoDinero(limiteImportes, divisaID));
        document.getElementById('in_nodenominado').value = (isNaN(valor) || valor >= limiteImportes || (valor > 0.0 && valor < 0.01)) ? 0.0 : toFixedJ(valor, 2);
        objArqueo.ValorDenominaciones[0] = Number($('#in_nodenominado').val());
        objArqueo.TotalDenominaciones = objArqueo.ValorDenominaciones[0];
    }
    setObjArqueo(divisaID, simboloOBJ, objArqueo);
}

//se asigna el comportamiento de las etiquetas, DESPUES de cargar la pagina
function AsignarEventosDenominaciones(divisaID, simboloOBJ, asignarEvento) {
    var objArqueo = getObjArqueo(divisaID, simboloOBJ);
    if (objArqueo.Editable) {
        if (objArqueo.Denominado || divisaID == "3") {
            var tagnombre;
            for (var i = 0 ; i < objArqueo.ValorDenominaciones.length ; i++) {
                tagnombre = a_datosArqueo[divisaID].Denominaciones[i].Etiqueta;
                $('#in_' + tagnombre).unbind('focusout keypress');
                $('#tag_' + tagnombre).unbind('click');
                if (asignarEvento) {
                    $('#in_' + tagnombre).on('focusout keypress', function (event) {
                        if ((event.type == 'keypress' && (event.keyCode === 13 || event.keyCode === 40 || event.keyCode === 38))
                            || event.type == 'focusout') {
                            var valor = '#' + event.target.id;
                            $(valor).css("display", "none");
                            valor = valor.replace("in", "tag");
                            $(valor).css("display", "block");
                            ActualizarTablaDenominaciones(a_divisaActual, a_objetoActual);
                            LlenarTablaDenominaciones(a_divisaActual, a_objetoActual, false);
                            if (event.type == 'keypress') {
                                valor = event.target.id;
                                valor = valor.replace("in_", "");
                                if (event.keyCode == 38)
                                    valor = ConseguirAnteriorEtiqueta(valor);
                                else
                                    valor = ConseguirSiguienteEtiqueta(valor);
                                //si este elemento de la tabla NO es el ultimo
                                if (valor != null) {
                                    //brincar al siguiente
                                    let el = document.getElementById(valor);
                                    if (el.fireEvent) {
                                        el.fireEvent('onclick');
                                    } else {
                                        var evObj = document.createEvent('Events');
                                        evObj.initEvent('click', true, false);
                                        el.dispatchEvent(evObj);
                                    }
                                }
                            }
                        }
                    });
                    $('#tag_' + tagnombre).on('click', function (event) {
                        var valor = '#' + event.target.id;
                        $(valor).css("display", "none");
                        valor = valor.replace("tag", "in");
                        $(valor).css("display", "block");
                        $(valor).focus().select();
                    });
                }
            }
        } else {
            $('#in_nodenominado').unbind('focusout keypress');
            $('#tag_nodenominado').unbind('click');
            if (asignarEvento) {
                $('#in_nodenominado').on('focusout keypress', function (event) {
                    if ((event.type == 'keypress' && event.which === 13) || event.type == 'focusout') {
                        var valor = '#' + event.target.id;
                        $(valor).css("display", "none");
                        valor = valor.replace("in", "tag");
                        $(valor).css("display", "block");
                        ActualizarTablaDenominaciones(a_divisaActual, a_objetoActual);
                        LlenarTablaDenominaciones(a_divisaActual, a_objetoActual, false);
                    }
                });
                $('#tag_nodenominado').on('click', function (event) {
                    var valor = '#' + event.target.id;
                    $(valor).css("display", "none");
                    valor = valor.replace("tag", "in");
                    $(valor).css("display", "block");
                    $(valor).focus().select();
                });
            }
        }
    }
}

function ConseguirSiguienteEtiqueta(valor) {
    try {
        for (var i = 0 ; i < a_datosArqueo[a_divisaActual].Denominaciones.length ; i++) {
            if (a_datosArqueo[a_divisaActual].Denominaciones[i].Etiqueta == valor)
                return "tag_" + a_datosArqueo[a_divisaActual].Denominaciones[i + 1].Etiqueta;
        }
    } catch (e) { }
    return null;
}

function ConseguirAnteriorEtiqueta(valor) {
    try {
        for (var i = 0 ; i < a_datosArqueo[a_divisaActual].Denominaciones.length ; i++) {
            if (a_datosArqueo[a_divisaActual].Denominaciones[i].Etiqueta == valor)
                return "tag_" + a_datosArqueo[a_divisaActual].Denominaciones[i - 1].Etiqueta;
        }
    } catch (e) { }
    return null;
}

//este metodo es para llenar el total de arqueo del objeto actual y llena la tabla de informes 
//se debe mandar a llamar DESPUES de actualizar correctamente a los valores de la tabla
function LlenarTotalesArqueo(divisaID, simboloOBJ) {
    $('#totalArqueo').html(formatoDinero(getObjArqueo(divisaID, simboloOBJ).TotalDenominaciones, divisaID));
    var tabla = '<tbody>';
    for (var i = 0 ; i < a_datosArqueo[divisaID].ObjetosArqueo.length ; i++)
        tabla += '<tr><td>' + a_datosArqueo[divisaID].ObjetosArqueo[i].Descripcion + '</td><td style="text-align:-moz-right">' + formatoDinero(a_datosArqueo[divisaID].ObjetosArqueo[i].TotalDenominaciones, divisaID) + '</td></tr>';
    tabla += '</tbody>';
    $('#tablaInforme').html(tabla);
}

function LlenarTablaDocumentos(divisaID, llenarTabla) {
    //si no se han definido los documentos
    if (a_datosArqueo[divisaID].Documentos == null) {
        var obj = ServDocumentos(divisaID);
        if (obj.NoError != 0) {
            DispararError(obj.Descripcion, 'consulta de documentos');
            return false;
        }
        a_datosArqueo[divisaID].Documentos = obj.Documentos;
        for (var i = 0 ; i < a_datosArqueo[divisaID].Documentos.length ; i++) {
            Object.defineProperty(a_datosArqueo[divisaID].Documentos[i], "NoDocumentos", { enumerable: true, configurable: true, writable: true, value: 0 });
            Object.defineProperty(a_datosArqueo[divisaID].Documentos[i], "ImporteTotal", { enumerable: true, configurable: true, writable: true, value: 0 });
        }
    }
    if (llenarTabla) {
        var tabla = '<tbody><tr><th>Tipo de pago:</th><th>No. documentos</th><th style="text-align:-moz-right">Importe total</th></tr>';
        for (var i = 0 ; i < a_datosArqueo[divisaID].Documentos.length ; i++) {
            tabla += '<tr><td>' + a_datosArqueo[divisaID].Documentos[i].Descripcion + '</td>' +
                '<td><b id="tag_NoDoc' + a_datosArqueo[divisaID].Documentos[i].TipoDocumento + '" style="display:block">' + Number(a_datosArqueo[divisaID].Documentos[i].NoDocumentos) + '</b><input id="in_NoDoc' + a_datosArqueo[divisaID].Documentos[i].TipoDocumento + '" value="' + Number(a_datosArqueo[divisaID].Documentos[i].NoDocumentos) + '" onkeypress="return isNumberKey(event)" style="display:none;text-align:-moz-center;width:80px;margin: 0 auto"></td>' +
                '<td><b id="tag_ImpTot' + a_datosArqueo[divisaID].Documentos[i].TipoDocumento + '" style="display:block;text-align:-moz-right">' + formatoDinero(Number(a_datosArqueo[divisaID].Documentos[i].ImporteTotal), divisaID) + '</b><input id="in_ImpTot' + a_datosArqueo[divisaID].Documentos[i].TipoDocumento + '" value="' + toFixedJ(Number(a_datosArqueo[divisaID].Documentos[i].ImporteTotal), 2) + '" onkeypress="return isNumberDecimalKey(event)" style="display:none;text-align:-moz-center;width:80px;margin: 0 auto"></td></tr>';
        }
        tabla += '</tbody>';
        $('#tablaDocumentos').html(tabla);
        AsignarEventosDocumentos(divisaID, true);
    }
}

function AsignarEventosDocumentos(divisaID, asignarEvento) {
    //ahora se asigna el comportamiento de las etiquetas, DESPUES de cargar la pagina
    var iddoc;
    for (var i = 0 ; i < a_datosArqueo[divisaID].Documentos.length ; i++) {
        iddoc = a_datosArqueo[divisaID].Documentos[i].TipoDocumento;
        $('#in_ImpTot' + iddoc).unbind('focusout keypress');
        $('#in_NoDoc' + iddoc).unbind('focusout keypress');
        $('#tag_ImpTot' + iddoc).unbind('click focus');
        $('#tag_NoDoc' + iddoc).unbind('click focus');
        if (asignarEvento) {
            $('#in_ImpTot' + iddoc).on('focusout keypress', function (event) {
                if ((event.type == 'keypress' && (event.keyCode == 13 || event.keyCode == 38 || event.keyCode == 40)) || event.type == 'focusout') {
                    var valor = '#' + event.target.id;
                    $(valor).css("display", "none");
                    valor = valor.replace("in", "tag");
                    $(valor).css("display", "block");
                    if (isNaN(Number($(this).val())) || $(this).val() == 0 || $(this).val() >= limiteImportes || ($(this).val() > 0.0 && $(this).val() < 0.01)) {
                        if ($(this).val() >= limiteImportes) DispararMensaje('El total de arqueo no puede exceder los ' + formatoDinero(limiteImportes, divisaID));
                        valor = event.target.id;
                        document.getElementById(valor).value = 0.0;
                        valor = (valor).replace("ImpTot", "NoDoc");
                        document.getElementById(valor).value = 0;
                    }
                    ActualizarValoresDocumentos(a_divisaActual);
                    if (event.type == 'keypress') {
                        valor = event.target.id;
                        valor = valor.replace("in_ImpTot", "");
                        if (event.keyCode == 38)
                            valor = ConseguirAnteriorEtiquetaDoc(valor);
                        else
                            valor = ConseguirSiguienteEtiquetaDoc(valor);
                        //si este elemento de la tabla NO es el ultimo
                        if (valor != null) {
                            //brincar al siguiente
                            let el = document.getElementById(valor);
                            if (el.fireEvent) {
                                el.fireEvent('onclick');
                            } else {
                                var evObj = document.createEvent('Events');
                                evObj.initEvent('click', true, false);
                                el.dispatchEvent(evObj);
                            }
                        }
                    }
                }
            });
            $('#in_NoDoc' + iddoc).on('focusout keypress', function (event) {
                if ((event.type == 'keypress' && (event.keyCode == 13 || event.keyCode == 38 || event.keyCode == 40)) || event.type == 'focusout') {
                    var valor = '#' + event.target.id;
                    $(valor).css("display", "none");
                    valor = valor.replace("in", "tag");
                    $(valor).css("display", "block");

                    //ahora checa si puso 0 en el valor, si es asi, imptot tambien se lleva a 0
                    valor = event.target.id;
                    if ($(this).val() == 0 || $(this).val() > limitePiezas) {
                        document.getElementById(valor).value = 0;
                        valor = valor.replace("NoDoc", "ImpTot");
                        document.getElementById(valor).value = 0.0;
                    }
                    ActualizarValoresDocumentos(a_divisaActual);
                    if (event.type == 'keypress') {
                        //si le da enter a NoDoc, que se pase a ImpTot
                        if (event.keyCode == 13) {
                            valor = event.target.id;
                            valor = valor.replace("NoDoc", "ImpTot");
                            valor = '#' + valor;
                            valor = valor.replace("in", "tag");
                            $(valor).css("display", "none");
                            valor = valor.replace("tag", "in");
                            $(valor).css("display", "block");
                            $(valor).focus().select();
                            return;
                        }
                        //si se le dio arriba o abajo
                        valor = event.target.id;
                        valor = valor.replace("in_NoDoc", "");
                        if (event.keyCode == 38)
                            valor = ConseguirAnteriorEtiquetaDoc(valor);
                        else
                            valor = ConseguirSiguienteEtiquetaDoc(valor);
                        //si este elemento de la tabla NO es el ultimo
                        if (valor != null) {
                            //brincar al siguiente
                            let el = document.getElementById(valor);
                            if (el.fireEvent) {
                                el.fireEvent('onclick');
                            } else {
                                var evObj = document.createEvent('Events');
                                evObj.initEvent('click', true, false);
                                el.dispatchEvent(evObj);
                            }
                        }
                    }
                }
            });
            $('#tag_ImpTot' + iddoc).on('click focus', function (event) {
                var valor = '#' + event.target.id;
                $(valor).css("display", "none");
                valor = valor.replace("tag", "in");
                $(valor).css("display", "block");
                $(valor).focus().select();
            });
            $('#tag_NoDoc' + iddoc).on('click focus', function (event) {
                var valor = '#' + event.target.id;
                $(valor).css("display", "none");
                valor = valor.replace("tag", "in");
                $(valor).css("display", "block");
                $(valor).focus().select();
            });
        }
    }
}

function ConseguirSiguienteEtiquetaDoc(valor) {
    try {
        for (var i = 0 ; i < a_datosArqueo[a_divisaActual].Documentos.length ; i++) {
            if (a_datosArqueo[a_divisaActual].Documentos[i].TipoDocumento == valor)
                return "tag_NoDoc" + a_datosArqueo[a_divisaActual].Documentos[i + 1].TipoDocumento;
        }
    } catch (e) { }
    return null;
}

function ConseguirAnteriorEtiquetaDoc(valor) {
    try {
        for (var i = 0 ; i < a_datosArqueo[a_divisaActual].Documentos.length ; i++) {
            if (a_datosArqueo[a_divisaActual].Documentos[i].TipoDocumento == valor)
                return "tag_NoDoc" + a_datosArqueo[a_divisaActual].Documentos[i - 1].TipoDocumento;
        }
    } catch (e) { }
    return null;
}

function ActualizarValoresDocumentos(divisaID) {
    var tempImp;
    var tempDoc;
    for (var i = 0 ; i < a_datosArqueo[divisaID].Documentos.length ; i++) {

        iddoc = a_datosArqueo[divisaID].Documentos[i].TipoDocumento;

        tempDoc = Number(document.getElementById('in_NoDoc' + iddoc).value);
        tempDoc = isNaN(tempDoc) ? 0 : tempDoc;

        tempImp = Number(document.getElementById('in_ImpTot' + iddoc).value);
        tempImp = isNaN(tempImp) ? 0.0 : toFixedJ(tempImp, 2);
        document.getElementById('in_ImpTot' + iddoc).value = tempImp;
        document.getElementById('tag_ImpTot' + iddoc).innerHTML = formatoDinero(Number(tempImp), divisaID);
        if (tempDoc == 0 && tempImp > 0)
            tempDoc = 1;
        document.getElementById('in_NoDoc' + iddoc).value = tempDoc;
        document.getElementById('tag_NoDoc' + iddoc).innerHTML = tempDoc.toString();

        a_datosArqueo[divisaID].Documentos[i].NoDocumentos = tempDoc;
        a_datosArqueo[divisaID].Documentos[i].ImporteTotal = tempImp;
    }
}

function RegistrarArqueo() {
    mostrarCarga(true);
    setTimeout(function () {
        //0. obtener el comentario del textbox
        let observaciones = $('#textoObservaciones').val();
        objRegistro = {
            "DetalleDenominaciones": [],
            "DetalleObjetos": [],
            "Empleado": pg_empleadoUser.toString(),
            "PassEmpleado": pg_empleadoPass.toString(),
            "Sucursal": Number(pg_noTienda),
            "Terminal": pg_cajaNombre,
            "NoTransaccion": 0,
            "Observaciones": observaciones,
            "OnzasPlata": {
                "PiezasDanadas": 0,
                "PiezasManchadas": 0,
                "PiezasOk": 0
            },
            "Puesto": pg_empleadoPuesto
        };
        const denomVacio = {
            "Denominacion": null,
            "NoBilletes": 0,
            "ObjetoArqueado": "",
            "TipoDivisa": null
        };
        const objdocVacio = {
            "DocumentosArqueados": 0,
            "NoTransaccion": 0,
            "ObjetoArqueado": "CD",
            "Saldo": 0,
            "TipoDivisa": null,
            "TipoPago": null
        };
        var divisaID;
        //1. llenar arreglo de detalle de denominaciones
        //2. llenar el arreglo de detalle objetos
        for (var i = 0 ; i < a_indicesDivisas.length ; i++) {
            divisaID = a_indicesDivisas[i].toString();
            if (a_datosArqueo[divisaID].ObjetosArqueo == null)
                LlenarSelectObjetosArqueo(divisaID, false);
            for (var j = 0 ; j < a_datosArqueo[divisaID].ObjetosArqueo.length ; j++) { //recorrer los objetos de arqueo
                if (divisaID == "3") //aquí no se guardan los valores de las onzas de plata
                    break;
                //meter cambios que se han hecho a todas las denominaciones que se hicieron sobre este objeto
                if (a_datosArqueo[divisaID].ObjetosArqueo[j].Editable && a_datosArqueo[divisaID].ObjetosArqueo[j].Denominado) {
                    for (var k = 0 ; k < (a_datosArqueo[divisaID].ObjetosArqueo[j].ValorDenominaciones.length) ; k++) {
                        var denomTemp = denomVacio;
                        denomTemp.Denominacion = a_datosArqueo[divisaID].Denominaciones[k].IdDenominacion;
                        denomTemp.NoBilletes = a_datosArqueo[divisaID].ObjetosArqueo[j].ValorDenominaciones[k];
                        denomTemp.ObjetoArqueado = a_datosArqueo[divisaID].ObjetosArqueo[j].Simbolo;
                        denomTemp.TipoDivisa = Number(divisaID);
                        objRegistro.DetalleDenominaciones.push($.extend({}, (denomTemp)));
                    }
                }
            }
            //meter objeto de arqueo al registro, independiente si se modificó o no
            for (var j = 0 ; j < a_datosArqueo[divisaID].ObjetosArqueo.length ; j++) {
                var objdocTemp = objdocVacio;
                objdocTemp.DocumentosArqueados = 0;
                objdocTemp.Saldo = Number(a_datosArqueo[divisaID].ObjetosArqueo[j].TotalDenominaciones);
                objdocTemp.TipoDivisa = Number(divisaID);
                objdocTemp.ObjetoArqueado = a_datosArqueo[divisaID].ObjetosArqueo[j].Simbolo;
                objdocTemp.TipoPago = 1;
                objRegistro.DetalleObjetos.push($.extend({}, (objdocTemp)));
            }
            //meter cambios que se han hecho a los documentos de esta divisa
            if (a_datosArqueo[divisaID].Documentos == null)
                LlenarTablaDocumentos(divisaID, false);
            for (var j = 0 ; j < a_datosArqueo[divisaID].Documentos.length ; j++) {
                var objdocTemp = objdocVacio;
                objdocTemp.DocumentosArqueados = a_datosArqueo[divisaID].Documentos[j].NoDocumentos;
                objdocTemp.Saldo = Number(a_datosArqueo[divisaID].Documentos[j].ImporteTotal);
                objdocTemp.TipoDivisa = Number(divisaID);
                objdocTemp.ObjetoArqueado = "CD";
                objdocTemp.TipoPago = a_datosArqueo[divisaID].Documentos[j].TipoDocumento;
                objRegistro.DetalleObjetos.push($.extend({}, (objdocTemp)));
            }
        }
        //3. llenar el objeto de onzas de plata, si es que se definió esa divisa
        if (a_datosArqueo["3"] !== undefined) {
            divisaID = "3";
            //se cuenta uno menos porque ese ultimo objeto es el de la caja inmovil, el cual se cuenta como monedas buenas
            for (var i = 0 ; i < (a_datosArqueo[divisaID].ObjetosArqueo.length - 1) ; i++) {
                objRegistro.OnzasPlata["PiezasDanadas"] += a_datosArqueo[divisaID].ObjetosArqueo[i].ValorDenominaciones[0];
                objRegistro.OnzasPlata["PiezasManchadas"] += a_datosArqueo[divisaID].ObjetosArqueo[i].ValorDenominaciones[1];
                objRegistro.OnzasPlata["PiezasOk"] += a_datosArqueo[divisaID].ObjetosArqueo[i].ValorDenominaciones[2];
            }
            objRegistro.OnzasPlata["PiezasOk"] += a_datosArqueo[divisaID].ObjetosArqueo[a_datosArqueo[divisaID].ObjetosArqueo.length - 1].TotalDenominaciones;
        }
        
        var obj = ServRegistroArqueo(objRegistro);
        a_arqueoID = obj.Identificador;
        let mensErrorRegistros = "";
        if (obj.NoWarning == 1)
            mensErrorRegistros = "<br>Aviso de precaución: Falló el registro del servicio de ALNOVA.<br>" + obj.Descripcion + "<br>";
        if (obj.NoError == 0) {
            a_datosRegistro = obj.Diferencia;
            if (a_datosRegistro !== null) {
                $('#avisoRegistros').html(mensErrorRegistros);
                var tabla = '<tbody><tr><th>Movimiento</th><th>Elemento</th><th>Divisa</th><th>Tipo pago</th><th>Importe</th><th>Diferencia</th><th>Dif. doctos</th>' +
                    ((pg_tipoArqueo != 1 && pg_tipoArqueo != 2) ? '' : '<th>Acción a realizar</th>') +
                    '</tr>';
                let contPared = 0; //conteo de registros de pared electrónica
                for (var i = 0 ; i < a_datosRegistro.length ; i++) {
                    if (a_datosRegistro[i].DescElemento == "Pared Electrónica") {
                        contPared++;
                        continue;
                    }
                    tabla += '<tr><td>' + a_datosRegistro[i].DescStatusArqueo + '</td>' +
                        '<td>' + a_datosRegistro[i].DescElemento + '</td>' +
                    '<td>' + a_datosRegistro[i].AbrevDivisa + '</td>' +
                    '<td>' + a_datosRegistro[i].DescTipoPago + '</td>' +
                    '<td>' + formatoDinero(a_datosRegistro[i].SaldoArqueado, a_datosRegistro[i].TipoDivisa.toString()) + '</td>' +
                    '<td>' + formatoDinero(a_datosRegistro[i].Diferencia, a_datosRegistro[i].TipoDivisa.toString()) + '</td>' +
                    '<td>' + ((a_datosRegistro[i].IdElemento == "CD") ? a_datosRegistro[i].Documentos : '-') + '</td>';
                    if (pg_tipoArqueo == 1 || pg_tipoArqueo == 2) {
                        if (a_datosRegistro[i].DescStatusArqueo == 'Faltante')
                            tabla += '<td><b id="tagreg_' + i + '" style="display:block">Haga Click para editar</b><select id="reg_' + i + '" style="display:none"><option value="0" disabled selected>Seleccionar:</option><option value="1">Aceptar Ajuste</option><option value="2">Siniestro</option><option value="3">Error del sistema</option></select></td></tr>';
                        else
                            tabla += '<td>No Aplica<input type="hidden" value="1" id="reg_' + i + '"></td>';
                    } else {
                        //este registro de la tabla no es visible, pero se usa para que el boton de registrar funcione bien.
                        tabla += '<td><input type="hidden" value="0" id="reg_' + i + '"></td>';
                    }

                }
                tabla += '</tbody>';
                if (contPared == a_datosRegistro.length) //compara si los registros que salieron son todos de pared electrónica, si lo son, disparar mensaje de que no hubo problema
                    DispararConfirmacion('<b>No hay sobrantes o faltantes en los objetos arqueados.</b><br>' + mensErrorRegistros + '<br>¿Confirmar este arqueo de cajas?', botonAutenticar, null, "Sí", "No");
                else {
                    $('#tablaRegistro').html(tabla);
                    $j('#modal01').modal({ escClose: false });
                    AsignarEventosRegistro();
                    if (ActivarBotonRegistro())
                        $('#botonRegistro').show();
                    else
                        $('#botonRegistro').hide();
                }
            } else { //si no hay faltantes y sobrantes
                DispararConfirmacion('<b>No hay sobrantes o faltantes en los objetos arqueados.</b>' + mensErrorRegistros + '<br>¿Confirmar este arqueo de cajas?', botonAutenticar, null, "Sí", "No");
            }
        } else {
            DispararError(obj.Descripcion, 'registro de arqueo');
        }
        mostrarCarga(false);
    }, 250);

}

function AsignarEventosRegistro() {
    for (var i = 0 ; i < a_datosRegistro.length ; i++) {
        if (a_datosRegistro[i].DescElemento == "Pared Electrónica")
            continue;
        if (a_datosRegistro[i].DescStatusArqueo == 'Faltante') {
            $('#reg_' + i).unbind('focusout change');

            $('#reg_' + i).on('focusout change', function (event) {
                var valor = '#' + event.target.id;
                $(valor).css("display", "none");
                valor = valor.replace("reg", "tagreg");
                switch (Number($(this).val())) {
                    case 1:
                        $(valor).html('Aceptar Ajuste');
                        break;
                    case 2:
                        $(valor).html('Siniestro');
                        break;
                    case 3:
                        $(valor).html('Error del sistema');
                        break;
                    default:
                        $(valor).html('Haga Click para editar');
                        break;
                }
                $(valor).css("display", "block");
                if (ActivarBotonRegistro())
                    $('#botonRegistro').show();
                else
                    $('#botonRegistro').hide();
            });
            $('#tagreg_' + i).unbind('focusout change');
            $('#tagreg_' + i).on('click', function (event) {
                var valor = '#' + event.target.id;
                $(valor).css("display", "none");
                valor = valor.replace("tagreg", "reg");
                $(valor).css("display", "block");
                $(valor).focus().select();
            });
        }
    }
}

function ActivarBotonRegistro() {
    if (pg_tipoArqueo != 1 && pg_tipoArqueo != 2)
        return true;
    for (var i = 0 ; i < a_datosRegistro.length ; i++) {
        if (a_datosRegistro[i].DescElemento == "Pared Electrónica")
            continue;
        let val = $('#reg_' + i).val();
        if (val == 0 || val == null)
            return false;
    }
    return true;
}

/////////////////////////////////////Funciones para la ventana y la pagina////////////////////

//de esta manera se inicializa la autenticación
function AbrirHuellaOperador() {
    mostrarCarga(true);
    setTimeout(function () {
        mostrarCarga(false);
        validarOperador = true;
        let temp = pg_empleadoID;
        var json = '{"validarEmp":"' + temp + '","validarAut":"' + temp + '","perfiles":"' + pg_empleadoPuesto + '","tipo":"1","app":"Arqueo","ws":"' + pg_cajaNombre + '","top":"863","afectaHD":true}';
        json = JSON.parse(json);
        AutenticacionHuella(json);
    }, 300);
}

function AbrirHuellaValidar() {
    validarOperador = false;
    let temp = pg_empleadoID;
    var json = '{"validarEmp":"' + temp + '","validarAut":"' + pg_empleadosVal + '","perfiles":"' + pg_empleadosValPerfs + '","tipo":"1","app":"Arqueo","ws":"' + pg_cajaNombre + '","top":"863","afectaHD":true}';
    json = JSON.parse(json);
    AutenticacionHuella(json);
}

//se necesita definir esta función de esta manera para que la pagina pueda recibir el resultado de la autenticación
function RecibirResultadoHuella(resultado) {
    if (resultado.Status == 0) { //si hubo error
        DispararError(resultado.Descripcion, 'huella digital');
        return;
    }
    if (validarOperador) {
        if (!a_pideSoloUnaHuella) { //si se necesita autenticar a los dos empleados, abre la segunda autenticacion
            //ahora se obtienen a las personas que deben validar la operacion y se muestra en una ventana
            mostrarCarga(true);
            setTimeout(function () {
                let obj = ServObtenerValidadores(pg_empleadoID);
                if (obj.Estatus != 0) { //si hubo error
                    DispararError(obj.msjError, 'huella digital');
                    mostrarCarga(false);
                    return;
                }
                pg_empleadosVal = obj.EmpAutorizador;
                pg_empleadosValPerfs = obj.EmpPerfiles;
                mostrarCarga(false);
                AbrirHuellaValidar();
            }, 300);
            return; //sale, para no continuar a confirmación de arqueo
        } else //si solo se necesita un empleado, se le pasa a la variable quien autorizo el arqueo
            pg_empleadosVal = pg_empleadoID;
    } else {
        pg_empleadosVal = resultado.Autorizo; //se hizo bien las dos autenticaciones, pone quien autoriza el arqueo
        //pg_empleadosVal = pg_empleadoID; //TEST!!
        if (pg_tipoArqueo == 2) { //si es un arqueo de cierre, hay que checar que el que esté autenticando tenga un puesto base que corresponda a la autorizacion
            let obj = AServConsultaEmpleado(pg_empleadosVal);
            if (obj.NoError != 0) { //si hubo error en la consulta del empleado que valida
                DispararError('No se pudo consultar el puesto base del empleado que autorizó el arqueo de cierre.', 'autorización de arqueo');
                mostrarCarga(false);
                return;
            }
            //ahora se checa su puesto base y se compara contra los puestos que pueden autorizar (que se guardó previamente)
            if (!pg_empleadosValPerfs.includes(obj.InformacionInicial.PuestoBase.toString())) {
                DispararError('El empleado autorizador tiene el puesto base ' + obj.InformacionInicial.PuestoBase + ', el cual no puede autorizar un arqueo de cierre.', 'autorización de arqueo');
                mostrarCarga(false);
                return;
            }
        }
    }

    //confirma el arqueo si llega hasta aquí
    mostrarCarga(true);
    setTimeout(function () {
        var obj = ServConfirmacionArqueo();
        if (obj.NoError != 0) { //si hubo error
            DispararError(obj.Descripcion, 'confirmacion de arqueo');
            mostrarCarga(false);
            return;
        }
        mostrarCarga(false);
        if (obj.NoWarning == 1)
            DispararMensaje("<br>Aviso: Falló el Servicio de Camarografía. No es necesario contactar a Soporte Tecnico<br>" +
                obj.Descripcion +
                "<br><br>",
                botonImprimir);
        else
            botonImprimir();
        //DispararConfirmacion('<b>El arqueo ' + a_arqueoID + ' ha sido confirmado.</b><br>' + mensErrorRegistros + '¿Deseas imprimir un reporte?', botonImprimir, CerrarArqueo, "Sí", "No");
    }, 200);
}

//estos se van a quedar

function DispararError(mensaje, causa, refE) {
    refFuncError = (refE !== undefined) ? refE : null;
    if (refE !== undefined)
        $('#textoBotonError').html('Cerrar');
    else
        $('#textoBotonError').html('Continuar');
    $('#errorTitulo').html('Error de ' + causa + ':');
    $('#errorTexto').html(mensaje);
    $j('#modalError').modal({ escClose: false });
}

function DispararMensaje(mensaje, refM) {
    refFuncMensaje = (refM !== undefined) ? refM : null;
    $('#mensajeTitulo').html('Mensaje del sistema:');
    $('#mensajeTexto').html(mensaje);
    $j('#modalMensaje').modal({ escClose: false });
}

function DispararConfirmacion(mensaje, refA, refC, mensA, mensC) {
    refFuncAceptar = (refA !== undefined) ? refA : null;
    refFuncCancelar = (refC !== undefined) ? refC : null;
    if (mensA !== undefined)
        $('#mensA').html(mensA);
    if (mensC !== undefined)
        $('#mensC').html(mensC);
    $('#confTitulo').html('Mensaje del sistema:');
    $('#confTexto').html(mensaje);
    $j('#modalConfirmacion').modal({ escClose: false });
}

function botonDiagError() {
    if (refFuncError != null)
        refFuncError();
}

function botonDiagMensaje() {
    if (refFuncMensaje != null)
        refFuncMensaje();
}

function botonDiagAceptar() {
    if (refFuncAceptar != null)
        refFuncAceptar();
}

function botonDiagCancelar() {
    if (refFuncCancelar != null)
        refFuncCancelar();
}

function CerrarArqueo() {
    $j.modal.close();
    ocultarElementosPantalla();
    $('#modalFinalTexto').html("Operación finalizada.");
    $j('#modalFinal').modal({ escClose: false });
}

function botonRegistrar() {
    RegistrarArqueo();
}

function botonAutenticar() {
    setTimeout(function () { AbrirHuellaOperador(); }, 200);
}

var tempImpObj = null;
function botonImprimir() {
    mostrarCarga(true);
    setTimeout(function () {
        try {
            var obj = ServGeneraPDF(a_arqueoID);
            if (obj.NoError != 0) { //si hubo error
                mostrarCarga(false);
                DispararConfirmacion('<b>El arqueo ' + a_arqueoID + ' ha sido confirmado.</b><br> ¿El documento se imprimió correctamente?', CerrarArqueo, botonImprimir, "Sí", "No");
                return;
            }
            tempImpObj = obj;
            setTimeout(function () {
                //servicio configura impresion
                let obj = tempImpObj;
                let ruta = obj.Ruta;
                obj = ServImpresionArqueo(ruta);
                ServBorraPDF(ruta);
                DispararConfirmacion('<b>El arqueo ' + a_arqueoID + ' ha sido confirmado.</b><br> ¿El documento se imprimió correctamente?', CerrarArqueo, botonImprimir, "Sí", "No");
                mostrarCarga(false);
            }, 1000);
        } catch (err) {
            DispararError("Error de ejecución:<br>" + err, 'ejecución');
            mostrarCarga(false);
        }
    }, 200);
}

/////////////////////////////////////Funciones de utilidad///////////////////////////////////////

//para obtener un objeto de arqueo
function getObjArqueo(divisaID, simboloOBJ) {
    var objs = a_datosArqueo[divisaID].ObjetosArqueo;
    for (var i = 0; i < objs.length ; i++)
        if (objs[i].Simbolo == simboloOBJ)
            return objs[i];
    return null;
}

//para asignar un objeto de arqueo
function setObjArqueo(divisaID, simboloOBJ, objArqueo) {
    for (var i = 0; i < a_datosArqueo[divisaID].ObjetosArqueo.length ; i++) {
        if (a_datosArqueo[divisaID].ObjetosArqueo[i].Simbolo == simboloOBJ) {
            a_datosArqueo[divisaID].ObjetosArqueo[i] = objArqueo;
            return true;
        }
    }
    return false;
}

Number.prototype.formatMoney = function (c, d, t) {
    var n = this,
        c = isNaN(c = Math.abs(c)) ? 2 : c,
        d = d == undefined ? "." : d,
        t = t == undefined ? "," : t,
        s = n < 0 ? "-" : "",
        i = String(parseInt(n = Math.abs(Number(n) || 0).toFixed(c))),
        j = (j = i.length) > 3 ? j % 3 : 0;
    return s + (j ? i.substr(0, j) + t : "") + i.substr(j).replace(/(\d{3})(?=\d)/g, "$1" + t) + (c ? d + Math.abs(n - i).toFixed(c).slice(2) : "");
};

//imprimir un valor monetario con el formato correcto, dependiendo de la divias
function formatoDinero(numero, divisaID) {
    numero = Number(numero);
    return (divisaID == "3") ? a_datosArqueo[divisaID].Simbolo + ' ' + numero : a_datosArqueo[divisaID].Simbolo + (numero).formatMoney(2);
}

function isNumberKey(evt) {
    var charCode = (evt.which) ? evt.which : evt.keyCode
    if (charCode > 31 && (charCode < 48 || charCode > 57))
        return false;
    return true;
}

function isNumberDecimalKey(evt) {
    var charCode = (evt.which) ? evt.which : evt.keyCode
    if (charCode > 31 && (charCode < 48 || charCode > 57) && charCode != 46)
        return false;
    return true;
}

function toFixedJ(num, fixed) {
    var re = new RegExp('^-?\\d+(?:\.\\d{0,' + (fixed || -1) + '})?');
    return num.toString().match(re)[0];
}

function pad(number, length) {
    var str = '' + number;
    while (str.length < length)
        str = '0' + str;
    return str;
}

/////////////////////////////////////Servicios////////////////////////////////////////////////

function getUrlArqueo(servicio) {
    var url = "";
    if (window.location.hostname == "localhost") {
        url = "http://" + ServidorPrueba + ":" + PuertoPrueba + "/Caja/Servicios/" + servicio;
    } else {
        url = "http://" + window.location.hostname + ":9014/Caja/Servicios/" + servicio;
    }
    return url;
}

function ConsumirServicio(url, objEntrada, nombreError, nombreDescripcion) {

    if (objEntrada == undefined)
        objEntrada = {}
    if (nombreError == undefined)
        nombreError = 'NoError'
    if (nombreDescripcion == undefined)
        nombreDescripcion = 'Descripcion'
    //alert(JSON.stringify(objEntrada))
    var objRespuesta = {}
    Object.defineProperty(objRespuesta, nombreError, { enumerable: true, configurable: true, writable: true, value: null });
    Object.defineProperty(objRespuesta, nombreDescripcion, { enumerable: true, configurable: true, writable: true, value: null });

    $.ajax({
        url: "" + url,
        contentType: "application/json; charset=UTF-8",
        type: "POST",
        async: false,
        data: JSON.stringify(objEntrada),
        dataType: 'json',
        crossDomain: true,
        success: function (data) {
            objRespuesta = data;
        },
        error: function () {
            objRespuesta[nombreError] = 2;
            objRespuesta[nombreDescripcion] = "No se pudo contactar al servicio o hubo error en el request.";
        }
    });
    //alert(JSON.stringify(objRespuesta))
    return objRespuesta;
}

function AServValidaAcceso(terminal) {
    return ConsumirServicio(getUrlArqueo(AUrlValidaAcceso), {
        "Terminal": "" + terminal
    });
}

function AServConsultaEmpleado(empleado) {
    return ConsumirServicio(getUrlArqueo(AUrlValidaEmpleado), {
        "NoEmpleado": "" + empleado
    });
}

function ServConsultaDivisa() {
    return ConsumirServicio(getUrlArqueo(AUrlDivisas));
}

function ServObjetosArqueo(divisa) {
    return ConsumirServicio(getUrlArqueo(AUrlObjArquear), {
        "Divisa": "" + divisa
    });
}

function ServDenominaciones(divisa) {
    return ConsumirServicio(getUrlArqueo(AUrlDenominaciones), {
        "Divisa": "" + divisa
    });
}

function ServDocumentos(divisa) {
    return ConsumirServicio(getUrlArqueo(AUrlDocsArqueo), {
        "Divisa": "" + divisa
    });
}

function ServRegistroArqueo(objRegistro) {
    return ConsumirServicio(getUrlArqueo(AUrlRegistraArqueo), objRegistro);
}

function ServObtenerValidadores(empleado) {
    return ConsumirServicio(getUrlArqueo(AUrlObtieneValidadores), {
        "opc": 1,
        "IdModulo": "27",
        "IdFolio": "3",
        "Empleado": "" + empleado
    });
}

function ServConfirmacionArqueo() {
    return ConsumirServicio(getUrlArqueo(AUrlConfirmaArqueo), {
        "EmpleadoLogueado": pg_empleadoID,
        "EmpleadoValida": pg_empleadosVal,
        "IdentificadorArqueo": a_arqueoID,
        "Terminal": pg_cajaNombre,
        "TipoArqueo": Number(pg_tipoArqueo)
    });
}

function ServGeneraPDF(a_arqueoID) {
    return ConsumirServicio(getUrlArqueo(AUrlGeneraPDF), {
        "IdArqueo": a_arqueoID,
        "Ws": pg_cajaNombre,
        "Reimpresion": false
    });
}

function ServImpresionArqueo(ruta) {
    return ConsumirServicio(AHostImpresion + AUrlImprimeArqueo, {
        "Ruta": ruta
    }, "EstatusExito", "Detalle");
}

function ServBorraPDF(ruta) {
    ConsumirServicio(getUrlArqueo(AUrlBorraPDF), {
        "Ruta": ruta
    });
}