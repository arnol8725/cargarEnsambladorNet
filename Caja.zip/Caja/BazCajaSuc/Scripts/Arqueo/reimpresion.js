﻿if ($j === undefined) { var $j = jQuery.noConflict(true); console.log($().jquery); console.log($j().jquery); }

const AUrlValidaAcceso = "Arqueo/WsCajaArqueo.svc/wsValidaAccesoArqueo"; //
const AUrlValidaEmpleado = "Comun/WsCajaComun.svc/wsConsultaInformacionInicial";
const AUrlDivisas = "Comun/WsCajaComun.svc/wsconsultaDivisa"; //
const AUrlConsultaReimpresion = "Arqueo/WsCajaArqueo.svc/wsConsultaReimpresionArqueo"; //
const AUrlDetalleReimpresion = "Arqueo/WsCajaArqueo.svc/wsConsultaDetalleReimpresion"; //
const AUrlGeneraPDF = "Arqueo/WsCajaArqueo.svc/wsGeneraDocumentoImpresion";
const AUrlBorraPDF = "Arqueo/WsCajaArqueo.svc/wsEliminaDocumentoImpresion";

//const AUrlValidaAcceso = "http://localhost:41029/WsCajaArqueo.svc/wsValidaAccesoArqueo"; //
//const AUrlValidaEmpleado = "http://localhost:41029/WsCajaComun.svc/wsConsultaInformacionInicial"; //
//const AUrlDivisas = "http://localhost:41029/WsCajaComun.svc/wsconsultaDivisa"; //
//const AUrlObjArquear = "http://localhost:41029/WsCajaArqueo.svc/wsConsultaObjetosArqueo"; //
//const AUrlDocsArqueo = "http://localhost:41029/WsCajaArqueo.svc/wsConsultaDocumentosArqueo"; //
//const AUrlDenominaciones = "http://localhost:41029/WsCajaArqueo.svc/wsConsultaDenominacion"; //
//const AUrlRegistraArqueo = "http://localhost:41029/WsCajaArqueo.svc/wsRegistraArqueo"; //
//const AUrlObtieneValidadores = "http://localhost:41029/wsUtileria.svc/wsPerfilAutorizador"; //
//const AUrlConfirmaArqueo = "http://localhost:41029/WsCajaArqueo.svc/wsConfirmaArqueo";
//const AUrlGeneraPDF = "http://localhost:15579/WsCajaArqueo.svc/wsGeneraDocumentoImpresion";
//const AUrlBorraPDF = "http://localhost:15579/WsCajaArqueo.svc/wsEliminaDocumentoImpresion";


const ServidorPrueba = "10.54.28.222";
const PuertoPrueba = "9014";
const AHostImpresion = "http://localhost:9001/";
const AUrlImprimeArqueo = "WSDesTecAppsLocal/ImprimirDocumentoPDFCarta";

var pg_empleadoID = null;
var pg_cajaNombre = null;

var a_arqueoID = null;
var a_arqueoStatus = null;
var a_fechaAnterior = null;
var a_diasImpresion = 30;
var a_permitirImpresion = true;
var a_divisas = null;

var refFuncError = null;
var refFuncMensaje = null;
var refFuncAceptar = null;
var refFuncCancelar = null;

var refArqCont = null;
var tiempoRestante = null;
var pantallaCargada = false;

//instrucciones para que el seleccionador de fechas funcione correctamente
$j.datepicker.regional['es'] = {
    closeText: 'Cerrar',
    prevText: '',
    nextText: ' ',
    currentText: 'Hoy',
    monthNames: ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'],
    monthNamesShort: ['Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun', 'Jul', 'Ago', 'Sep', 'Oct', 'Nov', 'Dic'],
    dayNames: ['Domingo', 'Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado'],
    dayNamesShort: ['Dom', 'Lun', 'Mar', 'Mié', 'Juv', 'Vie', 'Sáb'],
    dayNamesMin: ['Do', 'Lu', 'Ma', 'Mi', 'Ju', 'Vi', 'Sá'],
    weekHeader: 'Sm',
    dateFormat: 'dd/mm/yy',
    firstDay: 1,
    isRTL: false,
    showMonthAfterYear: false,
    yearSuffix: ''
};
$j.datepicker.setDefaults($j.datepicker.regional['es']);
$j(function () {
    $j("#datepicker").datepicker({
        firstDay: 1
    });
});
$j("#datepicker").on('click', function () {
    //guarda la fecha que está seleccionada actualmente
    a_fechaAnterior = this.value;
});

var t_haSeleccionado = false;
$j("#datepicker").datepicker({
    onSelect: function () {
        //usa una expresion regular para confirmar que la fecha tenga el formato indicado
        if (/^(0?[1-9]|[12][0-9]|3[01])[\/\-](0?[1-9]|1[012])[\/\-]\d{4}$/.test(this.value)) {
            //que no haga nada si se selecciona la misma fecha que la que estaba antes
            if (a_fechaAnterior == this.value)
                return;

            //al seleccionar la fecha, determinamos si se va a dejar realizar la impresión o no
            let fechaLimite = new Date();
            fechaLimite.setDate(fechaLimite.getDate() - a_diasImpresion);
            fechaLimite.setHours(0);
            fechaLimite.setMinutes(0);
            fechaLimite.setSeconds(0);
            fechaLimite.setMilliseconds(0);
            let arrFecha = this.value.split('/');
            let fechaSeleccionada = new Date(arrFecha[2], (arrFecha[1] - 1), arrFecha[0]);
            a_permitirImpresion = fechaSeleccionada >= fechaLimite;

            //llamar al servicio para llamar la tabla si llega hasta acá
            LlenarTablaArqueos(fechaFormato(arrFecha[2], arrFecha[1], arrFecha[0]), true);
        } else {
            DispararMensaje('La fecha insertada no tiene un formato válido');
            $j("#datepicker").val(a_fechaAnterior);
        }
        t_haSeleccionado = true;
    },
    onClose: function () {
        if (!t_haSeleccionado)
            $j("#datepicker").val(a_fechaAnterior);
        t_haSeleccionado = false;
    }
});

//cuando la pagina cargue completamente, cargará estas instrucciones
$(document).ready(function () {

    let date = new Date();
    $('#tagHora').html(pad(date.getHours(),2) + ":" + pad(date.getMinutes(),2));
    $('#tagFecha').html(date.getDate() + "/" + (date.getMonth() + 1) + "/" + date.getFullYear());

    pg_empleadoID = getUrlVars()["empleado"];
    pg_cajaNombre = getUrlVars()["ws"];
    if (pg_empleadoID === undefined || pg_empleadoID == "" ||
        pg_cajaNombre === undefined || pg_cajaNombre == "") {
        DispararError("Los parámetros no son correctos.", 'parámetros de URL', CerrarArqueo);
        return;
    }
    pg_empleadoID = pg_empleadoID.toString().replace('#', '');
    pg_cajaNombre = pg_cajaNombre.toString().replace('#', '');
    mostrarCarga(true);
    setTimeout(function () {
        let obj = AServValidaAcceso(pg_cajaNombre);
        if (obj.NoError != 0) {
            DispararError(obj.Descripcion, 'consulta de estación de trabajo',CerrarArqueo);
            mostrarCarga(false);
            return;
        } else if (!obj.Acceso) {
            DispararError(obj.Descripcion, 'consulta de estación de trabajo',CerrarArqueo);
            mostrarCarga(false);
            return;
        }
        //empieza a cargar los servicios de empleado y de acceso de estación
        obj = AServConsultaEmpleado(pg_empleadoID);
        if (obj.NoError != 0) {
            DispararError(obj.Descripcion, 'consulta de empleado',CerrarArqueo);
            mostrarCarga(false);
            return;
        }
        $('#tagEstacion').html(pg_cajaNombre + " -");
        $('#tagEmpNombre').html(obj.InformacionInicial.NombreEmpleado);
        $('#tagEmpDescripcion').html(obj.InformacionInicial.DescripcionPBase);
        $('#tagNumTienda').html(obj.InformacionInicial.NoTienda);
        $('#tagNombreTienda').html(obj.InformacionInicial.NombreTienda);
        $('#tagPais').html(obj.InformacionInicial.DescripcionPais);

        //Traer informacion de divisas y estructurarla para usarla
        obj = ServConsultaDivisa();
        if (obj.NoError != 0) {
            DispararError(obj.Descripcion, 'consulta de divisas',CerrarArqueo);
            mostrarCarga(false);
            return;
        }
        let divisas = obj.Divisas;
        a_divisas = {};
        //al acceder a los datos de una divisa, de debe usar un indice que sea STRING, no que sea numerico
        for (var i = 0 ; i < divisas.length ; i++) {
            //definir el objeto de divisas con indices que correspondan a su ID del servicio, no a su indice del arreglo
            Object.defineProperty(a_divisas, divisas[i].Id.toString(), { enumerable: true, configurable: true, writable: true, value: divisas[i] });
        }

        let diahoy = new Date();
        $j("#datepicker").val( pad(diahoy.getDate(),2) + '/' + pad((diahoy.getMonth() + 1),2) + '/' + diahoy.getFullYear());
        LlenarTablaArqueos(fechaFormato(diahoy.getFullYear(), diahoy.getMonth() + 1, diahoy.getDate()), true);
        mostrarCarga(false);
    }, 250);
});

/////////////////////////Funciones para rellenar las tablas//////////////////////////////////////////

//recibe la fecha con el formato para mandarlo al web service
function LlenarTablaArqueos(fecha, asignareventos) {
    //resetear valores
    a_arqueoID = null;
    a_arqueoStatus = null;
    let obj = ServConsultaReimpresion(fecha);
    if (obj.NoError == 0) { //llena la tabla con la información correspondiente
        let conj = obj.CabeceroReimpresion;
        let tabla = "<tbody><tr><th>ID Arqueo</th><th>Fecha / Hora</th><th>Empleado</th><th>Estatus del arqueo</th></tr>";
        for (let i in conj) {
            tabla += '<tr id="tag_' + conj[i].Identificador + '" class="">';
            tabla += '<td><img src="../../Imgs/Arqueo/' + (conj[i].IdStatus == 0 ? 'roja' : 'verde') + '.png">' + conj[i].Identificador + '</td>';
            tabla += "<td>" + conj[i].Fecha + "</td>";
            tabla += "<td>" + conj[i].Nombre + "</td>";
            tabla += "<td>" + conj[i].Status + "</td>";
            tabla += '<input type="hidden" id="in_' + conj[i].Identificador + '" value="' + (conj[i].IdStatus == 0 ? '0' : '1') + '">'
            tabla += "</tr>";
        }
        tabla += "</tbody>";
        $('#tablaArqueos').html(tabla);
        for (let i in conj) {
            $('#tag_' + conj[i].Identificador).unbind('click');
            if (asignareventos) {
                $('#tag_' + conj[i].Identificador).on('click', function (event) {
                    $("#tag_" + a_arqueoID).removeClass("act");
                    $("#" + $(this).attr("id")).addClass("act");
                    let valor = $(this).attr("id");
                    valor = valor.replace("tag_", "");
                    a_arqueoID = valor;
                    a_arqueoStatus = $("#in_" + a_arqueoID).val();
                });
            }
        }
    } else {
        DispararMensaje("No hay arqueos registrados en esta fecha.");
        let tabla = "<tbody><tr><th>ID Arqueo</th><th>Fecha / Hora</th><th>Empleado</th><th>Estatus del arqueo</th></tr></tbody>";
        $('#tablaArqueos').html(tabla);
    }
}

function LlenarTablaDetalle(arID) {
    
    var obj = ServDetalleReimpresion(arID);
    if (obj.NoError != 0) {
        DispararError(obj.Descripcion,'consulta de reimpresión');
        return;
    }
    $('#detalle').html(arID);
    var conj = obj.DetalleReimpresion;
    var tabla = "<tbody><tr><th>Tipo Pago</th><th>Tipo Divisa</th><th>Resultado</th><th>Diferencia</th><th>Documentos</th></tr>";
    for (let i in conj) {
        tabla += '<tr>';
        tabla += '<td><img src="../../Imgs/Arqueo/' + (conj[i].Estatus == 2 ? 'roja' : 'verde') + '.png">' + conj[i].Objeto + '</td>';
        tabla += "<td>" + conj[i].DescripcionDivisa + "</td>";
        tabla += "<td>" + conj[i].Resultado + "</td>";
        tabla += "<td>" + formatoDinero(conj[i].Diferencia, conj[i].TipoDivisa.toString()) + "</td>";
        tabla += "<td>" + conj[i].Documentos + "</td>";
        tabla += "</tr>";
    }
    tabla += "</tbody>";
    $('#tablaDetalle').html(tabla);
    $j('#modal01').modal({ escClose: false });
}

/////////////////////////////////////Funciones para la ventana y la pagina////////////////////

function DispararError(mensaje, causa, refE) {
    refFuncError = (refE !== undefined) ? refE : null;
    if (refE !== undefined)
        $('#textoBotonError').html('Cerrar');
    else
        $('#textoBotonError').html('Continuar');
    $('#errorTitulo').html('Error de ' + causa + ':');
    $('#errorTexto').html(mensaje);
    $j('#modalError').modal({ escClose: false });
}

function DispararMensaje(mensaje, refM) {
    refFuncMensaje = (refM !== undefined) ? refM : null;
    $('#mensajeTitulo').html('Mensaje del sistema:');
    $('#mensajeTexto').html(mensaje);
    $j('#modalMensaje').modal({ escClose: false });
}

function DispararConfirmacion(mensaje, refA, refC, mensA, mensC) {
    refFuncAceptar = (refA !== undefined) ? refA : null;
    refFuncCancelar = (refC !== undefined) ? refC : null;
    if (mensA !== undefined)
        $('#mensA').html(mensA);
    if (mensC !== undefined)
        $('#mensC').html(mensC);
    $('#confTitulo').html('Mensaje del sistema:');
    $('#confTexto').html(mensaje);
    $j('#modalConfirmacion').modal({ escClose: false });
}

function botonDiagError() {
    if (refFuncError != null)
        refFuncError();
}

function botonDiagMensaje() {
    if (refFuncMensaje != null)
        refFuncMensaje();
}

function botonDiagAceptar() {
    if (refFuncAceptar != null)
        refFuncAceptar();
}

function botonDiagCancelar() {
    if (refFuncCancelar != null)
        refFuncCancelar();
}

function CerrarArqueo() {
    $j.modal.close();
    ocultarElementosPantalla();
    $('#modalFinalTexto').html("Operación finalizada.");
    $j('#modalFinal').modal({ escClose: false });
}

function BotonConsultar() {
    if (a_arqueoID == null){
        DispararMensaje("No se seleccionó un ID de arqueo.");
    } else if (!a_permitirImpresion) {
        DispararMensaje("No se permite reimprimir un arqueo que tenga más de " + a_diasImpresion + " días de antigüedad.");
    } else if (a_arqueoStatus == '1') { //arqueo cuadrado
        DispararConfirmacion('¿Imprimir el arqueo con el ID ' + a_arqueoID + '?', BotonImprimir, null, 'Imprimir', 'Cancelar');
    } else { //arqueo con diferencias
        let obj = ServDetalleReimpresion(a_arqueoID);
        if (obj.NoError != 0) {
            DispararError(obj.Descripcion,'consulta de reimpresión');
            return;
        }
        LlenarTablaDetalle(a_arqueoID);
    }
}
var tempImpObj = null;
function BotonImprimir() {
    mostrarCarga(true);
    setTimeout(function () {
        try {
            let obj = ServGeneraPDF(a_arqueoID);
            if (obj.NoError != 0) { //si hubo error
                mostrarCarga(false);
                DispararConfirmacion('¿El documento se imprimió correctamente?', null, BotonImprimir, 'Sí', 'No');
                return;
            }
            tempImpObj = obj;
            setTimeout(function () {
                //servicio configura impresion
                let obj = tempImpObj;
                let ruta = obj.Ruta;
                obj = ServImpresionArqueo(ruta);
                ServBorraPDF(ruta);
                DispararConfirmacion('¿El documento se imprimió correctamente?', null, BotonImprimir, 'Sí', 'No');
                mostrarCarga(false);
            }, 1000);
        } catch (err) {
            DispararError("Error de ejecución:<br>" + err,'ejecución');
            mostrarCarga(false);
        }
    }, 200);
}

/////////////////////////////////////Funciones de utilidad///////////////////////////////////////

function fechaFormato(a,m,d) {
    return a + "/" + m + "/" + d;
}

function pad(number, length) {
    var str = '' + number;
    while (str.length < length)
        str = '0' + str;
    return str;
}

Number.prototype.formatMoney = function (c, d, t) {
    var n = this,
        c = isNaN(c = Math.abs(c)) ? 2 : c,
        d = d == undefined ? "." : d,
        t = t == undefined ? "," : t,
        s = n < 0 ? "-" : "",
        i = String(parseInt(n = Math.abs(Number(n) || 0).toFixed(c))),
        j = (j = i.length) > 3 ? j % 3 : 0;
    return s + (j ? i.substr(0, j) + t : "") + i.substr(j).replace(/(\d{3})(?=\d)/g, "$1" + t) + (c ? d + Math.abs(n - i).toFixed(c).slice(2) : "");
};

//imprimir un valor monetario con el formato correcto, dependiendo de la divias
function formatoDinero(numero, divisaID) {
    numero = Number(numero);
    return (divisaID == "3") ? a_divisas[divisaID].Simbolo + ' ' + numero : a_divisas[divisaID].Simbolo + (numero).formatMoney(2);
}

/////////////////////////////////////Servicios////////////////////////////////////////////////

function getUrlArqueo(servicio) {
    var url = "";
    if (window.location.hostname == "localhost") {
        url = "http://" + ServidorPrueba + ":" + PuertoPrueba + "/Caja/Servicios/" + servicio;
    } else {
        url = "http://" + window.location.hostname + ":9014/Caja/Servicios/" + servicio;
    }
    return url;
}

function ConsumirServicio(url, objEntrada, nombreError, nombreDescripcion) {

    if (objEntrada == undefined)
        objEntrada = {}
    if (nombreError == undefined)
        nombreError = 'NoError'
    if (nombreDescripcion == undefined)
        nombreDescripcion = 'Descripcion'

    var objRespuesta = {}
    Object.defineProperty(objRespuesta, nombreError, { enumerable: true, configurable: true, writable: true, value: null });
    Object.defineProperty(objRespuesta, nombreDescripcion, { enumerable: true, configurable: true, writable: true, value: null });
    $.ajax({
        url: "" + url,
        contentType: "application/json; charset=UTF-8",
        type: "POST",
        async: false,
        data: JSON.stringify(objEntrada),
        dataType: 'json',
        crossDomain: true,
        success: function (data) {
            objRespuesta = data;
        },
        error: function () {
            objRespuesta[nombreError] = 2;
            objRespuesta[nombreDescripcion] = "No se pudo contactar al servicio o hubo error en la peticion.";
        }
    });
    return objRespuesta;
}

function AServValidaAcceso(terminal) {
    return ConsumirServicio(getUrlArqueo(AUrlValidaAcceso), {
        "Terminal": "" + terminal
    });
}

function AServConsultaEmpleado(empleado) {
    return ConsumirServicio(getUrlArqueo(AUrlValidaEmpleado), {
        "NoEmpleado": "" + empleado
    });
}

function ServConsultaDivisa() {
    return ConsumirServicio(getUrlArqueo(AUrlDivisas));
}

function ServConsultaReimpresion(fecha) {
    return ConsumirServicio(getUrlArqueo(AUrlConsultaReimpresion), {
        "Fecha": fecha
    });
}

function ServDetalleReimpresion(id) {
    return ConsumirServicio(getUrlArqueo(AUrlDetalleReimpresion), {
        "IdArqueo": id
    });
}

function ServGeneraPDF(a_arqueoID) {
    return ConsumirServicio(getUrlArqueo(AUrlGeneraPDF), {
        "IdArqueo": a_arqueoID,
        "Ws": pg_cajaNombre,
        "Reimpresion": true
    });
}

function ServImpresionArqueo(ruta) {
    return ConsumirServicio(AHostImpresion + AUrlImprimeArqueo, {
        "Ruta": ruta
    }, "EstatusExito", "Detalle");
}

function ServBorraPDF(ruta) {
    ConsumirServicio(getUrlArqueo(AUrlBorraPDF), {
        "Ruta": ruta
    });
}