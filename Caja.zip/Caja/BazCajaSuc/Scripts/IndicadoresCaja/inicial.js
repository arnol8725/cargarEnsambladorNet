﻿
var usuario;
var pass;
$(document).ready(function () {
    usuario = getParametros()["usuario"];
    pass = getParametros()["pass"];
    if (usuario === undefined || pass === undefined) {
        mandaError("escriba una url valida");
    } else {
        getDateSystem();
    }
    
})
function getDateSystem() {
    var date = new Date();
    var mes = date.getMonth() + 1;
    var dia = date.getDate();
    var anio = date.getFullYear();

    if (dia < 10) {
        //var fechaSis = "0" + dia + "/" + mes + "/" + anio;
        dia = "0" + date.getDate();

    }
    if (mes < 10) {
        //var fechaSis = dia + "/0" + mes + "/" + anio;
        mes = '' + date.getMonth() + 1

    }
    else {
        var fechaSis = dia + "/" + mes + "/" + anio;
    }
    var fechaSis = dia + "/" + mes + "/" + anio
    $("#fechaSist").text(fechaSis);

    $('#datepicker').val(fechaSis);
    //$('#datepicker1').html(fechaSis);
    //$('#datepicker2').html(fechaSis);
    //$('#finaldatepicker3').html(fechaSis);
}
function mandaError(mensaje) {
    //limpiarcontenedor();
    //limpiarcontenedor2();
    $('#mensajeTitulo').html('Mensaje del sistema:');
    $('#mensajeTexto').html(mensaje);
    $('#modal05').modal();
}

//function fechaI(fecha) {
//    //var fecha = document.getElementById('fecha1').value;
//    if (fecha === "") {
//        alert("SELECCIONE UNA FECHA");
//    }
//    else {
//        var fecha2 = fecha.split("/");
//        var FechaOriginal = "";
//        for (var i = fecha2.length; i > 0; i--) {
//            FechaOriginal += fecha2[i - 1];

//        }
//        return FechaOriginal;
//    }
//}

function EnviaError2(mensaje) {
    $('#mensajeTitulo').html('Mensaje del sistema:');
    $('#mensajeTexto').html(mensaje);
    $('#modal05').modal();
}
//function getDateSystem() {
//        var date = new Date();
//        var mes = date.getMonth() + 1;
//        var dia = date.getDate();
//        var anio = date.getFullYear();
//        var fechaSis = dia + "/" + mes + "/" + anio;
//        $('#datepicker').html(fechaSis);
//        $('#inicio').html(fechaSis);
//        $('#final').html(fechaSis);
//    }

function fechaI(fecha) {
    var fecha = document.getElementById('fecha1').value;
    if (fecha === "") {
        alert("SELECCIONE UNA FECHA");
    }
    else {
        var fecha2 = fecha.split("/");
        var FechaOriginal = "";
        for (var i = fecha2.length; i > 0; i--) {
            FechaOriginal += fecha2[i - 1];

        }
        return FechaOriginal;
    }
}
function getParametros() {
    var vars = [], hash;
    var hashes = window.location.href.slice(window.location.href.indexOf('?') + 1).split('&');
    for (var i = 0; i < hashes.length; i++) {
        hash = hashes[i].split('=');
        vars.push(hash[0]);
        vars[hash[0]] = hash[1];
    }
    return vars;
}
function getUrlBase() {

    arrurl = window.location.href.split("/");
    var url = "";
    for (var i = 0 ; i < (arrurl.length - 1) ; i++) {
        if (arrurl[i] == "Fronts")
            break;
        url += arrurl[i] + "/";
    }
    return url;
}