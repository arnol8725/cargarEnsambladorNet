﻿var urlDiferencias='IndicadoresCaja/IndicadoresCaja.svc/wsICFaltSdos';
var urlArqueos = 'IndicadoresCaja/IndicadoresCaja.svc/wsICIndicadoresArq';
var urlDotaciones = 'IndicadoresCaja/IndicadoresCaja.svc/wsICAcumDotRec';
var pantallaCargada = false;
$(document).ready(function () {
    getDateSystem();
    caraFunciones();
})
var cerrarFrame = function () {
    $('IdicadorFrame').remove();
}
function getUrls(serv) {
    var url = "";
    if (window.location.hostname == "localhost") {
        url = "http://10.54.28.105:9014/Caja/Servicios/" + serv;
    } else {
        url = "http://" + window.location.hostname + ":9014/Caja/Servicios/" + serv;
    }
    return url;
}


function fechaI(num) {
    var fecha;
    if (num===1) {
       fecha = document.getElementById('datepicker1').value;
    }
    else if (num===2) {
        fecha = document.getElementById('datepicker2').value;
    }
    
    if (fecha === "") {
        MensajeError("NO SELECCIONO NINGUNA FECHA");       
    }
    else {
        var fecha2 = fecha.split("/");
        var FechaOriginal = "";
        for (var i = fecha2.length; i > 0; i--) {
            FechaOriginal += fecha2[i - 1];
        }
        return FechaOriginal;
    }
}
function fechaF() {
   
    var fechaFin = document.getElementById('datepicker3').value;
    if (fechaFin === "") {
        MensajeError("NO SELECCIONO NINGUNA FECHA");
    }
    else {        
        var fechafin2 = fechaFin.split("/");        
        var fechaFinal1 = "";
        for (var i = fechafin2.length; i > 0; i--) {
            fechaFinal1 += fechafin2[i - 1];
        }
        return fechaFinal1;
    }
}
function caraFunciones() {
    var num=1;
    var fechaInicial = fechaI(num);
    difCajeros(fechaInicial);
    SaldoCajeros(fechaInicial);
    ArqueosDiferencias(fechaInicial);
    DotacionesEfectivo(fechaInicial);
    ConcentracionesCaja(fechaInicial);
}
function caraFunciones2() {
    var num = 2;
    var fechaInicial = fechaI(num);
    var fechaFinal = fechaF();
    difCajerosAcum(fechaInicial, fechaFinal);
    SaldoCajerosAcum(fechaInicial, fechaFinal);
    ArqueosDiferenciasAcum(fechaInicial, fechaFinal);
    DotacionesEfectivoAcum(fechaInicial, fechaFinal);
    ConcentracionesCajaAcum(fechaInicial, fechaFinal);
}

function MensajeError(mensaje) {
    limpiarcontenedor();
    limpiarcontenedor2();
    $('#mensajeTitulo').html('Mensaje del sistema:');
    $('#mensajeTexto').html(mensaje);
    $('#modal04').modal();
}
function ventanas() {

    $('#modal05').modal();
}
function cerrar1() {
    //var iframe = document.getElementById('#principal');
    $('#principal').html("");
}

function limpiarcontenedor() {
    //ConcentCaja, DotEfectivo, DifArqueo, SaldosCajeros, DifCajero
    $('#DifCajero').html("");
    $('#SaldosCajeros').html("");
    $('#tabArqueo').html("");
    $('#DotacionesEfec').html("");
    $('#concCajaGral').html("");
    

}

function limpiarcontenedor2() {
    //ConcentCaja, DotEfectivo, DifArqueo, SaldosCajeros, DifCajero
    $('#DCA').html("");
    $('#sca').html("");
    $('#ada').html("");
    $('#cda1').html("");
    $('#ccg').html("");
}
function getDateSystem() {
    var date = new Date();
    var mes = date.getMonth() + 1;
    var dia = date.getDate();
    var anio = date.getFullYear();
    if (dia < 10) {
        dia = "0" + date.getDate();

    }
    if (mes < 10) {

        mes = '' + date.getMonth() + 1

    }
    else {
        var fechaSis = dia + "/" + mes + "/" + anio;
    }
    var fechaSis = dia + "/" + mes + "/" + anio;

    $('#datepicker1').val(fechaSis);
    $('#datepicker2').val(fechaSis);
    $('#datepicker3').val(fechaSis);
}

//diferencias cajeros
function difCajeros(fechaInic) {
    mostrarCarga(true);
    var numero = 1;
    var urlDif = getUrls(urlDiferencias);
    $.ajax({
        url: ""+urlDif, //opcion a cambios en la url 
        contentType: "application/json; charset=UTF-8",
        type: "POST",
        data: JSON.stringify(
            {
                "FechaFin": "" + fechaInic,
                "FechaInicio": "" + fechaInic,
                "Modulo": numero

            }
),
        dataType: 'json',
        crossDomain: true,
        success: function (data) {
            mostrarCarga(false);
            consumeDiferenciasCajeros(data);
        },
        error: function () {
            // alert(data);
            mostrarCarga(false);
            MensajeError("error en el consumo del servicio");
            
        }
    });
}
function consumeDiferenciasCajeros(jsonResp) {
    var suma = 0;
    if (jsonResp.NoError == 0) {
        consumeDiferencias(jsonResp);
    }
    else if (jsonResp.NoError == 1) {
        document.getElementById("DifCajero").html = jsonResp.Descripcion;
    } else if (jsonResp.Respuesta == 3) {
        document.getElementById("DifCajero").innerHTML = jsonResp.Descripcion;
    } else {
        document.getElementById("DifCajero").innerHTML = "Intente mas tarde.";
    }
}
function consumeDiferencias(data) {
    //aqui va la forma de llenar el primer cajon de informacion diferencias cajeros
    var arr = ['Sob', 'Fal'];
    var dat = data.Respuesta;
    var j = 0;

    var tablaDif ='<table class="tblGeneral ">' +
					  '<tbody>' +
					  	'<tr class="sinBg">' +
						  '<td colspan="6" >Diferencias en cajeros</td>' +
						'</tr>' +
					  	'<tr class="sinBg">' +
						  '<td colspan="2">&nbsp;</td>' +
						  '<td colspan="2"><strong>Al cierre</strong></td>' +
						 '<td colspan="2"><strong>Actual</strong></td>' +
						'</tr>' +
						'<tr>' +
					  		'<th>&nbsp;</th>' +
					  		'<th>&nbsp;</th>' +
						  	'<th>Ope</th>' +
						  	'<th>Importe</th>' +
						  	'<th>Ope</th>' +
						  	'<th>Importe</th>' +
						'</tr>';

    $.each(dat, function (i, p) {
        if (j == 0) { j = 1; }
        else if (j == 1) {j = 0;}
        tablaDif += '<tr>'+
                '<td>' + p.FcDivisa + '</td>' +
                '<td>' + arr[j] + '</td>' +
                '<td>' + p.FiCierre_1 + '</td>';
        if (p.FcDivisa == "OLP") {
            tablaDif += '<td>OLP ' + p.FiCierre_2 + '</td>';
        } else {
            if (p.FcDivisa == "EUR") {
                if (parseFloat(p.FiCierre_2) <= 0) {
                    tablaDif += '<td>€' + $.number(p.FiCierre_2, 2) + '</td>';
                } else {
                    tablaDif += '<td><a href="#" onclick="ventanas()">€' + $.number(p.FiCierre_2, 2) + '</a></td>';
                }
            } else {
                if (parseFloat(p.FiCierre_2) <= 0) {
                    tablaDif += '<td>$' + $.number(p.FiCierre_2, 2) + '</td>';
                } else {
                    tablaDif += '<td><a href="#">$' + $.number(p.FiCierre_2, 2) + '</a></td>';
                }
            }
        }

        tablaDif += '<td>' + p.FiActual_1 + '</td>';
        if (p.FcDivisa == "OLP") {
            tablaDif += '<td>OLP ' + p.FiActual_2 + '</td>';
        } else {
            if (p.FcDivisa == "EUR") {
                if (parseFloat(p.FiActual_2) <= 0) {
                    tablaDif += '<td>€' + $.number(p.FiActual_2, 2) + '</td></tr>';
                } else {
                    tablaDif += '<td><a href="#" onclick="ventanas()">€' + $.number(p.FiActual_2, 2) + '</a></td></tr>';
                }
            } else {
                if (parseFloat(p.FiActual_2) <= 0) {
                    tablaDif += '<td>$' + $.number(p.FiActual_2, 2) + '</td></tr>';
                } else {
                    tablaDif += '<td><a href="#" onclick="ventanas()">$' + $.number(p.FiActual_2, 2) + '</a></td></tr>';
                }
            }
        }
    });
    tablaDif += '</tbody></table>';
    $('#DifCajero').html(tablaDif);

}
//saldos cajeros
function SaldoCajeros(fechaInic) {
    var numero = 2;
    var url = getUrls(urlDiferencias);
    $.ajax({
        url: ""+url, //opcion a cambios en la url 
        contentType: "application/json; charset=UTF-8",
        type: "POST",
        data: JSON.stringify(
            {
                "FechaFin": ""+fechaInic,
                "FechaInicio": ""+fechaInic,
                "Modulo": numero
                //"FechaFin": "20030803",
                //"FechaInicio": "20030803",
                //"Modulo": 2
            }
),
        dataType: 'json',
        crossDomain: true,
        success: function (data) {
            consumeSaldosCajeros(data);
        },
        error: function () {
            // alert(data);
            $("#rev").text("Error en el consumo del servicio ");
        }
    });
}
function consumeSaldosCajeros(jresp) {
    var suma = 0;
    if (jresp.NoError == 0) {
        consumeSaldos(jresp);
    }
    else if (jresp.NoError == 1) {
        MensajeError(""+jresp.Descripcion);
        //document.getElementById("SaldosCajeros").innerHTML = jresp.Descripcion;
    } else if (jresp.Respuesta == 3) {
        MensajeError("" + jresp.Descripcion);
        //document.getElementById("SaldosCajeros").innerHTML = jresp.Descripcion;
    } else {
        MensajeError("" + jresp.Descripcion);
        //document.getElementById("SaldosCajeros").innerHTML = "Intente mas tarde.";
    }
}
function consumeSaldos(jsonResp) {
    //aqui va la forma de llenar el segundo cajon de informacion saldos cajeros
    var datos = jsonResp.Respuesta;
    var tablaSal = '<table class="tblGeneral ">' +
					  '<tbody>' +
					  	'<tr class="sinBg">' +
						  '<td colspan="5" >Saldo en Cajeros</td>' +
						'</tr>' +
					  	'<tr class="sinBg">' +
						  '<td>&nbsp;</td>' +
						  '<td colspan="2"><strong>Al cierre</strong></td>' +
						 '<td colspan="2"><strong>Actual</strong></td>' +
						'</tr>' +
						'<tr>' +
					  		'<th>&nbsp;</th>' +
						  	'<th>Emp</th>' +
						  	'<th>Importe</th>' +
						  	'<th>Emp</th>' +
						  	'<th>Importe</th>' +
						'</tr>';

    $.each(datos, function (i, p) {
        tablaSal += '<tr>' +
                '<td>' + p.FcDivisa + '</td>' +
                '<td>' + p.FiCierre_1 + '</td>';
        if (p.FcDivisa == "OLP") {
            tablaSal += '<td>OLP ' + p.FiCierre_2 + '</td>';
        } else {
            if (p.FcDivisa == "EUR") {
                if (parseFloat(p.FiCierre_2) <= 0) {
                    tablaSal += '<td>€' + $.number(p.FiCierre_2, 2) + '</td>';
                } else {
                    tablaSal += '<td onclick="ventanas()"><a href="#" >€' + $.number(p.FiCierre_2, 2) + '</a></td>';
                }
            } else {

                if (parseFloat(p.FiCierre_2) <= 0) {
                    tablaSal += '<td>$' + $.number(p.FiCierre_2, 2) + '</td>';
                } else {
                    tablaSal += '<td onclick="ventanas()"><a href="#">$' + $.number(p.FiCierre_2, 2) + '</a></td>';
                }
            }
        }

        tablaSal += '<td>' + p.FiActual_1 + '</td>';
        if (p.FcDivisa == "OLP") {
            tablaSal += '<td>OLP ' + p.FiActual_2 + '</td>';
        } else {
            if (p.FcDivisa == "EUR") {
                if (parseFloat(p.FiActual_2) <= 0) {
                    tablaSal += '<td>€' + $.number(p.FiActual_2, 2) + '</td></tr>';
                } else {
                    tablaSal += '<td><a href="#">€' + $.number(p.FiActual_2, 2) + '</a></td></tr>';
                }
            } else {
                if (parseFloat(p.FiActual_2) <= 0) {
                    tablaSal += '<td>$' + $.number(p.FiActual_2, 2) + '</td></tr>';
                } else {
                    tablaSal += '<td><a href="#">$' + $.number(p.FiActual_2, 2) + '</a></td></tr>';
                }
            }
        }
    });
    tablaSal += '</tbody></table>';
    $('#SaldosCajeros').html(tablaSal);

}
//Arqueos con Diferencias
function ArqueosDiferencias(fechaInic) {
    var numero = 3;
    var urlArq= getUrls(urlArqueos);
    $.ajax({
        url: "" + urlArq, //opcion a cambios en la url 
        contentType: "application/json; charset=UTF-8",
        type: "POST",
        data: JSON.stringify(
            {
                "FechaFin": ""+fechaInic,
                "FechaInicio": ""+fechaInic,
                "Modulo": numero
            }
           

),
        dataType: 'json',
        crossDomain: true,
        success: function (data) {
            consumeArqueosDif(data);
        },
        error: function () {
            // alert(data);
            $("#rev").text("Error en el consumo del servicio ");
        }
    });
}
function consumeArqueosDif(jresp) {
    var suma = 0;
    if (jresp.NoError == 0) {
        consumeArqueos(jresp);
    }
    else if (jresp.NoError == 1) {
        MensajeError("" + jresp.Descripcion);

//        document.getElementById("DifArqueo").innerHTML = jresp.Descripcion;
    } else if (jresp.Respuesta == 3) {
        MensajeError("" + jresp.Descripcion);
        //document.getElementById("DifArqueo").innerHTML = jresp.Descripcion;
    } else {
        MensajeError("" + jresp.Descripcion);
        //document.getElementById("DifArqueo").innerHTML = "Intente mas tarde.";
    }
}
function consumeArqueos(jsonResp) {
    //aqui va la forma de llenar el segundo cajon de informacion Arqueos con Diferencias
    var arr = ['Doc', 'Efe'];
    var dato = jsonResp.Respuesta;
    var j = 0;
    var tablaArqu = '<table class="tblGeneral ">' +
                     '<tbody>' +
                       '<tr class="sinBg">' +
                         '<td colspan="6" >Arqueo con diferencias</td>' +
                       '</tr>' +
                       '<tr class="sinBg">' +
                         '<td colspan="2">&nbsp;</td>' +
                         '<td colspan="2"><strong>Al cierre</strong></td>' +
                        '<td colspan="2"><strong>Actual</strong></td>' +
                       '</tr>' +
                       '<tr>' +
                           '<th>&nbsp;</th>' +
                           '<th>&nbsp;</th>' +
                           '<th>Ope</th>' +
                           '<th>Importe</th>' +
                           '<th>Ope</th>' +
                           '<th>Importe</th>' +
                       '</tr>';

    $.each(dato, function (i, p) {
        if (j == 0) { j = 1; }
        else if (j == 1) { j = 0; }
        tablaArqu += '<tr>' +
                '<td>' + p.FcDivisa + '</td>' +
                '<td>' + arr[j] + '</td>' +
                '<td>' + p.FiCierre_1 + '</td>';
        if (p.FcDivisa == "OLP") {
            tablaArqu += '<td>OLP ' + p.FiCierre_2 + '</td>';
        } else {
            if (p.FcDivisa == "EUR") {
                if (parseFloat(p.FiCierre_2) <= 0) {
                    tablaArqu += '<td>€' + $.number(p.FiCierre_2, 2) + '</td>';
                } else {
                    tablaArqu += '<td><a href="#">€' + $.number(p.FiCierre_2, 2) + '</a></td>';
                }
            } else {
                if (parseFloat(p.FiCierre_2) <= 0) {
                    tablaArqu += '<td>$' + $.number(p.FiCierre_2, 2) + '</td>';
                } else {
                    tablaArqu += '<td><a href="#">$' + $.number(p.FiCierre_2, 2) + '</a></td>';
                }
            }
        }

        tablaArqu += '<td>' + p.FiActual_1 + '</td>';
        if (p.FcDivisa == "OLP") {
            tablaArqu += '<td>OLP ' + p.FiActual_2 + '</td>';
        } else {
            if (p.FcDivisa == "EUR") {
                if (parseFloat(p.FiActual_2) <= 0) {
                    tablaArqu += '<td>€' + $.number(p.FiActual_2, 2) + '</td></tr>';
                } else {
                    tablaArqu += '<td><a href="#">€' + $.number(p.FiActual_2, 2) + '</a></td></tr>';
                }
            } else {
                if (parseFloat(p.FiActual_2) <= 0) {
                    tablaArqu += '<td>$' + $.number(p.FiActual_2, 2) + '</td></tr>';
                } else {
                    tablaArqu += '<td><a href="#">$' + $.number(p.FiActual_2, 2) + '</a></td></tr>';
                }
            }
        }
    });
    tablaArqu += '</tbody></table>';
    $('#tabArqueo').html(tablaArqu);

}
//Dotaciones de Efectivo a CajaPrincipal
function DotacionesEfectivo(fechaInic) {
    var modulo = "D";
    var urlDot = getUrls(urlDotaciones);
    $.ajax({
        url: "" + urlDot, //opcion a cambios en la url 
        contentType: "application/json; charset=UTF-8",
        type: "POST",
        data: JSON.stringify(
            {
                "FechaFin": ""+fechaInic,
                "FechaInicio": ""+fechaInic,
                "Modulo": ""+modulo
              

            }
),
        dataType: 'json',
        crossDomain: true,
        success: function (data) {
            consumeDotyConc(data);
        },
        error: function () {
            // alert(data);
            $("#rev").text("Error en el consumo del servicio ");
        }
    });
}
function consumeDotyConc(jresp) {
    var suma = 0;
    if (jresp.NoError == 0) {
        consumeDotaciones(jresp);
    }
    else if (jresp.NoError == 1) {
        MensajeError("" + jresp.Descripcion);
        //document.getElementById("DotEfectivo").innerHTML = jresp.Descripcion;
    } else if (jresp.Respuesta == 3) {
        MensajeError("" + jresp.Descripcion);
        //document.getElementById("DotEfectivo").innerHTML = jresp.Descripcion;
    } else {
        MensajeError("" + jresp.Descripcion);
        //document.getElementById("DotEfectivo").innerHTML = "Intente mas tarde.";
    }
}
function consumeDotaciones(jsonResp) {
    //aqui va la forma de llenar el segundo cajon de informacion Dotaciones de Efectivo a CajaPrincipal
    var obj = jsonResp.Respuesta;
    var tablaDot = '<table class="tblGeneral ">' +
                        '<tbody>' +
                          '<tr class="sinBg">' +
                            '<td colspan="5" >Dotaciones de Efectivo</td>' +
                          '</tr>' +
                          '<tr class="sinBg">' +
                            '<td>&nbsp;</td>' +
                            '<td colspan="2"><strong>Al cierre</strong></td>' +
                           '<td colspan="2"><strong>Actual</strong></td>' +
                          '</tr>' +
                          '<tr>' +
                              '<th>&nbsp;</th>' +
                              '<th>Ope</th>' +
                              '<th>Importe</th>' +
                              '<th>Ope</th>' +
                              '<th>Importe</th>' +
                          '</tr>';

    $.each(obj, function (i, p) {
        tablaDot += '<tr>' +
                '<td>' + p.FcDivisa + '</td>' +
                '<td>' + p.FiCierre_1 + '</td>';
        if (p.FcDivisa == "OLP") {
            tablaDot += '<td>OLP ' + p.FiCierre_2 + '</td>';
        } else {
            if (p.FcDivisa == "EUR") {
                if (parseFloat(p.FiCierre_2) <= 0) {
                    tablaDot += '<td>€' + $.number(p.FiCierre_2, 2) + '</td>';
                } else {
                    tablaDot += '<td><a href="#">€' + $.number(p.FiCierre_2, 2) + '</a></td>';
                }
            } else {

                if (parseFloat(p.FiCierre_2) <= 0) {
                    tablaDot += '<td>$' + $.number(p.FiCierre_2, 2) + '</td>';
                } else {
                    tablaDot += '<td><a href="#">$' + $.number(p.FiCierre_2, 2) + '</a></td>';
                }
            }
        }

        tablaDot += '<td>' + p.FiActual_1 + '</td>';
        if (p.FcDivisa == "OLP") {
            tablaDot += '<td>OLP ' + p.FiActual_2 + '</td>';
        } else {
            if (p.FcDivisa == "EUR") {               
                if (parseFloat(p.FiActual_2) <= 0) {
                    tablaDot += '<td>€' + $.number(p.FiActual_2, 2) + '</td></tr>';
                } else {
                    tablaDot += '<td><a href="#">€' + $.number(p.FiActual_2, 2) + '</a></td></tr>';
                }
            }else{
            if (parseFloat(p.FiActual_2) <= 0) {
                tablaDot += '<td>$' + $.number(p.FiActual_2, 2) + '</td></tr>';
            } else {
                tablaDot += '<td><a href="#">$' + $.number(p.FiActual_2, 2) + '</a></td></tr>';
            }
        }
        }
    });
    tablaDot += '</tbody></table>';
    $('#DotacionesEfec').html(tablaDot);
}
//Concentraciones a caja General
function ConcentracionesCaja(fechaInic) {
    var modulo = "F";
    var urlConc = getUrls(urlDotaciones);
    $.ajax({
        url: "" + urlConc, //opcion a cambios en la url 
        contentType: "application/json; charset=UTF-8",
        type: "POST",
        data: JSON.stringify(
            {
                "FechaFin": ""+fechaInic,
                "FechaInicio": ""+fechaInic,
                "Modulo": "" + modulo
               
            }
),
        dataType: 'json',
        crossDomain: true,
        success: function (data) {
            consumeConc(data);
        },
        error: function () {
            // alert(data);
            $("#rev").text("Error en el consumo del servicio ");
        }
    });
}
function consumeConc(jresp) {
    var suma = 0;
    if (jresp.NoError == 0) {
        consumeConcentraciones(jresp);
    }
    else if (jresp.NoError == 1) {
        MensajeError("" + jresp.Descripcion);
        //document.getElementById("ConcentCaja").innerHTML = jresp.Descripcion;
    } else if (jresp.Respuesta == 3) {
        MensajeError("" + jresp.Descripcion);
        //document.getElementById("ConcentCaja").innerHTML = jresp.Descripcion;
    } else {
        MensajeError("" + jresp.Descripcion);
        //document.getElementById("ConcentCaja").innerHTML = "Intente mas tarde.";
    }
}
function consumeConcentraciones(jsonResp) {
    //aqui va la forma de llenar el segundo cajon de informacion Dotaciones de Concentraciones a caja General
    var obj = jsonResp.Respuesta;
    var tablaConc = '<table class="tblGeneral ">' +
                        '<tbody>' +
                          '<tr class="sinBg">' +
                            '<td colspan="5" >Concentraciones a caja general</td>' +
                          '</tr>' +
                          '<tr class="sinBg">' +
                            '<td>&nbsp;</td>' +
                            '<td colspan="2"><strong>Al cierre</strong></td>' +
                           '<td colspan="2"><strong>Actual</strong></td>' +
                          '</tr>' +
                          '<tr>' +
                              '<th>&nbsp;</th>' +
                              '<th>Ope</th>' +
                              '<th>Importe</th>' +
                              '<th>Ope</th>' +
                              '<th>Importe</th>' +
                          '</tr>';

    $.each(obj, function (i, p) {
        tablaConc += '<tr>' +
                '<td>' + p.FcDivisa + '</td>' +
                '<td>' + p.FiCierre_1 + '</td>';
        if (p.FcDivisa == "OLP") {
            tablaConc += '<td>OLP ' + p.FiCierre_2 + '</td>';
        } else {
            if (p.FcDivisa == "EUR") {
                if (parseFloat(p.FiCierre_2) <= 0) {
                    tablaConc += '<td>€' + $.number(p.FiCierre_2, 2) + '</td>';
                } else {
                    tablaConc += '<td><a href="#">€' + $.number(p.FiCierre_2, 2) + '</a></td>';
                }
            } else {
                if (parseFloat(p.FiCierre_2) <= 0) {
                    tablaConc += '<td>$' + $.number(p.FiCierre_2, 2) + '</td>';
                } else {
                    tablaConc += '<td><a href="#">$' + $.number(p.FiCierre_2, 2) + '</a></td>';
                }
            }
        }

        tablaConc += '<td>' + p.FiActual_1 + '</td>';
        if (p.FcDivisa == "OLP") {
            tablaConc += '<td>OLP ' + p.FiActual_2 + '</td>';
        } else {
            if (p.FcDivisa == "EUR") {if (parseFloat(p.FiActual_2) <= 0) {
                tablaConc += '<td>€' + $.number(p.FiActual_2, 2) + '</td></tr>';
            } else {
                tablaConc += '<td><a href="#">€' + $.number(p.FiActual_2, 2) + '</a></td></tr>';
            }
            } else {
                if (parseFloat(p.FiActual_2) <= 0) {
                    tablaConc += '<td>$' + $.number(p.FiActual_2, 2) + '</td></tr>';
                } else {
                    tablaConc += '<td><a href="#">$' + $.number(p.FiActual_2, 2) + '</a></td></tr>';
                }
            }
        }
    });
    tablaConc += '</tbody></table>';
    $('#concCajaGral').html(tablaConc);
}

//SEGUNDA PANTALLA   **************diferencias cajeros Acumulados**************
//
function difCajerosAcum(fechaInic, fechafin) {
    mostrarCarga(true);
    var numero = 1;
    var urlDif = getUrls(urlDiferencias);
    $.ajax({
        url: "" + urlDif, //opcion a cambios en la url 
        contentType: "application/json; charset=UTF-8",
        type: "POST",
        data: JSON.stringify(
            {
                "FechaFin": "" + fechafin,
                "FechaInicio": "" + fechaInic,
                "Modulo": numero
                //"FechaFin": "20030803",
                //"FechaInicio": "20030803",
                //"Modulo": 1

            }
),
        dataType: 'json',
        crossDomain: true,
        success: function (data) {
            mostrarCarga(false);
            consumeDiferenciasCajerosAcum(data);
        },
        error: function () {
            // alert(data);
            $("#rev").text("Error en el consumo del servicio ");
        }
    });
}
function consumeDiferenciasCajerosAcum(jsonResp) {
    var suma = 0;
    if (jsonResp.NoError == 0) {
        consumeDiferenciasAcum(jsonResp);
    }
    else if (jsonResp.NoError == 1) {
        document.getElementById("DifCajero").html = jsonResp.Descripcion;
    } else if (jsonResp.Respuesta == 3) {
        document.getElementById("DifCajero").innerHTML = jsonResp.Descripcion;
    } else {
        document.getElementById("DifCajero").innerHTML = "Intente mas tarde.";
    }
}
function consumeDiferenciasAcum(data) {
    //aqui va la forma de llenar el primer cajon de informacion diferencias cajeros
    var arr = ['Sob', 'Fal'];
    var dat = data.Respuesta;
    var j = 0;
    var tablaDifAcum ='<table class="tblGeneral ">' +
                     '<tbody>' +
					  	'<tr class="sinBg">' +
						  '<td colspan="4" >Diferencias en cajeros</td>' +
						'</tr>' +
					  	'<tr class="sinBg">' +
						  '<td colspan="4"><strong>Acumulado</strong></td>' +
						'</tr>' +
						'<tr>' +
					  		'<th>&nbsp;</th>' +
					  		'<th>&nbsp;</th>' +
						  	'<th> No. Ope</th>' +
						  	'<th>Importe</th>' +
						'</tr>';

    $.each(dat, function (i, p) {
        if (j == 0) { j = 1; }
        else if (j == 1) { j = 0; }
        tablaDifAcum += '<tr>' +
                '<td>' + p.FcDivisa + '</td>' + //divisa= MXP
                '<td>' + arr[j] + '</td>' + //faltante o sobrante
                '<td>' + p.FiCierre_1 + '</td>';//No. Operaciones
        if (p.FcDivisa == "OLP") {
            tablaDifAcum += '<td><div class="w40">OLP ' + p.FiCierre_2 + '</div></td>';
        } else {
            if (p.FcDivisa == "EUR") {
                if (parseFloat(p.FiCierre_2) <= 0) {
                    tablaDifAcum += '<td><div class="w40">€' + $.number(p.FiCierre_2, 2) + '</div></td>';
                } else {
                    tablaDifAcum += '<td><div class="w40"><a href="#">€' + $.number(p.FiCierre_2, 2) + '</a></div></td>';
                }
            } else {
                if (parseFloat(p.FiCierre_2) <= 0) {
                    tablaDifAcum += '<td><div class="w40">$' + $.number(p.FiCierre_2, 2) + '</div></td>';
                } else {
                    tablaDifAcum += '<td><div class="w40"><a href="#">$' + $.number(p.FiCierre_2, 2) + '</a></div></td>';
                }
            }
        }

        tablaDifAcum += '</tr>';
       
    });
    tablaDifAcum += '</tbody></table>';
    $('#DCA').html(tablaDifAcum);

}
//Arqueos con Diferencias
function ArqueosDiferenciasAcum(fechaInic, fechafin) {
    var numero = 3;
    var urlArq = getUrls(urlArqueos);
    $.ajax({
        url: "" + urlArq, //opcion a cambios en la url 
        contentType: "application/json; charset=UTF-8",
        type: "POST",
        data: JSON.stringify(
            {
                "FechaFin": "" + fechafin,
                "FechaInicio": "" + fechaInic,
                "Modulo": numero
            }


),
        dataType: 'json',
        crossDomain: true,
        success: function (data) {
            consumeArqueosDifAcum(data);
        },
        error: function () {
            // alert(data);
            $("#rev").text("Error en el consumo del servicio ");
        }
    });
}
function consumeArqueosDifAcum(jresp) {
    var suma = 0;
    if (jresp.NoError == 0) {
        consumeArqueosAcum(jresp);
    }
    else if (jresp.NoError == 1) {
        document.getElementById("DifArqueo").innerHTML = jresp.Descripcion;
    } else if (jresp.Respuesta == 3) {
        document.getElementById("DifArqueo").innerHTML = jresp.Descripcion;
    } else {
        document.getElementById("DifArqueo").innerHTML = "Intente mas tarde.";
    }
}
function consumeArqueosAcum(jsonResp) {
    //aqui va la forma de llenar el segundo cajon de informacion Arqueos con Diferencias
    var arr = ['Doc', 'Efe'];
    var dato = jsonResp.Respuesta;
    var j = 0;
    var tablaArquAcum = '<table class="tblGeneral ">' +
                     '<tbody>' +
					  	'<tr class="sinBg">' +
						  '<td colspan="4" >Arqueo con Diferencias</td>' +
						'</tr>' +
					  	'<tr class="sinBg">' +
						  '<td colspan="4"><strong>Acumulado</strong></td>' +
						'</tr>' +
						'<tr>' +
					  		'<th>&nbsp;</th>' +
					  		'<th>&nbsp;</th>' +
						  	'<th> No. Ope</th>' +
						  	'<th>Importe</th>' +
						'</tr>';

    $.each(dato, function (i, p) {
        if (j == 0) { j = 1; }
        else if (j == 1) { j = 0; }
        tablaArquAcum += '<tr>' +
                '<td>' + p.FcDivisa + '</td>' + //divisa= MXP
                '<td>' + arr[j] + '</td>' + //faltante o sobrante
                '<td>' + p.FiCierre_1 + '</td>';//No. Operaciones
        if (p.FcDivisa == "OLP") {
            tablaArquAcum += '<td><div class="w40">OLP ' + p.FiCierre_2 + '</div></td>';
        } else {
            if (p.FcDivisa == "EUR") {
                if (parseFloat(p.FiCierre_2) <= 0) {
                    tablaArquAcum += '<td><div class="w40">€' + $.number(p.FiCierre_2, 2) + '</div></td>';
                } else {
                    tablaArquAcum += '<td><div class="w40"><a href="#">€' + $.number(p.FiCierre_2, 2) + '</a></div></td>';
                }
            } else {
                if (parseFloat(p.FiCierre_2) <= 0) {
                    tablaArquAcum += '<td><div class="w40">$' + $.number(p.FiCierre_2, 2) + '</div></td>';
                } else {
                    tablaArquAcum += '<td><div class="w40"><a href="#">$' + $.number(p.FiCierre_2, 2) + '</a></div></td>';
                }
            }
        }

        tablaArquAcum += '</tr>';
       
    });
    tablaArquAcum += '</tbody></table>';
    $('#ada').html(tablaArquAcum);

}
//SALDO EN CAJEROS ACUMULADO
function SaldoCajerosAcum(fechaInic, fechafin) {
    mostrarCarga(true);
    var numero = 2;
    var url = getUrls(urlDiferencias);
    $.ajax({
        url: "" + url, //opcion a cambios en la url 
        contentType: "application/json; charset=UTF-8",
        type: "POST",
        data: JSON.stringify(
            {
                "FechaFin": "" + fechafin,
                "FechaInicio": "" + fechaInic,
                "Modulo": numero
                
            }
),
        dataType: 'json',
        crossDomain: true,
        success: function (data) {
            mostrarCarga(false);
            consumeSaldosCajerosAcum(data);
        },
        error: function () {
            // alert(data);
            $("#rev").text("Error en el consumo del servicio ");
        }
    });
}
function consumeSaldosCajerosAcum(jresp) {
    var suma = 0;
    if (jresp.NoError == 0) {
        consumeSaldosAcum(jresp);
    }
    else if (jresp.NoError == 1) {
        document.getElementById("SaldosCajeros").innerHTML = jresp.Descripcion;
    } else if (jresp.Respuesta == 3) {
        document.getElementById("SaldosCajeros").innerHTML = jresp.Descripcion;
    } else {
        document.getElementById("SaldosCajeros").innerHTML = "Intente mas tarde.";
    }
}
function consumeSaldosAcum(jsonResp) {
    //aqui va la forma de llenar el segundo cajon de informacion saldos cajeros
    var datos = jsonResp.Respuesta;
    var tablaSalAcum = '<table class="tblGeneral ">' +
                     '<tbody>' +
					  	'<tr class="sinBg">' +
						  '<td colspan="3" >Saldo en Cajeros</td>' +
						'</tr>' +
					  	'<tr class="sinBg">' +
						  '<td colspan="3"><strong>Acumulado</strong></td>' +
						'</tr>' +
						'<tr>' +
					  		'<th>&nbsp;</th>' +
						  	'<th> No. Ope</th>' +
						  	'<th>Importe</th>' +
						'</tr>';

    $.each(datos, function (i, p) {
        tablaSalAcum += '<tr>' +
                '<td>' + p.FcDivisa + '</td>' + //divisa= MXP
                '<td>' + p.FiCierre_1 + '</td>';//No. Operaciones
        if (p.FcDivisa == "OLP") {
            tablaSalAcum += '<td><div class="w40">OLP ' + p.FiCierre_2 + '</div></td>';
        } else {
            if (p.FcDivisa == "EUR") {
                if (parseFloat(p.FiCierre_2) <= 0) {
                    tablaSalAcum += '<td><div class="w40">€' + $.number(p.FiCierre_2, 2) + '</div></td>';
                } else {
                    tablaSalAcum += '<td><div class="w40"><a href="#">€' + $.number(p.FiCierre_2, 2) + '</a></div></td>';
                }
            }else{
                if (parseFloat(p.FiCierre_2) <= 0) {
                    tablaSalAcum += '<td><div class="w40">$' + $.number(p.FiCierre_2, 2) + '</div></td>';
                } else {
                    tablaSalAcum += '<td><div class="w40"><a href="#">$' + $.number(p.FiCierre_2, 2) + '</a></div></td>';
                }
            }
        }

        tablaSalAcum += '</tr>';

    });
tablaSalAcum += '</tbody></table>';
$('#sca').html(tablaSalAcum);

}
//Dotaciones de Efectivo a CajaPrincipal Acumulado
function DotacionesEfectivoAcum(fechaInic,fechafin) {
    var modulo = "D";
    var urlDot = getUrls(urlDotaciones);
    $.ajax({
        url: "" + urlDot, //opcion a cambios en la url 
        contentType: "application/json; charset=UTF-8",
        type: "POST",
        data: JSON.stringify(
            {
                "FechaFin": "" + fechafin,
                "FechaInicio": "" + fechaInic,
                "Modulo": "" + modulo


            }
),
        dataType: 'json',
        crossDomain: true,
        success: function (data) {
            consumeDotyConcAcum(data);
        },
        error: function () {
            // alert(data);
            $("#rev").text("Error en el consumo del servicio ");
        }
    });
}
function consumeDotyConcAcum(jresp) {
    var suma = 0;
    if (jresp.NoError == 0) {
        consumeDotacionesAcum(jresp);
    }
    else if (jresp.NoError == 1) {
        document.getElementById("DotEfectivo").innerHTML = jresp.Descripcion;
    } else if (jresp.Respuesta == 3) {
        document.getElementById("DotEfectivo").innerHTML = jresp.Descripcion;
    } else {
        document.getElementById("DotEfectivo").innerHTML = "Intente mas tarde.";
    }
}
function consumeDotacionesAcum(jsonResp) {
    //aqui va la forma de llenar el segundo cajon de informacion Dotaciones de Efectivo a CajaPrincipal
    var obj = jsonResp.Respuesta;
    var tablaDotAcum = '<table class="tblGeneral ">' +
                     '<tbody>' +
					  	'<tr class="sinBg">' +
						  '<td colspan="5" >Saldo en Cajeros</td>' +
						'</tr>' +
					  	'<tr class="sinBg">' +
						  '<td colspan="3"><strong>Acumulado</strong></td>' +
						'</tr>' +
						'<tr>' +
					  		'<th>&nbsp;</th>' +
						  	'<th> No. Ope</th>' +
						  	'<th>Importe</th>' +
						'</tr>';

    $.each(obj, function (i, p) {
        tablaDotAcum += '<tr>' +
                '<td>' + p.FcDivisa + '</td>' + //divisa= MXP
                '<td>' + p.FiCierre_1 + '</td>';//No. Operaciones
        if (p.FcDivisa == "OLP") {
            tablaDotAcum += '<td><div class="w40">OLP ' + p.FiCierre_2 + '</div></td>';
        } else {
            if (p.FcDivisa == "EUR") {
                if (parseFloat(p.FiCierre_2) <= 0) {
                    tablaDotAcum += '<td><div class="w40">€' + $.number(p.FiCierre_2, 2) + '</div></td>';
                } else {
                    tablaDotAcum += '<td><div class="w40"><a href="#">€' + $.number(p.FiCierre_2, 2) + '</a></div></td>';
                }
            }else{
                if (parseFloat(p.FiCierre_2) <= 0) {
                    tablaDotAcum += '<td><div class="w40">$' + $.number(p.FiCierre_2, 2) + '</div></td>';
                } else {
                    tablaDotAcum += '<td><div class="w40"><a href="#">$' + $.number(p.FiCierre_2, 2) + '</a></div></td>';
                }
            }
        }

        tablaDotAcum += '</tr>';

    });
    tablaDotAcum += '</tbody></table>';
    $('#cda1').html(tablaDotAcum);
}
//Concentraciones a caja General Acumulado
function ConcentracionesCajaAcum(fechaInic,fechafin) {
    var modulo = "F";
    var urlConc = getUrls(urlDotaciones);
    $.ajax({
        url: "" + urlConc, //opcion a cambios en la url 
        contentType: "application/json; charset=UTF-8",
        type: "POST",
        data: JSON.stringify(
            {
                "FechaFin": "" + fechafin,
                "FechaInicio": "" + fechaInic,
                "Modulo": "" + modulo

            }
),
        dataType: 'json',
        crossDomain: true,
        success: function (data) {
            consumeConcAcum(data);
        },
        error: function () {
            // alert(data);
            $("#rev").text("Error en el consumo del servicio ");
        }
    });
}
function consumeConcAcum(jresp) {
    var suma = 0;
    if (jresp.NoError == 0) {
        consumeConcentracionesAcum(jresp);
    }
    else if (jresp.NoError == 1) {
        document.getElementById("ConcentCaja").innerHTML = jresp.Descripcion;
    } else if (jresp.Respuesta == 3) {
        document.getElementById("ConcentCaja").innerHTML = jresp.Descripcion;
    } else {
        document.getElementById("ConcentCaja").innerHTML = "Intente mas tarde.";
    }
}
function consumeConcentracionesAcum(jsonResp) {
    //aqui va la forma de llenar el segundo cajon de informacion Dotaciones de Concentraciones a caja General
    var obj = jsonResp.Respuesta;
    var tablaConc = '<table class="tblGeneral ">' +
                     '<tbody>' +
					  	'<tr class="sinBg">' +
						  '<td colspan="5" >Concentraciones a Caja General</td>' +
						'</tr>' +
					  	'<tr class="sinBg">' +
						  '<td colspan="3"><strong>Acumulado</strong></td>' +
						'</tr>' +
						'<tr>' +
					  		'<th>&nbsp;</th>' +
						  	'<th> No. Ope</th>' +
						  	'<th>Importe</th>' +
						'</tr>';

    $.each(obj, function (i, p) {
        tablaConc += '<tr>' +
                '<td>' + p.FcDivisa + '</td>' + //divisa= MXP
                '<td>' + p.FiCierre_1 + '</td>';//No. Operaciones    €
        if (p.FcDivisa == "OLP") {
            tablaConc += '<td><div class="w40">OLP ' + p.FiCierre_2 + '</div></td>';
        } else {
            if (p.FcDivisa == "EUR") {
                if (parseFloat(p.FiCierre_2) <= 0) {
                    tablaConc += '<td><div class="w40">€' + $.number(p.FiCierre_2, 2) + '</div></td>';
                } else {
                    tablaConc += '<td><div class="w40"><a href="#">€' + $.number(p.FiCierre_2, 2) + '</a></div></td>';
                }
            }else{
                if (parseFloat(p.FiCierre_2) <= 0) {
                    tablaConc += '<td><div class="w40">$' + $.number(p.FiCierre_2, 2) + '</div></td>';
                } else {
                    tablaConc += '<td><div class="w40"><a href="#">$' + $.number(p.FiCierre_2, 2) + '</a></div></td>';
                }
            }
        }

        tablaConc += '</tr>';

    });
    tablaConc += '</tbody></table>';
    $('#ccg').html(tablaConc);
}




