

//Calendario
	
$.datepicker.regional['es'] = {
 closeText: 'Cerrar',
 prevText: '',
 nextText: ' ',
 currentText: 'Hoy',
 monthNames: ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'],
 monthNamesShort: ['Ene','Feb','Mar','Abr', 'May','Jun','Jul','Ago','Sep', 'Oct','Nov','Dic'],
 dayNames: ['Domingo', 'Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado'],
 dayNamesShort: ['Dom','Lun','Mar','Mié','Juv','Vie','Sáb'],
 dayNamesMin: ['Do','Lu','Ma','Mi','Ju','Vi','Sá'],
 weekHeader: 'Sm',
 dateFormat: 'dd/mm/yy',
 firstDay: 1,
 isRTL: false,
 showMonthAfterYear: false,
 yearSuffix: ''
 };
$.datepicker.setDefaults($.datepicker.regional['es']);
$(function () {

	$( "#datepicker1" ).datepicker({
		firstDay: 1 
	});
	$( "#datepicker2" ).datepicker({
		firstDay: 1 
	});
	$( "#datepicker3" ).datepicker({
		firstDay: 1 
	});
});


// Select




/* *********Radios************************** */


$(".cont2").hide();
$(".tdPeriodo").hide();
  
  $('#radio3').on( "change", function() {
		$('.cont1').show();
		$('.cont2').hide();
	  	$(".tdDia").show();
	  	$(".tdPeriodo").hide();
	  	caraFunciones();
		return false;
	});
	$('#radio4').on( "change", function() {
		$('.cont1').hide();
		$('.cont2').show();
		$(".tdDia").hide();
		$(".tdPeriodo").show();
		caraFunciones2();

		return false;
	});

$('#datepicker1').change(function () {
	            limpiarcontenedor();
	            caraFunciones();
});
$('#datepicker3').change(function () {
    limpiarcontenedor2();
    caraFunciones2();
});
$(".txtSelect").hide();

$('#selectValor').change(function() {
	if($('#selectValor option:selected').val() == 1) {
		$(".txtSelect").show();
	}
});

/* *********Loading************************** */
function mostrarCarga(mostrar) {
    if (mostrar && !pantallaCargada) {
        pantallaCargada = true;
        $.LoadingOverlay("show");
    } else if (!mostrar && pantallaCargada) {
        pantallaCargada = false;
        $.LoadingOverlay("hide");
    }
}
