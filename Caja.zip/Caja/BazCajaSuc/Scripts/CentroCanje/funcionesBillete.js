let ws = getUrlVars()["ws"];
let usuario = getUrlVars()["usuario"];
let canje= getUrlVars()["canje"];

let noSerie;
let countSerie = 0;
let doomedRow;
let ImpRecivi = 0;
let suma = 0.00;
let grupDenom = [];
let modalSave;
let sumaHelp3;

const AUrlValidaEmpleado = "Comun/WsCajaComun.svc/wsConsultaInformacionInicial";

$(document).ready(function () {
    var date = new Date();
        $('#tagHora').html(date.getHours() + ":" + date.getMinutes() + " Hrs.");

        let mes = MesLetra ((date.getMonth() + 1));

        $('#tagFecha').html(date.getDate() + "/" + mes + "/" + date.getFullYear()); 


        empleadoID = usuario;
        cajaNombre = ws;

        //empieza a cargar los servicios de empleado y de acceso de estación
        //mostrarCarga(true);
        var obj = AServConsultaEmpleado(empleadoID);
        if (obj.NoError == 1) {
            DispararError(obj.Descripcion);
            mostrarCarga(false);
            return;
        }
        $('#tagNoEmpleado').html(obj.InformacionInicial.NoEmpleado);
        $('#tagEmpNombre').html(" - " + obj.InformacionInicial.NombreEmpleado);
        $('#tagPuesto').html(obj.InformacionInicial.PuestoBase);
        $('#tagEmpDescripcion').html(" - " + obj.InformacionInicial.DescripcionPBase);
        $('#tagEstrab').html("ESTACIÓN: ");
        $('#tagEstacion').html(cajaNombre);
        empleadoPuesto = obj.InformacionInicial.PuestoRol;
        $('#tagNumTienda').html(obj.InformacionInicial.NoTienda);
        $('#tagNombreTienda').html(obj.InformacionInicial.NombreTienda);
        $('#tagPais').html(obj.InformacionInicial.DescripcionPais);
        
        $('#tagNumTienda').html(obj.InformacionInicial.NoTienda);
        $('#tagNombreTienda').html(obj.InformacionInicial.NombreTienda);
});

function getUrlComun(servicio) {
    var url = "";
    url = "http://" + window.location.hostname + ":9014/Caja/Servicios/" + servicio;
    return url;
}

function MesLetra(mes) {
    var mesLetra = "";
    switch (mes) {
        case 1: 
            mesLetra = "Ene";
        break;
        case 2:
            mesLetra = "Feb";
        break;
        case 3:
            mesLetra = "Mar";
        break;
        case 4:
            mesLetra = "Abr";
        break;
        case 5:
            mesLetra = "May";
        break;
        case 6:
            mesLetra = "Jun";
        break;
        case 7:
            mesLetra = "Jul";
        break;
        case 8:
            mesLetra = "Ago";
        break;
        case 9:
            mesLetra = "Sep";
        break;
        case 10:
            mesLetra = "Oct";
        break;
        case 11:
            mesLetra = "Nov";
        break;
        case 12:
            mesLetra = "Dic";
        break;
        }
    return mesLetra;
}

function AServConsultaEmpleado(empleado) {
    var objRespuesta = { NoError: null, Descripcion: null };
    var url = getUrlComun(AUrlValidaEmpleado);
    $.ajax({
        url: "" + url,
        contentType: "application/json; charset=UTF-8",
        type: "POST",
        async: false,
        data: JSON.stringify({
            "NoEmpleado": "" + empleado
        }),
        dataType: 'json',
        crossDomain: true,
        success: function (data) {
            objRespuesta = data;
        },
        error: function () {
            objRespuesta.NoError = 1;
            objRespuesta.Descripcion = "Error: No se pudo contactar al servicio de validacion de empleado.";
        }
    });
    return objRespuesta;
}

function cargaDenominaciones(opcionCanje){
	try{
    	switch(opcionCanje) {
        case "1":
            denominaciones().done(function(respuesta){
                try{
                if (!isDefined(respuesta)) {
                    timeStampErroresImpresion = Commons.getStampId();      
                    registraHistorial("El servicio no puede encontrar denomincaiones, respuesta= "+JSON.stringify(respuesta, null, 4) + '. No se obtuvo respuesta del servicio de Dentro de Canje metodo denominaciones.',timeStampErroresImpresion);                                                            
                    FuncionesEfectivo.mostrarModal('errorTransaccion');
                    return;
                    }
                var array = respuesta.Denominaciones;
                addOptions("denominacionSelect", array);
                }
                catch(eError){
                    alert(JSON.stringify(eError,null,4))
                }

            });
            
            // Llenado de Tabla
                var tablaApoyo = '<table><thead>'+
                        '<tr>'+
                        '<th>Eliminar</th>'+
                        '<th>No. de serie</th>'+
                        '<th>Denominación</th>'+
                        '<th>Estatus</th>'+
                        '</tr></thead>';
                tablaApoyo += '<tbody id="tablaBody"></tbody></table>';
                $('#tablaId').html(tablaApoyo);

            //titulo
            document.getElementById("idTitulo").innerHTML= "Canje de billete con valor"

            break;

        case "2":
            denominaciones().done(function(respuesta){
                try{
                if (!isDefined(respuesta)) {
                    timeStampErroresImpresion = Commons.getStampId();      
                    registraHistorial("El servicio no puede encontrar denomincaiones, respuesta= "+JSON.stringify(respuesta, null, 4) + '. No se obtuvo respuesta del servicio de Dentro de Canje metodo denominaciones.',timeStampErroresImpresion);                                                            
                    FuncionesEfectivo.mostrarModal('errorTransaccion');
                    return;
                    }
                var array = respuesta.Denominaciones;
                addOptions("denominacionSelect", array);
                }
                catch(eError){
                    alert(JSON.stringify(eError,null,4))
                }
            });
            // Llenado de Tabla
                var tablaApoyo = '<table><thead>'+
                        '<tr>'+
                        '<th>Eliminar</th>'+
                        '<th>No. de serie</th>'+
                        '<th>Denominación</th>'+
                        '<th>Estatus</th>'+
                        '</tr></thead>';
                tablaApoyo += '<tbody id="tablaBody"></tbody></table>';
                $('#tablaId').html(tablaApoyo);

                //titulo
            document.getElementById("idTitulo").innerHTML= "Canje de billete no apto (Deteriorado)"

            break;

        case "3":
            denominacionesRetiro().done(function(respuesta){
                timeStampErroresImpresion = Commons.getStampId();
                if (!isDefined(respuesta)) {    
                    registraHistorial("El servicio no puede encontrar denomincaiones, respuesta= "+JSON.stringify(respuesta, null, 4) + '. No se obtuvo respuesta del servicio de Dentro de Canje metodo denominacionesRetiro.',timeStampErroresImpresion);                                                            
                    avisaError("No se encontraron denominaciones en la consulta.");
                    return;
                    }
                if(respuesta.Denominaciones == null){
                    registraHistorial("El servicio no puede encontrar denomincaiones, respuesta= "+JSON.stringify(respuesta, null, 4) + '. No se obtuvo respuesta del servicio de Dentro de Canje metodo denominacionesRetiro.',timeStampErroresImpresion);                                                            
                    avisaError("No se encontraron denominaciones en la consulta.");
                    return;
                }
                var array = respuesta.Denominaciones;
                addOptions("denominacionSelect", array);

            });
            // Llenado de Tabla
                var tablaApoyo = '<table><thead>'+
                        '<tr>'+
                        '<th>Eliminar</th>'+
                        '<th>No. de serie</th>'+
                        '<th>Denominación</th>'+
                        '<th>Estatus</th>'+
                        '<th>Valor Actual</th>'+
                        '</tr></thead>';
                tablaApoyo += '<tbody id="tablaBody"></tbody></table>';
                $('#tablaId').html(tablaApoyo);

            //titulo
            document.getElementById("idTitulo").innerHTML= "Canje de billete en retiro"

            break;

        default:
            // mandar error
    	}
        document.getElementById("idNoSerie").focus();
    }
    catch(oError){
        alert(JSON.stringify(oError,null,4))
    }
}
function addOptions(domElement, array) {
 var select = document.getElementsByName(domElement)[0];
 for (value in array) {
  var option = document.createElement("option");
  option.text = array[value];
  select.add(option);
 }
}

function validaNoSerie(event){
if (document.getElementById("idNoSerie").value != ""){
    if (!event) {
        event = window.event;
        keyCode = event.keyCode;
    }
    else { // ff
        keyCode = event.which;
    }
        var letra = document.getElementById("idNoSerie").value;
        document.getElementById("idNoSerie").value = letra.toUpperCase();
    if (keyCode == 13) {

        if (countSerie === 0){
            noSerie = document.getElementById("idNoSerie").value;
            document.getElementById("idNoSerie").value="";
            FuncionesEfectivo.mostrarModal('modalNumeroSerie');
            countSerie = 1;
            document.getElementById("idNoSerie").focus();
            }
        else{
            if (noSerie === document.getElementById("idNoSerie").value){
                var _select = document.getElementById("idImporte");
                _select.removeAttribute("disabled");
                countSerie=0;
                noSerie = "";
                document.getElementById("idImporte").focus();
                }
            else{
                FuncionesEfectivo.mostrarModal('modalNumeroSerie1');
                countSerie=0;
                noSerie = "";
                document.getElementById("idNoSerie").value="";
                document.getElementById("idNoSerie").focus();
                }
            }
        }
    }
}

function agregaBillete(opcionCanje){
if(document.getElementById("idImporte").value == "0"){
    FuncionesEfectivo.mostrarModal('faltaDenominacion');
}
else{
    if(document.getElementById("idNoSerie").value == ""){
    FuncionesEfectivo.mostrarModal('modalNumeroSerie1');
    }
    else{
        var _ntnDelete =
        '<a href="#" class="borrar" onClick="eliminaModal(this)"><img src="../../Imgs/CentroCanje/eliminar.png" class="imgIco"></a>';
        var _noSwerie = document.getElementById("idNoSerie").value;
        
        if(opcionCanje == "1")
        {
        var _denominacion = document.getElementById("idImporte").value;
        var _estatus = "Recibido por canje de billete con valor";
        var fila = "<tr><td>"+_ntnDelete+"</td><td>"+_noSwerie+"</td><td>"+_denominacion+"</td><td>"+_estatus+"</td></tr>";
        };
        if(opcionCanje == "2")
        {
        var _denominacion = document.getElementById("idImporte").value;
        var _estatus = "Recibido por canje de billete no apto (Deteriorado)";
        var fila="<tr><td>"+_ntnDelete+"</td><td>"+_noSwerie+"</td><td>"+_denominacion+"</td><td>"+_estatus+"</td></tr>";
        }
        if(opcionCanje == "3"){
            var _denominacion = document.getElementById("idImporte").value+".00";
            {
                switch(document.getElementById("idImporte").value){
                    case "1000000":
                    var _valorActual = "100.00";
                    break;

                    case "50000":
                    var _valorActual = "50.00";
                    break;

                    case "20000":
                    var _valorActual = "20.00";
                    break;

                    case "10000":
                    var _valorActual = "10.00";
                    break;

                     case "5000":
                     var _valorActual = "5.00";
                    break;

                    case "2000":
                    var _valorActual = "2.00";
                    break;

                    case "1000":
                    var _valorActual = "1.00";
                    break;

                    case "500":
                    var _valorActual = "0.50";
                    break;

                    case "200":
                    var _valorActual = "0.20";
                    break;

                    case "100":
                    var _valorActual = "0.10";
                    break;

                    case "50":
                    var _valorActual = "0.050";
                    break;

                    case "20":
                    var _valorActual = "0.020";
                    break;

                    case "10":
                    var _valorActual = "0.010";
                    break;

                    case "5":
                    var _valorActual = "0.005";
                    break;

                    case "1":
                    var _valorActual = "0.001";
                    break;
                    }    
                var _estatus = "Recibido por canje de billete en retiro";
                var fila="<tr><td>"+_ntnDelete+"</td><td>"+_noSwerie+"</td><td>"+_denominacion+"</td><td>"+_estatus+"</td><td>"+_valorActual+"</td></tr>";
            }
        }

        var btn = document.createElement("TR");
        btn.innerHTML=fila;
        var tBody = document.getElementById("tablaBody");

        //Al agregar un billete, estos se agrupan del mayor al menor
        if(tBody.rows.length === 0)
            tBody.appendChild(btn);
        else{
            var cinserta = 0;
            var trs = tBody.getElementsByTagName("TR")
            for (var i = 0; i < tBody.rows.length; i++) {
                if(_denominacion>=Number(tBody.rows[i].cells[2].innerHTML)){
                    tBody.insertBefore(btn,trs[i]);
                    cinserta = 1;
                    break;
                }
            }
            if(cinserta===0)
                tBody.appendChild(btn);
        }
        document.getElementById("idNoSerie").value="";
        document.getElementById("idImporte").value = '0';
        document.getElementById("idImporte").setAttribute("disabled","true");

        calculaImporte();
        focusNoSerie()
        }
    }
}

function quitarBillete(){
var i = doomedRow.parentNode.parentNode.rowIndex;
    document.getElementById("tablaId").deleteRow(i);

    calculaImporte();
    doomedRow=null;
}

function calculaImporte(){
    suma = 0;
    sumaHelp3 = 0;

    var tablaBilletes = document.getElementById("tablaId");
    for(var i = 1; i < tablaBilletes.rows.length; i++){
        suma += Number(tablaBilletes.rows[i].cells[2].innerHTML);
        // if (canje==="1" || canje === "2")
        // suma += Number(tablaBilletes.rows[i].cells[2].innerHTML);
        if (canje==="3")
        sumaHelp3 += Number(tablaBilletes.rows[i].cells[4].innerHTML);
    }
    document.getElementById("etiquetaImporteR").innerHTML = "Importe recibido:   "+suma+".00"
}

function indexBilletes(){
    if(opcionCanje == "1"){
        FuncionesEfectivo.mostrarModal('modalBilletes');
        acomodaModalB();            
    }
    if(opcionCanje == "2"){
        FuncionesEfectivo.mostrarModal('modalBilletes');
        acomodaModalB();  
    }
    if(opcionCanje == "3")
        FuncionesEfectivo.mostrarModal('modalDenominaciones2');
}

function acomodaModalB(){
    $(".menuMoney a.item").click(function (e) {
            $(".menuMoney a.item").removeClass("itemAct");
            $(this).addClass("itemAct");
        });

            $(".billete1").show();
            $(".billete2").hide();
            $(".billete3").hide();
            $(".billete4").hide();

        $('a.bill1').click(function (e) {
            $('.bill1 img').attr('src', '../../Imgs/CentroCanje/cuadroV.jpg');
            $('.bill2 img').attr('src', '../../Imgs/CentroCanje/cuadroT.png');
            $('.bill3 img').attr('src', '../../Imgs/CentroCanje/cuadroT.png');
            $('.bill4 img').attr('src', '../../Imgs/CentroCanje/cuadroT.png');
            $(".billete1").show();
            $(".billete2").hide();
            $(".billete3").hide();
            $(".billete4").hide();
        });

        $('a.bill2').click(function (e) {
            $('.bill1 img').attr('src', '../../Imgs/CentroCanje/cuadroT.png');
            $('.bill2 img').attr('src', '../../Imgs/CentroCanje/cuadroV.jpg');
            $('.bill3 img').attr('src', '../../Imgs/CentroCanje/cuadroT.png');
            $('.bill4 img').attr('src', '../../Imgs/CentroCanje/cuadroT.png');
            $(".billete1").hide();
            $(".billete2").show();
            $(".billete3").hide();
            $(".billete4").hide();
        });

        $('a.bill3').click(function (e) {
            $('.bill1 img').attr('src', '../../Imgs/CentroCanje/cuadroT.png');
            $('.bill2 img').attr('src', '../../Imgs/CentroCanje/cuadroT.png');
            $('.bill3 img').attr('src', '../../Imgs/CentroCanje/cuadroV.jpg');
            $('.bill4 img').attr('src', '../../Imgs/CentroCanje/cuadroT.png');
            $(".billete1").hide();
            $(".billete2").hide();
            $(".billete3").show();
            $(".billete4").hide();
        });

        $('a.bill4').click(function (e) {
            $('.bill1 img').attr('src', '../../Imgs/CentroCanje/cuadroT.png');
            $('.bill2 img').attr('src', '../../Imgs/CentroCanje/cuadroT.png');
            $('.bill3 img').attr('src', '../../Imgs/CentroCanje/cuadroT.png');
            $('.bill4 img').attr('src', '../../Imgs/CentroCanje/cuadroV.jpg');
            $(".billete1").hide();
            $(".billete2").hide();
            $(".billete3").hide();
            $(".billete4").show();
        });
}

function soloNumero(e){
    var key = window.Event ? e.which : e.keyCode 
    return ((key >= 48 && key <= 57) || (key==8)) 
}
    
function soloAlfaNum(e){
    var key = window.Event ? e.which : e.keyCode 

    if((key >= 97 && key <= 122)){
        key-=32;
        window.Event ? e.which : e.keyCode = key;
        window.Event ? e.which : e.key = letra2;
    }

    return ((key >= 48 && key <= 57) || (key >= 65 && key <= 90) || (key==8) || (key==37) || (key==39)) 
}

function regresa(){
    window.top.location.href = 'efectivo.html?ws='+ws+'&usuario='+usuario;
}
function denominacionesModal(){
    // Existan Registros en Tabla
    var tam = document.getElementById("tablaId").rows.length;
    if ( tam > 1){
        llenaDenominacionesHelper();
        FuncionesEfectivo.mostrarModal('modalDemoninaciones');
        if (canje==="3")
            document.getElementById("tdTextImporte").innerHTML="Importe Valor Actual";
        else
            document.getElementById("tdTextImporte").innerHTML="Importe recibido";

        document.getElementById("idD1000b").focus();
    }
    else
        FuncionesEfectivo.mostrarModal('modalBilletesTabla');   

    cargaTablaDenom();
}

function eliminaModal(valor){
    // Existan Registros en Tabla
    doomedRow=valor;
    FuncionesEfectivo.mostrarModal('modalEliminar');
        let e = document.getElementById("modal00").querySelector("#msgNoSerie");
        e.innerHTML = doomedRow.parentNode.parentNode.cells[1].textContent;

}

function llenaDenominacionesHelper(){
    
    var aDenom = [];
    var aNoB = [];
    var DenominacionT;
    var tablaBilletes = document.getElementById("tablaId");


    for(var i = 1; i < tablaBilletes.rows.length; i++){
        
        if (canje==="1" || canje === "2")
            DenominacionT= Number(tablaBilletes.rows[i].cells[2].innerHTML);
        if (canje==="3"){
            DenominacionT= Number(tablaBilletes.rows[i].cells[4].innerHTML);

        }

        if(aDenom.length===0){
            aDenom[0]=DenominacionT;
            aNoB[0]=1;
        }
        else{
            var lengthArray = aDenom.length;
            var nuevo=0;
            for (x=0;x<lengthArray;x++){
                if(aDenom[x]===DenominacionT){
                    aNoB[x]+=1;
                    nuevo=1
                   break;
                }
            }
            if(nuevo===0){
                aDenom[aDenom.length]=DenominacionT;
                aNoB[aNoB.length]=1;
            }
        }
    }

    grupDenom[0]=aDenom;
    grupDenom[1]=aNoB;
}

function cargaTablaDenom(){
    for (x=0;x<grupDenom[0].length;x++){
        var fila="<tr><td>"+grupDenom[0][x]+"</td><td>"+grupDenom[1][x]+"</td></tr>";

        var btn = document.createElement("TR");
            btn.innerHTML=fila;
            document.getElementById("tablaBody2").appendChild(btn);
    }

    if (canje==="3")
        document.getElementById("importRe2").value='$'+formatMoney(sumaHelp3);
    else
        document.getElementById("importRe2").value='$'+formatMoney(suma);
}


function SumatoriasDenomEnM2(){
    //Suma billetes
    var SumaBillete = 0;
    var SumaMoneda = 0;
    ImpRecivi = 0;

    SumaBillete+=(document.getElementById("idD1000b").value*1000);
    SumaBillete+=(document.getElementById("idD500b").value*500);
    SumaBillete+=(document.getElementById("idD200b").value*200);
    SumaBillete+=(document.getElementById("idD100b").value*100);
    SumaBillete+=(document.getElementById("idD50b").value*50);
    SumaBillete+=(document.getElementById("idD20b").value*20);

    ImpRecivi+=SumaBillete;

    //Suma monedas
    SumaMoneda+=(document.getElementById("idD100m").value*100);
    SumaMoneda+=(document.getElementById("idD20m").value*20);
    SumaMoneda+=(document.getElementById("idD10m").value*10);
    SumaMoneda+=(document.getElementById("idD5m").value*5);
    SumaMoneda+=(document.getElementById("idD2m").value*2);
    SumaMoneda+=(document.getElementById("idD1m").value*1);
    SumaMoneda+=(document.getElementById("idD050m").value*.50);
    SumaMoneda+=(document.getElementById("idD020m").value*.20);
    SumaMoneda+=(document.getElementById("idD010m").value*.10);

    ImpRecivi+=SumaMoneda;

    document.getElementById("idDTdB").innerHTML='$'+formatMoney(SumaBillete);
    document.getElementById("idDTdM").innerHTML='$'+formatMoney(SumaMoneda);
    document.getElementById("idDImpReci").innerHTML='$'+formatMoney(ImpRecivi);
}

function retornaDatosDenom(){
    // Verifica
    if (canje==="3"){
        if(sumaHelp3 != ImpRecivi)
            alert("El importe recibido no coincide con el Importe a entregar. Favor de verificarlo.");
        else
            cerrarModal();
        document.getElementById("etiquetaImporteE").innerHTML="Importe a entregar:   "+formatMoney(ImpRecivi);
    }
    else{
        if(suma != ImpRecivi){
            alert("El importe recibido no coincide con el Importe a entregar. Favor de verificarlo.");
        }
        else
            cerrarModal();
        document.getElementById("etiquetaImporteE").innerHTML="Importe a entregar:   "+formatMoney(ImpRecivi);
    }    
}

function recuperaModal(){
    // $('#modal00').html(modalSave);                        
    // $('#modal00').modal();
    ImpRecivi=0;
    llenaDenominacionesHelper();
    FuncionesEfectivo.mostrarModal('modalDemoninaciones');
    cargaTablaDenom();
}

var FuncionesEfectivo = {
    mostrarModal: function mostrarModal(tipo) {
        html = ManejadorMsgCentroCanje.getContent(tipo);
        muestraModal(html)
    }
};

function guardar(){
    var sumaIT = 0;
    var sumaAC = 0;

    if (canje==="3"){
        sumaIT=sumaHelp3;
        sumaAC=suma;
    }
    else{
        sumaIT=suma;
        sumaAC=0;
    }
    //Verificar Importes
    if(sumaIT === ImpRecivi && suma != 0 ){
        if (canje==="3"){
            sumaIT=suma;
            sumaAC=sumaHelp3;
        }
        //Genera Objeto
        
        var billetes = [];
        var billete;

        //Detalle
        var tablaBilletes = document.getElementById("tablaId");

        for(var i = 1; i < tablaBilletes.rows.length; i++){
            billete = {
            NoSerie:tablaBilletes.rows[i].cells[1].innerHTML,
            Denominacion: Number(tablaBilletes.rows[i].cells[2].innerHTML),
            IngEgr:1,
            TipoMoneda:'B',
            Fracciones:0,
            Cantidad:1,
            Status:0
            };

            billetes[i-1]=billete;
        }
        //Princupal
        var transaccion = {
            WS:ws,
            Usuario:usuario,
            TipoTransaccion:3465,
            OpcionCanje:opcionCanje,
            NoPiezas:document.getElementById("tablaId").rows.length-1,
            Importe: sumaIT,
            Divisa:1,
            ValorAc:sumaAC,
            Detalle:billetes
        };
        //Ejecuta
        centroCanjeAfectacionCaja(transaccion).done(function (respuesta){
            timeStampErroresImpresion = Commons.getStampId();      
            if (!isDefined(respuesta)) {
            registraHistorial("El servicio de Centro de Canje no puede procesar la Transaccion, respuesta= "+JSON.stringify(respuesta, null, 4) + '. No se obtuvo respuesta del servicio de Centro de Canje metodo centroCanjeAfectacionCaja.',timeStampErroresImpresion);                                                            
            avisaError("No se obtuvo respuesta del servicio de Centro de Canje metodo centroCanjeAfectacionCaja.");
            return;
            }
            if(respuesta.NoError != 0){
                registraHistorial("El servicio de Centro de Canje no puede procesar la Transaccion, respuesta= " +
                    JSON.stringify(respuesta, null, 4) + '. No se obtuvo respuesta del servicio de Centro de Canje metodo centroCanjeAfectacionCaja.',
                    timeStampErroresImpresion);
                avisaError("No se obtuvo respuesta del servicio de Centro de Canje metodo centroCanjeAfectacionCaja.");
                return;
            }
            FuncionesEfectivo.mostrarModal('modalCambioExito');

            //Limpiar
            limpiarMod1();

        });
    }
    else{
        FuncionesEfectivo.mostrarModal('inputImporte');
        let e = document.getElementById("modal00").querySelector("#impReM");
        e.innerHTML = formatMoney(sumaIT);

        e = document.getElementById("modal00").querySelector("#impEnM");
        if (ImpRecivi===0)
            e.innerHTML = "0.00";
        else
            e.innerHTML = formatMoney(ImpRecivi);
    }

}

function limpiarMod1(){
    //Tabla
     var tablaApoyo = '<table><thead>'+
                    '<tr>'+
                    '<th>Eliminar</th>'+
                    '<th>No. de serie</th>'+
                    '<th>Denominación</th>'+
                    '<th>Estatus</th>'+
                    '<th>Valor Actual</th>'+
                    '</tr></thead>';
            tablaApoyo += '<tbody id="tablaBody"></tbody></table>';
            $('#tablaId').html(tablaApoyo);

    //Etiquetas
    document.getElementById("etiquetaImporteR").innerHTML = "Importe recibido:   0.00"
    document.getElementById("etiquetaImporteE").innerHTML = "Importe entregar:   0.00";

    //Variables
    suma = 0;
    ImpRecivi = 0;
}

function focusNoSerie(){
    document.getElementById("idNoSerie").focus();
}
function focusBoton(event){
    document.getElementById("btnAceptar").focus();
}