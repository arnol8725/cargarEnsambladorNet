﻿//Sesion
let ws = getUrlVars()["ws"];
let usuario = getUrlVars()["usuario"];

let ImpReciv = 0;
let ImpEntre = 0;

const AUrlValidaEmpleado = "Comun/WsCajaComun.svc/wsConsultaInformacionInicial";

$(document).ready(function () {
    if (FuncionesEfectivo.validaGet()) {
        var date = new Date();
                $('#tagHora').html(date.getHours() + ":" + date.getMinutes() + " Hrs.");

                let mes = MesLetra ((date.getMonth() + 1));

                $('#tagFecha').html(date.getDate() + "/" + mes + "/" + date.getFullYear()); 


                empleadoID = usuario;
                cajaNombre = ws;

                //empieza a cargar los servicios de empleado y de acceso de estación
                //mostrarCarga(true);
                var obj = AServConsultaEmpleadoE(empleadoID);
                if (obj.NoError == 1) {
                    avisaError(obj.Descripcion);
                    mostrarCarga(false);
                    return;
                }
                $('#tagNoEmpleado').html(obj.InformacionInicial.NoEmpleado);
                $('#tagEmpNombre').html(" - " + obj.InformacionInicial.NombreEmpleado);
                $('#tagPuesto').html(obj.InformacionInicial.PuestoBase);
                $('#tagEmpDescripcion').html(" - " + obj.InformacionInicial.DescripcionPBase);
                $('#tagEstrab').html("ESTACIÓN: ");
                $('#tagEstacion').html(cajaNombre);
                empleadoPuesto = obj.InformacionInicial.PuestoRol;
                $('#tagNumTienda').html(obj.InformacionInicial.NoTienda);
                $('#tagNombreTienda').html(obj.InformacionInicial.NombreTienda);
                $('#tagPais').html(obj.InformacionInicial.DescripcionPais);
                
                $('#tagNumTienda').html(obj.InformacionInicial.NoTienda);
                $('#tagNombreTienda').html(obj.InformacionInicial.NombreTienda);
        }
});

function getUrlComun(servicio) {
    var url = "";
    url = "http://" + window.location.hostname + ":9014/Caja/Servicios/" + servicio;
    return url;   
}

function MesLetra(mes) {
    var mesLetra = "";
    switch (mes) {
        case 1: 
            mesLetra = "Ene";
        break;
        case 2:
            mesLetra = "Feb";
        break;
        case 3:
            mesLetra = "Mar";
        break;
        case 4:
            mesLetra = "Abr";
        break;
        case 5:
            mesLetra = "May";
        break;
        case 6:
            mesLetra = "Jun";
        break;
        case 7:
            mesLetra = "Jul";
        break;
        case 8:
            mesLetra = "Ago";
        break;
        case 9:
            mesLetra = "Sep";
        break;
        case 10:
            mesLetra = "Oct";
        break;
        case 11:
            mesLetra = "Nov";
        break;
        case 12:
            mesLetra = "Dic";
        break;
        }
    return mesLetra;
}

function AServConsultaEmpleadoE(empleado) {
    var objRespuesta = { NoError: null, Descripcion: null };
    var url = getUrlComun(AUrlValidaEmpleado);
    $.ajax({
        url: "" + url,
        contentType: "application/json; charset=UTF-8",
        type: "POST",
        async: false,
        data: JSON.stringify({
            "NoEmpleado": "" + empleado
        }),
        dataType: 'json',
        crossDomain: true,
        success: function (data) {
            objRespuesta = data;
        },
        error: function () {
            objRespuesta.NoError = 1;
            objRespuesta.Descripcion = "Error: No se pudo contactar al servicio de validacion de empleado.";
        }
    });
    return objRespuesta;
}

function eligeVentana() {
    if (document.getElementById("checkCanje1").checked)
        window.top.location.href = 'billete.html?canje=1&ws='+ws+'&usuario='+usuario;

    if (document.getElementById("checkCanje2").checked)
        window.top.location.href = 'billete.html?canje=2&ws='+ws+'&usuario='+usuario;

    if (document.getElementById("checkCanje3").checked)
        window.top.location.href = 'billete.html?canje=3&ws='+ws+'&usuario='+usuario;

    if (document.getElementById("checkCanje4").checked)
    	FuncionesEfectivo.mostrarModal("modalDenominaciones1");
}

function SumatoriasDenomRe(){
    //Suma billetes
    var SumaBillete = 0;
    var SumaMoneda = 0;
    ImpReciv = 0;

    SumaBillete+=(document.getElementById("idB1").value*1000);
    SumaBillete+=(document.getElementById("idB2").value*500);
    SumaBillete+=(document.getElementById("idB3").value*200);
    SumaBillete+=(document.getElementById("idB4").value*100);
    SumaBillete+=(document.getElementById("idB5").value*50);
    SumaBillete+=(document.getElementById("idB6").value*20);

    ImpReciv+=SumaBillete;

    //Suma monedas
    SumaMoneda+=(document.getElementById("idM1").value*100);
    SumaMoneda+=(document.getElementById("idM2").value*20);
    SumaMoneda+=(document.getElementById("idM3").value*10);
    SumaMoneda+=(document.getElementById("idM4").value*5);
    SumaMoneda+=(document.getElementById("idM5").value*2);
    SumaMoneda+=(document.getElementById("idM6").value*1);
    SumaMoneda+=(document.getElementById("idM7").value*.50);
    SumaMoneda+=(document.getElementById("idM8").value*.20);
    SumaMoneda+=(document.getElementById("idM9").value*.10);

    ImpReciv+=SumaMoneda;

    document.getElementById("idTdB").innerHTML='$'+formatMoney(SumaBillete);
    document.getElementById("idTdM").innerHTML='$'+formatMoney(SumaMoneda);
    document.getElementById("idImpReci").value='$'+formatMoney(ImpReciv);

}

function SumatoriasDenomEn(){
    //Suma billetesvar 
    var SumaBillete = 0;
    var SumaMoneda = 0;
    ImpEntre = 0;

    SumaBillete+=(document.getElementById("id2B1").value*1000);
    SumaBillete+=(document.getElementById("id2B2").value*500);
    SumaBillete+=(document.getElementById("id2B3").value*200);
    SumaBillete+=(document.getElementById("id2B4").value*100);
    SumaBillete+=(document.getElementById("id2B5").value*50);
    SumaBillete+=(document.getElementById("id2B6").value*20);

    ImpEntre+=SumaBillete;

    //Suma monedas
    SumaMoneda+=(document.getElementById("id2M1").value*100);
    SumaMoneda+=(document.getElementById("id2M2").value*20);
    SumaMoneda+=(document.getElementById("id2M3").value*10);
    SumaMoneda+=(document.getElementById("id2M4").value*5);
    SumaMoneda+=(document.getElementById("id2M5").value*2);
    SumaMoneda+=(document.getElementById("id2M6").value*1);
    SumaMoneda+=(document.getElementById("id2M7").value*.50);
    SumaMoneda+=(document.getElementById("id2M8").value*.20);
    SumaMoneda+=(document.getElementById("id2M9").value*.10);

    ImpEntre+=SumaMoneda;

    document.getElementById("idTdB2").innerHTML='$'+formatMoney(SumaBillete)
    document.getElementById("idTdM2").innerHTML='$'+formatMoney(SumaMoneda);
    document.getElementById("idImpEntrega").innerHTML='$'+formatMoney(ImpEntre);

}

function DenomAceptar(){
    var count=0;
    if (ImpReciv === ImpEntre && ImpReciv != 0 && ImpEntre != 0) {

        //Genera Objeto
        var billetes = [];
        var billete;
        var denominacionS;
        // billetes
        for (var i = 1; i <= 6; i++) {
            if (document.getElementById("idB" + i).value != 0) {

                switch (i) {
                case 1:
                    denominacionS=1000;
                    count++;
                    break;
                case 2:
                    denominacionS=500;
                    count++;
                    break;
                case 3:
                    denominacionS=200;
                    count++;
                    break;
                case 4:
                    denominacionS=100;
                    count++;
                    break;
                case 5:
                    denominacionS=50;
                    count++;
                    break;
                case 6:
                    denominacionS=20;
                    count++;
                    break;
                }
                billete = {
                    NoSerie: "",
                    Denominacion: denominacionS,
                    IngEgr: 1,
                    TipoMoneda: 'B',
                    Fracciones: 0,
                    Cantidad: document.getElementById("idB" + i).value,
                    Status: 0
                };

                billetes[billetes.length] = billete;
            }
        }
        for (var i = 1; i <= 9; i++) {
            if (document.getElementById("idM" + i).value != 0) {
                switch (i) {
                case 1:
                    denominacionS=100;
                    count++;
                    break;
                case 2:
                    denominacionS=20;
                    count++;
                    break;
                case 3:
                    denominacionS=10;
                    count++;
                    break;
                case 4:
                    denominacionS=5;
                    count++;
                    break;
                case 5:
                    denominacionS=2;
                    count++;
                    break;
                case 6:
                    denominacionS=1;
                    count++;
                    break;
                case 7:
                    denominacionS=0.50;
                    count++;
                    break;
                case 8:
                    denominacionS=0.20;
                    count++;
                    break;
                case 9:
                    denominacionS=0.10;
                    count++;
                    break;
                }
                billete = {
                    NoSerie: "",
                    Denominacion: denominacionS,
                    IngEgr: 1,
                    TipoMoneda: 'M',
                    Fracciones: 0,
                    Cantidad: document.getElementById("idM" + i).value,
                    Status: 0
                };

                billetes[billetes.length] = billete;
            }
        }
        for (var i = 1; i <= 6; i++) {
            if (document.getElementById("id2B" + i).value != 0) {
                switch (i) {
                case 1:
                    denominacionS=1000;
                    count++;
                    break;
                case 2:
                    denominacionS=500;
                    count++;
                    break;
                case 3:
                    denominacionS=200;
                    count++;
                    break;
                case 4:
                    denominacionS=100;
                    count++;
                    break;
                case 5:
                    denominacionS=50;
                    count++;
                    break;
                case 6:
                    denominacionS=20;
                    count++;
                    break;
                }
                billete = {
                    NoSerie: "",
                    Denominacion: denominacionS,
                    IngEgr: 2,
                    TipoMoneda: 'B',
                    Fracciones: 0,
                    Cantidad: document.getElementById("id2B" + i).value,
                    Status: 0
                };

                billetes[billetes.length] = billete;
            }
        }
        for (var i = 1; i <= 9; i++) {
            if (document.getElementById("id2M" + i).value != 0) {
                switch (i) {
                case 1:
                    denominacionS=100;
                    count++;
                    break;
                case 2:
                    denominacionS=20;
                    count++;
                    break;
                case 3:
                    denominacionS=10;
                    count++;
                    break;
                case 4:
                    denominacionS=5;
                    count++;
                    break;
                case 5:
                    denominacionS=2;
                    count++;
                    break;
                case 6:
                    denominacionS=1;
                    count++;
                    break;
                case 7:
                    denominacionS=0.50;
                    count++;
                    break;
                case 8:
                    denominacionS=0.20;
                    count++;
                    break;
                case 9:
                    denominacionS=0.10;
                    count++;
                    break;
                }
                billete = {
                    NoSerie: "",
                    Denominacion: denominacionS,
                    IngEgr: 2,
                    TipoMoneda: 'M',
                    Fracciones: 0,
                    Cantidad: document.getElementById("id2M" + i).value,
                    Status: 0
                };

                billetes[billetes.length] = billete;
            }
        }
        //Princupal
        transaccion = {
            WS: ws,
            Usuario: usuario,
            TipoTransaccion: 3465,
            OpcionCanje: 5,
            NoPiezas: count,
            Importe: ImpReciv,
            Divisa: 1,
            VAlorAc: 0,
            Detalle: billetes
        };

        //Ejecuta
        centroCanjeAfectacionCaja(transaccion).done(function(respuesta) {
            timeStampErroresImpresion = Commons.getStampId();
            if (!isDefined(respuesta)) {
                registraHistorial("El servicio de Centro de Canje no puede procesar la Transaccion, respuesta= " +
                    JSON.stringify(respuesta, null, 4) + '. No se obtuvo respuesta del servicio de Centro de Canje metodo centroCanjeAfectacionCaja.',
                    timeStampErroresImpresion);
                FuncionesEfectivo.mostrarModal('errorTransaccion');
                avisaError("No se obtuvo respuesta del servicio de Centro de Canje metodo centroCanjeAfectacionCaja.");
                return;
            }
            if(respuesta.NoError != 0){
                registraHistorial("El servicio de Centro de Canje no puede procesar la Transaccion, respuesta= " +
                    JSON.stringify(respuesta, null, 4) + '. No se obtuvo respuesta del servicio de Centro de Canje metodo centroCanjeAfectacionCaja.',
                    timeStampErroresImpresion);
                FuncionesEfectivo.mostrarModal('errorTransaccion');
                avisaError("No se obtuvo respuesta del servicio de Centro de Canje metodo centroCanjeAfectacionCaja.");
                return;
            }
            FuncionesEfectivo.mostrarModal('modalCambioExito');
        });
    }
    else {
        // FuncionesEfectivo.mostrarModal("errorImportes");
        alert("El importe recibido no coincide con el Importe a entregar. Favor de verificarlo.");
    }

}


function procesaCerrarControlError(){
    cerrarModal();
    cerrarControl();
    ocultarElementosPantalla()
}


function ModalHelpAceptar(){
    FuncionesEfectivo.mostrarModal("modalDenominaciones1");
}

function soloNumero(e){
    var key = window.Event ? e.which : e.keyCode 
    return ((key >= 48 && key <= 57) || (key==8)) 
}

var FuncionesEfectivo = {
    mostrarModal: function mostrarModal(tipo) {
        html = ManejadorMsgCentroCanje.getContent(tipo);
        muestraModal(html)
    },

    validaGet: function validaGet() {
        let result = false;
        try {
            timeStampErroresEfectivo = Commons.getStampId(ws);
            registraHistorial("Los datos para procesar la operación son: ws:" + ws+" usuario:"+usuario+" ;",timeStampErroresEfectivo,0);                                    
            if (ws != "" || usuario != "") {
                if (ws == undefined || usuario == undefined) {
                                
                    registraHistorial("Los datos para procesar la operación ha llegado incompletos, no declarados o indefinidos; ws:" + ws+" usuario:"+usuario+" ;",timeStampErroresEfectivo,3);                
                    finalizarConError("No se han mandado los parámetros correctos. </br>[Código de seguimiento:"+timeStampErroresEfectivo+"]");
                }
                else {
                    result = true;
                }
            }
        }
        catch (err) {
            timeStampErroresEfectivo = Commons.getStampId(ws);      
            registraHistorial("Ocurrió un error no controlado durante la inicializacion de la pagina; oError = "+JSON.stringify(oError, null, 4),timeStampErroresEfectivo,3);                                                
            finalizarConError("Algo salio mal, si el problema persiste favor de comunicarse a soporte." + " </br>[Código de seguimiento:"+timeStampErroresEfectivo+"]");        
        }
        finally {
            return result;
        }
    }
};
