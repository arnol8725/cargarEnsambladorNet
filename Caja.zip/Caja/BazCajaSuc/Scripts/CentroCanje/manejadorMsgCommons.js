﻿var ManejadorMsgCommons = {
    getContent: function getContent(caseMessage) {
        content = "";
        switch (caseMessage) {
            case "error":
                content = '<div class="cuadro">\
                                <a style="visibility:hidden;" href="#" class=" simplemodal-close" id="botonCerrar">\
                                    <img src="../../Imgs/cerrar.png class="cerrar">\
                                </a>\
                                <div class="titModal">Centro Canje</div>\
                                <div class="clear"></div><br>\
                                <div class="texto1">\
                                    <label id="lblError"></label>\
                                    <br>\
                                    <div class="botones1"><a href="#" onclick="cerrarModal()" class="btnV w48">Aceptar</a></div>\
                                    <br><br>\
                                </div>\
                            </div>\
                            <br>';
                break;
            case "errorFin": //se manda llamar con finaliza con error
                content = '<div class="cuadro">\
                                <a href="#" class="simplemodal-close" id="botonCerrar">\
                                    <img src="../../Imgs/cerrar.png" onclick="procesaCerrarControlError()" class="cerrar">\
                                </a>\
                                <div class="titModal">Centro Canje</div>\
                                <div class="clear"></div><br>\
                                <div class="texto1">\
                                    <label id="lblError"></label>\
                                    <br><br><br>\
                                </div>\
                                <br>\
                            </div>' 
                break;
            default:
                content = '<p>No se eligío un mensaje valido para mostrar<\p>'
                break;

        }
        return content;
    }
};