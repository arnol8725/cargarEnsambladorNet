var ManejadorMsgCentroCanje = {
    getContent: function getContent(caseMessage) {
        var content = "";
        switch (caseMessage) {
            case "modalNumeroSerie":
                content = ' <div class="cuadro1">\
                                    <a style="visibility: hidden" href="#" class=" simplemodal-close" id="botonCerrar">\
                                        <img src="../../Imgs/CentroCanje/cerrar.png" class="cerrar" visible="false">\
                                    </a>\
                                    <div class="titModal">Centro de canje de efectivo</div>\
                                    <div class="clear"></div><br>\
                                    <div class="texto1">\
                                        Por favor vuelva a ingresar el número de serie del billete<br>\
                                        para confirmar la información.\
                                    </div><br>\
                                    <div class="botones1"><a href="#" class="btnV w48  simplemodal-close" id="modalNumeroSerie1_view" onClick="focusNoSerie()">Aceptar</a></div><br>\
                            </div>';
            break;

            case "modalNumeroSerie1":
                content = ' <div class="cuadro1">\
                                <a style="visibility: hidden" href="#" class=" simplemodal-close" id="botonCerrar">\
                                    //<img src="../../Imgs/CentroCanje/cerrar.png" class="cerrar" visible="false">\
                                </a>\
                                <div class="titModal">Centro de canje de efectivo</div>\
                                <div class="clear"></div><br>\
                                <div class="texto1">\
                                    El número de serie que ingresó es incorrecto,<br>\
                                    favor de verificarlo.\
                                </div><br>\
                                <div class="botones1"><a href="#" class="btnV w48  simplemodal-close" onClick="focusNoSerie()">Aceptar</a></div><br> \
                        </div>';
            break;

            case "faltaDenominacion":
                content = ' <div class="cuadro1">\
                                <a style="visibility: hidden" href="#" class=" simplemodal-close" id="botonCerrar">\
                                    <img src="../../Imgs/CentroCanje/cerrar.png" class="cerrar" visible="false">\
                                </a>\
                                <div class="titModal">Centro de canje de efectivo</div>\
                                <div class="clear"></div><br>\
                                <div class="texto1">\
                                    La denominación es incorrecta,<br>\
                                    favor de verificarlo.\
                                </div><br>\
                                <div class="botones1"><a href="#" class="btnV w48  simplemodal-close">Aceptar</a></div><br> \
                        </div>';
            break;

            case "errorImportes":
                content = ' <div class="cuadro1">\
                                <a style="visibility: hidden" href="#" class=" simplemodal-close" id="botonCerrar">\
                                    <img src="../../Imgs/CentroCanje/cerrar.png" class="cerrar" visible="false">\
                                </a>\
                                <div class="titModal">Centro de canje de efectivo</div>\
                                <div class="clear"></div><br>\
                                <div class="texto1">\
                                    El importe recibido no coincide con el Importe a entregar,<br>\
                                    favor de verificarlo.\
                                </div><br>\
                                <div class="botones1"><a href="#" class="btnV w48  simplemodal-close" onclick="ModalHelpAceptar()">Aceptar</a></div><br> \
                        </div>';
            break;

            case "errorTransaccion":
                content = ' <div class="cuadro1">\
                                <a style="visibility: hidden" href="#" class=" simplemodal-close" id="botonCerrar">\
                                    <img src="../../Imgs/CentroCanje/cerrar.png" class="cerrar" visible="false">\
                                </a>\
                                <div class="titModal">Centro de canje de efectivo</div>\
                                <div class="clear"></div><br>\
                                <div class="texto1">\
                                    No es posible realizar la Transaccion,<br>\
                                    favor de verificarlo.\
                                </div><br>\
                                <div class="botones1"><a href="#" class="btnV w48  simplemodal-close" onclick="ModalHelpAceptar()">Aceptar</a></div><br> \
                        </div>';
            break;

            case "modalDemoninaciones":
                content = '<div class="cuadro">\
                            <a style="visibility: hidden" href="#" class=" simplemodal-close" id="botonCerrar">\
                                <img src="../../Imgs/CentroCanje/cerrar.png" class="cerrar">\
                            </a>\
                            <div class="titModal">Denominaciones</div>\
                            <div class="clear"></div><br>\
                            <div class="cont">\
                                <div class="col1">\
                                    <div class="titNegro tLeft w90">Importe recibido</div><br>\
                                    <table class="tblSimple w94 td20">\
                                      <tbody>\
                                        <tr>\
                                          <td id="tdTextImporte">Importe recibido:</td>\
                                          <td><input id="importRe2" type="text" placeholder="$0.00" readonly="readonly"></td>\
                                        </tr>\
                                      </tbody>\
                                    </table>\
                                    <table id="idTablaDenom2" class="tblModalImporte1">\
                                      <thead>\
                                        <tr>\
                                          <th>Denominación</th>\
                                          <th>No. billetes</th>\
                                        </tr>\
                                      </thead>\
                                      <tbody id="tablaBody2">\
                                      </tbody>\
                                    </table>\
                                </div>\
                                <div class="col2">\
                                    <div class="titNegro tLeft w90">Importe por entregar</div><br>\
                                    <div class="h32"></div>\
                                    <table class="tblModalImporte1 ">\
                                      <tbody>\
                                        <tr>\
                                          <th>Denominación</th>\
                                          <th>No. billetes</th>\
                                          <th>No.monedas</th>\
                                        </tr>\
                                        <tr>\
                                          <td>1,000.00</td>\
                                          <td class="w100"><input type="text" id="idD1000b" placeholder="0" class="gen3" onkeypress="return soloNumero(event)" onkeyup="SumatoriasDenomEnM2()"></td>\
                                          <td>-</td>\
                                        </tr>\
                                        <tr>\
                                          <td>500.00</td>\
                                          <td><input type="text" id="idD500b" placeholder="0" class="gen3" onkeypress="return soloNumero(event)" onkeyup="SumatoriasDenomEnM2()"></td>\
                                          <td>-</td>\
                                        </tr>\
                                        <tr>\
                                          <td>200.00</td>\
                                          <td><input type="text" id="idD200b" placeholder="0" class="gen3" onkeypress="return soloNumero(event)" onkeyup="SumatoriasDenomEnM2()"></td>\
                                          <td>-</td>\
                                        </tr>\
                                        <tr>\
                                          <td>100.00</td>\
                                          <td><input type="text" id="idD100b" placeholder="0" class="gen3" onkeypress="return soloNumero(event)" onkeyup="SumatoriasDenomEnM2()"></td>\
                                          <td><input type="text" id="idD100m" placeholder="0" class="gen3" onkeypress="return soloNumero(event)" onkeyup="SumatoriasDenomEnM2()"></td>\
                                        </tr>\
                                        <tr>\
                                          <td>50.00</td>\
                                          <td><input type="text" id="idD50b" placeholder="0" class="gen3" onkeypress="return soloNumero(event)" onkeyup="SumatoriasDenomEnM2()"></td>\
                                          <td>-</td>\
                                        </tr>\
                                        <tr>\
                                          <td>20.00</td>\
                                          <td><input type="text" id="idD20b" placeholder="0" class="gen3" onkeypress="return soloNumero(event)" onkeyup="SumatoriasDenomEnM2()"></td>\
                                          <td><input type="text" id="idD20m" placeholder="0" class="gen3" onkeypress="return soloNumero(event)" onkeyup="SumatoriasDenomEnM2()"></td>\
                                        </tr>\
                                        <tr>\
                                          <td>10.00</td>\
                                          <td>-</td>\
                                          <td><input type="text" id="idD10m" placeholder="0" class="gen3" onkeypress="return soloNumero(event)" onkeyup="SumatoriasDenomEnM2()"></td>\
                                        </tr>\
                                        <tr>\
                                          <td>5.00</td>\
                                          <td>-</td>\
                                          <td><input type="text" id="idD5m" placeholder="0" class="gen3" onkeypress="return soloNumero(event)" onkeyup="SumatoriasDenomEnM2()"></td>\
                                        </tr>\
                                        <tr>\
                                          <td>2.00</td>\
                                          <td>-</td>\
                                          <td><input type="text" id="idD2m" placeholder="0" class="gen3" onkeypress="return soloNumero(event)" onkeyup="SumatoriasDenomEnM2()"></td>\
                                        </tr>\
                                        <tr>\
                                          <td>1.00</td>\
                                          <td>-</td>\
                                          <td><input type="text" id="idD1m" placeholder="0" class="gen3" onkeypress="return soloNumero(event)" onkeyup="SumatoriasDenomEnM2()"></td>\
                                        </tr>\
                                        <tr>\
                                          <td>0.50</td>\
                                          <td>-</td>\
                                          <td><input type="text" id="idD050m" placeholder="0" class="gen3" onkeypress="return soloNumero(event)" onkeyup="SumatoriasDenomEnM2()"></td>\
                                        </tr>\
                                        <tr>\
                                          <td>0.20</td>\
                                          <td>-</td>\
                                          <td><input type="text" id="idD020m" placeholder="0" class="gen3" onkeypress="return soloNumero(event)" onkeyup="SumatoriasDenomEnM2()"></td>\
                                        </tr>\
                                        <tr>\
                                          <td>0.10</td>\
                                          <td>-</td>\
                                          <td><input type="text" id="idD010m" placeholder="0" class="gen3" onkeypress="return soloNumero(event)" onkeyup="SumatoriasDenomEnM2()"></td>\
                                        </tr>\
                                        <tr class="total">\
                                          <td>&nbsp;</td>\
                                          <td id="idDTdB">0</td>\
                                          <td id="idDTdM">0</td>\
                                        </tr>\
                                      </tbody>\
                                    </table>\
                                    <table class="tblGeneral tblModalImporte1 tRight">\
                                        <tbody>\
                                          <tr class="total">\
                                            <td>Importe entregado</td>\
                                            <td id="idDImpReci">$0.00</td>\
                                          </tr>\
                                        </tbody>\
                                      </table>\
                                </div>\
                            </div>\
                            <div class="clear"></div>\
                            <br>\
                            <div class="botones1">\
                                <a href="#" class="btnB w48  simplemodal-close" >Salir</a>\
                                <a href="#" class="btnV w48  simplemodal" onClick="retornaDatosDenom()">Aceptar</a>\
                            </div><br>\
                            <div class="botones1">\
                            </div><br>\
                        </div>';
            break;

            case "modalCambioExito":
                content = '<div class="cuadro1">\
                            <a style="visibility: hidden" href="#" class=" simplemodal-close" id="botonCerrar">\
                                <img src="../../Imgs/CentroCanje/cerrar.png" class="cerrar">\
                            </a>\
                            <div class="titModal">Aplicando cambio</div>\
                            <div class="clear"></div><br>\
                            <div class="texto1">\
                                La operación de canje de efectivo se realizó satisfactoriamente.\
                            </div><br>\
                            <div class="botones1"><a href="#" class="btnV w48  simplemodal-close">Aceptar</a></div><br> \
                        </div>';
            break;

            case "inputImporte":
                content = '<div class="cuadro1">\
                            <a style="visibility: hidden" href="#" class=" simplemodal-close" id="botonCerrar">\
                                <img src="../../Imgs/CentroCanje/cerrar.png" class="cerrar">\
                            </a>\
                            <div class="titModal">Verificación de importes</div>\
                            <div class="clear"></div><br>\
                            <div class="texto1">\
                                El importe a entregar no corresponde al valor actual de la denominación.<br><br>\
                                <strong>Importe recibido</strong>: (Valor actual): $<strong id="impReM"></strong><br>\
                                <strong>Importe entregado</strong>: $<strong id="impEnM"></strong><br><br>\
                                Por favor, verifique.\
                            </div><br>\
                            <div class="botones1"><a href="#" class="btnV w48  simplemodal-close" onClick="recuperaModal()">Aceptar</a></div><br> \
                        </div>';
            break;

            case "modalEliminar":
                content = '<div class="cuadro1">\
                            <a style="visibility: hidden" href="#" class=" simplemodal-close" id="botonCerrar">\
                                <img src="../../Imgs/CentroCanje/cerrar.png" class="cerrar">\
                            </a>\
                            <div class="titModal">Eliminar registro</div>\
                            <div class="clear"></div><br>\
                            <div class="texto1">\
                                ¿Desea eliminar el registro con número de serie: <strong id="msgNoSerie"></strong> ?\
                            </div><br>\
                            <div class="botones1">\
                                <a href="#" class="btnB w48  simplemodal-close">No</a>\
                                <a href="#" class="btnV w48  simplemodal-close" onClick="quitarBillete()">Sí</a>\
                            </div><br>\
                        </div>';
            break;

            case "modalBilletesTabla":
                content = ' <div class="cuadro1">\
                                <a style="visibility: hidden" href="#" class=" simplemodal-close" id="botonCerrar">\
                                    //<img src="../../Imgs/CentroCanje/cerrar.png" class="cerrar" visible="false">\
                                </a>\
                                <div class="titModal">Centro de canje de efectivo</div>\
                                <div class="clear"></div><br>\
                                <div class="texto1">\
                                    Debe capturar todos los billetes que desea ingresar en esta operación,<br>\
                                    anetes de la captura de denominaciones que entregará.\
                                </div><br>\
                                <div class="botones1"><a href="#" class="btnV w48  simplemodal-close">Aceptar</a></div><br> \
                        </div>';
            break;


            case "modalDenominaciones1":
                content = '<div class="cuadro">\
                            <a style="visibility: hidden" href="#" class=" simplemodal-close" id="botonCerrar">\
                                <img src="../../Imgs/CentroCanje/cerrar.png" class="cerrar">\
                            </a>\
                            <div class="titModal">Denominaciones</div>\
                            <div class="clear"></div><br>\                            <div class="cont">\
                                <div class="col1">\
                                    <div class="titNegro tLeft w90">Importe recibido</div><br>\
                                    <table class="tblSimple w94 td20">\
                                      <tbody>\
                                        <tr>\
                                          <td>Importe recibido:</td>\
                                          <td><input id="idImpReci" type="text" placeholder="0.00" readonly="readonly"></td>\
                                        </tr>\
                                      </tbody>\
                                    </table>\
                                    <table class="tblModalImporte1 ">\
                                      <tbody>\
                                        <tr>\
                                          <th>Denominación</th>\
                                          <th>No. billetes</th>\
                                          <th>No.monedas</th>\
                                        </tr>\
                                        <tr>\
                                          <td>1,000.00</td>\
                                          <td class="w100"><input id="idB1" type="text" placeholder="0" class="gen3" onkeypress="return soloNumero(event)" onkeyup="SumatoriasDenomRe()"></td>\
                                          <td>-</td>\
                                        </tr>\
                                        <tr>\
                                          <td>500.00</td>\
                                          <td><input type="text" id="idB2" placeholder="0" class="gen3" onkeypress="return soloNumero(event)" onkeyup="SumatoriasDenomRe()"></td>\
                                          <td>-</td>\
                                        </tr>\
                                        <tr>\
                                          <td>200.00</td>\
                                          <td><input type="text" id="idB3" placeholder="0" class="gen3" onkeypress="return soloNumero(event)" onkeyup="SumatoriasDenomRe()"></td>\
                                          <td>-</td>\
                                        </tr>\
                                        <tr>\
                                          <td>100.00</td>\
                                          <td><input type="text" id="idB4" placeholder="0" class="gen3" onkeypress="return soloNumero(event)" onkeyup="SumatoriasDenomRe()"></td>\
                                          <td><input type="text" id="idM1" placeholder="0" class="gen3" onkeypress="return soloNumero(event)" onkeyup="SumatoriasDenomRe()"></td>\
                                        </tr>\
                                        <tr>\
                                          <td>50.00</td>\
                                          <td><input type="text" id="idB5" placeholder="0" class="gen3" onkeypress="return soloNumero(event)" onkeyup="SumatoriasDenomRe()"></td>\
                                          <td>-</td>\
                                        </tr>\
                                        <tr>\
                                          <td>20.00</td>\
                                          <td><input type="text" id="idB6" placeholder="0" class="gen3" onkeypress="return soloNumero(event)" onkeyup="SumatoriasDenomRe()"></td>\
                                          <td><input type="text" id="idM2" placeholder="0" class="gen3" onkeypress="return soloNumero(event)" onkeyup="SumatoriasDenomRe()"></td>\
                                        </tr>\
                                        <tr>\
                                          <td>10.00</td>\
                                          <td>-</td>\
                                          <td><input type="text" id="idM3" placeholder="0" class="gen3" onkeypress="return soloNumero(event)" onkeyup="SumatoriasDenomRe()"></td>\
                                        </tr>\
                                        <tr>\
                                          <td>5.00</td>\
                                          <td>-</td>\
                                          <td><input type="text" id="idM4" placeholder="0" class="gen3" onkeypress="return soloNumero(event)" onkeyup="SumatoriasDenomRe()"></td>\
                                        </tr>\
                                        <tr>\
                                          <td>2.00</td>\
                                          <td>-</td>\
                                          <td><input type="text" id="idM5" placeholder="0" class="gen3" onkeypress="return soloNumero(event)" onkeyup="SumatoriasDenomRe()"></td>\
                                        </tr>\
                                        <tr>\
                                          <td>1.00</td>\
                                          <td>-</td>\
                                          <td><input type="text" id="idM6" placeholder="0" class="gen3" onkeypress="return soloNumero(event)" onkeyup="SumatoriasDenomRe()"></td>\
                                        </tr>\
                                        <tr>\
                                          <td>0.50</td>\
                                          <td>-</td>\
                                          <td><input type="text" id="idM7" placeholder="0" class="gen3" onkeypress="return soloNumero(event)" onkeyup="SumatoriasDenomRe()"></td>\
                                        </tr>\
                                        <tr>\
                                          <td>0.20</td>\
                                          <td>-</td>\
                                          <td><input type="text" id="idM8" placeholder="0" class="gen3" onkeypress="return soloNumero(event)" onkeyup="SumatoriasDenomRe()"></td>\
                                        </tr>\
                                        <tr>\
                                          <td>0.10</td>\
                                          <td>-</td>\
                                          <td><input type="text" id="idM9" placeholder="0" class="gen3" onkeypress="return soloNumero(event)" onkeyup="SumatoriasDenomRe()"></td>\
                                        </tr>\
                                        <tr class="total">\
                                          <td>&nbsp;</td>\
                                          <td id="idTdB">0</td>\
                                          <td id="idTdM">0</td>\
                                        </tr>\
                                      </tbody>\
                                    </table>\
                                </div>\
                                <div class="col2">\
                                    <div class="titNegro tLeft w90">Importe por entregar</div><br>\
                                    <div class="h32"></div>\
                                    <table class="tblModalImporte1 ">\
                                      <tbody>\
                                        <tr>\
                                          <th>Denominación</th>\
                                          <th>No. billetes</th>\
                                          <th>No.monedas</th>\
                                        </tr>\
                                        <tr>\
                                          <td>1,000.00</td>\
                                          <td class="w100"><input id="id2B1" type="text" placeholder="0" class="gen3" onkeypress="return soloNumero(event)" onkeyup="SumatoriasDenomEn()"></td>\
                                          <td>-</td>\
                                        </tr>\
                                        <tr>\
                                          <td>500.00</td>\
                                          <td><input type="text" id="id2B2" placeholder="0" class="gen3" onkeypress="return soloNumero(event)" onkeyup="SumatoriasDenomEn()"></td>\
                                          <td>-</td>\
                                        </tr>\
                                        <tr>\
                                          <td>200.00</td>\
                                          <td><input type="text" id="id2B3" placeholder="0" class="gen3" onkeypress="return soloNumero(event)" onkeyup="SumatoriasDenomEn()"></td>\
                                          <td>-</td>\
                                        </tr>\
                                        <tr>\
                                          <td>100.00</td>\
                                          <td><input type="text" id="id2B4" placeholder="0" class="gen3" onkeypress="return soloNumero(event)" onkeyup="SumatoriasDenomEn()"></td>\
                                          <td><input type="text" id="id2M1" placeholder="0" class="gen3" onkeypress="return soloNumero(event)" onkeyup="SumatoriasDenomEn()"></td>\
                                        </tr>\
                                        <tr>\
                                          <td>50.00</td>\
                                          <td><input type="text" id="id2B5" placeholder="0" class="gen3" onkeypress="return soloNumero(event)" onkeyup="SumatoriasDenomEn()"></td>\
                                          <td>-</td>\
                                        </tr>\
                                        <tr>\
                                          <td>20.00</td>\
                                          <td><input type="text" id="id2B6" placeholder="0" class="gen3" onkeypress="return soloNumero(event)" onkeyup="SumatoriasDenomEn()"></td>\
                                          <td><input type="text" id="id2M2" placeholder="0" class="gen3" onkeypress="return soloNumero(event)" onkeyup="SumatoriasDenomEn()"></td>\
                                        </tr>\
                                        <tr>\
                                          <td>10.00</td>\
                                          <td>-</td>\
                                          <td><input type="text" id="id2M3" placeholder="0" class="gen3" onkeypress="return soloNumero(event)" onkeyup="SumatoriasDenomEn()"></td>\
                                        </tr>\
                                        <tr>\
                                          <td>5.00</td>\
                                          <td>-</td>\
                                          <td><input type="text" id="id2M4" placeholder="0" class="gen3" onkeypress="return soloNumero(event)" onkeyup="SumatoriasDenomEn()"></td>\
                                        </tr>\
                                        <tr>\
                                          <td>2.00</td>\
                                          <td>-</td>\
                                          <td><input type="text" id="id2M5" placeholder="0" class="gen3" onkeypress="return soloNumero(event)" onkeyup="SumatoriasDenomEn()"></td>\
                                        </tr>\
                                        <tr>\
                                          <td>1.00</td>\
                                          <td>-</td>\
                                          <td><input type="text" id="id2M6" placeholder="0" class="gen3" onkeypress="return soloNumero(event)" onkeyup="SumatoriasDenomEn()"></td>\
                                        </tr>\
                                        <tr>\
                                          <td>0.50</td>\
                                          <td>-</td>\
                                          <td><input type="text" id="id2M7" placeholder="0" class="gen3" onkeypress="return soloNumero(event)" onkeyup="SumatoriasDenomEn()"></td>\
                                        </tr>\
                                        <tr>\
                                          <td>0.20</td>\
                                          <td>-</td>\
                                          <td><input type="text" id="id2M8" placeholder="0" class="gen3" onkeypress="return soloNumero(event)" onkeyup="SumatoriasDenomEn()"></td>\
                                        </tr>\
                                        <tr>\
                                          <td>0.10</td>\
                                          <td>-</td>\
                                          <td><input type="text" id="id2M9" placeholder="0" class="gen3" onkeypress="return soloNumero(event)" onkeyup="SumatoriasDenomEn()"></td>\
                                        </tr>\
                                        <tr class="total">\
                                          <td>&nbsp;</td>\
                                          <td id="idTdB2">0</td>\
                                          <td id="idTdM2">0</td>\
                                        </tr>\
                                      </tbody>\
                                    </table>\
                                    <table class="tblGeneral tblModalImporte1 tRight">\
                                        <tbody>\
                                          <tr class="total">\
                                            <td>Importe entregado</td>\
                                            <td id="idImpEntrega">$0.00</td>\
                                          </tr>\
                                        </tbody>\
                                      </table>\
                                </div>\
                            </div>\
                            <div class="clear"></div>\
                            <br>\
                            <div class="botones1">\
                                <a href="#" class="btnB w48  simplemodal-close" >Salir</a>\
                                <a href="#" class="btnV w48  simplemodal" onClick="DenomAceptar()">Aceptar</a>\
                            </div><br>  \
                        </div>';
            break;

            case "modalDenominaciones2":
                content = '<div class="cuadro">\
                            <a style="visibility: hidden" href="#" class=" simplemodal-close" id="botonCerrar">\
                                <img src="../../Imgs/CentroCanje/cerrar.png" class="cerrar">\
                            </a>\
                            <div class="titModal">Denominaciones</div>\
                            <div class="clear"></div><br>\
                            <table class="tblBilletes">\
                              <tbody>\
                                <tr>\
                                  <td>\
                                    <img src="../../Imgs/CentroCanje/billetes/billete100.jpg">\
                                    <div class="txtG1">Denominación: 100,000.00</div>\
                                    <div>Valor actual: 100.00</div>\
                                  </td>\
                                  <td>\
                                    <img src="../../Imgs/CentroCanje/billetes/billete5.png">\
                                    <div class="txtG1">Denominación: 5,000.00</div>\
                                    <div>Valor actual: 5.00</div>\
                                  </td>\
                                  <td>\
                                    <img src="../../Imgs/CentroCanje/billetes/billete05.png">\
                                    <div class="txtG1">Denominación: 500.00</div>\
                                    <div>Valor actual: 0.50</div>\
                                  </td>\
                                  <td>\
                                    <img src="../../Imgs/CentroCanje/billetes/billete50.png">\
                                    <div class="txtG1">Denominación: 50.00</div>\
                                    <div>Valor actual: 50.00</div>\
                                  </td>\
                                </tr>\
                                <tr>\
                                  <td>\
                                    <img src="../../Imgs/CentroCanje/billetes/billete50-1.png">\
                                    <div class="txtG1">Denominación: 50,000.00</div>\
                                    <div>Valor actual: 50.00</div>\
                                  </td>\
                                  <td>\
                                    <img src="../../Imgs/CentroCanje/billetes/billete2.png">\
                                    <div class="txtG1">Denominación: 2,000.00</div>\
                                    <div>Valor actual: 2.00</div>\
                                  </td>\
                                  <td>\
                                    <img src="../../Imgs/CentroCanje/billetes/billete200.png">\
                                    <div class="txtG1">Denominación: 200.00</div>\
                                    <div>Valor actual: 200.00</div>\
                                  </td>\
                                  <td>\
                                    <img src="../../Imgs/CentroCanje/billetes/billete50-2.png">\
                                    <div class="txtG1">Denominación: 50.00</div>\
                                    <div>Valor actual: 50.00</div>\
                                  </td>\
                                </tr>\
                                <tr>\
                                  <td>\
                                    <img src="../../Imgs/CentroCanje/billetes/billete20.png">\
                                    <div class="txtG1">Denominación: 20,000.00</div>\
                                    <div>Valor actual: 20.00</div>\
                                  </td>\
                                  <td>\
                                    <img src="../../Imgs/CentroCanje/billetes/billete1.png">\
                                    <div class="txtG1">Denominación: 1,000.00</div>\
                                    <div>Valor actual: 1.00</div>\
                                  </td>\
                                  <td>\
                                    <img src="../../Imgs/CentroCanje/billetes/billete100.png">\
                                    <div class="txtG1">Denominación: 100.00</div>\
                                    <div>Valor actual: 100.00</div>\
                                  </td>\
                                  <td>\
                                    <img src="../../Imgs/CentroCanje/billetes/billete20-1.png">\
                                    <div class="txtG1">Denominación: 20.00</div>\
                                    <div>Valor actual: 20.00</div>\
                                  </td>\
                                </tr>\
                                <tr>\
                                  <td>\
                                    <img src="../../Imgs/CentroCanje/billetes/billete10.png">\
                                    <div class="txtG1">Denominación: 10,000.00</div>\
                                    <div>Valor actual: 10.00</div>\
                                  </td>\
                                  <td>\
                                    <img src="../../Imgs/CentroCanje/billetes/billete1-1.png">\
                                    <div class="txtG1">Denominación: 1,000.00</div>\
                                    <div>Valor actual: 1.00</div>\
                                  </td>\
                                  <td>\
                                    <img src="../../Imgs/CentroCanje/billetes/billete01.png">\
                                    <div class="txtG1">Denominación: 100.00</div>\
                                    <div>Valor actual: 0.10</div>\
                                  </td>\
                                  <td>&nbsp;</td>\
                                </tr>\
                                <tr>\
                                  <td>\
                                    <img src="../../Imgs/CentroCanje/billetes/billete10-1.png">\
                                    <div class="txtG1">Denominación: 10,000.00</div>\
                                    <div>Valor actual: 10.00</div>\
                                  </td>\
                                  <td>\
                                    <img src="../../Imgs/CentroCanje/billetes/billete500.png">\
                                    <div class="txtG1">Denominación: 500.00</div>\
                                    <div>Valor actual: 500.00</div>\
                                  </td>\
                                  <td>\
                                    <img src="../../Imgs/CentroCanje/billetes/billete0.png">\
                                    <div class="txtG1">Denominación: 100.00</div>\
                                    <div>Valor actual: 0.00</div>\
                                  </td>\
                                  <td>&nbsp;</td>\
                                </tr>\
                              </tbody>\
                            </table>\
                            <div class="clear"></div>\
                            <br>\
                            <div class="botones1">\
                                <a href="#" class="btnB w48  simplemodal-close" >Salir</a>\
                            </div><br>\
                        </div>';
            break;

            case "modalBilletes":
                content = '<div class="cuadro">\
                            <a href="#" class=" simplemodal-close" id="botonCerrar">\
                                <img src="../../Imgs/CentroCanje/cerrar.png" class="cerrar">\
                            </a>\
                            <div class="billete1"><!-- Secc1 Billetes -->\
                                <div class="titModal">Billetes incompletos</div>\
                                <div class="titNegro tLeft w90">Con valor</div>\
                                <div class="clear"></div><br>\
                                <div class="cont">\
                                    <div class="col1">\
                                        <ul class="buletBillete" type="square">\
                                            <li><span>Tiene completo en número de folio, es auténtico y no tiene injertos o fracciones de otro u otros billetes.</span></li>\
                                            <li><span>Tiene más de la mitad de la superficie de un billete completo.</span></li>\
                                            <li><span>Presenta porciones faltantes por haber sido engrapados, sin embargo, la suma de la superficie de los faltantes no supera los 616 milímetros cuadrados.<br>\
                                            <div>Aproximadamente la superficie de una moneda de 10 pesos</div>\
                                            </span></li>\
                                            <li><span>Tiene el 80% de la superficie original del billete sin importar dónde está el faltante.</span></li>\
                                            <li><span>En billetes de alta denominación, el corte debe ser 12.4 cm. o más.</span></li>\
                                            <li><span>En billetes de baja denominación, el corte debe ser 10.3 cm. o más.</span></li>\
                                        </ul>\
                                    </div>\
                                    <div class="col2"><img src="../../Imgs/CentroCanje/billetes/billeteIncompleto.png" class="imgMoney"></div>\
                                </div>\
                            </div>\
                                <div class="billete2"><!-- Secc2 Billetes -->\
                                    <div class="titModal">Billetes incompletos</div>\
                                    <div class="titNegro tLeft w90">Sin valor</div>\
                                    <div class="clear"></div><br>\
                                    <div class="cont">\
                                        <div class="col1">\
                                            <ul class="buletBillete" type="square">\
                                                <li><span>Tiene completo en número de serie, pero tiene menos de la mitad de un billete.</span></li>\
                                                <li><span>Tiene la mitad o más de un billete completo, pero no tiene el número de folio.</span></li>\
                                                <li><span>Tiene el número de folio completo pero el faltante supera los 616 milímetros cuadrados.<br>\
                                                <div>Aproximadamente la superficie de una moneda de 10 pesos</div>\
                                                </span></li>\
                                            </ul>\
                                        </div>\
                                        <div class="col2"><img src="../../Imgs/CentroCanje/billetes/billeteIncompleto2.png"" class="imgMoney"></div>\
                                    </div>\
                                </div>\
                                <div class="billete3"><!-- Secc1 Billetes -->\
                                    <div class="titModal">Billetes marcados</div>\
                                    <div class="titNegro tLeft w90">Con valor</div>\
                                    <div class="clear"></div><br>\
                                    <div class="cont">\
                                        <div class="col1">\
                                            <ul class="buletBillete" type="square">\
                                                <li><span>Tiene mensajes dirigidos al público, firmas y dibujos ajenos al entorno político, religioso o comercial.</span></li>\
                                                <li><span>Tiene sellos incompletos de bancos, empresas de traslado de valores u otros rubros comerciales donde no se aprecia el logotipo o el nombre completo de la empresa.</span></li>\
                                                <li><span>Es auténtico pero presenta descoloramiento de sus partes por haber sido mojado.</span></li>\
                                                <li><span>Presenta alteraciones en la imagen, el importe o el número de serie hechas con una pluma o marcador sin intención de divulgar mensajes políticos, religiosos o comerciales.</span></li>\
                                            </ul>\
                                        </div>\
                                        <div class="col2"><img src="../../Imgs/CentroCanje/billetes/billeteMarcado.png" class="imgMoney"></div>\
                                    </div>\
                                </div>\
                                <div class="billete4"><!-- Secc1 Billetes -->\
                                    <div class="titModal">Billetes marcados</div>\
                                    <div class="titNegro tLeft w90">Sin valor</div>\
                                    <div class="clear"></div><br>\
                                    <div class="cont">\
                                        <div class="col1">\
                                            <ul class="buletBillete" type="square">\
                                                <li><span>Tiene palabras, frases o dibujos en forma manuscrita, impresa o cualquier otro medio indeleble que tiene como finalidad divulgar mensajes dirigidos al público de carácter político, religioso o comercial.</span></li>\
                                                <li><span>Tiene sellos completos de bancos, empresas de traslado de valores u otros rubros comerciales, donde se aprecia el logotipo o nombre completo de la empresa.</span></li>\
                                                <li><span>Tiene marcas sistemáticas e intencionales para forzar el deterioro de los billetes.</span></li>\
                                            </ul>\
                                        </div>\
                                        <div class="col2"><img src="../../Imgs/CentroCanje/billetes/billeteMarcado1.png" class="imgMoney"></div>\
                                    </div>\
                                </div>\
                                <div class="clear"></div><br>\
                                <div class="menuMoney">\
                                    <a href="#" class="bill1 item itemAct">\
                                        <img src="../../Imgs/CentroCanje/cuadroV.jpg" class="png">\
                                        Incompleto con valor\
                                    </a>\
                                    <a href="#" class=" bill2 item">\
                                        <img src="../../Imgs/CentroCanje/cuadroT.png" class="png">\
                                        Incompleto sin valor\
                                    </a>\
                                    <a href="#" class=" bill3 item">\
                                        <img src="../../Imgs/CentroCanje/cuadroT.png" class="png">\
                                        Marcado con valor\
                                    </a>\
                                    <a href="#" class="bill4 item">\
                                    <img src="../../Imgs/CentroCanje/cuadroT.png" class="png">\
                                        Marcado sin valor\
                                    </a>\
                                </div>\
                                <div class="clear"></div>\
                                <br>\
                            </div>';
            break;

            default:
              content = '<p>No se eligío un mensaje valido para mostrar<\p>'
            break;
        }
        return content;
    }
};