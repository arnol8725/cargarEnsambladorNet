
jQuery(function ($) {
		
		$('.numSerie').click(function (e) {
			
			$('#modalNumeroSerie').modal();
			return false;
		});
		
		$('#modalNumeroSerie1_view').click(function (e) {
			setTimeout(function() {
				$('#modalNumeroSerie1').modal({
				});
				return false;
			}, 1);
		});
	
		$('#inputImporte_view').click(function (e) {
			setTimeout(function() {
				$('#inputImporte').modal({
				});
				return false;
			}, 1);
		});
	
		$('.modalEliminar_view').click(function (e) {
				$('#modalEliminar').modal();
				return false;
			});
		});

		$('.modalDenominaciones1_view').click(function (e) {
				$('#modalDenominaciones1').modal();
				return false;
			});


		$('.modalDenominaciones2_view').click(function (e) {
				$('#modalDenominaciones2').modal();
				return false;
			});

		$('.modalBilletes_view').click(function (e) {
				$('#modalBilletes').modal();
				return false;
			});




		$('#idImporte').change(function() {
			if($('#idImporte option:selected').val() == 1) {
				$('#modalDemoninaciones').modal();
			}
		});

		// $('#modalCambioExito_view').click(function (e) {
		// 	setTimeout(function() {
		// 		$('#modalCambioExito').modal({
		// 		});
		// 		return false;
		// 	}, 1);
		// });
//Calendario
	
$.datepicker.regional['es'] = {
 closeText: 'Cerrar',
 prevText: '',
 nextText: ' ',
 currentText: 'Hoy',
 monthNames: ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'],
 monthNamesShort: ['Ene','Feb','Mar','Abr', 'May','Jun','Jul','Ago','Sep', 'Oct','Nov','Dic'],
 dayNames: ['Domingo', 'Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado'],
 dayNamesShort: ['Dom','Lun','Mar','Mié','Juv','Vie','Sáb'],
 dayNamesMin: ['Do','Lu','Ma','Mi','Ju','Vi','Sá'],
 weekHeader: 'Sm',
 dateFormat: 'dd/mm/yy',
 firstDay: 1,
 isRTL: false,
 showMonthAfterYear: false,
 yearSuffix: ''
 };
$.datepicker.setDefaults($.datepicker.regional['es']);
$(function() {
	$( "#datepicker1" ).datepicker({
		firstDay: 1 
	});
	$( "#datepicker2" ).datepicker({
		firstDay: 1 
	});
	$( "#datepicker3" ).datepicker({
		firstDay: 1 
	});
	$( "#datepicker4" ).datepicker({
		firstDay: 1 
	});
	$( "#datepicker5" ).datepicker({
		firstDay: 1 
	});
});


// Select
$( ".normal_select").dropkick({
	mobile: true
});

//Eliminar
$(function(){
	$('.menos').on('click',function(e){
		e.preventDefault();
		$(this).parent().parent().remove(); 
	});
});


	//Centro de canje de efectivo
$("div.aviso1").hide();
$("div.aviso2").hide();
$("div.aviso3").hide();
$("div.aviso4").hide();

	
$("#checkCanje1").click(function() {  
	if($(this).is(':checked')) {  
		$("div.aviso1").show();
		$("div.aviso2").hide();
		$("div.aviso3").hide();
		$("div.aviso4").hide();
	}  
});  
	
	
$("#checkCanje2").click(function() {  
	if($(this).is(':checked')) {  
		$("div.aviso1").hide();
		$("div.aviso2").show();
		$("div.aviso3").hide();
		$("div.aviso4").hide();
	}  
});  
$("#checkCanje3").click(function() {  
	if($(this).is(':checked')) {  
		$("div.aviso1").hide();
		$("div.aviso2").hide();
		$("div.aviso3").show();
		$("div.aviso4").hide();
	}  
});  
$("#checkCanje4").click(function() {  
	if($(this).is(':checked')) {  
		$("div.aviso1").hide();
		$("div.aviso2").hide();
		$("div.aviso3").hide();
		$("div.aviso4").show();
	}  
});  

$(".menuMoney a.item").click(function (e) {
	$(".menuMoney a.item").removeClass("itemAct");
	$(this).addClass("itemAct");
});

	$(".billete1").show();
	$(".billete2").hide();
	$(".billete3").hide();
	$(".billete4").hide();

$('a.bill1').click(function (e) {
	$('.bill1 img').attr('src', 'img/cuadroV.jpg');
	$('.bill2 img').attr('src', 'img/cuadroT.png');
	$('.bill3 img').attr('src', 'img/cuadroT.png');
	$('.bill4 img').attr('src', 'img/cuadroT.png');
	$(".billete1").show();
	$(".billete2").hide();
	$(".billete3").hide();
	$(".billete4").hide();
});

$('a.bill2').click(function (e) {
	$('.bill1 img').attr('src', 'img/cuadroT.png');
	$('.bill2 img').attr('src', 'img/cuadroV.jpg');
	$('.bill3 img').attr('src', 'img/cuadroT.png');
	$('.bill4 img').attr('src', 'img/cuadroT.png');
	$(".billete1").hide();
	$(".billete2").show();
	$(".billete3").hide();
	$(".billete4").hide();
});

$('a.bill3').click(function (e) {
	$('.bill1 img').attr('src', 'img/cuadroT.png');
	$('.bill2 img').attr('src', 'img/cuadroT.png');
	$('.bill3 img').attr('src', 'img/cuadroV.jpg');
	$('.bill4 img').attr('src', 'img/cuadroT.png');
	$(".billete1").hide();
	$(".billete2").hide();
	$(".billete3").show();
	$(".billete4").hide();
});

$('a.bill4').click(function (e) {
	$('.bill1 img').attr('src', 'img/cuadroT.png');
	$('.bill2 img').attr('src', 'img/cuadroT.png');
	$('.bill3 img').attr('src', 'img/cuadroT.png');
	$('.bill4 img').attr('src', 'img/cuadroV.jpg');
	$(".billete1").hide();
	$(".billete2").hide();
	$(".billete3").hide();
	$(".billete4").show();
});