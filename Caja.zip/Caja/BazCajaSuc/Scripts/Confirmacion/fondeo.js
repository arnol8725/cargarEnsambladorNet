﻿
$(document).ready(function () {
    mostrarCarga(true);
    document.title = titulo;
    divisa = divisa == '' ? "1" : divisa;
    desc_divisa = desc_divisa = '' ? "Moneda Nacional" : desc_divisa;
    $('#desc_divisa').html(desc_divisa);
    if (id_page_select == "caja") {
        wsConsultaConfirmacionPendientes("F");
    } else {
        //Cargar consulta fondeo de cajero
        $('#solicitaFondeocajero').hide(); //Ocultar boton fondear cuando es fondeo de cajero
        wsConsultaConfirmacionPendientes("T");
    }
});

function separaTraspFondeoCajero(input){
    let jsonAux=input;
let jsonTraspasos=[];
let jsonDenominacion=[];
let queryResult=[]
for (let valTraspasos of jsonAux){
	let queryTraspasos = Enumerable.From(jsonAux)
    .Where(function (x) { return x.Concentracion ==valTraspasos.Concentracion})    
    .Select(function (x) { return x }).ToArray();          
    if(queryTraspasos.length>0){
    	queryResult.push(queryTraspasos);
    }
	jsonAux=jsonAux.filter(function(itm){return itm.Concentracion!==valTraspasos.Concentracion});     
}

for (let val of queryResult){
	let aux=val[0];  
	for(let c of val){
  	let aux=c;
      	let query = Enumerable.From(val)
    					.Where(function (y) { return y.Concentracion ==c.Concentracion})   
    					.Select(function (y) { return y }).ToArray(); 
    		//console.log(queryDep);
    		if (query.length>0){        	
        	jsonDenominacion=query;//push({"concentracion": aux.Concentracion, "denominaciones":query});        
        }
        val=val.filter(function(itm){return itm.Concentracion!==c.Concentracion}); 
  }
  jsonTraspasos.push({"Concentracion":aux.Concentracion, "Importe": aux.Importe, "NoCajero": aux.NoCajero, "NomCajEmisor": aux.NomCajEmisor, "Operacion":aux.Operacion, "Origen":aux.Origen,"PuestoSaldo":aux.PuestoSaldo, "UltimoTraspaso":aux.UltimoTraspaso, "denominaciones":jsonDenominacion});
}
console.log(jsonTraspasos);
return jsonTraspasos;
}