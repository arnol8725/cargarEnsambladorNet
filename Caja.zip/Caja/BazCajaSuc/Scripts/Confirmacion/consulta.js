﻿var dateIni = undefined;
var dateFin = undefined;
var fechaIni = "";
var fechaFin = "";
var opcion="4";
var egresosDetalle=[];

var fechaIniC=false;
var fechaFinC=false;

//Calendario
$j.datepicker.regional['es'] = {
    closeText: 'Cerrar',
    prevText: '',
    nextText: ' ',
    currentText: 'Hoy',
    monthNames: ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'],
    monthNamesShort: ['Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun', 'Jul', 'Ago', 'Sep', 'Oct', 'Nov', 'Dic'],
    dayNames: ['Domingo', 'Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado'],
    dayNamesShort: ['Dom', 'Lun', 'Mar', 'Mié', 'Juv', 'Vie', 'Sáb'],
    dayNamesMin: ['Do', 'Lu', 'Ma', 'Mi', 'Ju', 'Vi', 'Sá'],
    weekHeader: 'Sm',
    dateFormat: 'dd/mm/yy',
    firstDay: 01,
    isRTL: false,
    showMonthAfterYear: false,
    yearSuffix: ''
};
$j.datepicker.setDefaults($j.datepicker.regional['es']);
$j(function () {
    $j("#fechaIni").datepicker({
        firstDay: 1
    });
});

$j(function () {
    $j("#fechaFin").datepicker({
        firstDay: 1
    });
});

$j("#fechaFin").datepicker({
    onSelect: function () {
        alert(this.value);
    }
});


$(document).ready(function () {
    mostrarCarga(true);
    document.title = titulo;
    divisa = divisa == '' ? "1" : divisa;
    desc_divisa = desc_divisa = '' ? "Moneda Nacional" : desc_divisa;
    onChangeDivisaConsulta();
    //Cargar tipo pago
    wsConsultaTiposdePago();
});

function onChangeDivisaConsulta(){
    $('#desc_divisa').html(desc_divisa);
    $("#fechaFin").attr("disabled", true);
    $("#fechaFin").val("");
    $("#fechaIni").attr("disabled", true);
    $("#fechaIni").val("");
    $("#egresos").hide();  
    $('#imprimirconsulta').hide();  
    $("#btnConsulta").attr("disabled", true);
}

function onChangeFechaIni(date){
    $("#fechaFin").attr("disabled", true);
    $("#btnConsulta").attr("disabled", true);
    if(date.value!="" ){
        fechaIni= date.value;   
        const [dayI, monthI, yearI] = fechaIni.split("/");
        dateIni = new Date(yearI, monthI - 1, dayI);
        let today = new Date();
        if(dateIni.toString()=="Invalid Date" || dateIni>today) {
            alert("Fecha inválida");
        }else{
            if (dateFin){             
                if(dateIni<=dateFin){
                    $('#fechaFin').removeAttr("disabled");
                    $("#btnConsulta").removeAttr("disabled");
                    changeFechaIni=true;
                }else{ 
                    alert("Rango de fechas inválido");
                }
            }else{
                $('#fechaFin').removeAttr("disabled");
            }
        }
    }
}

function onChangeFechaFin(date){
    if(date.value!=""){
        fechaFin = date.value;
        const [dayF, monthF, yearF] = fechaFin.split("/");     
        dateFin = new Date(yearF, monthF - 1, dayF);
        let today = new Date();
        if(dateIni.toString()!="Invalid Date" && dateFin>=dateIni && dateFin<=today) {
            $('#btnConsulta').removeAttr("disabled");
            changeFechaFin=true;
        }else{        
            $("#btnConsulta").attr("disabled", true);
            alert("Rango de fechas inválido");
        }
    }
}


function separaEgresosConsulta(input){
    let jsonAux=input;
    let jsonEgresos=[];
    let jsonDepositos=[];
    let queryResultE=[]
    for (let valEgreso of jsonAux){
	    let queryEgresos = Enumerable.From(jsonAux)
            .Where(function (x) { return x.NoEgreso ==valEgreso.NoEgreso})    
            .Select(function (x) { return x }).ToArray();          
        if(queryEgresos.length>0){
    	    queryResultE.push(queryEgresos);
        }
	    jsonAux=jsonAux.filter(function(itm){return itm.NoEgreso!==valEgreso.NoEgreso});     
    }
    let numDoctos=0;
    for (let val of queryResultE){
    	let aux=val[0];
        jsonDepositos=[];        
	    for(let dep of val){
  	        let auxDep=dep;
      	    let queryDep = Enumerable.From(val)
    		    .Where(function (y) { return y.Deposito ==dep.Deposito})   
    			.Select(function (y) { return {"noEgreso": y.NoEgreso, "noDeposito": y.Deposito, "fecha":y.FechaConf, "noOperacion":auxDep.TranDep,
                                               "emisor":y.Emisor, "numDocto": y.Numero, "importe": y.MontoDocto} }).ToArray();    		
    		if (queryDep.length>0){
                numDoctos+=queryDep.length;
        	    jsonDepositos.push({"noEgreso": auxDep.NoEgreso,"noDeposito": auxDep.Deposito, "noOperacion":auxDep.TranDep, 
                                    "fecha": auxDep.FechaDep, "emisor": auxDep.EmisorConf, "importe":auxDep.ImporteDep, 
                                    "documentos":queryDep});        
            }
            val=val.filter(function(itm){return itm.Deposito!==dep.Deposito}); 
        }
        jsonEgresos.push({"noEgreso":aux.NoEgreso, "noOperacion": aux.TranEgr, "fecha": aux.FechaEgr, "emisor": aux.EmisorEgr, 
                          "importe":aux.ImporteEgr, "numDoctos":numDoctos, "depositos":jsonDepositos});
    }
    console.log(jsonEgresos);    
    return jsonEgresos;
}

function llenaEgresosConsulta(array) {    
    let egresos= separaEgresosConsulta(array);
    let accordion='<dl class="accordion">';
    if(egresos.length>0)
        $('#imprimirconsulta').show();
    else
        $('#imprimirconsulta').hide();   
    $.each(egresos, function (i, p) {
        accordion += '<dt id="dtEgresos'+i+'" class="AcoInpar" onclick="expand(dtEgresos'+i+')">'+
                       '<table class="tblGeneral3 w90 tLeft">' +
                         '<tbody>'+
                           '<tr>' +
                             '<td class="tLeft">'+p.noEgreso+'</td>'+
                             '<td>&nbsp;</td>'+
                             '<td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'+p.noOperacion+'</td>'+
                             '<td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'+p.fecha+'</td>'+
                             '<td>&nbsp;&nbsp;&nbsp;'+p.emisor+'</td>'+
                             '<td>&nbsp;</td>'+
                             '<td style="text-align: right;">'+formatMoney(Number(p.importe))+'</td>'+
                            '</tr>' +
                          '</tbody>'+
                        '</table>' +
                      '</dt>' +
                      '<dd id="ddEgresos'+i+'" class="AcoInpar" style="display: none;">' +
                        '<div class="inner">' +
                         '<div class="nivel2">';            
       $.each(p.depositos, function (j, d) {
            accordion += '<dl class="accordion">' +
                           '<dt id="dtDepositos'+j+i+'" onclick="expand(dtDepositos'+j+i+')">'+
                            '<table class="tblGeneral3 w90 tLeft">' +
                             '<tbody>'+
                               '<tr>' +
                                 '<td>&nbsp;</td>'+
                                 '<td>'+d.noDeposito+'</td>'+
                                 '<td>'+d.noOperacion+'</td>'+
                                 '<td>'+d.fecha+'</td>'+
                                 '<td>'+d.emisor+'</td>'+
                                 '<td>&nbsp;</td>'+
                                 '<td style="text-align: right;">'+formatMoney(Number(d.importe))+'</td>'+
                               '</tr>' +
                              '</tbody>'+
                             '</table>' +
                           '</dt>' +
                           '<dd id="ddDepositos'+j+i+'" class="AcoInpar" style="display: none;">' +
                             '<div class="inner">' +
                               '<div>';                
           $.each(d.documentos, function (k, doc) {
                 accordion += ' <dl class="accordion">' +
                                 '<dd id="dtDocuments'+k+'" class="AcoInpar">'+                                  
                                     '<table class="tblGeneral3">' +
                                        '<tbody>'+
                                       '<tr>' +
                                         '<td>&nbsp;</td>'+
                                         '<td>&nbsp;</td>'+
                                         '<td>&nbsp;</td>'+
                                         '<td>&nbsp;&nbsp;'+doc.fecha+'</td>'+
                                         '<td>'+doc.emisor+'</td>'+
                                         '<td>'+doc.numDocto+'</td>'+
                                         '<td style="text-align: right;">'+formatMoney(Number(doc.importe))+'</td>'+
                                       '</tr>' +
                                     '</tbody>'+
                                    '</table>' +                                    
                                  '</dd>' ;
            });
                accordion += '</dl></div>' +
                            '</div>' +
                          '</dd>' +
                          '<div class="clear"></div>';
      });
      accordion += '</dl></div>' +
                 '</div>' +
               '</dd>' +
               '<div class="clear"></div>'; 
    });
    accordion+='</dl>';
    $('#egresos').html(accordion); 
    $("#egresos").show();
    egresosDetalle=egresos;
    mostrarCarga(false);   
}

function getUrlImg() {    
    let url = "";
    url=window.location.hostname == "localhost"?"\\\\10.54.28.114":"\\\\"+window.location.hostname;
    url+="\\ADN\\BMP\\Logos\\logoBAZBN.jpg";
    return url;
}

function imprimirEgresos(){    
    mostrarCarga(true); 
    $.when(generaTicket(construirTicketEgresos(), false, true)).done(function(result){       
        if(result.Contenido>0){
            mostrarCarga(true); 
            $.when(imprimirTicket(result.Contenido, false, true)).done(function(resultI){                
                mostrarCarga(false);
                $j.modal.close();
                $j('#modal09').modal();
            }).fail(function(){ 
                mostrarCarga(false);
                $j.modal.close();
                $j('#modal09').modal();});           
        }        
    }).fail(function(){ 
        mostrarCarga(false);
        $j.modal.close();
        $j('#modal09').modal();});
}



function construirTicketEgresos(){
    let contenido="<TICKET>"+
                    "<IMG POSX = \"5\" HEIGHT  = \"10\" WIDTH  = \"60\" PATH = \""+getUrlImg()+"\"></IMG>"+
                    "<LINE POSX = \"0\" WIDTH = \"100\" BORDERWIDTH = \"0.3\"></LINE>"+
                    "<TEXT ALIGNH = \"LEFT\" FONTFAMILY = \"Calibri\" FONTSIZE = \"9\" FONTTYPE = \"N\">"+sucNum+"-"+sucName+"</TEXT>"+
                    "<TEXT ALIGNH = \"LEFT\" FONTFAMILY = \"Calibri\" FONTSIZE = \"7\" FONTTYPE = \"N\">Ticket impreso el dia: "+getFecha()+"</TEXT>"+
                    "<TEXT></TEXT><TEXT></TEXT><TEXT ALIGNH = \"LEFT\" FONTFAMILY = \"Calibri\" FONTSIZE = \"6\" FONTTYPE = \"B\">Relacion de documentos Egresados del "+fechaIni+" al "+fechaFin+"</TEXT>"+
                    "<TEXT ALIGNH = \"LEFT\" FONTFAMILY = \"Calibri\" FONTSIZE = \"7\" FONTTYPE = \"B\">Tipo de pago: "+tipoPago+"</TEXT><TEXT></TEXT><TEXT></TEXT>"+
                    "<TEXT ALIGNH = \"LEFT\" FONTFAMILY = \"Calibri\" FONTSIZE = \"7\" FONTTYPE = \"B\">No. Egreso    No.Operacion      Fecha          Documentos      Importe</TEXT>"+
                    "<LINE POSX = \"1\" WIDTH = \"100\" BORDERWIDTH = \"0.3\"></LINE>";
    let totalDoctos=0;
    let importeTotal=0;
    for(let egreso of egresosDetalle){
        totalDoctos+=egreso.numDoctos;
        importeTotal+=Number(egreso.importe);
        contenido+="<TEXT ALIGNH = \"LEFT\" FONTFAMILY = \"Calibri\" FONTSIZE = \"7\" FONTTYPE = \"B\">  "+egreso.noEgreso+"            "+egreso.noOperacion+"         "+egreso.fecha+"            "+egreso.numDoctos+"          "+formatMoney(egreso.importe)+"               </TEXT>";
    }
    contenido+="<LINE POSX = \"40\" WIDTH = \"40\" BORDERWIDTH = \"0.3\"></LINE>"+
               "<TEXT ALIGNH = \"RIGHT\" FONTFAMILY = \"Calibri\" FONTSIZE = \"7\" FONTTYPE = \"B\">TOTAL:             "+totalDoctos+"                 "+formatMoney(importeTotal)+"               </TEXT></TICKET>";
    let listaTickets={"ListaTickets":[{
		                "Aplicacion":"Caja",
		                "Contenido":contenido,
		                "NoCopias": 1
	                 }]};
    console.log(listaTickets);
    return listaTickets;
}