﻿var detalleDocuments=[];
var docsLista=[];
var detalleDocsLista=[];

$(document).ready(function () {
    mostrarCarga(true);
    document.title = titulo;
    divisa = divisa == '' ? "1" : divisa;
    desc_divisa = desc_divisa = '' ? "Moneda Nacional" : desc_divisa;
    $('#desc_divisa').html(desc_divisa);
    $(".documentos").hide();

    $('#radio1').on("change", function () {
        $('.efectivo').show();
        $('.documentos').hide();
        return false;
    });
    $('#radio2').on("change", function () {
        $('.efectivo').hide();
        $('.documentos').show();
        return false;
    });
    wsConsultaRecepcionConcentracionSaldosCajeroaCaja("D");
});

function separaDocs(input){
    let jsonAux=input;
    let jsonDocumentos=[];
    let jsonDepositos=[];
    let queryResult=[]
    for (let valTipos of jsonAux){
	    let queryTipos = Enumerable.From(jsonAux)
                        .Where(function (x) { return x.TipoPago ==valTipos.TipoPago})    
                        .Select(function (x) { return x }).ToArray();          
        if(queryTipos.length>0){
        	queryResult.push(queryTipos);
        }
	    jsonAux=jsonAux.filter(function(itm){return itm.TipoPago!==valTipos.TipoPago});     
    }
    for (let val of queryResult){
	    let aux=val[0];
        jsonDepositos=[];
	    for(let dep of val){
  	        let auxDep=dep;
      	    let queryDep = Enumerable.From(val)
    					.Where(function (y) { return y.NoDeposito ==dep.NoDeposito})   
    					.Select(function (y) { return {"tipoPago": y.TipoPago, "noDeposito": y.NoDeposito, "numDocto":y.Docto, "importe":y.ImporteDoc, "noOperacion": y.Notransac} }).ToArray();     		
    		if (queryDep.length>0){
        	    //if(Number(auxDep.NoDoctosTrasp)==0) queryDep=[];
        	    jsonDepositos.push({"tipoPago": auxDep.TipoPago, "noDeposito": auxDep.NoDeposito, "emisor":auxDep.NombreCorto, "fecha":auxDep.FecDep, "importe": auxDep.Importe, "documentos":queryDep});        
            }
            val=val.filter(function(itm){return itm.NoDeposito!==dep.NoDeposito}); 
        }
        //if(Number(aux.NoDepositos)==0) jsonDepositos=[];
        jsonDocumentos.push({"tipoPago":aux.TipoPago, "descTipo": aux.TpagDesc, "numDepositos": aux.NoDepositos, "numDoctos": aux.NoDoctosTrasp, "importe":aux.TotalTrasp, "depositos":jsonDepositos});
   }
    console.log(jsonDocumentos);    
    return jsonDocumentos;
}

function llenaDocumentos(array) {    
    detalleDocuments= separaDocs(array);
    let accordion='<dl class="accordion">';   
    let importeDocs=0;
    let cantTraspasos=0;
    $.each(detalleDocuments, function (i, p) {
        importeDocs+=Number(p.importe);
        cantTraspasos+=Number(p.numDepositos);
        accordion += "<div class='checks'>" +
                        "<input type='checkbox' onchange='onCheckTipoPago("+i+","+true+")' id='checkTipo"+i+"' />"+
					    "<label for='checkTipo"+i+"'></label>"+
				     "</div>"+
                '<dt id="dtTipoPago'+i+'" class="AcoInpar" onclick="expand(dtTipoPago'+i+')">'+
                       '<table class="tblGeneral3 w90 tLeft">' +                       
                         '<tbody>'+
                           '<tr>' +
                             '<td>'+p.descTipo+'</td>'+                             
                             '<td style="text-align: right;">'+Number(p.numDepositos)+'</td>'+    
                             '<td>&nbsp;</td>'+                                                   
                             '<td class="tRight">'+Number(p.numDoctos)+'</td>'+                             
                             '<td class="tRight">'+formatMoney(Number(p.importe))+'</td>'+                             
                            '</tr>' +
                          '</tbody>'+
                        '</table>' +
                      '</dt>' +
                      '<dd id="ddTipoPago'+i+'" class="AcoInpar" style="display: none;">' +
                        '<div class="inner">' +
                         '<div style="margin-left: 10%;">';            
       $.each(p.depositos, function (j, d) {
            
            accordion += '<dl class="accordion">' + 
                           "<div class='checks'>" +
                             "<input type='checkbox' onchange='onCheckDeposito("+i+","+j+")' id='checkDep"+j+i+"' />"+
					         "<label for='checkDep"+j+i+"'></label>"+
				           "</div>"+                                                                               
                           '<dt id="dtDepositos'+j+i+'" onclick="expand(dtDepositos'+j+i+')">'+
                            '<table class="tblGeneral3 w90" style="text-align: right;">' +
                             '<tbody>'+
                               '<tr>' +
                                 '<td>&nbsp;</td>'+                                 
                                 '<td>'+d.noDeposito+'&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>'+
                                 '<td>'+d.emisor+'&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>'+
                                 '<td>'+d.fecha+'</td>'+                                 
                                 '<td class="tRight">'+formatMoney(Number(d.importe))+'</td>'+
                               '</tr>' +
                              '</tbody>'+
                             '</table>' +
                           '</dt>' +
                           '<dd id="ddDepositos'+j+i+'" class="AcoInpar" style="display: none;">' +
                             '<div class="inner">' +
                               '<div style="margin-left: 20%;">';                                   
           $.each(d.documentos, function (k, doc) {
                 accordion += ' <dl class="accordion">' +
                                 '<dd id="dtDocuments'+k+'" class="AcoInpar">'+                                  
                                     '<table class="tblGeneral3" style="text-align: right;">' +
                                        '<tbody>'+
                                       '<tr>' +                                         
                                         '<td>&nbsp;</td>'+
                                         '<td>&nbsp;</td>'+
                                         '<td>&nbsp;</td>'+
                                         '<td>'+doc.numDocto+'</td>'+
                                         '<td class="tRight">'+formatMoney(Number(doc.importe))+'</td>'+
                                       '</tr>' +
                                     '</tbody>'+
                                    '</table>' +                                    
                                  '</dd>' ;
            });
                accordion += '</dl></div>' +
                            '</div>' +
                          '</dd>' +
                          '<div class="clear"></div>';
      });
      accordion += '</dl></div>' +
                 '</div>' +
               '</dd>' +
               '<div class="clear"></div>'; 
    });
    accordion+='</dl>';
    $('#documentosPend').html(accordion);     
    $('#traspConfirmDoc'+page_select).html(cantTraspasos);
    $('#saldoConfirmDoc'+page_select).html(formatMoney(importeDocs));
}

function onCheckTipoPago(id, all){
    detalleDocsLista=[];    
    let importe = 0;
    let subImporte=0;
    $('#btnDoc'+page_select).attr("disabled", true);
    if($('#checkTipo'+id).is(':checked') && Number(detalleDocuments[id].importe)<=0 ){
        $('#checkTipo'+id).prop('checked', false);
    }else{
        let saldo= deleteFormatMoney($('#importeDocconcentracion').val());
        let imp = detalleDocuments[id].importe;
        if(Number(imp)>0){
			docsLista=[];
			detalleDocsLista=[];

			//if($('#checkTipo'+id).is(':checked')){
				$.each(detalleDocuments, function (i, doc) {
					detalleDocsLista=[];
					if($('#checkTipo'+i).is(':checked')){
                        subImporte=0;
						$.each(doc.depositos, function (j, det) {                            
							if (all && i == id){
								if(Number(det.importe)>0)
									$('#checkDep'+j+i).prop('checked', true);
							}
							if($('#checkDep'+j+i).is(':checked') && Number(det.importe)>0){
                                importe += Number(det.importe);
                                subImporte+=Number(det.importe);
                                $.each(det.documentos, function (k, documents) {								    
								    detalleDocsLista.push({ "Importe":  documents.importe.toString(), 
                                        "NoDocto": documents.numDocto, "NoDeposito": documents.noDeposito, 
                                        "NoOperacion": documents.noOperacion});
                                });
							}
						});
						if(subImporte>0)
							docsLista.push({ "Tipo_PagoId": doc.tipoPago, "TipoPagoDesc":doc.descTipo, 
                            "SaldoTotal": importe.toString(),
                              "LstDocumento": detalleDocsLista}); 
					}	
				});        
			//}else{
                //importe=saldo-Number(detalleDocuments[id].importe);
                if(!$('#checkTipo'+id).is(':checked')){
				    $.each(detalleDocuments[id].depositos, function (j, doc) { 
				        $('#checkDep'+j+id).prop('checked', false);                    
				    });               				
                }
			//}
			$('#importeDocconcentracion').val(importe.toFixed(2));
            if(importe>0)
			    $('#btnDoc'+page_select).removeAttr("disabled");
		}else{
            $('#checkTipo'+id).prop('checked', false);            
        }
    }
    if($('#selectDocs').is(':checked')) validaChecks();
    traspasoSelect={
        Concentracion : importe
    };
    console.log(docsLista);
}

function onCheckDeposito(id, idDetalle){
    if($('#checkDep'+idDetalle+id).is(':checked')){
        let saldo= deleteFormatMoney($('#importeDocconcentracion').val());
        let imp = detalleDocuments[id].depositos[idDetalle].importe;
        if(Number(imp)<=0){
            $('#checkDep'+idDetalle+id).prop('checked',false);            
        }else{
            $('#checkTipo'+id).prop('checked',true);
            onCheckTipoPago(id, false);
        }
    }else{        
        validaDetalle(detalleDocuments[id].depositos.length, id);
        onCheckTipoPago(id, false);
    }       
}

function validaDetalle(size, id){
    let status=false;
    for (let i=0; i<size;i++){       
        status= $('#checkDep'+i+id).is(':checked');
        if(status)break;
    }
    $('#checkTipo'+id).prop('checked', status);
    return status;
}

function checkUncheckDocs(status, changeList){
    for (let i=0; i<detalleDocuments.length;i++){
        $('#checkTipo'+i).prop('checked', status);
        if (changeList)
            onCheckTipoPago(i, true);                    
    }
}

function selectDocs(){
    checkUncheckDocs($('#selectDocs').is(':checked'), true);  
    validaChecks();
}

function validaChecks(){
    let status=false;
    for (let i=0; i<detalleDocuments.length;i++){       
        status= $('#checkTipo'+i).is(':checked'); 
        if(status){
            $('#btnDoc'+page_select).removeAttr("disabled");
            break;
        }           
    }
    $('#selectDocs').prop('checked', status);
}

//# sourceURL=concentracion.js