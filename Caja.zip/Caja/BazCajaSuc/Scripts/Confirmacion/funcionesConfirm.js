﻿var ConfirmacionService = {
getUrlServicio:function getUrlServicio(nombreServicio) {
                   // var protocolo = "http"
        // var ipPuerto = "10.54.28.226:9014"
        // var rutaAplicativo = "BazCajaSuc/Servicios/TiposPago/TiposPago.svc"
        var protocolo = "http";
        var ipPuerto = ""
        var rutaAplicativo = "";                    
        if(window.location.hostname == "localhost"){
            ipPuerto = "localhost:57766";
            rutaAplicativo = "Traspasos/Traspasos.svc";
        }
        else{
            ipPuerto= window.location.host;
            rutaAplicativo = "Caja/Servicios/Traspasos/Traspasos.svc";
        }                    
        var urlBase = protocolo + "://" + ipPuerto + "/" + rutaAplicativo + "/";
        var r = urlBase + nombreServicio;
        return r;
    }
}


var usuario = getParamUrl("usuario");
var workstation = getParamUrl("ws");
var isMonedas = true;
var cantBilletes = 0;
var cantMonedas = 0;
var importeTraspDen = 0;
var tipoH = 1;
var app = "Confirmacion";
var topH = "230";
var afectaHD = true;

var page_select = "";
var id_page_select = "";
var titulo = "";

var origen=""; //D=Concentracion, T=?, D=?, F=?

var perfil = "";
var idTipoPago=-1;
var tipoPago="";
var tipoTraspaso;

var traspasosPend = [];
var traspasoSelect = undefined;

var importeFondeo=0;
var userAuto="";

var concentracionImpr="";
var transaccionImpr="";
var rutaCarta="";

var opc="1";
var idModulo="27";
var idFolio="3";

var lstSrvDenominaciones=[];

var tipoDivisas="";
var lstDenominaciones=[];
var totalRecibir="";
var totalRecibirRestante="";
var pagare=[];

var xmlTicketEgresoCheques = "";

$(document).ready(function () {
    $('#nav').hide();
    document.title = titulo;
    mostrarCarga(true);
    if (getParamUrl("opc1") && getParamUrl("opc2") && getParamUrl("opc3") && getParamUrl("usuario") && getParamUrl("ws")){        
        $.when(wsConsultaDivisa()).done(function(result){
            if(result.NoError==0){
                $.when(wsConfiguraMenu(2, getParamUrl("opc1"), getParamUrl("opc2"), getParamUrl("opc3"))).done(function(resultMenu){
                    if(resultMenu.NoError==0){
                        let opc= resultMenu.Descripcion.split(",");
                        let opcLoad="";
                        perfil= opc[0].split("|")[1];
                        for(let index=1; index<opc.length;index++){
                            if(opc[index].split("|")[1]=="1"){
                                if(index==1) opcLoad=opc[index].split("|")[0];
                                $('#'+opc[index].split("|")[0]).show();
                            }else
                                $('#'+opc[index].split("|")[0]).hide();
                        }
                        $('#nav').show();
                        pantallasConfirmacion();
                        if(opcLoad!=""){
                            if(opcLoad=="consulta") opcLoad="consultaEgreso";
                            if (changeMenu($('#'+opcLoad))){            
                                $('#content').hide().load( $('#'+opcLoad).attr("href") , function(){
                                    $('#selectValor').removeAttr("disabled");
			                        $('#content').show();
			                    });
                            }
                        }
                    }                    
                });
            }        
        });        
    }else {
        showMesagge(1, "Parámetros de entrada incorrectos");
    }
});

function msjs(mensaje) {
    $('#mensajeTitulo').html('Mensaje:');
    $('#mensajeTexto').html(mensaje);
    $j('#modal104').modal();
}

function pantallasConfirmacion() {
    var empleado = usuario;
    $.ajax({
        url: ConfirmacionService.getUrlServicio("wsRequestTipoVistaConfirmacion"),   
        contentType: "application/json; charset=UTF-8",
        type: "POST",
        data: JSON.stringify({
            "Cajero": empleado,
        }),
        dataType: 'json',
        crossDomain: true,
        success: function (resps) {
            //mostrarCarga(false);
            mostrarCarga(false);
                if (resps.NoError==0) {
                pantallaConfirmacion(resps.Vista);    
                }
                else
                {
                    msjs(resps.DescripcionError);
                }
            
        },
        error: function () {
            msjs("Ocurrió un error en el consumo del servicio.");
        }
    });
}
function pantallaConfirmacion(jsonVista){
        
           var vista=jsonVista[0];
           var vista2=jsonVista[1];
           var vista3=jsonVista[2];
           var vista4=jsonVista[3];
           var vista5=jsonVista[4];
           
           //if (vista3.key==3){
            if (vista.Value==false) {                
                document.getElementById('caja').style.display='none';
                //$('#consulta').hide();
            }
            
            if (vista2.Value==false) {                
                document.getElementById('cajero').style.display='none';
                //$('#consulta').hide();
            }

            if (vista3.Value==false) {                
                document.getElementById('concentracion').style.display='none';
                //$('#consulta').hide();
            }

            if (vista4.Value==false) {                
                document.getElementById('egreso').style.display='none';
                //$('#consulta').hide();
            }
           if (vista5.Value==false) {                
                document.getElementById('consulta').style.display='none';
                //$('#consulta').hide();
            }
           

}

//Carga la pagina solicitada
$(function(){
    $('#nav a').click(function(e) { 
        if (changeMenu( $(this))){            
            $('#content').hide().load( $(this).attr('href') , function(){
                $('#selectValor').removeAttr("disabled");
			    $('#content').show();
			});
        }
         return false;
	});
})

function changeMenu(e){    
    if ($(e).attr('id')!=id_page_select){
        mostrarCarga(true);
        if(id_page_select!=""){
            $('#'+id_page_select).removeClass('Act');//class="Act"
            $('#'+id_page_select+' img:last-child').remove();        
        }        
        id_page_select=$(e).attr('id');
        page_select=id_page_select;
        page_select=page_select=='cajero'||page_select=='caja'?'cajero':page_select; 
        switch (id_page_select){
            case "concentracion": //Concentracion
                origen="D";
                break;
            case "cajero": //Traspaso saldo a cajero
                origen="T";
                break;
            case "caja": //Fondeo
                origen="F";
                break;
            default:
                origen="";
                break;
        }       
        titulo=$(e).text();
        $('html head').find('title').text(titulo);
        $('#titulo').text(titulo);
        $(e).addClass('Act');//class="Act"
        $(e).prepend('<img src="../../Imgs/slider/cuadroV.jpg" class="png">');
        return true;
    }
    return false;  
}

//----- CLOSE popup
function onClosePopup(id){
    $('#btnAceptarPopup').off('click');
    $('[data-popup="'+id+'"]').fadeOut(350);
}

function changeDivisas() {
    $('#desc_divisa').html(desc_divisa);
    reloadContent();
}

function reloadContent() {
    mostrarCarga(true);
    limpiaVariblesConfirm();
    switch (id_page_select) {
        case 'caja': //Recepción de Fondeo de Caja 
            $('#importeConfirm'+page_select).val("");           
            wsConsultaConfirmacionPendientes("F");
            break;
        case 'cajero': //Recepción de Fondeo de Cajero
            $('#importeConfirm'+page_select).val("");
            wsConsultaConfirmacionPendientes("T");
            break;
        case 'concentracion': //Recepción de Concentración de Cajero a Caja
            $('#importeConfirm'+page_select).val("");
            $('#importeDoc'+page_select).val("");
            wsConsultaRecepcionConcentracionSaldosCajeroaCaja("D");         
            break;
        case 'egreso': //Egreso de Valores  
            changeEgresos();
            wsConsultaTiposdePago();
            break;
        case 'consulta': //Consulta de Egresos    
            onChangeDivisaConsulta();
            //Cargar tipo pago
            wsConsultaTiposdePago();        
            break;
    }    
}

function limpiaVariblesConfirm(){
    if($('#selectDocs') !== 'undefined'){
        $('#selectDocs').prop('checked', false);
    }

    if($('#selectEgresos') !== 'undefined'){
        $('#selectEgresos').prop('checked', false);
    }

    if(typeof cantBilletes !== 'undefined'){
        cantBilletes = 0;
    }
    if(typeof cantMonedas !== 'undefined'){
        cantMonedas    = 0;
    }
    if(typeof importeTraspDen !== 'undefined'){
        importeTraspDen    = 0;
    }    
    if(typeof tipoPago !== 'undefined'){
        tipoPago   ="";
    }
    if(typeof tipoTraspaso !== 'undefined'){
        tipoTraspaso   ;
    }
    if(typeof traspasosPend !== 'undefined'){
        traspasosPend    = [];
    }
    if(typeof traspasoSelect !== 'undefined'){
        traspasoSelect    = undefined;
    }
    if(typeof importeFondeo !== 'undefined'){
        importeFondeo   =0;
    }
    if(typeof userAuto !== 'undefined'){
        userAuto   ="";
    }
    if(typeof totalRecibir !== 'undefined'){
        totalRecibir   ="";
    }
    if(typeof totalRecibirRestante !== 'undefined'){
        totalRecibirRestante   ="";
    }
    if(typeof pagare !== 'undefined'){
        pagare   =[];
    }
    if(typeof detalleDocuments !== 'undefined'){
        detalleDocuments=[];
    }
    if(typeof docsLista !== 'undefined'){
        docsLista=[];
    }
    if(typeof detalleDocsLista !== 'undefined'){
        detalleDocsLista=[];
    }
    if(typeof egresosPend !=='undefined'){
        egresosPend = [];
    }
    if(typeof totalEgresos !=='undefined'){
        totalEgresos=[];
    }
    if(typeof detalleDocsLista !=='undefined'){
        detalleDocsLista=[];
    }
    if(typeof depLista !=='undefined'){
        depLista=[];
    }
    if(typeof dateIni !== 'undefined'){
        dateIni = undefined;
    }
    if(typeof dateFin !== 'undefined'){
        dateFin = undefined;
    }
    if(typeof fechaIni !== 'undefined'){
        fechaIni = "";
    }
    if(typeof fechaFin !== 'undefined'){
        fechaFin = "";
    }
    if(typeof egresosDetalle !== 'undefined'){
        egresosDetalle=[];
    }
    if(typeof fechaIniC !== 'undefined'){
        fechaIniC=false;
    }
    if(typeof fechaFinC !== 'undefined'){
        fechaFinC=false;
    }

    if($('#btnDoc'+page_select) !== 'undefined'){
        $('#btnDoc'+page_select).attr("disabled", true);
    }

    setHuellaMsgImporte("");
}

function onChangeTipoPago(){
    $("#fechaIni").attr("disabled", true);
    $("#fechaFin").attr("disabled", true);
    $("#btnConsulta").attr("disabled", true);

    idTipoPago= $('#tipoPago option:selected').val();
    tipoPago=$('#tipoPago option:selected').text();    
    if(idTipoPago!="-1"){
        if(page_select=="egreso"){
            mostrarCarga(true);
            changeEgresos();
            wsConsultaEgresos(idTipoPago, "", "", "3");
        }else
            $('#fechaIni').removeAttr("disabled");        
    }        
}

function expand(name){
    let comp="";
    if(name.id)
        comp=name.id;
    else{
        if(name[0].id)
            comp=name[0].id;
    }            
    $this = $('#'+comp);
    //the target panel content
    $target = $this.next();

    jQuery(document.getElementById(''+comp)).removeClass('accordion-active');
    if ($target.hasClass("in")) {
        $this.removeClass('accordion-active');
        $target.slideUp();
        $target.removeClass("in");
    } else {
        $this.addClass('accordion-active');
        jQuery(''+comp).removeClass("in");
        $target.addClass("in");
        $(".subSeccion").show();
        $target.slideDown();
    }
}

function onCheckTraspaso(concentracion, id){        
    $("#btnConfirmar"+page_select).attr("disabled", true);
    $('#cancelaTrasp'+page_select).attr("disabled", true);           
    if($('#checkTrasp'+id).is(':checked')){
        let index = traspasosPend.findIndex(function(o){
                        return o.Concentracion === concentracion.toString();
                    });
        traspasoSelect=traspasosPend[index];         
        $("#importeConfirm"+page_select).val(formatMoney(traspasoSelect.Importe));
        $('#cancelaTrasp'+page_select).removeAttr("disabled");
        $("#btnConfirmar"+page_select).removeAttr("disabled");
		$('#cancelaTrasp'+page_select).removeClass("btnB").addClass("btnV");
        $("#btnConfirmar"+page_select).removeClass("btnB").addClass("btnV");
        for(let i=0; i<traspasosPend.length; i++){
            if (id!=i) {
                if($('#checkTrasp'+i).is(':checked')){
                    $('#checkTrasp'+i).prop('checked', false);              
										
                }
            }
        }
    }else{
        traspasoSelect=undefined;
        $("#importeConfirm"+page_select).val(formatMoney(0));
		$('#cancelaTrasp'+page_select).removeClass("btnV").addClass("btnB");
					$("#btnConfirmar"+page_select).removeClass("btnV").addClass("btnB");
    }
    console.log(traspasoSelect);
}

function btncancelaTraspaso(){
    if(traspasoSelect!=undefined){
        $j('#modal05').modal();       
    }
}

function doCancelacion(){
    mostrarCarga(true);    
    cancelaTraspaso(traspasoSelect.Concentracion);
}

function openDenominaciones(){
    mostrarCarga(true); 
    if(tipoDivisas=="F")
        $('#divImporte').show();
    else
        $('#divImporte').hide();
    $('#importe_denominacion').val(Number(importeFondeo));
    cantBilletes=0;
    cantMonedas=0;
    importeTraspDen=0;
    $('#cantMoneda').val(cantMonedas);
    $('#cantBilletes').val(cantBilletes);
    $('#totalMB').val(formatMoney(importeTraspDen));      
    llenarDenominacion();
}

function totales(IdDenominacion, id) {    
    let cantOld = Number(id.oldvalue);       
    let importeTotal = Number(importeFondeo);
    let idInput="";
    let denominacion="";
    let cant=0;
    cantBilletes=0;
    importeTraspDen=0;
    $("#tableDenominacion :input").each(function() {
        cant = Number($(this).val());
        if(cant>0){
            cantBilletes+=cant;
            denominacion = $(this).attr('id').substring(3,$(this).attr('id').length);            
            importeTraspDen+= cant * Number(denominacion);
        }
    });
    cant = Number($('#cantMoneda').val());
    if(cant>0)
        importeTraspDen+= cant;
    //$("#btnAcepTrasp").attr("disabled", true);
    idInput=IdDenominacion==1&& isMonedas?'cantMoneda':'den'+IdDenominacion.toString().replace(/\./g,'');
    if(importeTraspDen > importeTotal && tipoDivisas!="C"){        
        $('#'+idInput).val(cantOld);
        importeTraspDen=deleteFormatMoney($('#totalMB').val());         
        msjs("Monto excedido");        
    }else{
        $('#total'+IdDenominacion.toString().replace(/\./g,'')).html(formatMoney(Number(IdDenominacion) * Number(id.value)));
        $('#totalMB').val(formatMoney(importeTraspDen));
        $('#cantBilletes').val(cantBilletes);                       
    }
}

function onChangeMorralla(id){
    let importeTotal = Number(deleteFormatMoney($('#importe_denominacion').val()));
    let importeTraspDen = Number(deleteFormatMoney($('#totalMB').val()));    
    $("#btnAcepTrasp").attr("disabled", true);
    if(importeTraspDen+Number(id.value) > importeTotal){
        $('#cantMoneda').val(id.oldvalue);
        importeTraspDen-=Number(id.oldvalue);
        $('#totalMB').val(formatMoney(importeTraspDen));
        msjs("Monto excedido"); 
    }else{
        importeTraspDen+=Number(id.value);
        $('#totalMB').val(formatMoney(importeTraspDen));
        if(importeTraspDen==importeTotal)
            $("#btnAcepTrasp").removeAttr("disabled");
    }    
}

//Funcion para abrir el componente de huellas
function abrirHuella(callback, tipo) {
    mostrarCarga(true);
    //Quitar de opendenominaciones        
    let emp="";
    let auth="";
    let perfiles="0";
    switch(tipo){
        case 1: //Fondeo
            emp=usuario;
            let result = getPerfilesAutorizador(opc, idModulo, idFolio);//Servicio de perfiles autorizadores;
            if(result && result.Estatus==0){
                auth=result.EmpAutorizador;
                if(puestoBaseId == 632){
                    if(auth.length > 0){
                        auth=auth + ",'"+emp+"'";
                    }
                    else{
                        auth=auth + "'"+emp+"'";   
                    }                    
                }
                perfiles=result.EmpPerfiles;
            }else{
                showMessage(1, result.msjCliente || "Ocurrio un error en el servidor");
            }
            break;
        case 2: //Confirmir concentraciones - efectivo
        case 3: //Confirmir concentraciones - documentos            
            emp=usuario;
            tipoTraspaso=tipo==2?"efectivo":"doc";
            if (id_page_select=='caja' || id_page_select=='concentracion'){                
                let result = getPerfilesAutorizador(opc, idModulo, idFolio);//Servicio de perfiles autorizadores;
                if(result && result.Estatus==0){
                    auth=result.EmpAutorizador;
                    perfiles=result.EmpPerfiles;
                }else{
                    showMessage(1, result.msjCliente || "Ocurrio un error en el servidor");
                }
            }else{
                emp=traspasoSelect.NoCajero;
                auth = traspasoSelect.NoCajero;
            }
            break;        
        case 4: //Pagare
            emp = usuario;            
            let resultP = getPerfilesAutorizador(opc, idModulo, idFolio);//Servicio de perfiles autorizadores;
            if(resultP && resultP.Estatus==0){
                auth=resultP.EmpAutorizador;
                perfiles=resultP.EmpPerfiles;
            }else{
                continuar=false;
                showMesagge(1, resultP.msjCliente || "Ocurrio un error en el servidor");
            } 
            break;
        case 5:
            emp=usuario;
            auth = usuario;
        break;
    }
    let workstation= getParamUrl("ws"); 
    var json = '{"validarEmp":"' + emp + '",' +
                '"validarAut":"' + auth + '",' +
                '"tipo":"' + tipoH + '",' +
                '"app":"' + app + '",' +
                '"top":"' + topH + '",' +
                '"afectaHD":"' + afectaHD + '",' +
                '"perfiles":"' + perfiles + '",' +
                '"ws":"' + workstation + '"}';    
    json = JSON.parse(json);
    AutenticacionHuella(json,callback);
}

function doRecibirAhora(){   
    onClosePopup("popupMsj");
    let importeTotal= Number(traspasoSelect.Importe);    
    if(Number(totalRecibir)<importeTotal && traspasoSelect.UltimoTraspaso=="1" && tipoTraspaso=="efectivo"){
        totalRecibirRestante=importeTotal-Number(totalRecibir);
        $('#divisaAjuste').html(desc_divisa);
        $('#importeAjuste').html(formatMoney(totalRecibirRestante));
        $("#pagoAhoraCheck").attr("checked", false);
        $("#nominaCheck").attr("checked", false);
        $('[data-popup="popupAjusteSaldos"]').fadeIn(400); 
    }else{
        onClosePopup('popupAjusteSaldos');                
        mostrarCarga(true);    
        let saldo=totalRecibir-totalRecibirRestante;
        let userC=id_page_select=="cajero"||id_page_select=="concentracion"?traspasoSelect.NoCajero:usuario;
        if (id_page_select=="caja") userC=userAuto;
        let userA=id_page_select=="cajero"||id_page_select=="caja"?usuario:userAuto;
        let consulta = {
                "NoEmpleado": userC,
                "NoEmpleadoAuto": userA,
                "FormaPago":"0",
                "Origen": origen,
                "Divisa": divisa,
                "Terminal": workstation,
                "UltTraspaso":"0",
                "LstTipoPago": []
            };
        if (tipoTraspaso=="efectivo"){   
            consulta.UltTraspaso=traspasoSelect.UltimoTraspaso,                     
            consulta.LstTipoPago=[{ "Tipo_PagoId": 1, "TipoPagoDesc":"Efectivo", "SaldoTotal": saldo.toString(),
                              "LstDocumento": [{ "Importe": saldo.toString(), "NoDeposito": traspasoSelect.Concentracion}]}];         
        } 
        console.log(JSON.stringify(consulta));        
        ConfirmaConcentraciones(consulta, concentracion, tipoTraspaso);
    }    
}

function validaEmpleadoPropioFondeo(){
    mostrarCarga(true);
    setHuellaMsgImporte("Solicitando confirmación de Fondeo por el importe de: "+ formatMoney(traspasoSelect.Importe)+".");
    abrirHuella(doConfirmaFondeo,5);
}

function validaEmpleadoPropio(json){
    mostrarCarga(false);
    if(json.Status==0)      {        
        showMesagge(1, json.Descripcion);        
    }
    else{
        mostrarCarga(true);
        setHuellaMsgImporte("Solicitando confirmación de Fondeo por el importe de: "+ formatMoney(importeFondeo)+".");
        abrirHuella(solicitarFondeo,1);
    }
}

function doConfirmaFondeo(json){   

    mostrarCarga(false);
    if(json.Status==0)      {        
        showMesagge(1, json.Descripcion);        
    }
    else{
        let saldo= Number(traspasoSelect.Importe);            
        let consulta = {
                "NoEmpleado": usuario,
                "NoEmpleadoAuto": usuario,
                "FormaPago":"0",
                "Origen": origen,
                "Divisa": divisa,
                "Terminal": workstation,
                "UltTraspaso":"0",
                "LstTipoPago": [{ "Tipo_PagoId": 1, "TipoPagoDesc":"Efectivo", "SaldoTotal": saldo.toString(),
                              "LstDocumento": [{ "Importe": saldo.toString(), "NoDeposito": traspasoSelect.Concentracion}]}]
            };
            
        console.log(JSON.stringify(consulta));        
        ConfirmaTraspasoFondeo(consulta, concentracion, tipoTraspaso);
    }
    
}

function recibirEfectivo(){
    tipoPago=0; 
    if(traspasoSelect!=undefined){
        tipoDivisas="C";
        consultarDenominacion();
    }
}


function llenaTraspasosPendientes(confirmaciones, idTable, isShowFields, isShowPuestoCero, caja){
    let accordion='<dl class="accordion">';
    let importeTraspasos=0;
    let importeTraspasosCaja=0;
    let cantTraspasos=0;
    let cantTraspasosCaja=0;
    let ultimoTrasp="";
    let emisor="";
    traspasosPend=confirmaciones;
    if(confirmaciones.length<0){
        $("#cancelaTrasp"+page_select).attr("disabled", true);
        $("#solicitaFondeo"+page_select).attr("disabled", true);       
    }
    $.each(confirmaciones, function (i, p) {
        //if(p.PuestoSaldo!="0" || isShowPuestoCero){
            if(caja==""){        
                cantTraspasos++;
                importeTraspasos+=Number(p.Importe);
            }else{
                if(p.TipoPuesto=="2"){
                    cantTraspasos++;
                    importeTraspasos+=Number(p.Importe);
                }else{
                    cantTraspasosCaja++;
                    importeTraspasosCaja+=Number(p.Importe);
                }
            }
        ultimoTrasp=p.UltimoTraspaso=="0"?"No":"Si";
        emisor=p.NomCajEmisor=="NULL"?"Caja":p.NomCajEmisor;
        accordion += "<div class='checks'>" +
                        "<input type='checkbox' onchange='onCheckTraspaso("+p.Concentracion+","+i+")' id='checkTrasp"+i+"' />"+
					    "<label for='checkTrasp"+i+"'></label>"+
				     "</div>";
        accordion+="<dt id='dtTrasp"+i+"' class='AcoInpar' onclick='expand(dtTrasp"+i+")'>"+
                        '<table class="tblGeneral3 w90">'+
                            '<tbody>'+
                                '<tr>'+
							        '<td class="tLeft">'+p.Concentracion+'</td>'+ //Concentracion
                                    '<td>'+p.Operacion+'</td>'+ //Fecha
                                    '<td>'+emisor+'</td>'; //Emisor
                                    if(isShowFields){
                                    accordion+='<td>'+p.PuestoSaldo+'</td>'+ //Puesto
                                    '<td>'+ultimoTrasp+'</td>'; //Ultimo Traspaso
                                    }
                                    accordion+='<td class="tRight">'+formatMoney(Number(p.Importe))+'</td>'; //Importe
                                accordion+='</tr>'+
                            '</tbody>'+
                        '</table>'+
                    '</dt>'+
                    '<dd id="ddTrasp'+i+'" style="display: none;">'+
                        '<div class="inner"> '+
                            '<div class="nivel2">'+                                
                                '<table class="tblGeneral3 w90" style="text-align: right;">'+
                                "<tbody>";
                                let table="";
                                let namedenominacion="";
                                let den=p.Denominacion.split("|");
                                let cant=p.NumBilletes.split("|");
                                $.each(den, function (j, d) {                                       
                                    namedenominacion=Number(d)==0?"Morralla":"Denominacion";
                                    table+= "<tr>"+
                                             '<td>&nbsp;</td>'+
                                             '<td>'+namedenominacion+':   '+d+'</td>'+
                                             '<td>Cantidad:   ' +cant[j]+'</td>'+
                                             '<td>&nbsp;</td>'+
                                            "</tr>";
                                });
                                if (table==""){
                                    table="<tr><td>&nbsp;</td></tr>";
                                }                                                                 
                                accordion+= table + "</tbody></table>"+
                             '</div>'+
                         '</div>'+
                     '</dd> '+
				     '<div class="clear"></div>'; 
                     //}
    });
    accordion+='</dl>';
    $('#'+idTable).html(accordion);
    $('#traspConfirm'+page_select).html(cantTraspasos);
    $('#saldoConfirm'+page_select).html(formatMoney(importeTraspasos));      
    if(caja=="Caja"){        
        $('#traspConfirm'+caja+page_select).html(cantTraspasosCaja);
        $('#saldoConfirm'+caja+page_select).html(formatMoney(importeTraspasosCaja)); 
    }
}

function openImporteFondeo(){
    mostrarCarga(true);
    tipoDivisas="F";
    consultarDenominacion();    
}

function solicitarFondeo(json){        
    mostrarCarga(false);
    if(json.Status==0)     
    {         
        showMesagge(1, json.Descripcion);
    }
    else{
        mostrarCarga(true);
        userAuto=usuario;
        SolicitarFondeo(userAuto, importeFondeo.toString());
    }
}

function construirTicket(numOperacion,numTraspaso){
    let ticketEmp=generaContenido(numOperacion,numTraspaso, "Copia Empleado");
    let ticketTienda=generaContenido(numOperacion,numTraspaso, "Copia Tienda");
    let listaTickets={"ListaTickets":[{
		                "Aplicacion":"Caja",
		                "Contenido":ticketTienda,
		                "NoCopias": 1
	                 },
                     {
		                "Aplicacion":"Caja",
		                "Contenido":ticketEmp,
		                "NoCopias": 1
	                 }]};
    console.log(listaTickets);
    return listaTickets;    
}

function generaContenido(numOperacion,numTraspaso, tipo){
    let importeLetras = "( "+NumeroALetras(Number(traspasoSelect.Importe))+" )";
    let cajeroTrasp = traspasoSelect.NoCajero+"-"+serviceNombreEmpleado(traspasoSelect.NoCajero); 
    let cajeroRec = userAuto+"-"+serviceNombreEmpleado(userAuto); 
    
    let tituloTicket1=id_page_select=="caja"?"Fondeo de Caja Principal":"Concentracion de Saldos";
    let tituloTicket2=id_page_select=="caja"?"a Cajero / Vendedor":"de Cajero a Caja Principal";
    let opero="Opero: "+empName+" en "+workstation;

    let contenido="<TICKET>"+
                    "<TEXT ALIGNH = \"CENTER\" FONTFAMILY = \"Cambria\" FONTSIZE = \"11\" FONTTYPE = \"N\">BANCO AZTECA, S.A</TEXT>"+
                    "<TEXT ALIGNH = \"CENTER\" FONTFAMILY = \"Cambria\" FONTSIZE = \"6\" FONTTYPE = \"N\">Tienda: "+sucNum+" "+sucName+"</TEXT>"+
                    "<TEXT ALIGNH = \"CENTER\" FONTFAMILY = \"Cambria\" FONTSIZE = \"6\" FONTTYPE = \"N\">"+getFecha()+"</TEXT>"+
                    "<TEXT></TEXT><TEXT></TEXT><TEXT ALIGNH = \"CENTER\" FONTFAMILY = \"Calibri\" FONTSIZE = \"11\" FONTTYPE = \"B\">"+tituloTicket1+"</TEXT>"+
                    "<TEXT ALIGNH = \"CENTER\" FONTFAMILY = \"Calibri\" FONTSIZE = \"11\" FONTTYPE = \"B\">"+tituloTicket2+"</TEXT>"+
                    "<TEXT ALIGNH = \"CENTER\" FONTFAMILY = \"Calibri\" FONTSIZE = \"6\" FONTTYPE = \"B\">"+opero+"</TEXT><TEXT></TEXT><LINE POSX = \"0\" WIDTH = \"100\" BORDERWIDTH = \"0.3\"></LINE>"+
                    "<TEXT ALIGNH = \"CENTER\" FONTFAMILY = \"Cambria\" FONTSIZE = \"9\" FONTTYPE = \"B\">Tipo de Pago  :  Efectivo</TEXT>"+
                    "<TEXT ALIGNH = \"CENTER\" FONTFAMILY = \"Cambria\" FONTSIZE = \"9\" FONTTYPE = \"B\">Divisa  :  "+desc_divisa+"</TEXT>"+
                    "<TEXT ALIGNH = \"CENTER\" FONTFAMILY = \"Cambria\" FONTSIZE = \"9\" FONTTYPE = \"B\">Num. Operacion  :  "+numOperacion+"</TEXT><TEXT></TEXT><TEXT></TEXT>"+
                    "<TEXT ALIGNH = \"CENTER\" FONTFAMILY = \"Cambria\" FONTSIZE = \"11\" FONTTYPE = \"B\">Folio de Traspaso  : "+numTraspaso+"</TEXT><TEXT></TEXT><TEXT></TEXT>";
    if(id_page_select=="caja"){
        contenido+="<TEXT ALIGNH = \"RIGTH\" FONTFAMILY = \"Cambria\" FONTSIZE = \"9\" FONTTYPE = \"B\">Total a Fondear Efectivo:                          "+formatMoney(traspasoSelect.Importe)+"</TEXT><TEXT></TEXT>"+                   //"<TEXT ALIGNH = \"CENTER\" FONTFAMILY = \"Calibri\" FONTSIZE = \"9\" FONTTYPE = \"B\">Denominacion               Cantidad               Total</TEXT><TEXT></TEXT><TEXT></TEXT>"+ //"<TEXT ALIGNH = \"CENTER\" FONTFAMILY = \"Cambria\" FONTSIZE = \"9\" FONTTYPE = \"B\">Morralla:                                                $5.00</TEXT><LINE POSX = \"50\" WIDTH = \"20\" BORDERWIDTH = \"0.3\"></LINE>"+
                   separaCadenasTickets(importeLetras,"Cambria",9,"B")+"<TEXT></TEXT><TEXT></TEXT><TEXT></TEXT>"+
                   "<TEXT ALIGNH = \"CENTER\" FONTFAMILY = \"Cambria\" FONTSIZE = \"9\" FONTTYPE = \"B\">Empleado que Recibio</TEXT>"+
                   separaCadenasTickets(cajeroRec,"Cambria",9, "B")+"<TEXT></TEXT><TEXT></TEXT><TEXT></TEXT><LINE POSX = \"20\" WIDTH = \"30\" BORDERWIDTH = \"0.3\"></LINE>"+
                   "<TEXT ALIGNH = \"CENTER\" FONTFAMILY = \"Cambria\" FONTSIZE = \"9\" FONTTYPE = \"B\">Firma</TEXT>";
    }else{
        contenido+="<TEXT ALIGNH = \"CENTER\" FONTFAMILY = \"Calibri\" FONTSIZE = \"9\" FONTTYPE = \"B\">Descripcion                                      Importe</TEXT><TEXT></TEXT><TEXT></TEXT>"+
                   "<TEXT ALIGNH = \"CENTER\" FONTFAMILY = \"Calibri\" FONTSIZE = \"7\" FONTTYPE = \"B\">Importe Traspasado por "+ traspasoSelect.NoCajero +"            "+formatMoney(traspasoSelect.Importe)+"</TEXT>"+
                   "<TEXT ALIGNH = \"CENTER\" FONTFAMILY = \"Calibri\" FONTSIZE = \"7\" FONTTYPE = \"B\">Importe Confirmado por "+ userAuto +"            "+formatMoney(traspasoSelect.Importe)+"</TEXT><TEXT></TEXT><TEXT></TEXT>"+
                   "<TEXT ALIGNH = \"CENTER\" FONTFAMILY = \"Cambria\" FONTSIZE = \"9\" FONTTYPE = \"B\">Cajero que entrego</TEXT>"+                   
                   separaCadenasTickets(cajeroTrasp,"Cambria",9, "B")+"<TEXT></TEXT><TEXT></TEXT><TEXT></TEXT><LINE POSX = \"20\" WIDTH = \"30\" BORDERWIDTH = \"0.3\"></LINE>"+
                   "<TEXT ALIGNH = \"CENTER\" FONTFAMILY = \"Cambria\" FONTSIZE = \"9\" FONTTYPE = \"B\">Firma</TEXT><TEXT></TEXT><TEXT></TEXT>"+
                   "<TEXT ALIGNH = \"CENTER\" FONTFAMILY = \"Cambria\" FONTSIZE = \"9\" FONTTYPE = \"B\">Cajero que Recibio</TEXT>"+
                   separaCadenasTickets(cajeroRec,"Cambria",9, "B")+"<TEXT></TEXT><TEXT></TEXT><TEXT></TEXT><LINE POSX = \"20\" WIDTH = \"30\" BORDERWIDTH = \"0.3\"></LINE>"+
                   "<TEXT ALIGNH = \"CENTER\" FONTFAMILY = \"Cambria\" FONTSIZE = \"9\" FONTTYPE = \"B\">Firma</TEXT>";
    }
    contenido+="<TEXT></TEXT><TEXT ALIGNH = \"LEFT\" FONTFAMILY = \"Cambria\" FONTSIZE = \"8\" FONTTYPE = \"B\">"+tipo+"</TEXT></TICKET>";
    console.log(contenido);        
    return contenido;
}

function separaCadenasTickets(cadena, font, size, fontType){
    let cant = Math.round(cadena.length/35);
    let result="";
    let iniIndex=0;
    let endIndex=35;    
    for (let i=0; i<=cant; i++){ 
        if(cadena.substring(iniIndex,endIndex)!=""){   	
        	result+="<TEXT ALIGNH = \"CENTER\" FONTFAMILY = \""+font+"\" FONTSIZE = \""+size+"\" FONTTYPE = \""+fontType+"\">"+cadena.substring(iniIndex,endIndex);
            result+=endIndex>=cadena.length?"</TEXT>":"-</TEXT>";            
        }
        iniIndex=endIndex;
        endIndex=iniIndex+35>cadena.length?cadena.length:iniIndex+35;
	}
    return result;
}

function finishConfirmacion(){
    if((id_page_select=="caja" || id_page_select=="concentracion") && tipoTraspaso=="efectivo"){
        imprimirTicketTrasp();                       
    } else{
        if(id_page_select=="egreso"){
            imprimirEgresosDocumentos();
        }else{
            mostrarCarga(true);
            reloadContent();
        }
    } 
}

function imprimir(){
    if((id_page_select=="caja" || id_page_select=="concentracion") && tipoTraspaso=="efectivo"){
        imprimirTicketTrasp();                       
    } else{
        if(id_page_select=="egreso"){
            imprimirEgresosDocumentos();
        }
    } 
}

function imprimirEgresosDocumentos(){
    mostrarCarga(true); 
    let listaTickets={"ListaTickets":[{
                        "Aplicacion":"Caja",
                        "Contenido":xmlTicketEgresoCheques,
                        "NoCopias": 2
                     }]};
    console.log(listaTickets);
    $.when(generaTicket(listaTickets, false, true)).done(function(result){       
        if(result.Contenido>0){
            mostrarCarga(true); 
            $.when(imprimirTicket(result.Contenido, false, true)).done(function(resultI){                
                if(pagare.suscriptor){
                    let ruta = wsurlGeneraCartaFaltante(pagare, totalRecibirRestante);
                    $.when(imprimirCarta(ruta, false, true)).done(function(resultC){
                        mostrarCarga(false);
                    }).fail(function(){mostrarCarga(false); });
                } 
                mostrarCarga(false);
                $j.modal.close();
                $j('#modal07').modal();
            }).fail(function(){ 
                mostrarCarga(false);
                $j.modal.close();
                $j('#modal07').modal();});           
        }
        else{
            alert(result.Detalle);
            mostrarCarga(false);
            $j.modal.close();
            $j('#modal07').modal();
        }        
    }).fail(function(){ 
        mostrarCarga(false);
        $j.modal.close();
        $j('#modal07').modal();});
}

function imprimirTicketTrasp(){
    mostrarCarga(true); 
    $.when(generaTicket(construirTicket(transaccionImpr,concentracionImpr), false, true)).done(function(result){       
        if(result.Contenido>0){
            mostrarCarga(true); 
            $.when(imprimirTicket(result.Contenido, false, true)).done(function(resultI){                
                if(pagare.suscriptor){
                    let ruta = wsurlGeneraCartaFaltante(pagare, totalRecibirRestante);
                    $.when(imprimirCarta(ruta, false, true)).done(function(resultC){
                        mostrarCarga(false);
                    }).fail(function(){mostrarCarga(false); });
                } 
                mostrarCarga(false);
                $j.modal.close();
                $j('#modal07').modal();
            }).fail(function(){ 
                mostrarCarga(false);
                $j.modal.close();
                $j('#modal07').modal();});           
        }
        else{
            alert(result.Detalle);
            mostrarCarga(false);
            $j.modal.close();
            $j('#modal07').modal();
        }                
    }).fail(function(){ 
        mostrarCarga(false);
        $j.modal.close();
        $j('#modal07').modal();});
}

function isNumberKey(evt, allowDot) {
    let charCode = (evt.which) ? evt.which : event.keyCode;
    let val=true;    
    if ((charCode < 48 || charCode > 57))
        val= false;
    if(allowDot && charCode == 46)
            val=true;   
    if (charCode==13)val=true;
    if (charCode==8)val=true; 
    return val;
}

function validaImporte(evt) {
    let charCode = (evt.which) ? evt.which : event.keyCode;
    let val=true;    
    if ((charCode < 48 || charCode > 57))
        val= false;
    if(isMonedas && charCode == 46)
            val=true;   
    if (charCode==13)val=true;
    if (charCode==8)val=true; 
    return val;
}

function btnSolicitarFondeo(){
    importeFondeo=Number($('#importeFondeo').val());
    if(importeFondeo>0){
        $j.modal.close();
        tipoDivisas="F";
        openDenominaciones();
    }
}

function salirDenominaciones(){
    $j.modal.close();
    $j("#modal10").modal();
}

function noSalirDenominaciones(){
    $j.modal.close();
    $j("#modal01").modal();
}

function siSalirDenominaciones(){
    importeFondeo=0;    
    $j.modal.close();
}

function editarMonto(){    
    $('#importe_denominacion').attr("disabled", false);
    $('#importe_denominacion').focus();
}

function cambiarMontoFondeo(val){ 
    console.log(val);  
    let newImporte=Number(val.value);
    if(newImporte==0){
        msjs ("El monto debe ser mayor a cero");
    }else{
        importeFondeo=newImporte;        
    }
}

function verificaFondeo(){
    let total=Number(deleteFormatMoney($('#totalMB').val()));
    if(total<=0){
        msjs ("El monto debe ser mayor a cero");
    }else{
        abrirHuella(solicitarFondeo,1);
    }    
}

function doAceptDenominaciones(){    
    lstDenominaciones=[];
    let denominacion="";
    let cant=0;
    let importe=0;
    $("#tableDenominacion :input").each(function() {
        cant = Number($(this).val());
        if(cant>0){
            denominacion = $(this).attr('id').substring(3,$(this).attr('id').length);            
            lstDenominaciones.push({"Denominacion": denominacion, "NumBilletes": cant});
            importe+=denominacion*cant;
        }
    });
    cant = Number($('#cantMoneda').val());
    if(cant>0){
        lstDenominaciones.push({"Denominacion": "0", "NumBilletes": cant});
        importe+=cant;
    }   
    if(importe>0){
        if(tipoDivisas=="F"){
            if(importeFondeo!==null && importeFondeo !==undefined && importeFondeo !==0){
                if(importeFondeo !== importe) {
                    alert("El importe a desglosar ("+formatMoney(importeFondeo)+") no coincide con el total de las denominaciones (" +formatMoney(importe)+"). Favor de validar")
                    return;
                }                
            }
            $j.modal.close();
            // abrirHuella(solicitarFondeo,1);
			setHuellaMsgImporte("Solicitando autorización de fondeo por el importe de: "+formatMoney(importeFondeo));
            abrirHuella(validaEmpleadoPropio,5);
        }else{
            //doRecibirAhora();                                
            totalRecibir= deleteFormatMoney($("#totalMB").val());
            totalRecibirRestante="0";
            traspasoSelect.Importe = totalRecibir;
            $j.modal.close();
            $('#titlePoup').html("Confirmación de Concentración");
            $('#msjPopup').html("<p>En concentración de saldos debe autorizar el encargado de sucursal. Pide que te autorice esta operacion</p><p>NOTA: Un mismo empleado NO puede rendir y validar el Traspaso.</p>");
            $("#btnAceptarPopup").click(function(){ abrirHuella(comprobarHuellaRecibir,2); });
            $('[data-popup="popupMsj"]').fadeIn(300);
        }
    }else{
        alert("El Total no puede ser cero");
    }
}

function validaEmpleadoPropio(json){
    mostrarCarga(false);
    if(json.Status==0)      {        
        showMesagge(1, json.Descripcion);        
    }
    else{
        mostrarCarga(true);
        setHuellaMsgImporte("Solicitando confirmación de Fondeo por el importe de: "+ formatMoney(importeFondeo)+".");
        abrirHuella(solicitarFondeo,1);
    }
}

function comprobarHuellaRecibir(json){    
    userAuto="";
    mostrarCarga(false);
    onClosePopup('popupMsj');
    if(json.Status==0){               
        showMesagge(1, json.Descripcion);
    }else{            
        userAuto=usuario;              
        $('#titlePoup').html("Operación de Saldos");
        $('#msjPopup').html("<p>Se afectará con la autorización de T"+json.Autorizo+", por la cantidad de  "+formatMoney(totalRecibir)+"</p>");
        $("#btnAceptarPopup").click(function(){ doRecibirAhora(); });
        $('[data-popup="popupMsj"]').fadeIn(300);
    }
}

function ajusteSaldos(){
    if($('#pagoAhoraCheck').is(':checked') || $('#nominaCheck').is(':checked')){
        if($('#pagoAhoraCheck').is(':checked')){  
            tipoPago=2;          
            totalRecibir=Number(totalRecibirRestante)+Number(totalRecibir);
            doRecibirAhora();
        }
        if($('#nominaCheck').is(':checked')){
            tipoPago=1;
            onClosePopup('popupAjusteSaldos');
            abrirHuella(openFormularioPagare,4);            
        }
    }else 
        msjs("Debes seleccionar una opción");    
}

function openFormularioPagare(json){
    userAuto="";
    if(json.Status==0){
        mostrarCarga(false);
        showMesagge(1, json.Descripcion);
    }else{        
        $("#formPagare :input").each(function() {
            let element = $(this);
            element.val("");
        });
        userAuto=json.Autorizo;        
        $('[data-popup="popupFormulario"]').fadeIn(400);
        mostrarCarga(false);
    }    
}

function doPagare(){
    let isValid;
    $("#formPagare :input").each(function() {
        let element = $(this);
        if (element.val() == "") {
            isValid = false;
            return false;
        }else{
            isValid = true;
        }
    });
    if(isValid){
        totalRecibir=Number(totalRecibirRestante)+Number(totalRecibir);
        pagare = {
            "suscriptor": {"nombre": $('#nombreSus').val(), "calle": $('#calleSus').val(), 
                             "colonia": $('#coloniaSus').val(), "ciudad": $('#ciudadSus').val(), "cp": $('#cpSus').val()},
            "aval": {"nombre": $('#nombreAval').val(), "calle": $('#calleAval').val(), "colonia": $('#coloniaAval').val(),
                             "ciudad": $('#ciudadAval').val(), "cp": $('#cpAval').val()},
            "lugar": {"ciudad": $('#ciudadExp').val(), "estado": $('#estadoExp').val()},
        };
        onClosePopup('popupFormulario');
        doRecibirAhora();        
    }else
        msjs("Debes ingresar todos los campos solicitados");
}

function doRecibirDocs(json){           
    if(json.Status==0){
        mostrarCarga(false);
        showMesagge(1, json.Descripcion);
    }else{        
        userAuto=json.Autorizo;
        let consulta = {
                "NoEmpleado": usuario,
                "NoEmpleadoAuto": userAuto,
                "FormaPago":"0",
                "Origen": origen,
                "Divisa": divisa,
                "Terminal": workstation,
                "UltTraspaso":"0",
                "LstTipoPago": docsLista
            };        
        console.log(JSON.stringify(consulta));        
        ConfirmaConcentraciones(consulta, "", tipoTraspaso);
    }
}

///////////

function consultaEgresos(){
    fechaFinC="";
    fechaIniC="";
    mostrarCarga(true);
    const [d, m, y] = fechaFin.split("/");
    fechaFinC=m+"/"+d+"/"+y;
    const [di, mi, yi] = fechaIni.split("/");
    fechaIniC=mi+"/"+di+"/"+yi;    
    wsConsultaEgresos(idTipoPago, fechaIniC, fechaFinC, opcion);
}

function validaFormulario(evt, tipo){    
    let valid;
    switch(tipo){
        case 1: //solo numeros
            valid = (evt.which >= 48 && evt.which <= 57) || (evt.wich == 8);
            break;
        case 2: //solo letras
            valid = (evt.which >= 65 && evt.which <= 90) || (evt.which >= 97 && evt.which <= 122) || (evt.which ==32) || (evt.wich == 8);
            break;
        case 3: //letras y numeros
            valid = (evt.which >= 48 && evt.which <= 57) || (evt.which >= 65 && evt.which <= 90) || (evt.which >= 97 && evt.which <= 122) || (evt.which ==32) || (evt.wich == 8);
            break;

    }   
    return valid;
}