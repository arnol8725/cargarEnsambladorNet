﻿var usuario = getParamUrl("usuario");
var workstation = getParamUrl("ws");
var isMonedas=true;
var cantBilletes=0;
var cantMonedas=0;
var importeTraspDen=0;
var importeTrasp=0;
var tipoH = 1;
var app = "Traspasos";
var topH = "230";
var afectaHD = true;

var idInputTraspaso="";
var tipoTraspaso="";

var perfil="F"; //D=Concentracion, T=Saldos a cajero, F=Fondeo, A=?
var origen=""; //D=Concentracion, T=?, D=?, F=?

var ultimoTraspaso=0;

var lstDenominaciones=[];

var detalleDocuments=[];
var docsLista=[];
var detalleDocsLista=[];

var detalleTraspasos=[];
var traspasoSelect = undefined;

var detalleEmpleados=[];
var empleadoSelect = undefined;

var page_select="";
var id_page_select="";

var titulo="";

var indexDetalleDocs=[];

var tipoAccion="";

var totalRecibir="";
var totalRecibirRestante="";
var tipoPago;

var pagare=[];

var userAuto="";
var perfil="";

var isHuellaT=false;
var isHuellaR=false;

var concentracionImpr="";
var transaccionImpr="";

$(document).ready(function () {
    $('#nav').hide();
    document.title = titulo;
    mostrarCarga(true);
    if (getParamUrl("opc1") && getParamUrl("opc2") && getParamUrl("opc3") && getParamUrl("usuario") && getParamUrl("ws")){        
        $.when(wsConsultaDivisa()).done(function(result){
            if(result.NoError==0){
                $.when(wsConfiguraMenu(1, getParamUrl("opc1"), getParamUrl("opc2"), getParamUrl("opc3"))).done(function(resultMenu){
                    if(resultMenu.NoError==0){
                        let opc= resultMenu.Descripcion.split(",");
                        let opcLoad="";
                        perfil= opc[0].split("|")[1];
                        for(let index=1; index<opc.length;index++){
                            if(opc[index].split("|")[1]=="1"){
                                if(index==1) opcLoad=opc[index].split("|")[0];
                                $('#'+opc[index].split("|")[0]).show();
                            }else
                                $('#'+opc[index].split("|")[0]).hide();
                        }
                        $('#nav').show();
                        if(opcLoad!=""){
                            if (changeMenu($('#'+opcLoad))){            
                                $('#content').hide().load( $('#'+opcLoad).attr("href") , function(){
                                    $('#selectValor').removeAttr("disabled");
			                        $('#content').show();
			                    });
                            }
                        }
                    }                    
                });
            }        
        });        
    }else {
        showMesagge(1, "Parámetros de entrada incorrectos");              
    }
});


//Carga la pagina solicitada
$(function(){
    $('#nav a').click(function(e) { 
        if (changeMenu( $(this))){   
            isHuellaT=false;
            isHuellaR=false;
            $("#btnDelete"+page_select).attr("disabled", true);
            $('#content').hide().load( $(this).attr('href') , function(){
                $('#selectValor').removeAttr("disabled");
			    $('#content').show();
			});
        }
         return false;
	});
})

//----- CLOSE popup
function onClosePopup(id){
    $('#btnAceptarPopup').off('click');
    $('[data-popup="'+id+'"]').fadeOut(350);
}

function isNumberKey(evt, allowDot) {
    let charCode = (evt.which) ? evt.which : event.keyCode;
    let val=true;    
    if ((charCode < 48 || charCode > 57))
        val= false;
    if(allowDot && charCode == 46)
            val=true;   
    if (charCode==13)val=true;
    if (charCode==8)val=true; 
    return val;
}

  
////////////////////////////////////////////////

//configura titulos, estilos al cambiar de menu
function changeMenu(e){    
    if ($(e).attr('id')!=id_page_select){
        mostrarCarga(true);
        if(id_page_select!=""){
            $('#'+id_page_select).removeClass('Act');//class="Act"
            $('#'+id_page_select+' img:last-child').remove();        
        }        
        id_page_select=$(e).attr('id');
        page_select=id_page_select;
        page_select=page_select=='cajero'||page_select=='fondeo'?'cajero':page_select;
        switch (id_page_select){
            case "caja": //Concentracion
                origen="D";
                break;
            case "cajero": //Traspaso saldo a cajero
                origen="T";
                break;
            case "fondeo": //Fondeo
                origen="F";
                break;
            default:
                origen="";
                break;
        }
        titulo=$(e).text();
        $('html head').find('title').text(titulo);
        $('#titulo').text(titulo);
        $(e).addClass('Act');//class="Act"
        $(e).prepend('<img src="../../Imgs/slider/cuadroV.jpg" class="png">');
        return true;
    }
    return false;  
}

function changeDivisas() {   
    $('#desc_divisa').html(desc_divisa);       
    reloadContent();    
}

function expandDocument(id){
    $this =$('#adt'+id);
        //the target panel content
        $target = $this.next();

        jQuery(document.getElementById('add'+id)).removeClass('accordion-active');
        if ($target.hasClass("in")) {
            $this.removeClass('accordion-active');
            $target.slideUp();
            $target.removeClass("in");

        } else {
            $this.addClass('accordion-active');
            jQuery('.accordion1 > dd').removeClass("in");
            $target.addClass("in");
            $(".subSeccion").show();
            //jQuery('.accordion > dd').slideUp();
            $target.slideDown();
        }
}


function expandEfectivo(name, subname){
$this = $('#'+name.id);
        //the target panel content
        $target = $this.next();

        jQuery(document.getElementById(''+subname.id)).removeClass('accordion-active');
        if ($target.hasClass("in")) {
            $this.removeClass('accordion-active');
            $target.slideUp();
            $target.removeClass("in");

        } else {
            $this.addClass('accordion-active');
            jQuery('.accordion > dd').removeClass("in");
            $target.addClass("in");
            $(".subSeccion").show();
            $target.slideDown();
        }
}

function beforeHuella(){
    if (tipoAccion!="recibir"){
        if (idInputTraspaso!="")
            $("#"+idInputTraspaso).attr("disabled", true);
    }
    if (page_select=="caja"){
            $("#btnCancelaDoc").removeAttr("disabled");            
    }
}

function openDenominaciones(val, importe, tipo){  
    tipoAccion=tipo;   
    mostrarCarga(true);
    tipoTraspaso=val;    
    $('#divImporte').show();  
    let band=0;  
    if(tipoAccion=="traspasar"){
        if (!isHuellaT){
            band=activebtnTraspaso(val)?1:0;
            if(band==1){
                let idInput=val=="efectivo"?'importe'+page_select:'importe'+page_select+'Doc';        
                $("#"+idInput).attr("disabled", true);
                idInputTraspaso=val=="efectivo"?'importe'+page_select:'importe'+page_select+'Doc';
                importe=importe==0?$('#'+idInputTraspaso).val():importe;
                importeTrasp=importe;
                if (importe>0){            
                    $('#importe_denominacion').val(importe);
                }
            }
        }else{           
            band=2;
        }
    }else{
        if (!isHuellaR){
            importeTrasp=importe;
            $('#divImporte').hide();
            band=1;
        }else{
            band=2;
        }
    }
    switch(band){
        case 0:
            mostrarCarga(false);
            break;
        case 1: 
            cantBilletes=0;
            cantMonedas=0;
            importeTraspDen=0;
            $('#cantMoneda').val(cantMonedas);
            $('#cantBilletes').val(cantBilletes);
            $('#totalMB').val(formatMoney(importeTraspDen));      
            consultarDenominacion();
            break;
        case 2: 
            mostrarCarga(false);
            traspasar();
            break;
    }
}

function totales(IdDenominacion, id) {    
    let cantOld = Number(id.oldvalue);       
    let importeTotal = tipoAccion=="recibir"?Number(traspasoSelect.Importe):Number(importeTrasp);
    let idInput="";
    let denominacion="";
    let cant=0;
    cantBilletes=0;
    importeTraspDen=0;
    $("#tableDenominacion :input").each(function() {
        cant = Number($(this).val());
        if(cant>0){
            cantBilletes+=cant;
            denominacion = $(this).attr('id').substring(3,$(this).attr('id').length);            
            importeTraspDen+= cant * Number(denominacion);
        }
    });
    cant = Number($('#cantMoneda').val());
    if(cant>0)
        importeTraspDen+= cant;
    $("#btnAcepTrasp").attr("disabled", true);
    idInput=IdDenominacion==1?'cantMoneda':'den'+IdDenominacion.toString().replace(/\./g,'');
    if(importeTraspDen > importeTotal && tipoAccion!="recibir"){        
        $('#'+idInput).val(cantOld);
        importeTraspDen=deleteFormatMoney($('#totalMB').val());         
        if(importeTraspDen==importeTotal)
            $("#btnAcepTrasp").removeAttr("disabled");
        alert("Monto excedido");        
    }else{
        if (IdDenominacion!=1)
            $('#total'+IdDenominacion.toString().replace(/\./g,'')).html(formatMoney(Number(IdDenominacion) * Number(id.value)));
        $('#totalMB').val(formatMoney(importeTraspDen));
         $('#cantBilletes').val(cantBilletes);                 
        if(importeTraspDen==importeTotal)
            $("#btnAcepTrasp").removeAttr("disabled");
    }  
    
    if(tipoAccion=="recibir" && importeTraspDen>0)
        $("#btnAcepTrasp").removeAttr("disabled");
}

function deleteImporte(val){
    isHuellaT=false;
    $('#lblMensaje').text("");
    let idInput=val=="efectivo"?'importe'+page_select:'importe'+page_select+'Doc';
    let idBtn=val=="efectivo"?'btn'+page_select:'btn'+page_select+'Doc';   
    $('#'+idInput).val("");
    $("#btnDelete"+page_select).attr("disabled", true);
    if(val=='efectivo'){
        $("#"+idInput).removeAttr("disabled");
        if(ultimoTraspaso==1){
            ultimoTraspaso=0;
            $('#checkUltimo').prop('checked', false);
        }
    }else{
        docsLista=[];
        $("#btnCancelaDoc").attr("disabled", true);
        checkUncheckDocs(false, false);
    }
    //$("#"+idBtn).attr("disabled", true);
}

function activebtnTraspaso(val){
    //validar si esta seleccionado un empleado. If page_select==cajero
    let idInput=val=="efectivo"?'importe'+page_select:'importe'+page_select+'Doc';
    let idBtn=val=="efectivo"?'btn'+page_select:'btn'+page_select+'Doc';
    let idSaldoActual=val=="efectivo"?'saldoDisponible'+page_select:'saldoDispDoc'+page_select;
    let saldo= deleteFormatMoney($('#'+idSaldoActual).text());
    let imp = $('#'+idInput).val();
    if (Number(imp)>0 && Number(imp)<=Number(saldo)){
        if(page_select=="caja")
            return true;
        else{
            if(empleadoSelect != undefined)
                return true;
            else{
                alert("Debe seleccionar un empleado para realizar el traspaso");
                return false;
            }
        }
    }else{
        if (Number(imp)>Number(saldo)) alert("Saldo insuficiente para el traspaso");
        else alert ("El monto debe ser mayor a cero");
        //$("#"+idBtn).attr("disabled", true);}
        return false; 
    }    
}


function doAceptDenominaciones(){
    lstDenominaciones=[];
    if(tipoAccion=="traspasar"){
        let denominacion="";
        let cant=0;
        let importe=0;
        $("#tableDenominacion :input").each(function() {
            cant = Number($(this).val());
            if(cant>0){
                denominacion = $(this).attr('id').substring(3,$(this).attr('id').length);            
                lstDenominaciones.push({"Denominacion": denominacion, "NumBilletes": cant});
                importe+=denominacion*cant;
            }
        });
        cant = Number($('#cantMoneda').val());
        if(cant>0){
            lstDenominaciones.push({"Denominacion": "0", "NumBilletes": cant});
            importe+=cant;
        }
        if(importeTrasp==importe){
            $j.modal.close();
            traspasar();
        }else 
            alert("El Total es Diferente al Importe a Desglozar");
    }else{
        //doRecibirAhora();        
        totalRecibir= deleteFormatMoney($("#totalMB").val());
        $j.modal.close();
        $('#titlePoup').html("Confirmación de Concentración a caja");
        $('#msjPopup').html("<p>En concentración de saldos debe autorizar el encargado de sucursal</p><p>Pide que te autorice esta operacion.</p>");
        $("#btnAceptarPopup").click(function(){ abrirHuella(comprobarHuellaRecibir,2); });
        $('[data-popup="popupMsj"]').fadeIn(300);        
    }        
}

function traspasar(origen){
    let band=true;
    let msj="";
    if(origen){
        band=activebtnTraspaso('doc');    
        tipoAccion="traspasar";
        msj="¿Esta seguro de Realizar el Traspaso a la Caja Documentos?";
    }else{
        msj = "¿Está seguro de realizar la siguiente operación?<br/>"+
                  "Depósito a caja principal por: "+formatMoney(importeTrasp)+' (' + desc_divisa+')';        
    }  
    if(band){  
        $('#msjConfirmacion').html(msj);
        setTimeout(function() {
            $j('#modal02').modal({
		    });
		    return false;
	    }, 1);
    }
}

function doTraspasar(json){
    isHuellaT=true;
    $("#btnDelete"+page_select).attr("disabled", false);
    if(json.Status==0){        
        mostrarCarga(false);
        showMesagge(1, json.Descripcion);
    }else{        
        RealizaConcentraciones(construirConsultaTraspaso(json.Autorizo), divisa, tipoTraspaso);        
    }
}

function construirConsultaTraspaso(user){
    let consulta;
    let empAuth=id_page_select=="caja"?"":empleadoSelect.NoEmpledo;    
    if(tipoTraspaso=='efectivo'){        
        consulta = {
            "NoEmpleado": usuario,
            "NoEmpleadoAuto":user,
            "Divisa": divisa,
            "Origen": origen,
            "UltTraspaso": ultimoTraspaso,
            "Terminal": workstation,
            "LstTipoPago": [{ "Tipo_PagoId": 1, "TipoPagoDesc":"Efectivo", "SaldoTotal": $('#importe'+page_select).val(), 
                          "LstDenominaciones":lstDenominaciones,
                          "LstDocumento": [{ "Importe":  $('#importe'+page_select).val(), "NoDeposito": "0"}]}]
        };
    }else{
        consulta = {
            "NoEmpleado": usuario,
            "NoEmpleadoAuto":user,
            "Divisa": divisa,
            "Origen": origen,
            "Terminal": workstation,
            "LstTipoPago": docsLista
        };
    }
    return consulta;
}

function recibirEfectivo(){
    tipoPago=0; 
    if(traspasoSelect!=undefined){
        openDenominaciones('efectivo', 0, "recibir");        
    }
}

function comprobarHuellaRecibir(json){
    mostrarCarga(false);
    if(json.Status==0){        
        showMesagge(1, json.Descripcion);
    }else{    
        userAuto=json.Autorizo;              
        $('#titlePoup').html("Operación de Saldos");
        $('#msjPopup').html("<p>Se afectará con la autorización de T"+json.Autorizo+", por la cantidad de  "+formatMoney(totalRecibir)+"</p>");
        $("#btnAceptarPopup").click(function(){ doRecibirAhora(); });
        $('[data-popup="popupMsj"]').fadeIn(300);
    }
}

function doRecibirAhora(){   
    onClosePopup("popupMsj");
    let importeTotal= Number(traspasoSelect.Importe);    
    if(Number(totalRecibir)<importeTotal && traspasoSelect.UltTraspaso=="1"){
        totalRecibirRestante=importeTotal-Number(totalRecibir);
        $('#divisaAjuste').html(desc_divisa);
        $('#importeAjuste').html(formatMoney(totalRecibirRestante));
        $("#pagoAhoraCheck").attr("checked", false);
        $("#nominaCheck").attr("checked", false);
        $('[data-popup="popupAjusteSaldos"]').fadeIn(400); 
    }else{
        onClosePopup('popupAjusteSaldos');        
        mostrarCarga(true);    
        let saldo=tipoPago==1|| tipoPago==2?totalRecibir-totalRecibirRestante:deleteFormatMoney(totalRecibir);
        let consulta = {
            "NoEmpleado": usuario,
            "NoEmpleadoAuto": userAuto,
            "FormaPago":tipoPago,
            "Divisa": divisa,
            "Terminal": workstation,
            "LstTipoPago": [{ "Tipo_PagoId": 1, "TipoPagoDesc":"Efectivo", "SaldoTotal": saldo,
                              "LstDocumento": [{ "Importe": saldo, "NoDeposito": traspasoSelect.Concentracion}]}]
        };
        ConfirmaConcentraciones(consulta, traspasoSelect.Concentracion, divisa, 'efectivo', pagare);
    }    
}

function ajusteSaldos(){
    if($('#pagoAhoraCheck').is(':checked') || $('#nominaCheck').is(':checked')){
        if($('#pagoAhoraCheck').is(':checked')){  
            tipoPago=2;          
            totalRecibir=Number(totalRecibirRestante)+Number(totalRecibir);
            doRecibirAhora();
        }
        if($('#nominaCheck').is(':checked')){
            tipoPago=1;
            onClosePopup('popupAjusteSaldos');
            abrirHuella(openFormularioPagare,3);            
        }
    }else 
        alert("Debes seleccionar una opción");    
}

function openFormularioPagare(json){
    if(json.Status==0){
        mostrarCarga(false);
        showMesagge(1, json.Descripcion);
    }else{
        $("#formPagare :input").each(function() {
            let element = $(this);
            element.val("");
        });
        userAuto=json.Autorizo;        
        $('[data-popup="popupFormulario"]').fadeIn(400);
    }    
}

function doPagare(){
    let isValid;
    $("#formPagare :input").each(function() {
        let element = $(this);
        if (element.val() == "") {
            isValid = false;
            return false;
        }else{
            isValid = true;
        }
    });
    if(isValid){
        totalRecibir=Number(totalRecibirRestante)+Number(totalRecibir);
        pagare = {
            "suscriptor": {"nombre": $('#nombreSus').val(), "calle": $('#calleSus').val(), 
                             "colonia": $('#coloniaSus').val(), "ciudad": $('#ciudadSus').val(), "cp": $('#cpSus').val()},
            "aval": {"nombre": $('#nombreAval').val(), "calle": $('#calleAval').val(), "colonia": $('#coloniaAval').val(),
                             "ciudad": $('#ciudadAval').val(), "cp": $('#cpAval').val()},
            "lugar": {"ciudad": $('#ciudadExp').val(), "estado": $('#estadoExp').val()},
        };
        onClosePopup('popupFormulario');
        doRecibirAhora();        
    }else
        alert("Debes ingresar todos los campos solicitados");
}

//Funcion para abrir el componente de huellas
function abrirHuella(callback, tipo) {
    mostrarCarga(true);
    //Quitar de opendenominaciones
    beforeHuella();    
    let emp="";
    let auth="";
    let perfiles="0";
    let continuar=true;
    switch(tipo){
        case 1: //Traspasos
            emp=usuario;
            auth=usuario;
            break;
        case 2: //Recibir concentraciones
            onClosePopup("popupMsj");
            emp=usuario;
            if (page_select=='caja'){                
                let result = getPerfilesAutorizador();//Servicio de perfiles autorizadores;
                if(result && result.Estatus==0){
                    auth=result.EmpAutorizador;
                    perfiles=result.EmpPerfiles;
                }else{
                    continuar=false;
                    showMesagge(1, result.msjCliente || "Ocurrio un error en el servidor");
                }                
            }else{
                emp=traspasoSelect.NoCajeroRec;
                auth = traspasoSelect.NoCajeroRec;
            }
            break;
        case 3: //Pagare 
            emp = usuario;            
            let result = getPerfilesAutorizador();//Servicio de perfiles autorizadores;
            if(result && result.Estatus==0){
                auth=result.EmpAutorizador;
                perfiles=result.EmpPerfiles;
            }else{
                continuar=false;
                showMesagge(1, result.msjCliente || "Ocurrio un error en el servidor");
            } 
            break;
    }
    if (continuar){
        let workstation= getParamUrl("ws"); 
        var json = '{"validarEmp":"' + emp + '",' +
                '"validarAut":"' + auth + '",' +
                '"tipo":"' + tipoH + '",' +
                '"app":"' + app + '",' +
                '"top":"' + topH + '",' +
                '"afectaHD":"' + afectaHD + '",' +
                '"perfiles":"' + perfiles + '",' +
                '"ws":"' + workstation + '"}';    
        json = JSON.parse(json);
        AutenticacionHuella(json,callback);
    }else{
        mostrarCarga(false);
    }
}

function btncancelaTraspaso(){
    if(traspasoSelect!=undefined){
        $j('#modal05').modal();        
    }
}

function doCancelacion(){
    mostrarCarga(true);
    let empleado=page_select=='caja'?usuario:traspasoSelect.empleado;
    cancelaTraspaso(empleado, divisa, traspasoSelect.Concentracion);
}

function onUltimoTraspaso(){
    ultimoTraspaso=0;
    if($('#checkUltimo').is(':checked')){
        let disponible = Number(deleteFormatMoney($('#saldoDisponiblecaja').text()));
        if(disponible>0){
            ultimoTraspaso=1;
            $('#importecaja').val(disponible);
            $('#titlePoup').html("Traspas de Saldos");
            $('#msjPopup').html("<p>Este será su último Traspaso de Efectivo a Caja Principal</p><p>Se deberá de Traspasar todo el Saldo de Efectivo, ya que éste será Validado en la Confirmación a Caja </p><p>Principal y si existiera alguna diferencia, se genenerá un Ajuste por Faltante o Sobrante. </p>");            
            $("#btnAceptarPopup").click(function(){ doUltimoTraspaso(); });
            $('[data-popup="popupMsj"]').fadeIn(300);
        }else{
            alert("Saldo insuficiente");
            $('#checkUltimo').prop('checked', false);
        }
    }else{
        $('#importecaja').val("0");
    }
}

function doUltimoTraspaso(){
    onClosePopup("popupMsj");
    openDenominaciones('efectivo', $('#importecaja').val(), "traspasar");
}

function onCheckDoc(id, all){
    detalleDocsLista=[];    
    let importe = 0;
    if($('#check'+id).is(':checked') && Number(detalleDocuments[id].saldo)<=0 ){
        $('#check'+id).prop('checked', false);
    }else{
        let saldo= deleteFormatMoney($('#saldoDispDoccaja').text());
        let imp = detalleDocuments[id].saldo;
        if(Number(imp)<=Number(saldo)){
        docsLista=[];
        detalleDocsLista=[];

        if($('#check'+id).is(':checked')){
        $.each(detalleDocuments, function (i, doc) {
            detalleDocsLista=[];
            if($('#check'+i).is(':checked')){
            $.each(doc.detalleDocs, function (j, det) {
                if (all){
                    if(Number(det.Importe)>0)
                        $('#checkDocuments'+j+i).prop('checked', true);
                }
                if($('#checkDocuments'+j+i).is(':checked') && Number(det.Importe)>0){    
                    importe += Number(det.Importe);
                    detalleDocsLista.push({ "Importe":  det.Importe.toString(), "NoDocto": det.NoDocto, "NoDeposito": "0", "NoOperacion": det.NoOperacion});
                }
            });
            if(doc.detalleDocs.length>0)
                    docsLista.push({ "Tipo_PagoId": doc.tipoId, 
                              "TipoPagoDesc":doc.desc, 
                              "SaldoTotal": importe.toString(),
                              "LstDenominaciones":[],
                              "LstDocumento": detalleDocsLista}); 
            }
        });        
        }else{
            $.each(detalleDocuments[id].detalleDocs, function (j, doc) { 
                $('#checkDocuments'+j+id).prop('checked', false);                    
            });               
            if($('#selectDocs').is(':checked')) validaChecks();            
        }
        $('#importecajaDoc').val(importe.toFixed(2));
        //activebtnTraspaso('doc');
        }else{
            $('#check'+id).prop('checked', false);
            alert("Saldo insuficiente para el traspaso");
        }
    }    
    console.log(docsLista);
}

function onCheckDetalleDoc(id, idDetalle){
    if($('#checkDocuments'+idDetalle+id).is(':checked')){
        let saldo= deleteFormatMoney($('#saldoDispDoccaja').text());
        let imp = detalleDocuments[id].detalleDocs[idDetalle].Importe;
        if(Number(imp)>Number(saldo)){
            $('#checkDocuments'+idDetalle+id).prop('checked',false);
            alert("Saldo insuficiente para el traspaso");
        }else{
            $('#check'+id).prop('checked',true);
            onCheckDoc(id, false);
        }
    }else{
        onCheckDoc(id, false);
        validaDetalle(detalleDocuments[id].detalleDocs.length, id);
    }       
}

function validaDetalle(size, id){
    let status=false;
    for (let i=0; i<size;i++){       
        status= $('#checkDocuments'+i+id).is(':checked');
        if(status)break;       
    }
    $('#check'+id).prop('checked', status);
    return status;
}

function checkUncheckDocs(status, changeList){
    for (let i=0; i<detalleDocuments.length;i++){
        $('#check'+i).prop('checked', status);
        if (changeList){
            onCheckDoc(i, true);
        }
            
    }
}

function validaChecks(){
    let status=false;
    for (let i=0; i<detalleDocuments.length;i++){       
        status= $('#check'+i).is(':checked');
        if(status) break;
    }
    $('#selectDocs').prop('checked', status);
}

function selectDocs(){
    checkUncheckDocs($('#selectDocs').is(':checked'), true);
    validaChecks();
}

function onCheckTraspaso(concentracion, id){        
    $("#recEfec"+page_select).attr("disabled", true);
    $('#btnCancelar'+page_select).attr("disabled", true);
             
    let index = detalleTraspasos.findIndex(function(o){
                    return o.Concentracion === concentracion.toString();
             });
    let indexLst;
    if($('#checkE'+id).is(':checked')){
        traspasoSelect=detalleTraspasos[index];        
        $('#btnCancelar'+page_select).removeAttr("disabled");
        $("#recEfec"+page_select).removeAttr("disabled");        
        for(let i=0; i<detalleTraspasos.length; i++){
            if (id!=i) {
                if($('#checkE'+i).is(':checked')){
                    $('#checkE'+i).prop('checked', false);                  
                }
            }
        }
    }else{
        traspasoSelect=undefined;
    }
    console.log(traspasoSelect);
}

function onCheckEmpleado(empleado, id){
    mostrarCarga(true);  
    empleadoSelect=undefined;  
    $("#recEfec"+page_select).attr("disabled", true);    
    let index = detalleEmpleados.findIndex(function(o){
                    return o.NoEmpledo === empleado.toString();
             });
    let indexLst;
    if($('#checkEmp'+id).is(':checked')){
        empleadoSelect=detalleEmpleados[index];
        if(traspasoSelect!=undefined)
                $("#recEfec"+page_select).removeAttr("disabled");
        for(let i=0; i<detalleEmpleados.length; i++){
            if (id!=i) {
                if($('#checkEmp'+i).is(':checked')){
                    $('#checkEmp'+i).prop('checked', false);                  
                }
            }
        }
        llenarTraspPend(getAllValues(empleado), true, "adtEfec", "addEfec", "efectivotable", false);
        mostrarCarga(false);
    }else{
        llenarTraspPend([], true, "adtEfec", "addEfec", "efectivotable", false);
        empleadoSelect=undefined;
        mostrarCarga(false);
    }
    console.log(empleadoSelect);
    console.log(getAllValues(empleado));
}

function getAllValues(empleado) {
    var indexes = [], i;
    for(i = 0; i < detalleTraspasos.length; i++)
        if (detalleTraspasos[i].NoCajeroRec === empleado)
            indexes.push(detalleTraspasos[i]);
    return indexes;
}

function reloadContent(){
    mostrarCarga(true);
    isHuellaT=false;
    isHuellaR=false;
    importeTrasp=0;
    $("#importe"+page_select).val("");
    $("#importe"+page_select+"Doc").val("");
    $("#btnDelete"+page_select).attr("disabled", true);
    traspasoSelect=undefined;
    switch(id_page_select){
        case 'caja':
            wsConsultaSaldoCaja(usuario, divisa);
            break;
        case 'cajero':
            wsConsultaTraspasosSaldosACajeros(usuario, divisa);
            break;
        case 'fondeo': 
            wsConsultaFondeoEfecCajaACajero(usuario, divisa);
            break;
        case 'consultas':
            wsConsultaHistorialTraspasos(usuario, divisa);
            break;     
    }
}

function construirTicket(numOperacion,numTraspaso){    
    let importeLetras = "( "+NumeroALetras(Number(totalRecibir))+" )";
    let cajeroTrasp= usuario+"-"+serviceNombreEmpleado(usuario); 
    let cajeroRec = userAuto+"-"+serviceNombreEmpleado(userAuto); 
    
    let tituloTicket1="Concentracion de Saldos";
    let tituloTicket2="de Cajero a Caja Principal";
    let opero="Opero: "+empName+" en "+workstation;

    let contenido="<TICKET>"+
                    "<TEXT ALIGNH = \"CENTER\" FONTFAMILY = \"Cambria\" FONTSIZE = \"11\" FONTTYPE = \"N\">BANCO AZTECA, S.A</TEXT>"+
                    "<TEXT ALIGNH = \"CENTER\" FONTFAMILY = \"Cambria\" FONTSIZE = \"6\" FONTTYPE = \"N\">Tienda: "+sucNum+" "+sucName+"</TEXT>"+
                    "<TEXT ALIGNH = \"CENTER\" FONTFAMILY = \"Cambria\" FONTSIZE = \"6\" FONTTYPE = \"N\">"+getFecha()+"</TEXT>"+
                    "<TEXT></TEXT><TEXT></TEXT><TEXT ALIGNH = \"CENTER\" FONTFAMILY = \"Calibri\" FONTSIZE = \"11\" FONTTYPE = \"B\">"+tituloTicket1+"</TEXT>"+
                    "<TEXT ALIGNH = \"CENTER\" FONTFAMILY = \"Calibri\" FONTSIZE = \"11\" FONTTYPE = \"B\">"+tituloTicket2+"</TEXT>"+
                    "<TEXT ALIGNH = \"CENTER\" FONTFAMILY = \"Calibri\" FONTSIZE = \"6\" FONTTYPE = \"B\">"+opero+"</TEXT><TEXT></TEXT><LINE POSX = \"0\" WIDTH = \"100\" BORDERWIDTH = \"0.3\"></LINE>"+
                    "<TEXT ALIGNH = \"CENTER\" FONTFAMILY = \"Cambria\" FONTSIZE = \"9\" FONTTYPE = \"B\">Tipo de Pago  :  Efectivo</TEXT>"+
                    "<TEXT ALIGNH = \"CENTER\" FONTFAMILY = \"Cambria\" FONTSIZE = \"9\" FONTTYPE = \"B\">Divisa  :  "+desc_divisa+"</TEXT>"+
                    "<TEXT ALIGNH = \"CENTER\" FONTFAMILY = \"Cambria\" FONTSIZE = \"9\" FONTTYPE = \"B\">Num. Operacion  :  "+numOperacion+"</TEXT><TEXT></TEXT><TEXT></TEXT>"+
                    "<TEXT ALIGNH = \"CENTER\" FONTFAMILY = \"Cambria\" FONTSIZE = \"11\" FONTTYPE = \"B\">Folio de Traspaso  : "+numTraspaso+"</TEXT><TEXT></TEXT><TEXT></TEXT>";
    
        contenido+="<TEXT ALIGNH = \"CENTER\" FONTFAMILY = \"Calibri\" FONTSIZE = \"9\" FONTTYPE = \"B\">Descripcion                                      Importe</TEXT><TEXT></TEXT><TEXT></TEXT>"+
                   "<TEXT ALIGNH = \"CENTER\" FONTFAMILY = \"Calibri\" FONTSIZE = \"7\" FONTTYPE = \"B\">Importe Traspasado por "+ usuario +"            "+formatMoney(traspasoSelect.Importe)+"</TEXT>"+
                   "<TEXT ALIGNH = \"CENTER\" FONTFAMILY = \"Calibri\" FONTSIZE = \"7\" FONTTYPE = \"B\">Importe Confirmado por "+ userAuto +"            "+formatMoney(traspasoSelect.Importe)+"</TEXT><TEXT></TEXT><TEXT></TEXT>"+
                   "<TEXT ALIGNH = \"CENTER\" FONTFAMILY = \"Cambria\" FONTSIZE = \"9\" FONTTYPE = \"B\">Cajero que entrego</TEXT>"+                   
                   separaCadenasTickets(cajeroTrasp,"Cambria",9, "B")+"<TEXT></TEXT><TEXT></TEXT><TEXT></TEXT><LINE POSX = \"20\" WIDTH = \"30\" BORDERWIDTH = \"0.3\"></LINE>"+
                   "<TEXT ALIGNH = \"CENTER\" FONTFAMILY = \"Cambria\" FONTSIZE = \"9\" FONTTYPE = \"B\">Firma</TEXT><TEXT></TEXT><TEXT></TEXT>"+
                   "<TEXT ALIGNH = \"CENTER\" FONTFAMILY = \"Cambria\" FONTSIZE = \"9\" FONTTYPE = \"B\">Cajero que Recibio</TEXT>"+
                   separaCadenasTickets(cajeroRec,"Cambria",9, "B")+"<TEXT></TEXT><TEXT></TEXT><TEXT></TEXT><LINE POSX = \"20\" WIDTH = \"30\" BORDERWIDTH = \"0.3\"></LINE>"+
                   "<TEXT ALIGNH = \"CENTER\" FONTFAMILY = \"Cambria\" FONTSIZE = \"9\" FONTTYPE = \"B\">Firma</TEXT></TICKET>";
    
    console.log(contenido);
    let listaTickets={"ListaTickets":[{
		                "Aplicacion":"Caja",
		                "Contenido":contenido,
		                "NoCopias": 1
	                 }]};
    return listaTickets;
}

function separaCadenasTickets(cadena, font, size, fontType){
    let cant = Math.round(cadena.length/35);
    let result="";
    let iniIndex=0;
    let endIndex=35;    
    for (let i=0; i<=cant; i++){ 
        if(cadena.substring(iniIndex,endIndex)!=""){   	
        	result+="<TEXT ALIGNH = \"CENTER\" FONTFAMILY = \""+font+"\" FONTSIZE = \""+size+"\" FONTTYPE = \""+fontType+"\">"+cadena.substring(iniIndex,endIndex);
            result+=endIndex>=cadena.length?"</TEXT>":"-</TEXT>";            
        }
        iniIndex=endIndex;
        endIndex=iniIndex+35>cadena.length?cadena.length:iniIndex+35;
	}
    return result;
}

function editarMonto(){    
    $('#importe_denominacion').attr("disabled", false);
    $('#importe_denominacion').focus();
}

function cambiarMontoTrasp(val){ 
    console.log(val);  
    let newImporte=Number(val.value);
    let idSaldoActual="saldoDisponible"+page_select;
    let saldo= deleteFormatMoney($('#'+idSaldoActual).text());
    if(newImporte==0){
        alert ("El monto debe ser mayor a cero");
    }else{
        if(newImporte>=saldo){
            alert("Saldo insuficiente para el traspaso");
        }else{
            importeTrasp=newImporte;
            $('#importe'+page_select).val(importeTrasp);
        }
    }
}

function interrumpirProceso(){    
    if (tipoAccion=="traspasar"){
        isHuellaT=true;
        $("#btnDelete"+page_select).attr("disabled", false);
    }else
        isHuellaR=true;
    $j.modal.close();    
}

function salirDenominaciones(){
    $j.modal.close();
    $j("#modal06").modal();
}

function noSalirDenominaciones(){
    $j.modal.close();
    $j("#modal01").modal();
}

function siSalirDenominaciones(){
    if(tipoAccion=="traspasar"){
        importeTrasp=0;
        $("#importe"+page_select).val("");
        $("#importe"+page_select).attr("disabled", false);
    }
    $j.modal.close();
}

function finishConfirmacion(){    
    if(id_page_select=="caja"){
        mostrarCarga(true);
        imprimir();                              
    } else{
        mostrarCarga(true);
        reloadContent();
    }
}

function imprimir(){
    mostrarCarga(true); 
    $.when(generaTicket(construirTicket(transaccionImpr,concentracionImpr), false, true)).then(function(result){       
        if(result.Contenido>0){
            $.when(imprimirTicket(result.Contenido, false, true)).then(function(resultI){
                if(pagare.suscriptor){
                    let ruta = wsurlGeneraCartaFaltante(pagare, totalRecibirRestante);
                    result=imprimirCarta(ruta, false, false);
                } 
                $j.modal.close();
                $j('#modal07').modal();
            }).fail(function(){ $j.modal.close();
                $j('#modal07').modal();});           
        }        
    }).fail(function(){ $j.modal.close();
        $j('#modal07').modal();});
}

