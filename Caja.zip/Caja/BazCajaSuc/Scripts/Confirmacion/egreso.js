﻿var egresosPend = [];
var totalEgresos=[];

var detalleDocsLista=[];
var depLista=[];

var opcion = "3";

$(document).ready(function () {
    mostrarCarga(true);
    document.title = titulo;
    divisa = divisa == '' ? "1" : divisa;
    desc_divisa = desc_divisa = '' ? "Moneda Nacional" : desc_divisa;
    $('#desc_divisa').html(desc_divisa);

    //Cargar tipo pago
    wsConsultaTiposdePago();
});

function changeEgresos(){
    $('#egresosPendientes').hide();
    $('#saldoActualegreso').val(formatMoney("0"));
    $('#topeMaxegreso').val(formatMoney("0"));
    $('#importeegresar').val("");
    $("#btnegreso").attr("disabled", true);
    $('#selectEgresos').prop('checked', false);
    depLista=[];
    detalleDocsLista=[];
}

function egresarDocumento(){
    mostrarCarga(true);
    let consulta = {
                "NoEmpleado": usuario,
                "NoEmpleadoAuto": usuario,
                "NombreEmpleado": empName,
                "Tienda": sucNum+"-"+sucName,
                "FormaPago":"0",
                "UltTraspaso": "0",
                "Divisa": divisa,
                "Terminal": workstation,
                "LstTipoPago": depLista
            };
     console.log(consulta);     
     wsEgresaTraspaso(consulta);
}

function separaEgresos(input){
    let jsonAux=input;    
    let jsonDepositos=[];
    let jsonDocumentos=[];  
    let queryResultE=[]
    for (let val of jsonAux){
	    let queryDepositos = Enumerable.From(jsonAux)
            .Where(function (x) { return x.Deposito ==val.Deposito})    
            .Select(function (x) { return x }).ToArray();          
        if(queryDepositos.length>0){
    	    queryResultE.push(queryDepositos);
        }
	    jsonAux=jsonAux.filter(function(itm){return itm.Deposito!==val.Deposito});     
    }
    let numDoctos=0;
    for (let val of queryResultE){
    	let aux=val[0];
        jsonDocumentos=[];        
	    for(let doc of val){
  	        let auxDoc=doc;
      	    let queryDoc = Enumerable.From(val)
    		    .Where(function (y) { return y.Numero ==doc.Numero})   
    			.Select(function (y) { return y }).ToArray();    		
    		if (queryDoc.length>0){                
        	    jsonDocumentos.push(queryDoc);        
            }
            val=val.filter(function(itm){return itm.Numero!==doc.Numero}); 
        }        
        jsonDepositos.push({"Deposito":aux.Deposito, "TranEgr": aux.TranEgr, "Emisor": aux.Emisor, 
            "EmisorConf": aux.EmisorConf, "EmisorEgr": aux.EmisorEgr, "FechaConf": aux.FechaConf, 
            "FechaDep": aux.FechaDep, "FechaEgr": aux.FechaEgr, "ImporteDep": aux.ImporteDep, 
            "ImporteEgr": aux.ImporteEgr, "MontoDocto": aux.MontoDocto, "NoEgreso": aux.NoEgreso,  
            "Numero": aux.Numero, "TipoPuesto": aux.TipoPuesto, "TranDep": aux.TranDep, 
            "documentos":jsonDocumentos});
    }
    console.log(jsonDepositos); 
    return jsonDepositos;   
}

function llenaEgresos(array) {
    totalEgresos= array;
    $('#egresosPendientes').show();
    let egresos= separaEgresos(array);    
    egresosPend=egresos;
    let accordion='<dl class="accordion">';    
    egresosPend=egresos;    
    $.each(egresos, function (i, p) {    
        accordion += "<div class='checks'>" +
                        "<input type='checkbox' onchange='onCheckEgreso("+i+","+true+")' id='checkEgreso"+i+"' />"+
					    "<label for='checkEgreso"+i+"'></label>"+
				     "</div>";
        accordion+="<dt id='dtEgreso"+i+"' class='AcoInpar' onclick='expand(dtEgreso"+i+")'>"+
                        '<table class="tblGeneral3 w90">'+
                            '<tbody>'+
                                '<tr>'+
							        '<td class="tLeft">'+p.Deposito+'</td>'+ 
                                    '<td>'+p.FechaDep+'</td>'+ //Fecha
                                    '<td>'+p.Emisor+'</td>'+                                    
                                    '<td></td>'+                                    
                                    '<td>'+formatMoney(Number(p.ImporteDep))+'</td>'+
                                 '</tr>'+
                            '</tbody>'+
                        '</table>'+
                    '</dt>'+
                    '<dd id="ddEgreso'+i+'" style="display: none;">'+
                        '<div class="inner"> '+
                            '<div class="">'+                                
                                '<table class="tblGeneral3 w90" style="text-align: right;">'+
                                "<tbody>";
                                let table="";                                
                                    $.each(p.documentos, function (j, d) {                                        
                                        table+= "<tr>"+
                                                '<td class="tLeft">No. Oper: '+d[0].TranEgr+'</td>'+                                                
                                                '<td>&nbsp;</td>'+
                                                '<td>&nbsp;</td>'+
                                                '<td>'+d[0].Numero+'</td>'+
                                                '<td>' +formatMoney(d[0].MontoDocto)+'</td>'+
                                            "</tr>";
                                    });
                                    if (table==""){
                                        table="<tr><td>&nbsp;</td></tr>";
                                    }
                                accordion+= table + "</tbody></table>"+
                             '</div>'+
                         '</div>'+
                     '</dd> '+
				     '<div class="clear"></div>';                      
    });
    accordion+='</dl>';
    $('#egresosPendientes').html(accordion);    
    mostrarCarga(false);   
}

function onCheckEgreso(id, validar){    
    $('#btn'+page_select).attr("disabled", true);
    if($('#checkEgreso'+id).is(':checked') && Number(egresosPend[id].ImporteDep)<=0 ){
        $('#checkEgreso'+id).prop('checked', false);
    }else{        
        let imp = egresosPend[id].ImporteDep;
        if(Number(imp)>0){			
            checkUncheckEgresos();
		}else{
            $('#checkEgreso'+id).prop('checked', false);            
        }
    }
    if($('#selectEgresos').is(':checked') || validar) 
        validaChecksEgresos();    
}

function validaChecksEgresos(){
    let status=false;
    for (let i=0; i<egresosPend.length;i++){       
        status= $('#checkEgreso'+i).is(':checked'); 
        if(!status)break;           
    }
    $('#selectEgresos').prop('checked', status);
}

function checkUncheckEgresos(status){
    let importe =0;
    let index=0;
    depLista=[];
    detalleDocsLista=[];
    let change;
    $('#btn'+page_select).attr("disabled", true);         
    $.each(egresosPend, function (i, egreso) { 
        if(status!=undefined) $('#checkEgreso'+i).prop('checked', status);
        if($('#checkEgreso'+i).is(':checked')){
            if(Number(egreso.ImporteDep)>0){
                importe += Number(egreso.ImporteDep);
                detalleDocsLista.push({ "Importe":  egreso.MontoDocto, "NoDocto": egreso.Numero, 
                                        "NoDeposito": egreso.Deposito, "NoOperacion": egreso.TranEgr});
            }
        }       
    });
    $('#importeegresar').val(importe.toFixed(2));
    if(importe>0){
        $('#btn'+page_select).removeAttr("disabled");
        depLista.push({ "Tipo_PagoId": idTipoPago, "TipoPagoDesc": tipoPago, "SaldoTotal": importe.toString(), 
                        "LstDocumento": detalleDocsLista});
    }
    console.log(depLista);
}

function selectEgresos(){    
    checkUncheckEgresos($('#selectEgresos').is(':checked'));  
    validaChecksEgresos();
}