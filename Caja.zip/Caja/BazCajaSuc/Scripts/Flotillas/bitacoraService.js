﻿let erroresCount = 0; //Para evitar que se cicle
let bitacoraCountRegistro = 0; //Para evitar que se cicle el registro
var BitacoraService = {
getUrlServicio:function getUrlServicio(nombreServicio) {

        // var protocolo = "http"
        // var ipPuerto = "10.54.28.226:9014"
        // var rutaAplicativo = "BazCajaSuc/Servicios/TiposPago/TiposPago.svc"
        // var protocolo = "http";
        // var ipPuerto = "10.54.28.114:9014";
        // var rutaAplicativo = "http://localhost:2860/FlotillasService.svc;
        var protocolo = "http";
        var ipPuerto = ""
        var rutaAplicativo = "";                    
        if(window.location.hostname == "localhost"){
            ipPuerto = "10.54.28.221:9014";
            rutaAplicativo = "Caja/Servicios/Flotillas/FlotillasService.svc/FlotillasRest"; //<- Se necesita un metodo expuesto como servicio para el registro en bitacora
        }
        else{
            ipPuerto= window.location.host;
            rutaAplicativo = "Caja/Servicios/Flotillas/FlotillasService.svc/FlotillasRest";
        }                    
        var urlBase = protocolo + "://" + ipPuerto + "/" + rutaAplicativo + "/";
        var r = urlBase + nombreServicio;
        return r;
    }
}

function registraHistorial(entrada,id) {  
    var urlServicio = BitacoraService.getUrlServicio("RegistraHistorial");
    var parametros = {
        Mensaje: "ID/BR["+id+"] "+entrada//string
    };
    var dfd = $.Deferred();
    doHistorialPost(urlServicio, parametros, true).done(function (objResponse) {
        erroresCount = 0;
        dfd.resolve(objResponse);
    }).fail(function () {
        erroresCount += 1;
    })
    return dfd.promise();
} //RequestMensaje:void

/*
RequestMensaje = {
    Mensaje: mensaje
}
*/