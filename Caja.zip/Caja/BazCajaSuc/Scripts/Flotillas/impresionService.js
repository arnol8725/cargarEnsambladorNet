﻿var ImpresionService = {
    getUrlServicio: function getUrlServicio(nombreServicio) {
        var protocolo = "http";
        var ipPuerto = "localhost:9001";
        var rutaAplicativo = rutaAplicativo = "WSDesTecAppsLocal";
        var urlBase = protocolo + "://" + ipPuerto + "/" + rutaAplicativo + "/";
        var r = urlBase + nombreServicio;
        return r;
    }
}

function generaTicket(entrada) {
    $.LoadingOverlay("show");
    var urlServicio = ImpresionService.getUrlServicio("GenerarTickets");
    var parametros = {
        ListaTickets: [{
            Aplicacion: entrada.Aplicacion,
            Contenido: entrada.Contenido,
            NoCopias: entrada.NoCopias
        }]
    };
    var dfd = $.Deferred();
    doJsonPost(urlServicio, parametros, true).done(function (objResponse) {
        dfd.resolve(objResponse);
        $.LoadingOverlay("hide");
    }).fail(function () {
        $.LoadingOverlay("hide");
    });
    return dfd.promise();
}

function imprimirTicket(ticket) {
    $.LoadingOverlay("show");
    var urlServicio = ImpresionService.getUrlServicio("ImprimirTickets?idticket=");
    urlServicio += ticket;
    var parametros = {};
    var dfd = $.Deferred();
    doJsonPost(urlServicio, parametros, true).done(function (objResponse) {
        dfd.resolve(objResponse);
        $.LoadingOverlay("hide");
    }).fail(function () {
        $.LoadingOverlay("hide");
    });
    return dfd.promise();
}
