﻿//Ejemplo de Tipos de pago tarjeta

var FlotillaService = {
getUrlServicio:function getUrlServicio(nombreServicio) {

        // var protocolo = "http"
        // var ipPuerto = "10.54.28.226:9014"
        // var rutaAplicativo = "BazCajaSuc/Servicios/TiposPago/TiposPago.svc"
        var protocolo = "http";
        var ipPuerto = "";
        var rutaAplicativo = "";                    
        if(window.location.hostname == "localhost"){
            ipPuerto = "10.54.28.221:9014";
            rutaAplicativo = "Caja/Servicios/Flotillas/FlotillasService.svc/FlotillasRest";
        }
        else{
            ipPuerto= window.location.host;
            rutaAplicativo = "Caja/Servicios/Flotillas/FlotillasService.svc/FlotillasRest";
        }
        var urlBase = protocolo + "://" + ipPuerto + "/" + rutaAplicativo + "/";
        var r = urlBase + nombreServicio;
        return r;
    }
}

function buscaCodigoPago(entrada) {
    $.LoadingOverlay("show");
    var urlServicio = FlotillaService.getUrlServicio("BuscaCodigoPago");
    var parametros = {
        ParametroString: entrada.parametroString //string                
    };
    var dfd = $.Deferred();
    doJsonPost(urlServicio, parametros, true).done(function (objResponse) {
        dfd.resolve(objResponse);
        $.LoadingOverlay("hide");
    }).fail(function () {
        $.LoadingOverlay("hide");
    });
    return dfd.promise();
} 

function confirmaPago(entrada) {
    $.LoadingOverlay("show");
    var urlServicio = FlotillaService.getUrlServicio("GeneraIngresoCaja");
    var parametros = {
        Folio: entrada.Folio, //string
        //Importe: entrada.Importe, 
        Ip: entrada.Ip,       
        TransTipo: entrada.TransTipo,
        Usuario: entrada.Usuario,
        WS: entrada.WS
    };
    var dfd = $.Deferred();
    doJsonPost(urlServicio, parametros, true).done(function (objResponse) {
        dfd.resolve(objResponse);
        $.LoadingOverlay("hide");
    }).fail(function () {
        $.LoadingOverlay("hide");
    });
    return dfd.promise();
} 