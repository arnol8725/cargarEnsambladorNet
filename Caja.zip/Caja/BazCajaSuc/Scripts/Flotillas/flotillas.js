﻿const TRANSTIPO=3279;
const APP="Caja";
var usuario = getParamUrl("usuario");
const NOCOPIAS=2;

let timeStampBitacoraFlotillas;
let timeStampErroresFlotillas;

var tableFlotillas;

var ticket="";

var datosOperacion = {   
//hay que verificar si esos parametros realmente se van a utilizar
   usuario: getUrlVars()["usuario"],
   workstation: getUrlVars()["WS"],
   ip: "localhost"
}

var jsonRecords={};

$(document).ready(function () {   
    if (FuncionesFlotillas.validaGet()) {
        timeStampBitacoraFlotillas = Commons.getStampId(datosOperacion.usuario) //Esta va a servir para los eventos que no son errores
    }
    $("#efectivoRecibido").focusout(function () {
        var texto = $("#efectivoRecibido").val();
        $("#efectivoRecibido").val(formatMoney(texto));
    });

    $("#efectivoRecibido").focusin(function () {
        var texto = $("#efectivoRecibido").val();
        $("#efectivoRecibido").val(deleteFormatMoney(texto));
    });

});

function buscaFolioPago()
{
	try{        
		let folioPago = $("#folioPago");
        if(folioPago.val()==""){            
            FuncionesCommons.mostrarModal('error');
            let e = document.getElementById("modal00").querySelector("#lblError");
            e.innerHTML = "Introduzca un folio";
            return;
        }
		var parametros = {
        	parametroString : folioPago.val()
    	};
	    buscaCodigoPago(parametros).done(function(respuesta) {
	        try {
	            timeStampErroresFlotillas = Commons.getStampId(datosOperacion.usuario);
	            if (!isDefined(respuesta)) {
                    initComponents(true);
	                registraHistorial("El servicio de buscaCodigoPago no ha respondido, respuesta = " +
	                    JSON.stringify(respuesta, null, 4),
	                    timeStampErroresFlotillas);
	                avisaError(
	                    "No se ha obtenido respuesta del servicio de consulta de Folio. </br>[Código de seguimiento:" +
	                    timeStampErroresFlotillas +
	                    "]");
	                return;
	            }
	            if (!isDefined(respuesta.UnidadFlotilla)) {
                    initComponents(true);
                    $('#content').show();
	                registraHistorial(respuesta.Mensaje || "El servicio de buscaCodigoPago no ha respondido correctamente, respuesta = " +
	                    JSON.stringify(respuesta, null, 4),
	                    timeStampErroresFlotillas);
	                avisaError((respuesta.Mensaje ||
	                    "El servicio de consulta de Folio no ha respondido correctamente.")+" </br>[Código de seguimiento:" +
	                    timeStampErroresFlotillas +
	                    "]");
	                return;
	            }	            
	            //Continua Aqui                
                switch (respuesta.NumeroError){
                    case "0": //exito
                        initComponents(false);
                        getObjectFlotillas(respuesta.UnidadFlotilla);
                        createTable('flotillas_table', jsonRecords.flotillas, false, false, false, false);                        
                        onFocusImporte();
                        $('#content').show();
                        break;
                    case "1": //error
                        initComponents(true);  
                        $('#content').show();                      
                        finalizarConError(respuesta.Mensaje);
                        break;
                }
	            

	        } catch (oError) {
                initComponents(true);
	            timeStampErroresFlotillas = Commons.getStampId(datosOperacion.wS);
	            registraHistorial("Ocurrió un error no controlado en buscaCodigoPago oError = " +
	                JSON.stringify(oError, null, 4),
	                timeStampErroresFlotillas);
	            finalizarConError(
	                "Algo salio mal en la busqueda del Folio, si el problema persiste favor de comunicarse a soporte. </br>[Código de seguimiento:" +
	                timeStampErroresFlotillas +
	                "]");
	            return;
	        }
	    });
	}	
    catch (oError) {
        timeStampErroresFlotillas = Commons.getStampId(datosOperacion.usuario);      
        registraHistorial("Ocurrió un error no controlado en buscaFolioPago oError = "+JSON.stringify(oError, null, 4),timeStampErroresFlotillas);                                                
        finalizarConError("Algo salio mal la busqueda del Folio, si el problema persiste favor de comunicarse a soporte. </br>[Código de seguimiento:"+timeStampErroresFlotillas+"]");
        return;
    }	
}

function initComponents(status){
    $("#cambio").val("");
    $("#efectivoRecibido").val("");    
    $("#importePagar").val("");
    $('#efectivoRecibido').attr('disabled',status);
    $('#btnConfirmar').attr('disabled',status);  
    if(status){
        $("#folioPago").val("");
        $('#flotillas_table tbody').hide();
    }else{        
        $('#flotillas_table tbody').show();
    }
}

function validaFolioPago(e, input) {
    // Allow: backspace, delete, tab, escape, enter and .
    try
    {
        var keyCode;
        var objeto;
        // event passed as param in Firefox, not IE where it's defined as window.event
        if (!e) {
            e = window.e;
            keyCode = e.keyCode;
        }
        else { // ff
            keyCode = e.which;
        }        
        if (keyCode == 13) {
        	buscaFolioPago();
        }

	    if ($.inArray(e.keyCode, [46, 8, 9, 27, 13, 110, 190]) !== -1 ||
	         // Allow: Ctrl/cmd+A
	        (e.keyCode == 65 && (e.ctrlKey === true || e.metaKey === true)) ||
	         // Allow: Ctrl/cmd+C
	        (e.keyCode == 67 && (e.ctrlKey === true || e.metaKey === true)) ||
	         // Allow: Ctrl/cmd+X
	        (e.keyCode == 88 && (e.ctrlKey === true || e.metaKey === true)) ||
	         // Allow: home, end, left, right
	        (e.keyCode >= 35 && e.keyCode <= 39)) {
	             // let it happen, don't do anything
	             return;
	    }
	    // Ensure that it is a number and stop the keypress
	    if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
	        e.preventDefault();
	    }
	}
    catch (oError) {
        timeStampErroresFlotillas = Commons.getStampId(datosOperacion.usuario);      
        registraHistorial("Ocurrió un error no controlado en validaFolioPago oError = "+JSON.stringify(oError, null, 4),timeStampErroresFlotillas);                                                
        finalizarConError("Algo salio mal validando el Folio, si el problema persiste favor de comunicarse a soporte. </br>[Código de seguimiento:"+timeStampErroresFlotillas+"]");
        return;
    }
}

function validaImporteRecibido(e, input) {
    // Allow: backspace, delete, tab, escape, enter and .
    try
    {
        var keyCode;
        var objeto;
        // event passed as param in Firefox, not IE where it's defined as window.event
        if (!e) {
            e = window.e;
            keyCode = e.keyCode;
        }
        else { // ff
            keyCode = e.which;
        }        
        if (keyCode == 13) {
        	confirmaFolioPago();
        }

	    if ($.inArray(e.keyCode, [46, 8, 9, 27, 13, 110, 190]) !== -1 ||
	         // Allow: Ctrl/cmd+A
	        (e.keyCode == 65 && (e.ctrlKey === true || e.metaKey === true)) ||
	         // Allow: Ctrl/cmd+C
	        (e.keyCode == 67 && (e.ctrlKey === true || e.metaKey === true)) ||
	         // Allow: Ctrl/cmd+X
	        (e.keyCode == 88 && (e.ctrlKey === true || e.metaKey === true)) ||
	         // Allow: home, end, left, right
	        (e.keyCode >= 35 && e.keyCode <= 39)) {
	             // let it happen, don't do anything
	             return;
	    }
	    // Ensure that it is a number and stop the keypress
	    if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
	        e.preventDefault();
	    }
	}
    catch (oError) {
        timeStampErroresFlotillas = Commons.getStampId(datosOperacion.usuario);      
        registraHistorial("Ocurrió un error no controlado en validaImporteRecibido oError = "+JSON.stringify(oError, null, 4),timeStampErroresFlotillas);                                                
        finalizarConError("Algo salio mal validando el Efectivo recibido, si el problema persiste favor de comunicarse a soporte. </br>[Código de seguimiento:"+timeStampErroresFlotillas+"]");
        return;
    }
}

function calculaCambio(){
    let totalRecibido=Number(jsonRecords.importeTotal);
    let totalPagado=Number(deleteFormatMoney($("#efectivoRecibido").val()));
    let cambio=0;
    if(totalPagado>=totalRecibido){
        cambio=totalRecibido-totalPagado;
        $("#cambio").val(formatMoney(cambio));
    }else{
        $("#cambio").val(formatMoney(0));
    }
}


function confirmaFolioPago()
{
	try{
		let folioPago = $("#folioPago");
        let totalPagado =$("#efectivoRecibido");        
        if(Number(deleteFormatMoney(totalPagado.val())) < Number(jsonRecords.importeTotal)){
            FuncionesCommons.mostrarModal('errorImporte');
            let e = document.getElementById("modal00").querySelector("#lblError");
            e.innerHTML = "El importe capturado es menor al total a pagar, por favor verifique.";                  
            return;
        }
        calculaCambio();
		var parametros = {
        	Folio : folioPago.val(),            
            Ip: datosOperacion.ip,
            TransTipo: TRANSTIPO,
            Usuario: datosOperacion.usuario,
            WS: datosOperacion.workstation
    	};        
	    confirmaPago(parametros).done(function(respuesta) {
	        try {
	            timeStampErroresFlotillas = Commons.getStampId(datosOperacion.usuario);
	            if (!isDefined(respuesta)) {
	                registraHistorial("El servicio de confirmaPago no ha respondido, respuesta = " +
	                    JSON.stringify(respuesta, null, 4),
	                    timeStampErroresFlotillas);
	                avisaError(
	                    "No se ha obtenido respuesta del servicio de confirmación de Pago. </br>[Código de seguimiento:" +
	                    timeStampErroresFlotillas +
	                    "]");
	                return;
	            }
	            if (!isDefined(respuesta.RespuestaString)) {
	                registraHistorial("El servicio de confirmaPago no ha respondido correctamente, respuesta = " +
	                    JSON.stringify(respuesta, null, 4),
	                    timeStampErroresFlotillas);
	                avisaError(
	                    "El servicio de confirmación de Pago no ha respondido correctamente. </br>[Código de seguimiento:" +
	                    timeStampErroresFlotillas +
	                    "]");
	                return;
	            }else{
                    if (respuesta.RespuestaString!="") {
						ticket=respuesta.RespuestaString.replace(/\\"/gi,"\""); ;                        
                        FuncionesFlotillas.mostrarModal("confirmadoOperacion");
                    }else{
                        $('#folioPago').val("");
                        finalizarConError(respuesta.Mensaje+". </br>[Código de seguimiento:" +timeStampErroresFlotillas +"]");
                    }                    
                }                	            
	        } catch (oError) {
	            timeStampErroresFlotillas = Commons.getStampId(datosOperacion.wS);
	            registraHistorial("Ocurrió un error no controlado en confirmaPago oError = " +
	                JSON.stringify(oError, null, 4),
	                timeStampErroresFlotillas);
	            finalizarConError(
	                "Algo salio mal confirmando el Pago, si el problema persiste favor de comunicarse a soporte. </br>[Código de seguimiento:" +
	                timeStampErroresFlotillas +
	                "]");
	            return;
	        }
	    });
	}	
    catch (oError) {
        timeStampErroresFlotillas = Commons.getStampId(datosOperacion.usuario);      
        registraHistorial("Ocurrió un error no controlado en buscaFolioPago oError = "+JSON.stringify(oError, null, 4),timeStampErroresFlotillas);                                                
        finalizarConError("Algo salio mal buscando el Folio, si el problema persiste favor de comunicarse a soporte. </br>[Código de seguimiento:"+timeStampErroresFlotillas+"]");
        return;
    }
	
}

function ImprimirTicket()
{
	try{		
		var parametros = {"ListaTickets":[{
				"Aplicacion":"Caja",
				"Contenido":ticket,
				"NoCopias":2}]}
	    generaTicket(parametros).done(function(respuesta) {
	        try {
	            timeStampErroresFlotillas = Commons.getStampId(datosOperacion.usuario);
	            if (!isDefined(respuesta)) {
	                registraHistorial("El servicio de genera Ticket no ha respondido, respuesta = " +JSON.stringify(respuesta, null, 4),timeStampErroresFlotillas);
	                avisaError("No se ha obtenido respuesta del servicio de generación de Ticket. </br>[Código de seguimiento:" +timeStampErroresFlotillas +"]");
	                return;
	            }
                if(respuesta.Contenido>0){
                    imprimirTicket(respuesta.Contenido).done(function(respuesta) {
                        try {
                            FuncionesFlotillas.mostrarModal("imprimirTicket");
                        }catch(oError){
                            timeStampErroresFlotillas = Commons.getStampId(datosOperacion.wS);
	                        registraHistorial("Ocurrió un error no controlado al imprimir el Ticket oError = " + JSON.stringify(oError, null, 4), timeStampErroresFlotillas);
	                        finalizarConError("Algo salio mal imprimiendo el Ticket, si el problema persiste favor de comunicarse a soporte. </br>[Código de seguimiento:" +timeStampErroresFlotillas +"]");
	                        return;
                        }
                    });
                }else{
                    finalizarConError("Ocurrió un error al imprimir el Ticket. </br>[Código de seguimiento:" +timeStampErroresFlotillas +"]");
                }
	        } catch (oError) {
	            timeStampErroresFlotillas = Commons.getStampId(datosOperacion.wS);
	            registraHistorial("Ocurrió un error no controlado en la generación del ticket oError = " + JSON.stringify(oError, null, 4), timeStampErroresFlotillas);
	            finalizarConError(
	                "Algo salio mal generando el Ticket, si el problema persiste favor de comunicarse a soporte. </br>[Código de seguimiento:" +
	                timeStampErroresFlotillas +
	                "]");
	            return;
	        }
	    });
	}	
    catch (oError) {
        timeStampErroresFlotillas = Commons.getStampId(datosOperacion.usuario);      
        registraHistorial("Ocurrió un error no controlado en imprimeVoucher oError = "+JSON.stringify(oError, null, 4),timeStampErroresFlotillas);                                                
        finalizarConError("Algo salio mal imprimiendo el Voucher, si el problema persiste favor de comunicarse a soporte. </br>[Código de seguimiento:"+timeStampErroresFlotillas+"]");
        return;
    }
	
}

function createTable(idTable, myRecords, paginate, recordCount, sort, search){   
   tableFlotillas= $('#'+idTable).dynatable({        
        dataset: { 
            records: myRecords
        },
        features: {
            paginate: paginate,
            recordCount: recordCount,
            sorting: sort,
            search: search
        }
    });
    tableFlotillas.data('dynatable').settings.dataset.records = myRecords;
    tableFlotillas.data('dynatable').dom.update();
}

function getObjectFlotillas(flotilla){  
    let arrayFlotillas=[];
    arrayFlotillas.push(flotilla);
    let importeTotal=0;     
    for (let u of arrayFlotillas){
        importeTotal+=Number(u.Importe);
        u.Importe=formatMoney(u.Importe);
    }
    $("#importePagar").val(formatMoney(importeTotal));
    jsonRecords = {flotillas: arrayFlotillas, importeTotal: importeTotal, voucher: "", importeRecibido: ""};        
}

function formatMoney(num) {    
    var p = Number(num).toFixed(2).split(".");
    return "$" + p[0].split("").reverse().reduce(function(acc, num, i, orig) {
        return  num=="-" ? acc : num + (i && !(i % 3) ? "," : "") + acc;
    }, "") + "." + p[1];
}

function deleteFormatMoney(str){
    let res = str.toString().split("$").join("");
    res = res.split(",").join("");
    return res;
}

function onFocusImporte(){    
    $("#efectivoRecibido").val("");
    $("#efectivoRecibido").focus();
}

function reloadContent(){    
    jsonRecords=[];
    initComponents(true);
}

function getCleanedString(cadena){  
   // Quitamos acentos
   cadena = cadena.replace(/á/gi,"a");
   cadena = cadena.replace(/é/gi,"e");
   cadena = cadena.replace(/í/gi,"i");
   cadena = cadena.replace(/ó/gi,"o");
   cadena = cadena.replace(/ú/gi,"u");   
   return cadena;
}