﻿var ManejadorMsgFlotillas ={
    getContent: function getContent(caseMessage) {
        content = "";
        switch (caseMessage) {
            case "operacionRebaseTope":
            content = '<div class="cuadro2">\
                            <a style="visibility:hidden" href="#" class=" simplemodal-close" id="botonCerrar">\
                                    <img src="../../Imgs/cerrar.png" class="cerrar">\
                            </a>\
                            <div class="titModal">Atención</div>\
                            <div class="clear"></div><br>\
                            <div class="texto1">\
                                Con ésta operación, el <strong>empleado</strong> ha rebasado el tope,<br>\
                                debe hacer el traspaso de: efectivo \
                                <br><br>\
                                <div class="porcentaje"><div class="verde" style="width: 80%"></div></div>\
                            </div><br>\
                            <div class="botones1"><a onclick="cerrarModal()" href="#" class="btnV w48" id="modalPagoAM_view">Aceptar</a></div><br>   \
                        </div>';
                break;
            case "confirmadoOperacion":
                content = '<div class="cuadro1">\
                            <a style="visibility:hidden" href="#" class=" simplemodal-close" id="botonCerrar">\
                                    <img src="../../../Imgs/cerrar.png" class="cerrar">\
                            </a>\
                            <div class="titModal">Operación confirmada</div>\
                            <div class="clear"></div><br>\
                            <div class="texto1">\
                                La operación se confirmo correctamente\
                            </div><br>\
                            <div class="tCenter">\
                                    <a href="#" class="btnB w48" onclick="ImprimirTicket()">Aceptar</a>\
                            </div><br>\
                        </div>';
                break;        
            case "imprimirTicket":
                content = '<div class="cuadro1">\
                            <a style="visibility:hidden" href="#" class=" simplemodal-close" id="botonCerrar">\
                                    <img src="../../../Imgs/cerrar.png" class="cerrar">\
                            </a>\
                            <div class="titModal">Imprimiendo comprobante</div>\
                            <div class="clear"></div><br>\
                            <div class="texto1">\
                                ¿Se imprimió correctamente el ticket?\
                            </div><br>\
                            <div class="tCenter">\
                                    <a href="#" class="btnB w48" onclick="ImprimirTicket()">No</a>\
                                    <a href="#" class="btnV w48" onclick="reloadContent();cerrarModal()">Sí</a>\
                            </div><br>\
                        </div>';
                break;               
            default:
                content = '<p>No se eligío un mensaje valido para mostrar<\p>'
            break;

        }
        return content;
    }
};