﻿var FuncionesFlotillas = {
    mostrarModal: function mostrarModal(tipo) {
        cerrarModal();
        html = ManejadorMsgFlotillas.getContent(tipo);
        $('#modal00').empty();
        $('#modal00').append(html);
        $('#modal00').modal();
    },
    validaGet: function validaGet() {
        let result = false;
        try {
            timeStampErroresFlotillas = Commons.getStampId(datosOperacion.usuario);
                    
            if (datosOperacion.usuario != "" || datosOperacion.workstation != "" ) {
                if (datosOperacion.usuario === undefined || datosOperacion.workstation === undefined ) {                
                    registraHistorial("Los datos para procesar la operación ha llegado incompletos, no declarados o indefinidos; " + JSON.stringify(datosOperacion, null, 4)+" ;",timeStampErroresFlotillas);                
                    finalizarConError("No se han mandado los parámetros correctos. </br>[Código de seguimiento:"+timeStampErroresFlotillas+"]");
                }
                else {
                    result = true;
                }
            }
        }
        catch (err) {
            timeStampErroresFlotillas = Commons.getStampId(datosOperacion.wS);      
            registraHistorial("Ocurrió un error no controlado durante la inicializacion de la pagina; oError = "+JSON.stringify(oError, null, 4),timeStampErroresFlotillas);                                                
            finalizarConError("Algo salio mal, si el problema persiste favor de comunicarse a soporte." + " </br>[Código de seguimiento:"+timeStampErroresFlotillas+"]");        
        }
        finally {
            return result;
        }
    }

};