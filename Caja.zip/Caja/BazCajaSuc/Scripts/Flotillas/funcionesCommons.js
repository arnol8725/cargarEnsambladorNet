function isDefined(obj) {
    if (obj === undefined || obj === null) {
        return false;
    }
    else {
        return true
    }
}

var FuncionesCommons = {
    mostrarModal: function mostrarModal(tipo) {
        cerrarModal();
        html = ManejadorMsgCommons.getContent(tipo);
        $('#modal00').empty();
        $('#modal00').append(html);
        $('#modal00').modal();
    }
};