﻿var timeStampErroresCommons;
var sesionRandomId = "";
var pantallaCargada = false;
$(document).ready(function () {   
    let e = document.getElementById("modal00");
    if(e === null || e === undefined || e === "")
    {
        $("body").append('<div id="modal00" class="modal"> </div>');
    }    
});

function doJsonPost(urlServicio, parmsIn, closeOnError) {
    substring = "RegistraHistorial";    
    if(urlServicio.indexOf(substring) === -1){
        timeStampErroresCommons = Commons.getStampId();      
        registraHistorial("Se ha realizado un doJsonPost urlServicio= " + JSON.stringify(urlServicio, null, 4) + "\n closeOnError = "+ JSON.stringify(closeOnError, null, 4),timeStampErroresCommons);            
    }
    return $.ajax({
        type: 'POST',
        url: urlServicio,
        data: JSON.stringify(parmsIn),
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        crossDomain: true,
        success: function(result,status,xhr){
            timeStampErroresCommons = Commons.getStampId();      
            registraHistorial("doJsonPost ha respondido result= " + JSON.stringify(result, null, 4)+" \n",timeStampErroresCommons);                            
        },
        error: function (jqXHR, exception) {
            var msg = '';
            timeStampErroresCommons = Commons.getStampId();      
            registraHistorial("Ha ocurrido un error en doJsonPost jqXHR= " + JSON.stringify(jqXHR, null, 4)+" \n exception= " + JSON.stringify(exception, null, 4),timeStampErroresCommons);
                
            if (jqXHR.status === 0) {
                msg = 'No hay conexión o el servicio no se encuentra disponible.\n Verifique la red.';
            }
            else if (exception === 'timeout') {
                msg = 'La conexión a tardado demasiado en responder.';
            } else {
                msg = 'Error no identificado: \n' + jqXHR.responseText;
            }
            if (closeOnError)
            {
                finalizarConError("Ha ocurrido un problema y se cerrará la ventana, en caso de que el problema persista contacte a soporte: </br>[Código de seguimiento:"+timeStampErroresCommons+"]");
            }
            else
            {
                avisaError("Ha ocurrido un problema con el servicio, en caso de que el problema persista contacte a soporte: </br>[Código de seguimiento:"+timeStampErroresCommons+"]");
            }
        },
    })
}


function doHistorialPost(urlServicio, parmsIn, closeOnError) {
    timeStampErroresCommons = Commons.getStampId();      
    let parmsEntrada = JSON.stringify(parmsIn, null, 4)               
    var stringControlador = parmsEntrada.match(/"([^"]*(?=A{3}).*?)"/);
    if(!(stringControlador === "" || stringControlador === null ||stringControlador ===undefined))
    {
        $.each(stringControlador, function( index, value ) {
            parmsEntrada = parmsEntrada.replace(value, value.substring(0, 30)+ '..."')
        });
    }
    var entrada = {
      Mensaje:parmsEntrada  
    } 
    return $.ajax({
        type: 'POST',
        url: urlServicio,
        data: JSON.stringify(entrada),
        contentType: "application/json",
        dataType: "json",
        crossDomain: true,
        error: function (jqXHR, exception) {
            var msg = '';
            timeStampErroresCommons = Commons.getStampId();      
            if (jqXHR.status === 0) {
                msg = 'No hay conexión o el servicio no se encuentra disponible.\n Verifique la red.';
            }
            else if (exception === 'timeout') {
                msg = 'La conexión a tardado demasiado en responder.';
            } else {
                msg = 'Error no identificado: \n' + jqXHR.responseText;
            }
            alert(msg);
        },
    })
}


function doUrlPost(urlServicio, closeOnError) {
    substring = "RegistraHistorial";    
    if(urlServicio.indexOf(substring) === -1){
        timeStampErroresCommons = Commons.getStampId();      
        registraHistorial("Se ha realizado un doUrlPost urlServicio= " + JSON.stringify(urlServicio, null, 4) + "\n closeOnError = "+ JSON.stringify(closeOnError, null, 4),timeStampErroresCommons);            
    }
    return $.ajax({
        type: 'POST',
        url: urlServicio,
        //contentType: "application/json",
        //dataType: "json",
        crossDomain: true,
        success: function(result,status,xhr){
            timeStampErroresCommons = Commons.getStampId();      
            registraHistorial("doUrlPost ha respondido result= " + JSON.stringify(result, null, 4)+" \n xhr= " + JSON.stringify(xhr, null, 4),timeStampErroresCommons);                
        },
        error: function (jqXHR, exception) {            
            timeStampErroresCommons = Commons.getStampId();      
            registraHistorial("Ha ocurrido un error en doUrlPost jqXHR= " + JSON.stringify(jqXHR, null, 4)+" \n exception= " + JSON.stringify(exception, null, 4),timeStampErroresCommons);    
            var msg = '';
            if (jqXHR.status === 0) {
                msg = 'No hay conexión o el servicio no se encuentra disponible.\n Verifique la red.';
            }
            else if (exception === 'timeout') {
                msg = 'La conexión a tardado demasiado en responder.';
            } else {
                msg = 'Error no identificado: \n' + jqXHR.responseText;
            }            
            if (closeOnError)
            {
                finalizarConError("Ha ocurrido un problema y se cerrará la ventana, en caso de que el problema persista contacte a soporte: </br>[Código de seguimiento:"+timeStampErroresCommons+"]");
            }
            else
            {
                avisaError("Ha ocurrido un problema con el servicio, en caso de que el problema persista contacte a soporte: </br>[Código de seguimiento:"+timeStampErroresCommons+"]");
            }
        },
    })
}


function cerrarModal() {
    try
    {
        let el = document.getElementById('botonCerrar');
        if(el === undefined ||el === ""  || el === null )
            return;
        let etype = 'click';

        if (el.fireEvent) {
            el.fireEvent('on' + etype);
        } else {
            let evObj = document.createEvent('Events');
            evObj.initEvent(etype, true, false);
            el.dispatchEvent(evObj);
        }
    }
    catch (oError) {
        timeStampErroresCommons = Commons.getStampId(datosOperacion.wS);      
        registraHistorial("Ocurrió un error no controlado en cerrarModal oError = "+JSON.stringify(oError, null, 4),timeStampErroresCommons);                                                
        finalizarConError("Algo salio mal cerrando un mensaje modal, si el problema persiste favor de comunicarse a soporte." + " </br>[Código de seguimiento:"+timeStampErroresCommons+"]");
        return;
    }
}

function finalizarConError(msg) {
    FuncionesCommons.mostrarModal('errorFin');
    let e = document.getElementById("modal00").querySelector("#lblError");
    e.innerHTML = msg;
    $.LoadingOverlay("hide");
}

function avisaError(msg) {
    FuncionesCommons.mostrarModal('error');
    let e = document.getElementById("modal00").querySelector("#lblError");
    e.innerHTML = msg;
    $.LoadingOverlay("hide");
}

var Commons = {
    getStampId:function getStampId(sesion){
        if(!isDefined(sesion))
        {
            if(sesionRandomId === "")
                 sesionRandomId = (Math.floor(10000 + Math.random() * 90000)).toString()
            sesion = sesionRandomId;
        }
    let timeStamp = Date.now();
    let stamp = "";
    stamp = sesion + "#" + timeStamp;        
    return stamp;
    }
}

/**////////////////////////////////////////////////////////////////////////////////////////////////////////////**/   
/**///Esta funcionalidad es para que los excepciones puedan ser convertidas a string mediante JSON.stringify  /**/
/**/if (!('toJSON' in Error.prototype))                                                                       /**/
/**/Object.defineProperty(Error.prototype, 'toJSON', {                                                        /**/
/**/    value: function () {                                                                                  /**/
/**/        var alt = {};                                                                                     /**/
/**/        Object.getOwnPropertyNames(this).forEach(function (key) {                                         /**/
/**/            alt[key] = this[key];                                                                         /**/
/**/        }, this);                                                                                         /**/
/**/        return alt;                                                                                       /**/
/**/    },                                                                                                    /**/
/**/    configurable: true,                                                                                   /**/
/**/    writable: true                                                                                        /**/
/**/});                                                                                                       /**/
/**////////////////////////////////////////////////////////////////////////////////////////////////////////////**/