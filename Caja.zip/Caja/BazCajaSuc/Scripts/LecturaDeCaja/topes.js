﻿var pantallaCargada = false;
var origen;
var urlTopes = "LecturaCaja/LecturaDeCaja.svc/wsLecturaTopesPuestos";
var urlCajas = "LecturaCaja/LecturaDeCaja.svc/wsLecturaTopesCajas";
var urlPerfileTopes = "LecturaCaja/lecturaDeCaja.svc/wsLecturaPerfiles";
var perfTopes;


function cambios() {
    //radio
    var divisa;
    var seleccionDivisa2 = $('#selector1 option:selected').text();
    seleccionDivisaMC = seleccionDivisa2;
    if (seleccionDivisaMC == "Moneda Nacional") {
        divisa = 1;
    } else if (seleccionDivisaMC == "Dolar Americano") {
        divisa = 2;
    } else if (seleccionDivisaMC == "Onza Libertad de Plata") {
        divisa = 3;
    } else if (seleccionDivisaMC == "Dolar Canadiense") {
        divisa = 5;
    } else if (seleccionDivisaMC == "Euros") {
        divisa = 7;
    }
    perfilTopes();

    var usuario = getUrlVars()["usuario"];
    $('input[type=radio][name=radio]').on('change', function () {
        switch ($(this).val()) {
            case 'radio1':
                origen = 1;

                $("#ventanaNueva").load(getUrlsTopes(topes));
                //limpiarContenedor();
                topesDentro(usuario, perfil, divisa, origen);
                topesCajas(usuario, perfil, divisa, origen);

                break;
            case 'radio2':
                origen = 2;

                $("#ventanaNueva").load(getUrlsTopes(topes));
                //limpiarContenedor();
                topesDentro(usuario, perfil, divisa, origen);
                topesCajas(usuario, perfil, divisa, origen);
                document.getElementById("radio2").checked = true;
                break;
        }
    });
}
function getUrlsTopes(serv) {
    var url = "";
    if (window.location.hostname == "localhost") {
        url = "http://10.54.28.226:9014/Caja/Servicios/" + serv;
    } else {
        url = "http://" + window.location.hostname + ":9014/Caja/Servicios/" + serv;
    }
    return url;
}
    
function perfilTopes() {
    mostrarLoading(true);
    var host1 = getUrlBase();
    $.ajax({
        url: getUrlsTopes(urlPerfileTopes),

        contentType: "application/json; charset=UTF-8",
        type: "POST",
        data: JSON.stringify({
            "NoEmpleado": "" + getUrlVars()["usuario"],
        }),
        dataType: 'json',
        crossDomain: true,
        success: function (data) {
            perfTopes = data.Respuesta;

            return data.Respuesta;
        },
        error: function () {
            $("#bMensaje").text("Ocurrió un error en el consumo del servicio.");
        }
    });
    mostrarLoading(false);
}
function topesDentro(usuario,perfil,divisa, origen  ) {

    var fechaActual = fechaI();
    
    mostrarLoading(true);
   
    $.ajax({
        url: getUrls(urlTopes),
        contentType: "application/json; charset=UTF-8",
        type: "POST",
        data: JSON.stringify(
            {
                "Operacion": 2,
                "Opcion": 1,
                "Perfil": ""+perfil,
                "IdTipoDivisa": divisa,
                "Inicio": ""+fechaActual,
                "Empleado": "" + usuario,
                "Origen": ""+origen
            }),
        dataType: 'json',
        crossDomain: true,
        success: function (data) {
            if (data.Respuesta != undefined && data.Respuesta.length != 0) {

                if (origen == 1) {
                    document.getElementById("radio1").checked = true;
                    document.getElementById("radio2").checked = false;

                } else if (origen == 2) {
                    document.getElementById("radio1").checked = false;
                    document.getElementById("radio2").checked = true;

                }
                Serviciotopes(data);
            }
            else {                
                $('#topesBunker').html("Topes no definidos"); 
                $('#topesBunkerComercio').html("");
                $('#topesBunkerOtros').html("");
            }
            mostrarLoading(false);
        },
        error: function () {           
            $("#topesBunker").text("Error en el consumo del servicio ");
            mostrarLoading(false);
        }
    });

} 

function Serviciotopes(jsonResptopes) {
    var suma = 0;
    if (jsonResptopes.NoError == 0) {
        repActualTopes(jsonResptopes.Respuesta);
     
    }
    else if (jsonResptopes.NoError == 1) {
        document.getElementById("rev").html( jsonResptopes.Descripcion);
    } else if (jsonResptopes.Respuesta == 3) {
        document.getElementById("rev").html(jsonResptopes.Descripcion);
    } else {
        document.getElementById("rev").html("Intente mas tarde.");
    }
}
function limpiarContenedor() {
    $('#topesBunker').html("");
    $('#topesBunkerComercio').html("");
    $('#segundaParte').html("");
}

function repActualTopes(jsonresptotal) {
    mostrarLoading(true);
    var tabla = '';
    var suma = 0.00;
    //CREAR UN OBJETO PARA ENVIARLO A UN WEBSERVICE PARA PROCESARLO E IMPRIMIRLO EN PDF

    var queryResult = Enumerable.From(jsonresptotal).Where("$.TipoPuesto == 1")
    .Select(function (x) {
        return {
            'A': x['FiPuestoId'] + " - " + x['DescPuestoBase'],
            'B': x['DescribeFuncion'],
            'C': x['FiTipoPago'] + " - " + x['FcTpagDesc'],
            'D': x['FnImporteTope']
        };
    })
    .ToArray();
    var formatResult = Enumerable.From(queryResult)
       .Let(grouper('A', function (g1) {
           return g1.Let(grouper('B', function (g2) {
               return g2.Let(grouper('C', function (g3) {
                   return g3.Select("$.D").ToArray();
               }));
           }));
       }))
    .ToArray();
    //Puestos (1 = Banco; 2 = Comercio)
    var queryPuestos = Enumerable.From(jsonresptotal)
        .GroupBy(function (x) { return x.TipoPuesto })
        .Select(function (x) {
            return x.Max(function (z) { return z.TipoPuesto });
        })
    .ToArray();
    /**************************************************************************
         *** Seccion Puestos Banco
         **************************************************************************/
    //Banco
    var queryPuestosBanco = Enumerable.From(jsonresptotal)
        .Where("$.TipoPuesto == 1")
        .Select(function (x) {
            return {
                'A': x['FiPuestoId'] + " - " + x['DescPuestoBase'],
                'B': x['DescribeFuncion'],
                'C': x['FiTipoPago'] + " - " + x['FcTpagDesc'],
                'D': x['FnImporteTope']
            };
        })
        .ToArray();
    var formatResultPuestosBanco = Enumerable.From(queryPuestosBanco)
        .Let(grouper('A', function (g1) {
            return g1.Let(grouper('B', function (g2) {
                return g2.Let(grouper('C', function (g3) {
                    return g3.Select("$.D").ToArray();
                }));
            }));
        }))
        .ToArray();
    //sumas de saldos para el nivel 1
    var subQueryN1Banco = Enumerable.From(jsonresptotal).Where("$.TipoPuesto == 1")
    .Select(function (x) {
        return {
            'A': x['FiPuestoId'] + " - " + x['DescPuestoBase'],
            'E': x['FnImporteTope']
        };
    })
    .ToArray();
    var sumN1 = Enumerable.From(subQueryN1Banco).GroupBy("$.A", null,
    function (key, g) {
        var result = {
            currency: key,
            total: g.Sum("$.E")
        }
        return result;
    }).ToArray();

    /**************************************************************************
         *** Cierra Seccion Puestos Banco
         **************************************************************************/
    /**************************************************************************
        *** Seccion Puestos Comercio
        **************************************************************************/
    //Banco
    var queryPuestosComercio = Enumerable.From(jsonresptotal)
        .Where("$.TipoPuesto == 2")
        .Select(function (x) {
            return {
                'A': x['FiPuestoId'] + " - " + x['DescPuestoBase'],
                'B': x['DescribeFuncion'],
                'C': x['FiTipoPago'] + " - " + x['FcTpagDesc'],
                'D': x['FnImporteTope']
            };
        })
        .ToArray();
    var formatResultPuestosComercio = Enumerable.From(queryPuestosComercio)
        .Let(grouper('A', function (g1) {
            return g1.Let(grouper('B', function (g2) {
                return g2.Let(grouper('C', function (g3) {
                    return g3.Select("$.D").ToArray();
                }));
            }));
        }))
        .ToArray();
    //sumas de saldos para el nivel 1
    var subQueryN1Comercio = Enumerable.From(jsonresptotal).Where("$.TipoPuesto == 2")
    .Select(function (x) {
        return {
            'A': x['FiPuestoId'] + " - " + x['DescPuestoBase'],
            'E': x['FnImporteTope']
        };
    })
    .ToArray();
    var sumN1 = Enumerable.From(subQueryN1Comercio).GroupBy("$.A", null,
    function (key, g) {
        var result = {
            currency: key,
            total: g.Sum("$.E")
        }
        return result;
    }).ToArray();

    /**************************************************************************
         *** Cierra Seccion Puestos comercio
         **************************************************************************/

    /**************************************************************************
        *** Seccion Puestos Otros
        **************************************************************************/
    //Banco
    var queryPuestosOtros = Enumerable.From(jsonresptotal)
        .Where("$.TipoPuesto == 3")
        .Select(function (x) {
            return {
                'A': x['FiPuestoId'] + " - " + x['DescPuestoBase'],
                'B': x['DescribeFuncion'],
                'C': x['FiTipoPago'] + " - " + x['FcTpagDesc'],
                'D': x['FnImporteTope']
            };
        })
        .ToArray();
    var formatResultPuestosOtros = Enumerable.From(queryPuestosOtros)
        .Let(grouper('A', function (g1) {
            return g1.Let(grouper('B', function (g2) {
                return g2.Let(grouper('C', function (g3) {
                    return g3.Select("$.D").ToArray();
                }));
            }));
        }))
        .ToArray();
    //sumas de saldos para el nivel 1
    var subQueryN1Comercio = Enumerable.From(jsonresptotal).Where("$.TipoPuesto == 3")
    .Select(function (x) {
        return {
            'A': x['FiPuestoId'] + " - " + x['DescPuestoBase'],
            'E': x['FnImporteTope']
        };
    })
    .ToArray();
    var sumN1 = Enumerable.From(subQueryN1Comercio).GroupBy("$.A", null,
    function (key, g) {
        var result = {
            currency: key,
            total: g.Sum("$.E")
        }
        return result;
    }).ToArray();

    /**************************************************************************
         *** Cierra Seccion Puestos Otros
         **************************************************************************/
    //Banco


    //sumas de saldos para el nivel 1
    
    var sumTotal = Enumerable.From(queryResult).Sum("$.D");
    var contN1 = 0, contN2 = 0, contN3 = 0;
    if (formatResultPuestosBanco.length!=0) {
        var tabla = '<table class="tblGeneral">' +
      '<tbody>' +
         '<tr class="total gris1">' +
             '<td class="tLeft" id="rev">Puestos de Banco</td>' +
             '<td class="tRight">&nbsp;</td>' +
         '</tr>' +
               '</tbody>' +
               '</table>' +
               '<dl class="accordion">';

        $.each(formatResultPuestosBanco, function (i, p) {   //NIVEL1
            tabla += '<dt id=topeBanco' + i + ' class="AcoInpar" onclick="AcordBanco(' + i + ')">' +
                       '<table class="tblGeneral1">' +
                          '<tr>' +
                              '<td class="p0 tLeft">' + p.text + '</td>' +
                              '<td class="tRight w150">&nbsp;</td>' +
                          '</tr>' +
                        '</table>' +
                    '</dt>' +
           '<dd style="display:none;">' +
           '<div class="inner">' +
           '<div class="nivel2"><dl class="accordion">';
            contN1++;
            $.each(p.children, function (j, p) {//nivel2  
                //'<input type="checkbox" onchange="onCheckEmpleado(\''+p.NoEmpledo.toString()+'\','+i+')" id="checkEmp'+i+'" />'+
                tabla += '<dt id="topeBancoSub' + i + j + '" class="AcoInpar" onclick="AcordBancoSub(\'' + i.toString() +''+ j.toString() + '\')">' +
                                  '<table>' +
                                    '<tr>' +
                                      '<td class="p0">' + p.text + '</td>' +
                                      '<td class="tRight w150">&nbsp;</td>' +
                                    '</tr>' +
                                  '</table>' +
                                  '</dt>' +
                                  '<dd  style="display:none;">' +
                                  '<div class="inner">' +
                                  '<div class="nivel3">' +
                                  '<table class="tblNivel2 t2">';
                $.each(p.children, function (i, p) {
                    tabla += '<tbody><tr><td>' + p.text + '</td><td>' + formatMoney(p.children[0]) + '</td></tr></tbody>';
                });
                tabla += '</table></div></div></dd>';
            });
            tabla += '</dl></div></div>' +
                        '</dd>';
        });


        tabla += '</dl>' + topesAcordion();
        tabla = tabla.substring(0, tabla.length - "undefined".length);
        $('#topesBunker').html(tabla);
    }
    contN1 = 0, contN2 = 0, contN3 = 0;
    if (formatResultPuestosComercio.length != 0) {
        var tablaComercio = '<table class="tblGeneral">' +
      '<tbody>' +
         '<tr class="total gris1">' +
             '<td class="tLeft" id="rev">Puestos de Comercio</td>' +
             '<td class="tRight">&nbsp;</td>' +
         '</tr>' +
               '</tbody>' +
               '</table>' +
               '<dl class="accordion">';

        $.each(formatResultPuestosComercio, function (i, p) {   //NIVEL1
            tablaComercio += '<dt id=topeComercio' + i + ' class="AcoInpar" onclick="AcordComercio(' + i + ')">' +
                       '<table class="tblGeneral1">' +
                          '<tr>' +
                              '<td class="p0 tLeft">' + p.text + '</td>' +
                              '<td class="tRight w150">&nbsp;</td>' +
                          '</tr>' +
                        '</table>' +
                    '</dt>' +
           '<dd style="display:none;">' +
           '<div class="inner">' +
           '<div class="nivel2"><dl class="accordion">';
            contN1++;
            $.each(p.children, function (j, p) {//nivel2  
                //'<input type="checkbox" onchange="onCheckEmpleado(\''+p.NoEmpledo.toString()+'\','+i+')" id="checkEmp'+i+'" />'+
                tablaComercio += '<dt id="topeComercioSub' + i + j + '" class="AcoInpar" onclick="AcordComercioSub(\'' + i.toString() + '' + j.toString() + '\')">' +
                                  '<table>' +
                                    '<tr>' +
                                      '<td class="p0">' + p.text + '</td>' +
                                      '<td class="tRight w150">&nbsp;</td>' +
                                    '</tr>' +
                                  '</table>' +
                                  '</dt>' +
                                  '<dd  style="display:none;">' +
                                  '<div class="inner">' +
                                  '<div class="nivel3">' +
                                  '<table class="tblNivel2 t2">';
                $.each(p.children, function (i, p) {
                    tablaComercio += '<tbody><tr><td>' + p.text + '</td><td>' + formatMoney(p.children[0]) + '</td></tr></tbody>';
                });
                tablaComercio += '</table></div></div></dd>';
            });
            tablaComercio += '</dl></div></div>' +
                        '</dd>';
        });


        tablaComercio += '</dl>' ;
        //tablaComercio = tablaComercio.substring(0, tablaComercio.length - "undefined".length);
        $('#topesBunkerComercio').html(tablaComercio);
    }
    contN1 = 0, contN2 = 0, contN3 = 0;
    if (formatResultPuestosOtros.length != 0) {
        var tablaOtros = '<table class="tblGeneral">' +
      '<tbody>' +
         '<tr class="total gris1">' +
             '<td class="tLeft" id="rev">Otros</td>' +
             '<td class="tRight">&nbsp;</td>' +
         '</tr>' +
               '</tbody>' +
               '</table>' +
               '<dl class="accordion">';

        $.each(formatResultPuestosComercio, function (i, p) {   //NIVEL1
            tablaOtros += '<dt id=topeOtros' + i + ' class="AcoInpar" onclick="AcordOtros(' + i + ')">' +
                       '<table class="tblGeneral1">' +
                          '<tr>' +
                              '<td class="p0 tLeft">' + p.text + '</td>' +
                              '<td class="tRight w150">&nbsp;</td>' +
                          '</tr>' +
                        '</table>' +
                    '</dt>' +
           '<dd style="display:none;">' +
           '<div class="inner">' +
           '<div class="nivel2"><dl class="accordion">';
            contN1++;
            $.each(p.children, function (j, p) {//nivel2  
                //'<input type="checkbox" onchange="onCheckEmpleado(\''+p.NoEmpledo.toString()+'\','+i+')" id="checkEmp'+i+'" />'+
                tablaOtros += '<dt id="topetrosSub' + i + j + '" class="AcoInpar" onclick="AcordOtrosSub(\'' + i.toString() + '' + j.toString() + '\')">' +
                                  '<table>' +
                                    '<tr>' +
                                      '<td class="p0">' + p.text + '</td>' +
                                      '<td class="tRight w150">&nbsp;</td>' +
                                    '</tr>' +
                                  '</table>' +
                                  '</dt>' +
                                  '<dd  style="display:none;">' +
                                  '<div class="inner">' +
                                  '<div class="nivel3">' +
                                  '<table class="tblNivel2 t2">';
                $.each(p.children, function (i, p) {
                    tablaOtros += '<tbody><tr><td>' + p.text + '</td><td>' + formatMoney(p.children[0]) + '</td></tr></tbody>';
                });
                tablaOtros += '</table></div></div></dd>';
            });
            tablaOtros += '</dl></div></div>' +
                        '</dd>';
        });


        tablaOtros += '</dl>';
        //tablaComercio = tablaComercio.substring(0, tablaComercio.length - "undefined".length);
        $('#topesBunkerComercio').html(tablaOtros);
    }   
    mostrarLoading(false);
}
function grouper(propertyName, selector) {
    return function (e) {
        return e.GroupBy("$." + propertyName, null, function (k, g) {
            return {
                text: k,
                children: g.Let(selector).ToArray()
            };
        });
    };
}
function groupBy(array, f) {
    var groups = {};
    array.forEach(function (o) {
        var group = JSON.stringify(f(o));
        groups[group] = groups[group] || [];
        groups[group].push(o);
    });
    return Object.keys(groups).map(function (group) {
        return groups[group];
    })
}
function topesCajas(usuario,perfTopes,divisass, origen) {
    mostrarLoading(true);
    var fechaActual = fechaI();
    $.ajax({
        url: getUrls(urlCajas),
        contentType: "application/json; charset=UTF-8",
        type: "POST",
        data: JSON.stringify(
            {
                "Operacion": 2,
                "Opcion": 2,
                "Perfil": ""+perfTopes,
                "IdTipoDivisa": divisass,
                "Inicio": ""+fechaActual,
                "Empleado": "" + usuario,
                "Origen": ""+origen
            }),
        dataType: 'json',
        crossDomain: true,
        success: function (data) {
            if (data.Respuesta != undefined && data.Respuesta.length != 0) {
                ServicioTopesCajas(data);
            }
            else {
                
                $('#segundaParte').html("Topes no definidos");
                
            }
            mostrarLoading(false);
        },
        error: function () {            
            $("#rev").text("Error en el consumo del servicio ");
            mostrarLoading(false);
        }
    });

}
function ServicioTopesCajas(jsonResptopesCajas) {
    var suma = 0;
    if (jsonResptopesCajas.NoError == 0) {
        respTopesmcajas(jsonResptopesCajas.Respuesta);
    }
    else if (jsonResptopesCajas.NoError == 1) {
        document.getElementById("rev").innerHTML = jsonResptopesCajas.Descripcion;
    } else if (jsonResptopesCajas.Respuesta == 3) {
        document.getElementById("rev").innerHTML = jsonResptopesCajas.Descripcion;
    } else {
        document.getElementById("rev").innerHTML = "Intente mas tarde.";
    }
}
function respTopesmcajas(respuestaTopesCajas) {
    mostrarLoading(true);
    if (respuestaTopesCajas.length === 0) {
        alert("NO HAY INFORMACION");
    }
    else {
        var tabla2 = '';
        var queryResultC = Enumerable.From(respuestaTopesCajas)
        .Select(function (x) {
            return {
                'A': x['FiCjId'] + " - " + x['FcCjDesc'],
                'B': x['FiTipoPago'] + " - " + x['FcTpagDesc'],
                'C': x['FnImporteTope']

            };
        })
        .ToArray();
        //Puestos (1 = Banco; 2 = Comercio)
        var queryPuestos = Enumerable.From(respuestaTopesCajas)
            .GroupBy(function (x) { return x.TipoPuesto })
            .Select(function (x) {
                return x.Max(function (z) { return z.TipoPuesto });
            })
        .ToArray();

        var formatResult = Enumerable.From(queryResultC)
           .Let(grouper('A', function (g1) {
               return g1.Let(grouper('B', function (g2) {
                   return g2.Select("$.C").ToArray();
               }));
           }))
        .ToArray();


        //sumas de saldos para el nivel 
        var subQueryN3 = Enumerable.From(respuestaTopesCajas)
        .Select(function (x) {
            return {
                'A': x['FiTipoPago'] + " - " + ['FcTpagDesc'],
                'D': x['FnImporteTope']
            };
        })
        .ToArray();
        var sumN1 = Enumerable.From(subQueryN3).GroupBy("$.A", null,
        function (key, g) {
            var result = {
                currency: key,
                total: g.Sum("$.D")
            }
            return result;
        }).ToArray();
        var sumTotal = Enumerable.From(queryResultC).Sum("$.D");
        var contN1 = 0;
        tabla2 ='<dl class="accordion">';
        $.each(formatResult, function (i, p) {   //NIVEL1
            tabla2 += '<dt id="topeCaja' + i + '" class="AcoInpar" onclick="AcordCaja(' + i + ')"> ' +
                       '<table class="tblGeneral1">' +
                          '<tr>' +
                              '<td class="p0 tLeft">' + p.text + '</td>' +
                              '<td class="tRight w150"></td>' +
                          '</tr>' +
                        '</table>' +
                    '</dt>' +
           '<dd style="display:none;">' +
           '<div class="nivel1"><table class="tblNivel1"><tbody>';
            contN1++;
            $.each(p.children, function (i, p) {//nivel2
                tabla2 += '<tr>' +
                          '<td>' + p.text + '</td>' +
                          '<td class="w150">' + formatMoney(p.children) + '</td>' +
                         '</tr>';


            });
            tabla2 += '</tbody></table></div></dd>';
        });

        tabla2 += '</dl>' + cajasAcordion();
        tabla2 = tabla2.substring(0, tabla2.length - "undefined".length);
        $('#segundaParte').html(tabla2);
    }
    mostrarLoading(false);
}
function AcordCaja(id) {
    
    $this = $("#topeCaja" + id);
            //the target panel content
            $target = $this.next();

            jQuery(document.getElementById("topeCaja"+id)).removeClass('accordion-active');
            if ($target.hasClass("in")) {
                $this.removeClass('accordion-active');
                $target.slideUp();
                $target.removeClass("in");

            } else {
                $this.addClass('accordion-active');
                jQuery('.accordion > dd').removeClass("in");
                $target.addClass("in");
                $(".subSeccion").show();

                //jQuery('.accordion1Caja > dd').slideUp();
                $target.slideDown();
            }
}
function AcordBanco(id) {

    $this = $("#topeBanco" + id);
    //the target panel content
    $target = $this.next();

    jQuery(document.getElementById("topeBanco" + id)).removeClass('accordion-active');
    if ($target.hasClass("in")) {
        $this.removeClass('accordion-active');
        $target.slideUp();
        $target.removeClass("in");

    } else {
        $this.addClass('accordion-active');
        jQuery('.accordion > dd').removeClass("in");
        $target.addClass("in");
        $(".subSeccion").show();

        //jQuery('.accordion1Caja > dd').slideUp();
        $target.slideDown();
    }
}
function AcordBancoSub(id) {

    $this = $("#topeBancoSub" + id);
    //the target panel content
    $target = $this.next();

    jQuery(document.getElementById("topeBancoSub" + id)).removeClass('accordion-active');
    if ($target.hasClass("in")) {
        $this.removeClass('accordion-active');
        $target.slideUp();
        $target.removeClass("in");

    } else {
        $this.addClass('accordion-active');
        jQuery('.accordion > dd').removeClass("in");
        $target.addClass("in");
        $(".subSeccion").show();

        //jQuery('.accordion1Caja > dd').slideUp();
        $target.slideDown();
    }
} 
function AcordComercio(id) {

    $this = $("#topeComercio" + id);
    //the target panel content
    $target = $this.next();

    jQuery(document.getElementById("topeComercio" + id)).removeClass('accordion-active');
    if ($target.hasClass("in")) {
        $this.removeClass('accordion-active');
        $target.slideUp();
        $target.removeClass("in");

    } else {
        $this.addClass('accordion-active');
        jQuery('.accordion > dd').removeClass("in");
        $target.addClass("in");
        $(".subSeccion").show();

        //jQuery('.accordion1Caja > dd').slideUp();
        $target.slideDown();
    }
} 
function AcordComercioSub(id) {

    $this = $("#topeComercioSub" + id);
    //the target panel content
    $target = $this.next();

    jQuery(document.getElementById("topeComercioSub" + id)).removeClass('accordion-active');
    if ($target.hasClass("in")) {
        $this.removeClass('accordion-active');
        $target.slideUp();
        $target.removeClass("in");

    } else {
        $this.addClass('accordion-active');
        jQuery('.accordion > dd').removeClass("in");
        $target.addClass("in");
        $(".subSeccion").show();

        //jQuery('.accordion1Caja > dd').slideUp();
        $target.slideDown();
    }
}
function AcordOtros(id) {

    $this = $("#topeOtros" + id);
    //the target panel content
    $target = $this.next();

    jQuery(document.getElementById("topeOtros" + id)).removeClass('accordion-active');
    if ($target.hasClass("in")) {
        $this.removeClass('accordion-active');
        $target.slideUp();
        $target.removeClass("in");

    } else {
        $this.addClass('accordion-active');
        jQuery('.accordion > dd').removeClass("in");
        $target.addClass("in");
        $(".subSeccion").show();

        //jQuery('.accordion1Caja > dd').slideUp();
        $target.slideDown();
    }
}
function AcordOtrosSub(id) {

    $this = $("#topetrosSub" + id);
    //the target panel content
    $target = $this.next();

    jQuery(document.getElementById("topetrosSub" + id)).removeClass('accordion-active');
    if ($target.hasClass("in")) {
        $this.removeClass('accordion-active');
        $target.slideUp();
        $target.removeClass("in");

    } else {
        $this.addClass('accordion-active');
        jQuery('.accordion > dd').removeClass("in");
        $target.addClass("in");
        $(".subSeccion").show();

        //jQuery('.accordion1Caja > dd').slideUp();
        $target.slideDown();
    }
}

function topesAcordion() {

    jQuery(function () {

        var allPanels = $('.accordionTope > dd').hide();

        jQuery('.accordionTope > dt').on('click', function () {
            $this = $(this);
            //the target panel content
            $target = $this.next();

            jQuery('.accordionTope > dt').removeClass('accordionTope-active');
            if ($target.hasClass("in")) {
                $this.removeClass('accordionTope-active');
                $target.slideUp();
                $target.removeClass("in");

            } else {
                $this.addClass('accordionTope-active');
                jQuery('.accordionTope > dd').removeClass("in");
                $target.addClass("in");
                $(".subSeccion").show();

               // jQuery('.accordion > dd').slideUp();
                $target.slideDown();
            }
        });

        var allPanels = $('.accordion1Tope > dd').hide();

        jQuery('.accordion1Tope > dt').on('click', function () {
            $this = $(this);
            //the target panel content
            $target = $this.next();

            jQuery('.accordion1Tope > dt').removeClass('accordionTope-active');
            if ($target.hasClass("in")) {
                $this.removeClass('accordionTope-active');
                $target.slideUp();
                $target.removeClass("in");

            } else {
                $this.addClass('accordionTope-active');
                jQuery('.accordion1Tope > dd').removeClass("in");
                $target.addClass("in");
                $(".subSeccion").show();

                //jQuery('.accordion1Tope > dd').slideUp();
                $target.slideDown();
            }
        });

        var allPanels = $('.accordion2 > dd').hide();

        jQuery('.accordion2 > dt').on('click', function () {
            $this = $(this);
            //the target panel content
            $target = $this.next();

            jQuery('.accordion2 > dt').removeClass('accordion-active');
            if ($target.hasClass("in")) {
                $this.removeClass('accordion-active');
                $target.slideUp();
                $target.removeClass("in");

            } else {
                $this.addClass('accordion-active');
                jQuery('.accordion2 > dd').removeClass("in");
                $target.addClass("in");
                $(".subSeccion").show();

                //jQuery('.accordion2 > dd').slideUp();
                $target.slideDown();
            }
        });
    });
}