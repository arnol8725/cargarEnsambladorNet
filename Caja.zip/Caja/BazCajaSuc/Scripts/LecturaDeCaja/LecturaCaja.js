﻿if ($j === undefined) { var $j = jQuery.noConflict(true); console.log($().jquery); console.log($j().jquery); }
var iniciales = "Fronts/LecturaDeCaja/saldos-iniciales.html";
var actuales = "Fronts/LecturaDeCaja/saldos-actuales.html";
var topes = "Fronts/LecturaDeCaja/topes.html";
var movimientos = "Fronts/LecturaDeCaja/MovimientosCaja.html";
var consMovtosSinFlujo = "Fronts/LecturaDeCaja/consMovtosSinFlujo.html";
var entradasSalidas = "Fronts/LecturaDeCaja/EntradasSalidas.html";
var consultaOperaciones = "Fronts/LecturaDeCaja/consultaOperaciones.html";
var consultaOperacionesDia = "Fronts/LecturaDeCaja/ConsOperaDia.html";
var movtosCentrocanje = "Fronts/LecturaDeCaja/movtosCentrocanje.html";
const AUrlDivisas = "Comun/WsCajaComun.svc/wsconsultaDivisa";
const UrlInfo = "Comun/WsCajaComun.svc/wsConsultaInformacionInicial";
const urlPerfiles = "LecturaCaja/lecturaDeCaja.svc/wsLecturaPerfiles";
var desc_divisa = "";
var idComponente_divisa = "";
var divisa_symbol = "";
var perfil;
var divisass=1;

var urlGeneraPdf = "WSDesTecAppsLocal/ImprimirDocumentoPDFCarta";
const HostImpresiones="http://localhost:9001/";
var pantallaCargada = false;
var nombre;
var usuario;
var opcion

var host = getUrlBase();
$(document).ready(function () {

    usuario = getUrlVars()["usuario"];
    opcion = getUrlVars()["opc"];
    if (opcion==undefined) {
        opcion = 0;
    } else {
        if (opcion.indexOf('?') !== -1) {
            opcion = opcion.split('?')[0];
        }
        
    }
	 if (usuario.indexOf('%') !== -1) {
        usuario = usuario.split('%')[0];
    }

    
    if (usuario.indexOf('?') !== -1) {
        usuario = usuario.split('?')[0];
    }

    if (usuario === undefined) {
        Mensaje("Debe ingresar la url completa con usuario ejemplo:\nhttp://Servidor:9014/Fronts/LecturaDeCaja/index.html?usuario=222222");
        window.close();
    } else {

        ServicePerfiles();

        serviceConsultaDivisa();
        
        serviceLecturacaja(usuario);
        $("#sIniciales").click(function () {
            ServicePerfiles();
            CambiarTitulo(1)
            document.title = "Saldo Inicial";
            $("#ventanaNueva").load(host + iniciales);
            serviceLecturaInicial(usuario,perfil,divisass);
            sActCaja(usuario, perfil, divisass);
        });
        $("#sActuales").click(function () {
            document.title="Saldo Actual";
            ServicePerfiles();
            CambiarTitulo(2)
            $("#ventanaNueva").load(host + actuales);
            serviceLecturaActual(usuario,perfil,divisass);
            sActCajaActuales(usuario,perfil,divisass);
        });
        $("#ventanaTopes").click(function () {
            document.title = "Topes";
            ServicePerfiles();
            CambiarTitulo(3)
            $("#ventanaNueva").load(host + topes);
            cambios(usuario, perfil, divisass);

        });
        $("#movimientos").click(function () {
            document.title = "Movimientos de Caja ";
            ServicePerfiles();
            CambiarTitulo(4)
            $("#ventanaNueva").load(host + movimientos);
            movimientoCaja(usuario, perfil, divisass);
        });
        $("#consMovtosSinFlujo").click(function () {
            document.title = "Cons. Mov sin Flujo";
            ServicePerfiles();
            CambiarTitulo(6)
            $("#ventanaNueva").load(host + consMovtosSinFlujo);
            serviceConsMovtosSinFlujo(usuario, perfil, divisass);
        });
        $("#EntSal").click(function () {
            document.title = "Entradas y Salidas";
            ServicePerfiles();
            CambiarTitulo(7)
            $("#ventanaNueva").load(host + entradasSalidas);
            servEntradaSalida(usuario, perfil, divisass);
            servEmpleados(usuario, perfil, divisass);
        });
        $("#consultaOperaciones").click(function () {
            document.title = "Consulta Operaciones ";
            ServicePerfiles();
            CambiarTitulo(5)
            $("#ventanaNueva").load(host + consultaOperaciones);
            consOpera(usuario, nombre, perfil, divisass);
        });
        $("#mvtosCentroCanje").click(function () {
            document.title = "Movimientos Centro de Canje";
            ServicePerfiles();
            CambiarTitulo(8)
            $("#ventanaNueva").load(host + movtosCentrocanje);
            servMovtosCentroCanje(usuario, perfil, divisass);
        });
        if (opcion == "27") {
            document.title = "Consulta Operaciones";
            ServicePerfiles();
            CambiarTitulo(27);
            
            $("#ventanaNueva").load(host + consultaOperacionesDia);
            consOpera(usuario, nombre, "D", divisass);
            initOp();
            $("#sIniciales").hide(); 
            $("#sActuales").hide();
            $("#ventanaTopes").hide();
            $("#movimientos").hide();
            $("#consMovtosSinFlujo").hide();
            $("#consultaOperaciones").hide();
            $("#mvtosCentroCanje").hide();
            $("#EntSal").hide();
            
        }
    }
   
    $j('#datepicker').change(function () {
        // actualiza();         
        
        if (document.getElementById('ventanaNuevaIniciales')) {
            recarga(getUrlVars()["usuario"], perfil, divisass); 
        }
        else if (document.getElementById('ventanaNuevaActuales')) {
            recargaActuales(getUrlVars()["usuario"], perfil, divisass); 
        }
        else if (document.getElementById('ventanaNuevaTopes')) {
            cambios(getUrlVars()["usuario"],perfil,divisass);
        }
        else if (document.getElementById('ventanaNuevaSinFlujo')) {
            serviceConsMovtosSinFlujo(usuario, perfil, divisass);
        }
        else if (document.getElementById('ventanaNuevaConsOpera')) {
            var usSelected = usuario;
            if (usSelected !== $('#bMensaje2').val()) {
                usSelected = $('#bMensaje2').val();
            }
        consOpera(usSelected, nombre, perfil, divisass);
        }
        else if (document.getElementById('NuevaCentroCanje')) {
            servMovtosCentroCanje(usuario);
        }
        else if (document.getElementById('ventanaNuevaEntSalidas')) {
            servEntradaSalida(usuario, perfil,divisass);
            servEmpleados(usuario, perfil,divisass);
        }
        else if (document.getElementById('ventanaNuevaMOvtosCaja')) {
            movimientoCaja(usuario, perfil, divisass);

        }
        else if (document.getElementById('ventanaNuevaConsOperaDia')) {            
            var usSelected = usuario;
            if (usSelected !== $('#bMensaje2').val()) {
                usSelected = $('#bMensaje2').val();
            }
            consOpera(usSelected, nombre, perfil, divisass);
        }
        
    });

    $('#selector1').change(function () {
        var seleccionDivisa2 = $('#selector1 option:selected').text();
        
        if (seleccionDivisa2 == "Moneda Nacional") {
            divisass = 1;
        } else if (seleccionDivisa2 == "Dolar Americano") {
            divisass = 2;
        } else if (seleccionDivisa2 == "Onza Libertad de Plata") {
            divisass = 3;
        } else if (seleccionDivisa2 == "Dolar Canadiense") {
            divisass = 5;
        } else if (seleccionDivisa2 == "Euros") {
            divisass = 7;
        }
        
       
        if (document.getElementById('ventanaNuevaIniciales')) {
            recarga(getUrlVars()["usuario"], perfil, divisass);
        }
        else if (document.getElementById('ventanaNuevaActuales')) {
            recargaActuales(getUrlVars()["usuario"], perfil, divisass);
        }
        else if (document.getElementById('ventanaNuevaTopes')) {
            //cambios(getUrlVars()["numempleado"], perfil, divisass);
            cambios();
        }
        else if (document.getElementById('ventanaNuevaSinFlujo')) {
            serviceConsMovtosSinFlujo(usuario,perfil,divisass);
        }
        else if (document.getElementById('ventanaNuevaConsOpera')) {
            consOpera(usuario, nombre, perfil, divisass);
        }
        else if (document.getElementById('NuevaCentroCanje')) {
            servMovtosCentroCanje(usuario, divisass);
        }
        else if (document.getElementById('ventanaNuevaEntSalidas')) {
            servEntradaSalida(usuario, perfil, divisass);
            servEmpleados(usuario, perfil, divisass);
        }
        else if (document.getElementById('ventanaNuevaMOvtosCaja')) {
            movimientoCaja(usuario, perfil, divisass);

        }
        else if (document.getElementById('ventanaNuevaConsOperaDia')) {
            consOpera(usuario, nombre, perfil, divisass);
        }

    ;})

});


function reimprime(respuesta) {
    if (respuesta == 1) {
        imprimeCaja();
    } else if (respuesta==2) {
        botonImprimir();
    } else if (respuesta == 3) {
        imprimirES();
    } else if (respuesta == 4) {
        imprimirOperaciones();
    } else if (respuesta == 33) {
        imprimirESDetalle();
    }
    else if (respuesta == 44) {
        imprimeCajaDetalle();
    } else if (respuesta == 27) {
        imprimirOperacionesTP();
    }
}
function MensajeImpresion(mensaje) {
    
    $('#mensajeTitulo').html('Mensaje del sistema:');
    $('#mensajeTexto').html(mensaje);
    $j('#modalImpresion').modal();
}
function MensajeImpresion2(mensaje) {

    $('#mensajeTitulo').html('Mensaje del sistema:');
    $('#mensajeTexto').html(mensaje);
    $j('#modalImpresion2').modal();
}
function formatMoney(num) {

    var p = Number(num).toFixed(2).split(".");
    return divisa_symbol+ " " + p[0].split("").reverse().reduce(function (acc, num, i, orig) {
        return num == " - " ? acc : num + (i && !(i % 3) ? "," : "") + acc;
    }, "") + "." + p[1];

}


function limpiar() {
    document.getElementById("datepicker").value = "";
    document.getElementById("lim").innerHTML = "";
    document.getElementById("limpCaja").innerHTML = "";
}
function fechaI() {
   
        var fecha = document.getElementById('datepicker').value;
        if (fecha === "") {
            Mensaje("SELECCIONE UNA FECHA");
            location.reload();
        }
        else {
            var fecha2 = fecha.split("/");
            if (fecha2[0] > 29 && fecha2[1] == 2) {
                Mensaje("fecha Invalida");
                location.reload();
            } else {
                if (fecha2[2].length > 4 || fecha2[1].length > 2 || fecha2[0].length > 2) {
                    $('#tablaTotalSaldIni').html("");
                    location.reload();
                    return false;
                }
            }
            if (fecha2[0].length < 2) {
                fecha2[0] = '0' + fecha2[0];
            }
            if (fecha2[1].length < 2) {
                fecha2[1] = '0' + fecha2[1];
            }
            var FechaOriginal = "";
            for (var i = fecha2.length; i > 0; i--) {
                FechaOriginal += fecha2[i - 1];

            }
            return FechaOriginal;
        }
    
}

function getUrlss(servicio) {
    var url = "";
    if (window.location.hostname == "localhost") {
        url = "http://10.54.28.226:9014/Caja/Servicios/" + servicio;
    } else {
        url = "http://" + window.location.hostname + ":9014/Caja/Servicios/" + servicio;
    }
    return url;
}
function getUrlBase() {
    arrurl = window.location.href.split("/");
    var url = "";
    for (var i = 0 ; i < (arrurl.length - 1) ; i++) {
        if (arrurl[i] == "Fronts")
            break;
        url += arrurl[i] + "/";
    }
    return url;
}
// serviceLecturacaja junto con servicelectura muestran en la parte del encabezado el usuario y su puesto
function serviceLecturacaja(usuario) {
    mostrarLoading(true);
    var host1=getUrlBase();
    $.ajax({
        url: getUrlss(UrlInfo),
        contentType: "application/json; charset=UTF-8",
        type: "POST",
        data: JSON.stringify({
            "NoEmpleado": ""+getUrlVars()["numempleado"],
        }),
        dataType: 'json',      
        crossDomain: true,
        success: function (data) {
         servicelectura(data);
         mostrarLoading(false);
        },
        error: function () {
            $("#bMensaje").text("Ocurrió un error en el consumo del servicio.");
            mostrarLoading(false);
        }
    });
}

function ServicePerfiles() {
    mostrarLoading(true);
    var host1 = getUrlss(urlPerfiles);
     var us1= getUrlVars()["numempleado"];
    //var us2=us1.trim();
    $.ajax({
        url: host1,
        contentType: "application/json; charset=UTF-8",
        type: "POST",
        data: JSON.stringify({
            
            "NoEmpleado": "" + us1,
        }),
        dataType: 'json',
        crossDomain: true,
        success: function (data) {
            //mostrarCarga(false);
            perfil = data.Respuesta;
            EsconderURLs(perfil);
            mostrarLoading(false);
           return data.Respuesta;
        },
        error: function () {
            $("#bMensaje").text("Ocurrió un error en el consumo del servicio.");
            mostrarLoading(false);
        }
    });
}


function servicelectura(jsonResp) {
    if (jsonResp.NoError == 0) {

        nombre = jsonResp.InformacionInicial.NombreEmpleado;
        noTienda = jsonResp.InformacionInicial.NoTienda;

        document.getElementById("tagNumTienda").innerHTML = jsonResp.InformacionInicial.NoTienda;
        document.getElementById("tagNombreTienda").innerHTML = jsonResp.InformacionInicial.NombreTienda;
 
        
        //document.getElementById("msjWS").innerHTML = ('ESTACIÓN: ');
        //document.getElementById("msjWSDes").innerHTML = (getUrlVars()["ws"]);

        document.getElementById("bMensaje").innerHTML = (jsonResp.InformacionInicial.NoEmpleado + ' - ');
        document.getElementById("bMensajeDes").innerHTML = (jsonResp.InformacionInicial.NombreEmpleado);

       
        document.getElementById("bMensaje1").innerHTML = (jsonResp.InformacionInicial.PuestoRol + ' - ');
        document.getElementById("bMensaje1Des").innerHTML = (jsonResp.InformacionInicial.DescripcionPRol);

    } else if (jsonResp.NoError == 1) {
        document.getElementById("bMensaje").innerHTML = jsonResp.Descripcion;

    } else if (jsonResp.Respuesta == 3) {
        document.getElementById("bMensaje").innerHTML = jsonResp.Descripcion;

    } else {
        document.getElementById("bMensaje").innerHTML = "Intente mas tarde.";
    }
}

//serviceConsultaDivisa serviceLecturaDivisa agregan en combo las etiquetas de divisas
function serviceConsultaDivisa() {
    mostrarLoading(true);
    var host = getUrlBase();
    $.ajax({
        url: getUrlss(AUrlDivisas),
        contentType: "application/json, charset=UTF-8",
        type: "POST",
        data: JSON.stringify({}),
        dataType: 'json',
        crossDomain: true,
        success: function (data) {           
            //serviceLecturaDivisa1(data);
            switch (data.NoError) {
                case 1:                   
                   
                    break;
                case 0:
                   // $('#nav').removeAttr("disabled");
                    serviceLecturaDivisa(data.Divisas, 'selector1');
                   
                    break;
            }
            mostrarLoading(false);
        },
        error: function () {
            $("#valor1").text("error en el consumo del servicio.");
            mostrarLoading(false);
        }
    });
}
function serviceLecturaDivisa1(jsonresp) {
    if (jsonresp.NoError == 0) {
        for (var i = 0; i < 4; i++) {
            document.getElementById("valor" + (i + 1)).innerHTML = jsonresp.Divisas[i].Descripcion;
        }
       
    }
    else if (jsonResp.NoError == 1) {
        document.getElementById("dMensaje").innerHTML = jsonResp.Descripcion;

    } else if (jsonResp.Respuesta == 3) {
        document.getElementById("dMensaje").innerHTML = jsonResp.Descripcion;

    } else {
        document.getElementById("dMensaje").innerHTML = "Intente mas tarde.";
    }
}
function serviceLecturaDivisa(divisas, idComponente) {
    if (divisas.length > 0) {
        divisa = divisas[0].Id;
        desc_divisa = divisas[0].Descripcion;
        divisa_symbol = divisas[0].Simbolo;
    }
    idComponente_divisa = idComponente;
    var $secondChoice = $("#" + idComponente);
    $secondChoice.empty();
    $.each(divisas, function (index, value) {
        $secondChoice.append('<option value="' + (index+1) + '">' + value.Descripcion + '</option>');
    });
    //mostrarCarga(false);   
}
function onchangeDivisas() {
    divisa = $('#' + idComponente_divisa + ' option:selected').val();
    let temp = $('#' + idComponente_divisa + ' option:selected').text().split("-");


    var seleccionDivisa2 = $('#selector1 option:selected').text();



    if (seleccionDivisa2 == "Moneda Nacional") {
        divisass = 1;
        divisa_symbol = "$";
        desc_divisa = "Moneda Nacional";
    } else if (seleccionDivisa2 == "Dolar Americano") {
        divisa_symbol = "$";
        divisass = 2;
        desc_divisa = "Dolar Americano";
    } else if (seleccionDivisa2 == "Onza Libertad de Plata") {
        divisass = 3;
        divisa_symbol = "OLP";
        desc_divisa = "Onza Libertad de Plata";
    } else if (seleccionDivisa2 == "Dolar Canadiense") {
        divisass = 5;
        divisa_symbol = "$";
        desc_divisa = "Dolar Canadiense";
    } else if (seleccionDivisa2 == "Euros") {
        divisass = 7;
        divisa_symbol = "€";
        desc_divisa = "Euros";
    }

    //divisass = idComponente_divisa;
    return divisa;
    //mostrarCarga(true);
}
function changeDivisas() {
    $('#desc_divisa').html(desc_divisa);
    reloadContent();
}
function cerrar() {
    window.close();
}

function imprimirCarta(ruta) {
    mostrarLoading(true);
    let jsonValue = ruta;
    var rUrl=HostImpresiones + urlGeneraPdf;
    $.ajax({
        url: rUrl,
        contentType: "application/json; charset=UTF-8",
        type: "POST",
        dataType: 'json',
        crossDomain: true,
        data: JSON.stringify({
          "Ruta":jsonValue

        }),
        success: function (data) {
            if (data.EstatusExito == true) {                
                MensajeImpresion(""+data.Detalle);

            } else {              
                MensajeImpresion(""+data.Detalle);

            }
            //return data.EstatusExito;
            mostrarLoading(false);
            //ServBorraPDF(ruta);
        },
        error: function (error) {
            MensajeImpresion();
            // alert("error"+jqXHR.readyState);   
            mostrarLoading(false);
            return false;
        }
    });
}
function imprimirCartaDetalle(ruta) {
    mostrarLoading(true);
    let jsonValue = ruta;
    var rUrl = HostImpresiones + urlGeneraPdf;
    $.ajax({
        url: rUrl,
        contentType: "application/json; charset=UTF-8",
        type: "POST",
        dataType: 'json',
        crossDomain: true,
        data: JSON.stringify({
            "Ruta": jsonValue

        }),       
        success: function (data) {
            if (data.EstatusExito == true) {
                MensajeImpresion2("" + data.Detalle);

            } else {
                MensajeImpresion2();

            }
            //return data.EstatusExito;
            mostrarLoading(false);
            //ServBorraPDF(ruta);
        },
        error: function (error) {
            mostrarLoading(false);
            MensajeImpresion2();
            // alert("error"+jqXHR.readyState);            
            return false;
        }
    });
}


function getUrlVars() {
    var vars = [], hash;
    var limite = window.location.href.indexOf('#');
    if (limite === -1)
        var hashes = window.location.href.slice(window.location.href.indexOf('?') + 1).split('&');
    else
        var hashes = window.location.href.slice(window.location.href.indexOf('?') + 1, limite).split('&');
    for (var i = 0; i < hashes.length; i++) {
        hash = hashes[i].split('=');
        vars.push(hash[0]);
        if (hash[0]==="usuario"){
        	if (hash[1].indexOf('%') !== -1) {
        	    var usTem = hash[1].split('%')[0];
        	    var ustem=hash[1].replace("%20"," ");
      		 
   			 }

			 else{
				 var ustem=hash[1];
			 }
        	hash[1]=ustem;
        }
        vars[hash[0]] = hash[1];

    }
   
    return vars;
}


function getParamUrl(name) {
    let url = new URL(window.location.href);
    let param = url.searchParams.get(name);
    return param;
}

