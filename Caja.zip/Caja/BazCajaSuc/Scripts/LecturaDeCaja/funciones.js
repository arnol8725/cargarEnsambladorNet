

//Calendario
	
$j.datepicker.regional['es'] = {
 closeText: 'Cerrar',
 prevText: '',
 nextText: ' ',
 currentText: 'Hoy',
 monthNames: ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'],
 monthNamesShort: ['Ene','Feb','Mar','Abr', 'May','Jun','Jul','Ago','Sep', 'Oct','Nov','Dic'],
 dayNames: ['Domingo', 'Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado'],
 dayNamesShort: ['Dom','Lun','Mar','Mié','Juv','Vie','Sáb'],
 dayNamesMin: ['Do','Lu','Ma','Mi','Ju','Vi','Sá'],
 weekHeader: 'Sm',
 dateFormat: 'dd/mm/yy',
 firstDay: 01,
 isRTL: false,
 showMonthAfterYear: false,
 yearSuffix: ''
 };
$j.datepicker.setDefaults($j.datepicker.regional['es']);
$(function() {
	$j("#datepicker" ).datepicker({
		firstDay: 1 
	});
});



// Check Box se comenta porque causa error desde el envio 
//document.getElementById('documento2').style.display = "none";
	
	function deseleccionar_todo(){ 
	   for (i=0;i<document.check01.elements.length;i++) 
		  if(document.check01.elements[i].type == "checkbox")	
			 document.check01.elements[i].checked=0 
	}

	$(document).ready(function() {
		$('#check01 input[type=checkbox]').on('click', function(){
		deseleccionar_todo();
		$(this).prop('checked', true);
		$(this).attr('checked', 'checked');
		});
	});

	function mostrar1() 
	{
	document.getElementById('documento1').style.display = "block"; 
	document.getElementById('documento2').style.display = "none";
	}
	function mostrar2() 
	{
	document.getElementById('documento1').style.display = "none"; 
	document.getElementById('documento2').style.display = "block";
	}

/* *********Descativar un Input*** con un checkBox************************** */

$(".folio").prop('disabled', true);

 $("#ns2").click(function() {  
	if($(this).is(':checked')) {  
		$(".folio").prop('disabled', false);
	} else {  
		$(".folio").prop('disabled', true);
	}  
});  

/* *********Radios************************** */


$(".radio02").hide();
  
  $('#radio1').on( "change", function() {
		$('.radio01').show();
		$('.radio02').hide();
		return false;
	});
	$('#radio2').on( "change", function() {
		$('.radio01').hide();
		$('.radio02').show();
		return false;
	});


$(".txtSelect").hide();

$('#selectValor').change(function() {
	if($('#selectValor option:selected').val() == 1) {
		$(".txtSelect").show();
	}
});

function mostrarLoading(mostrar) {
    if (mostrar) {
        $.LoadingOverlay("show");
    } else if (!mostrar){
        $.LoadingOverlay("hide");
    }
}