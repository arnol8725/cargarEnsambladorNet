﻿var pantallaCargada = false;



function wsLecturaDeCajaSaldos() {
    $.ajax({
        url: "http://10.54.28.114:9014/BazCajaSuc/Servicios/LecturaDeCaja/LecturaDeCaja.svc/wsLecturaDeCajaSaldos",
        type: "POST",
        cache: false,
        contentType: "application/json; charset=UTF-8",
        dataType: "JSON",
        success: function (resp) {
            var tabla = "";
            var d = JSON.stringify(resp.Descripcion);

            //tabla += "<tr>";
            //tabla += "<td>" + JSON.stringify(resp.Divisas[1].Descripcion) + "</td>";
            //tabla += "<td>" + JSON.stringify(resp.Divisas[1].DescripcionCorta) + "</td>";
            //tabla += "<td>" + JSON.stringify(resp.Divisas[1].Id) + "</td>";
            //tabla += "<td>" + JSON.stringify(resp.Divisas[1].Simbolo) + "</td>";
            //tabla += "</tr>";

            $.each(resp, function (i, di) {
                //tabla += "<tr>";
                //tabla += "<td>" + JSON.stringify(di.Divisas[i].Descripcion) + "</td>";
                //tabla += "<td>" + JSON.stringify(di.Divisas[i].DescripcionCorta) + "</td>";
                //tabla += "<td>" + JSON.stringify(di.Divisas[i].Id) + "</td>";
                //tabla += "<td>" + JSON.stringify(di.Divisas[i].Simbolo) + "</td>";
                //tabla += "</tr>";
            });
            $('#cuerpo').html(d);

            //$('#Moneda').html(JSON.stringify(resp.Divisas));
        },
        error: function (error) {

        }
    });
}