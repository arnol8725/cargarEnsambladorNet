﻿
var pantallaCargada = false;
var urlMtosCentCanje= "LecturaCaja/LecturaDeCaja.svc/wsLecturaMovtosCentroCanje";
var mtosCentroCanje="LecturaCaja/LecturaDeCaja.svc/wsLecturaMovtosCentroCanje";
function getUrls(serv) {
    var url = "";
    if (window.location.hostname == "localhost") {
        url = "http://10.54.28.226:9014/Caja/Servicios/" + serv;
    } else {
        url = "http://" + window.location.hostname + ":9014/Caja/Servicios/" + serv;
    }
    return url;
}
function servMovtosCentroCanje(empleado) {
    mostrarLoading(true);
    var fechaActual = fechaI();
    $.ajax({
        url: getUrls(urlMtosCentCanje),
        contentType: "application/json; charset=UTF-8",
        type: "POST",
        data: JSON.stringify(
            {
                "Actividad": 1,
                "Fecha": ""+fechaActual,
                "Empleado": "" + empleado
            }),
        dataType: 'json',
        crossDomain: true,
        success: function (data) {
            if (data.Respuesta.length!=0) {
                obtieneOperCentroCanjeDR(data);
              
            } else {
                $('#tablaDineroRecibido').html("No hay movimientos");
                $('#tablaCambioEntregado').html("No hay movimientos");   
            }
            mostrarLoading(false);
        },
        error: function () {
            $("#tablaDineroRecibido").text("Error en el consumo del servicio ");
            mostrarLoading(false);
        }
    });

    mostrarLoading(true);

    $.ajax({
        url:getUrls(mtosCentroCanje) , //opcion a cambios en la url 
        contentType: "application/json; charset=UTF-8",
        type: "POST",
        data: JSON.stringify(
            {
                "Actividad": 2,
                "Fecha": ""+fechaActual,
                "Empleado": ""+empleado
            }),
        dataType: 'json',
        crossDomain: true,
        success: function (data) {
            if (data.Respuesta.length != 0) {
                obtieneOperCentroCanjeCE(data);
                mostrarLoading(false);
            }
            else {
                $('#tablaDineroRecibido').html("No hay movimientos");
                $('#tablaCambioEntregado').html("No hay movimientos");
                mostrarLoading(false);

            }
        },
        error: function () {
            $("#tablaCambioEntregado").text("Error en el consumo del servicio ");
            mostrarLoading(false);
        }
    });
}

function obtieneOperCentroCanjeDR(jsonResp) {
    var suma = 0;
    if (jsonResp.NoError == 0) {
        respDineroRecibido(jsonResp);
    }
    else if (jsonResp.NoError == 1) {
        document.getElementById("rev").innerHTML = jsonResp.Descripcion;
    } else if (jsonResp.Descripcion == 3) {
        document.getElementById("rev").innerHTML = jsonResp.Descripcion;
    } else {
        document.getElementById("rev").innerHTML = "Intente mas tarde.";
    }
}
function obtieneOperCentroCanjeCE(jsonResp) {
    var suma = 0;
    if (jsonResp.NoError == 0) {
        respCambioEntregado(jsonResp);
    }
    else if (jsonResp.NoError == 1) {
        document.getElementById("rev").innerHTML = jsonResp.Descripcion;
    } else if (jsonResp.Descripcion == 3) {
        document.getElementById("rev").innerHTML = jsonResp.Descripcion;
    } else {
        document.getElementById("rev").innerHTML = "Intente mas tarde.";
    }
}
function respDineroRecibido(jsonResp) {
    mostrarLoading(true);
    if (jsonResp.Respuesta.length === 0) {
        alert("no hay movimientos");
    }
    else {
        var tablaDineroRecibido = '';
        tablaDineroRecibido +=
                        '<div class="titNegro2 tCenter"">Dinero recibido</div>' +
                        '<table class="tblGeneralMovtosCentroCanje" >' +
                            '<tbody>' +
                                '<tr>' +
                                    '<th>ID</th>' +
                                    '<th>Denominación</th>' +
                                    '<th>Tipo</th>' +
                                    '<th>No.piezas</th>' +
                                    '<th>Importe</th>' +
                                '</tr>';
        $.each(jsonResp.Respuesta, function (i, p) {
            tablaDineroRecibido +=
                          '<tr>' +
                               '<td>' + p.FiIdMovto.toString().trim() + '</td>' +
                               '<td class="tRight">' + formatMoney(p.FnDenominacion) + '</td>' +                               
                               '<td>' + p.FcTipoMoneda.toString().trim() + '</td>' +
                               '<td>' + p.FiCantidad.toString().trim() + '</td>' +
                               '<td class="tRight">' + formatMoney(p.FnImpMov) + '</td>' +
                               '<td>&nbsp;</td>' +
                          '</tr>';
        });
        tablaDineroRecibido += '</tbody>' +
                        '</table>';
        $('#tablaDineroRecibido').html(tablaDineroRecibido);
    }
    mostrarLoading(false);
}
function respCambioEntregado(jsonResp) {
    mostrarLoading(true);
    if (jsonResp.Respuesta.length != 0) {
        var tablaCambioEntregado = '';
        tablaCambioEntregado +=
                        '<div class="titNegro2 tCenter">Cambio entregado</div>' +
                        '<table class="tblGeneralMovtosCentroCanje">' +
                            '<tbody>' +
                                '<tr>' +
                                    '<th>ID</th>' +
                                    '<th>Denominación</th>' +
                                    '<th>Tipo</th>' +
                                    '<th>No.piezas</th>' +
                                    '<th>Importe</th>' +
                                '</tr>';
        $.each(jsonResp.Respuesta, function (i, p) {
            tablaCambioEntregado +=
                          '<tr>' +
                               '<td>' + p.FiIdMovto.toString().trim() + '</td>' +
                               '<td class="tRight">' + formatMoney(p.FnDenominacion) + '</td>' +
                               '<td>' + p.FcTipoMoneda.toString().trim() + '</td>' +
                               '<td>' + p.FiCantidad.toString().trim() + '</td>' +
                               '<td class="tRight">' + formatMoney(p.FnImpMov) + '</td>' +
                               '<td>&nbsp;</td>' +                               
                          '</tr>';
        });
        tablaCambioEntregado +=
                            '</tbody>' +
                        '</table>' +
                        '<div class="clear"></div>' +
                        '<table class="tblTotales1">' +
                            '<tbody>' +
                                '<tr>' +
                                    '<td><strong>Tipo de cambio: B - Billete / M - Moneda</strong></td>' +
                                '</tr>' +
                            '</tbody>' +
                        '</table>';
        $('#tablaCambioEntregado').html(tablaCambioEntregado);
    }
    mostrarLoading(false);
}



