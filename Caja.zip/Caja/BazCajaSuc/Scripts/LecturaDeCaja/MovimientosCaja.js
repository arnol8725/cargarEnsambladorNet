﻿if ($j === undefined) { var $j = jQuery.noConflict(true); console.log($().jquery); console.log($j().jquery); }

var pantallaCargada = false;
var urlMovCaja = "LecturaCaja/LecturaDeCaja.svc/wsLecturaMovimientosCaja";
var btnImpresiones = "LecturaCaja/LecturaDeCaja.svc/wsLecturaMovimientosCaja";
var mtosCajaDetalle = "LecturaCaja/LecturaDeCaja.svc/wsLecturaMovtosCajaDetalle";
var usrPerfil;
var perfilMotscaja = "LecturaCaja/lecturaDeCaja.svc/wsLecturaPerfiles";
var usrMtos;
var seleccionDivisaMC;
var Descripcion;
var habImpMtosCaja = false;


function getUrlsMtosCaja(serv) {
    var url = "";
    url = "http://" + window.location.hostname + ":9014/Caja/Servicios/" + serv;
    return url;
}
function extreDivisaMovtosCaja() {
    var seleccionDivisa2 = $('#selector1 option:selected').text();   
    seleccionDivisaMC = seleccionDivisa2;
}

function movimientoCaja(empleado, usrPerfil, divisass) {
    var fechaActual = fechaI();
    
    mostrarLoading(true);
    $.ajax({
        url: getUrlsMtosCaja(urlMovCaja), 

        contentType: "application/json; charset=UTF-8",
        type: "POST",
        data: JSON.stringify(
            {
                "Operacion": 3,
                "Opcion": 4,
                "Perfil": ""+usrPerfil,
                "IdTipoDivisa": divisass,
                "Inicio": "" + fechaActual,
                "Empleado": "" + empleado,
                "Origen": ""
            }),
        dataType: 'json',
        crossDomain: true,
        success: function (data) {
            if (data.Respuesta.length!=0 && data.NoError==0) {               
                habImpMtosCaja = true;
                ServicioMovimientos(data);
            } else {
                habImpMtosCaja = false;
                alert("No hay movimientos");
                $("#ventanaNueva").load(host + movimientos);
            }
            mostrarLoading(false);
           
        },
        error: function () {
            // alert(data);
            habImpMtosCaja = false;
            $("#rev").text("Error en el consumo del servicio ");
            mostrarLoading(false);
        }
    });

}
function ServicioMovimientos(jsonRespMovimientos) {
    var suma = 0;
    if (jsonRespMovimientos.NoError == 0) {
        MovimientosIngresos1(jsonRespMovimientos.Respuesta);
    }
    else if (jsonRespMovimientos.NoError == 1) {
        document.getElementById("ingresosBanco").innerHTML = jsonRespMovimientos.Descripcion;
    } else if (jsonRespMovimientos.Respuesta == 3) {
        document.getElementById("ingresosBanco").innerHTML = jsonRespMovimientos.Descripcion;
    } else {
        document.getElementById("ingresosBanco").innerHTML = "Intente mas tarde.";
    }
}
function MovimientosIngresos1(jsonMovomientos) {
    //mostrarLoading(true);
    if (jsonMovomientos.length == 0) {
        alert("no hay movimientos");
    }
    else {

        var suma = 0.00, suma2 = 0.00, suma3=0,suma4=0,suma5=0,suma6=0;
        var queryTo = Enumerable.From(jsonMovomientos)
        .Select(function (x) {
            return {
                'FiTipoOp': x['FiTipoOp'],
                'FcTopDesc': x['FcTopDesc'],
                'FiIngEgr': x['FiIngEgr'],
                'CuentaOp': x['CuentaOp'],
                'MontoOp': x['MontoOp'],
                'TipoPuesto':x['TipoPuesto']
            };
        }).ToArray();

        //BANCO-NEGOCIO
        var tablaIngresosBanco = '<table class="tblGeneral2Movimientos tCenter">' +
                           '<tbody>' +
                           '<tr> <!-- encabezado de la pagina -->' +
                           '<th>TOP</th>' +
                           '<th>Descripción</th>' +
                           '<th>Tot. op.</th>' +
                           '<th class="tRight">Importe</th>' +
                           '</tr>';
        var tablaEgresosBanco = '<table class="tblGeneral2Movimientos tCenter">' +
        '  <tbody>' +
           '   <tr>' +
            '      <th>TOP</th>' +
             '     <th>Descripción</th>' +
             '     <th>Tot. op.</th>' +
            '      <th class="tRight">Importe</th>' +
            '  </tr>';
        //BANCO ADMINISTRACION
        var tblIngBancoAdmon = '<table class="tblGeneral2Movimientos tCenter">' +
                           '<tbody>' +
                           '<tr> <!-- encabezado de la pagina -->' +
                           '<th>TOP</th>' +
                           '<th>Descripción</th>' +
                           '<th>Tot. op.</th>' +
                           '<th class="tRight">Importe</th>' +
                           '</tr>';
        var tblEgresoBancoAdmon = '<table class="tblGeneral2Movimientos tCenter">' +
        '  <tbody>' +
           '   <tr>' +
            '      <th>TOP</th>' +
             '     <th>Descripción</th>' +
             '     <th>Tot. op.</th>' +
            '      <th class="tRight">Importe</th>' +
            '  </tr>';
        //COMERCIO NEGOCIO
        var tblIngComercio = '<table class="tblGeneral2Movimientos tCenter">' +
                           '<tbody>' +
                           '<tr> <!-- encabezado de la pagina -->' +
                           '<th>TOP</th>' +
                           '<th>Descripción</th>' +
                           '<th>Tot. op.</th>' +
                           '<th class="tRight">Importe</th>' +
                           '</tr>';
        var tblEgComercio = '<table class="tblGeneral2Movimientos tCenter">' +
        '  <tbody>' +
           '   <tr>' +
            '      <th>TOP</th>' +
             '     <th>Descripción</th>' +
             '     <th>Tot. op.</th>' +
            '      <th class="tRight">Importe</th>' +
            '  </tr>';
        var detalle;
        var cont = 0;
        //banco Negocio
        $.each(queryTo, function (i, p) {
            //1 banco -negocio
            //2 comercio Negocio
            //3 banco - Administracion
            if (p.TipoPuesto === 1) {
                var compara = queryTo[i].FiIngEgr.toString().trim();
                if (compara === "1") {

                    tablaIngresosBanco += 
                        '<tr class="gris1"  onclick="MensajeDetalle(' + queryTo[i].FiTipoOp + ',\'' + queryTo[i].FcTopDesc + '\',1,1)" id="seleccion' + queryTo[i].FiTipoOp + '">' +
                                      //'<div style="overflow:auto;height:50%;">' +
                                      '<td class="top">' + queryTo[i].FiTipoOp.toString().trim() + '</td>' +
                                      '<td class="desc"><div class="tLeft">' + queryTo[i].FcTopDesc.toString().trim() + '</div></td>' +
                                      '<td class="totOp" style="text-align=left;">' + queryTo[i].CuentaOp.toString().trim() + '</td>' +
                                      '<td class="importe tRight">' + formatMoney(queryTo[i].MontoOp) + '</td>' +
                                      //'</div>' +
                                     '</tr>';

                    suma += parseFloat(queryTo[i].MontoOp.toString().trim());
                    cont++;
                }
                else if (compara === "2") {
                    tablaEgresosBanco += '<tr class="gris1" onclick="MensajeDetalle(' + queryTo[i].FiTipoOp + ',\'' + queryTo[i].FcTopDesc + '\',1,1)" id="seleccion' + queryTo[i].FiTipoOp + '">' +
                                       //'<div style="overflow:auto;height:50%;">' +
                                      '<td class="top">' + queryTo[i].FiTipoOp.toString().trim() + '</td>' +
                                      '<td class="desc"><div class="tLeft">' + queryTo[i].FcTopDesc.toString().trim() + '</div></td>' +
                                      '<td class="totOp" style="text-align=left;">' + queryTo[i].CuentaOp.toString().trim() + '</td>' +
                                      '<td class="importe tRight">' + formatMoney(queryTo[i].MontoOp) + '</td>' +
                                      //'</div>' +
                                     '</tr>';
                    suma2 += parseFloat(queryTo[i].MontoOp.toString().trim());
                }
            }
            else if (p.TipoPuesto === 3) {
                var compara = queryTo[i].FiIngEgr.toString().trim();
                if (compara === "1") {

                    tblIngBancoAdmon += '<tr class="gris1" onclick="MensajeDetalle(' + queryTo[i].FiTipoOp + ',\'' + queryTo[i].FcTopDesc + '\',1,3)" id="seleccion' + queryTo[i].FiTipoOp + '">' +
                                      //'<div style="overflow:auto;height:50%;">' +
                                      '<td class="top">' + queryTo[i].FiTipoOp.toString().trim() + '</td>' +
                                      '<td class="desc"><div class="tLeft">' + queryTo[i].FcTopDesc.toString().trim() + '</div></td>' +
                                      '<td class="totOp">' + queryTo[i].CuentaOp.toString().trim() + '</td>' +
                                      '<td class="importe tRight">' + formatMoney(queryTo[i].MontoOp) + '</td>' +
                                      //'</div>' +
                                     '</tr>';

                    suma3 += parseFloat(queryTo[i].MontoOp.toString().trim());
                }
                else if (compara === "2") {
                    tblEgresoBancoAdmon += '<tr class="gris1" onclick="MensajeDetalle(' + queryTo[i].FiTipoOp + ',\'' + queryTo[i].FcTopDesc + '\',1,3)" id="seleccion' + queryTo[i].FiTipoOp + '">' +
                                       //'<div style="overflow:auto;height:50%;">' +
                                      '<td class="top">' + queryTo[i].FiTipoOp.toString().trim() + '</td>' +
                                      '<td class="desc"><div class="tLeft">' + queryTo[i].FcTopDesc.toString().trim() + '</div></td>' +
                                      '<td class="totOp">' + queryTo[i].CuentaOp.toString().trim() + '</td>' +
                                      '<td class="importe tRight">' + formatMoney(queryTo[i].MontoOp) + '</td>' +
                                      //'</div>' +
                                     '</tr>';
                    suma4 += parseFloat(queryTo[i].MontoOp.toString().trim());
                }
            }
            else if (p.TipoPuesto === 2) {
                var compara = queryTo[i].FiIngEgr.toString().trim();
                if (compara === "1") { 

                    tblIngComercio += '<tr class="gris1" onclick="MensajeDetalle(' + queryTo[i].FiTipoOp + ',\'' + queryTo[i].FcTopDesc + '\',3,2)" id="seleccion' + queryTo[i].FiTipoOp + '">' +
                                      //'<div style="overflow:auto;height:50%;">' +
                                     '<td class="top">' + queryTo[i].FiTipoOp.toString().trim() + '</td>' +
                                      '<td class="desc"><div class="tLeft">' + queryTo[i].FcTopDesc.toString().trim() + '</div></td>' +
                                      '<td class="totOp">' + queryTo[i].CuentaOp.toString().trim() + '</td>' +
                                      '<td class="importe tRight">' + formatMoney(queryTo[i].MontoOp) + '</td>' +
                                      //'</div>' +
                                     '</tr>';

                    suma5 += parseFloat(queryTo[i].MontoOp.toString().trim());
                }
                else if (compara === "2") {
                    tblEgComercio += '<tr class="gris1" onclick="MensajeDetalle(' + queryTo[i].FiTipoOp + ',\'' + queryTo[i].FcTopDesc + '\',3,2)" id="seleccion' + queryTo[i].FiTipoOp + '">' +
                                       //'<div style="overflow:auto;height:50%;">' +
                                      '<td class="top">' + queryTo[i].FiTipoOp.toString().trim() + '</td>' +
                                      '<td class="desc"><div class="tLeft">' + queryTo[i].FcTopDesc.toString().trim() + '</div></td>' +
                                      '<td class="totOp">' + queryTo[i].CuentaOp.toString().trim() + '</td>' +
                                      '<td class="importe tRight">' + formatMoney(queryTo[i].MontoOp) + '</td>' +
                                      //'</div>' +
                                     '</tr>';
                    suma6 += parseFloat(queryTo[i].MontoOp.toString().trim());
                }
            }
            
        });
       
        //banco-negocio
        if (suma === 0) {
            tablaIngresosBanco += '<!-- para mostrar el resultado del SUBTOTAL de ingresos -->' +
                  '<tr class=" total">' +
                   '<td colspan="2" class="tLeft"></td>' +
                     '<td class="tRight">NO HAY OPERACIONES</td>' +
                      '</tr>' +
                       '</tbody>' +
                       '</table>';

        } else {
            tablaIngresosBanco += '<!-- para mostrar el resultado del SUBTOTAL de ingresos -->' +
                  '<tr class=" total">' +
                   '<td colspan="2" class="tLeft"><strong>Subtotal Ingresos</td></strong>' +
                     '<td colspan="2" class="tRight"><strong>' + formatMoney(suma) + '</strong></td>' +
                      '</tr>' +
                       '</tbody>' +
                       '</table>';
        }
        if (suma2 === 0) {
            tablaEgresosBanco +=
           '  <tr class=" total">' +
           '      <td colspan="2" class="tLeft"></td>' +
            '     <td class="tRight">NO HAY OPERACIONES</td>' +
            ' </tr>' +
        ' </tbody>' +
    '  </table>';
        }
        else {
            tablaEgresosBanco +=
                '  <tr class=" total">' +
                '      <td colspan="2" class="tLeft"><strong>Subtotal egresos</strong></td>' +
                 '     <td colspan="2" class="tRight"><strong>' + formatMoney(suma2) + '</strong></td>' +
                 ' </tr>' +
             ' </tbody>' +
        '  </table>';
        }
        //banco administracion
         if (suma3 === 0) {
             tblIngBancoAdmon += '<!-- para mostrar el resultado del SUBTOTAL de ingresos -->' +
                  '<tr class=" total">' +
                   '<td colspan="2" class="tLeft"></td>' +
                     '<td class="tRight">NO HAY OPERACIONES</td>' +
                      '</tr>' +
                       '</tbody>' +
                       '</table>';

         }
         else {
             tblIngBancoAdmon += '<!-- para mostrar el resultado del SUBTOTAL de ingresos -->' +
                  '<tr class=" total">' +
                   '<td colspan="2" class="tLeft"><strong>Subtotal Ingresos</strong></td>' +
                     '<td colspan="2" class="tRight"><strong>' + formatMoney(suma3) + '</strong></td>' +
                      '</tr>' +
                       '</tbody>' +
                       '</table>';
        }
        if (suma4 === 0) {
            tblEgresoBancoAdmon +=
           '  <tr class=" total">' +
           '      <td colspan="2" class="tLeft"></td>' +
            '     <td class="tRight">NO HAY OPERACIONES</td>' +
            ' </tr>' +
        ' </tbody>' +
    '  </table>';
        } else {
            tblEgresoBancoAdmon +=
                '  <tr class=" total">' +
                '      <td colspan="2" class="tLeft"><strong>Subtotal egresos</strong></td>' +
                 '     <td colspan="2" class="tRight"><strong>' + formatMoney(suma4) + '</strong></td>' +
                 ' </tr>' +
             ' </tbody>' +
        '  </table>';
        }
        //Comercio - Negocio
        if (suma5 === 0) {
            tblIngComercio += '<!-- para mostrar el resultado del SUBTOTAL de ingresos -->' +
                 '<tr class=" total">' +
                  '<td colspan="2" class="tLeft"></td>' +
                    '<td class="tRight">NO HAY OPERACIONES</td>' +
                     '</tr>' +
                      '</tbody>' +
                      '</table>';

        } else {
            tblIngComercio += '<!-- para mostrar el resultado del SUBTOTAL de ingresos -->' +
                 '<tr class=" total">' +
                  '<td colspan="2" class="tLeft"><strong>Subtotal Ingresos</strong></td>' +
                    '<td colspan="2" class="tRight"><strong>' + formatMoney(suma5) + '</strong></td>' +
                     '</tr>' +
                      '</tbody>' +
                      '</table>';
        }
        if (suma6 === 0) {
            tblEgComercio +=
           '  <tr class="total">' +
           '      <td colspan="2" class="tLeft"></td>' +
            '     <td class="tRight">NO HAY OPERACIONES</td>' +
            ' </tr>' +
        ' </tbody>' +
    '  </table>';
        } else {
            tblEgComercio +=
                '  <tr class=" total">' +
                '      <td colspan="2" class="tLeft"><strong>Subtotal egresos</strong></td>' +
                 '     <td colspan="2" class="tRight"><strong>' + formatMoney(suma6) + '</strong></td>' +
                 ' </tr>' +
             ' </tbody>' +
        '  </table>';
        }
        var sumaTotalIng = suma+suma3+suma5;
        var sumaTotalEg = suma2+suma4+ suma6;
        

        $('#ingresosBanco').html(tablaIngresosBanco);
        $('#egresosBanco').html(tablaEgresosBanco);
        $('#admoning').html(tblIngBancoAdmon);
        $('#admoneg').html(tblEgresoBancoAdmon);
        $('#comercioIng').html(tblIngComercio);
        $('#comercioEg').html(tblEgComercio);
        $('#sumaTotalIng').html( formatMoney(sumaTotalIng));
        $('#sumaTotalEg').html( formatMoney(sumaTotalEg));
    }
    mostrarLoading(false);

}
function grouper(propertyName, selector) {
    return function (e) {
        return e.GroupBy("$." + propertyName, null, function (k, g) {
            return {
                text: k,
                children: g.Let(selector).ToArray()
            };
        });
    };
}
function groupBy(array, f) {
    var groups = {};
    array.forEach(function (o) {
        var group = JSON.stringify(f(o));
        groups[group] = groups[group] || [];
        groups[group].push(o);
    });
    return Object.keys(groups).map(function (group) {
        return groups[group];
    })
}
function imprimeCaja() {
    
    if (!habImpMtosCaja) {
        alert("No hay Informacion para imprimir");
    } else {

        mostrarLoading(true);
        var fechaActual = fechaI();
        var ur = getUrls(btnImpresiones);
        extreDivisaMovtosCaja();
        ServicePerfilesMtosCaja(getUrlVars()["usuario"]);
        
        var divisass;
        var UsuarioMovtosCaja = getUrlVars()["usuario"];
        var seleccionDivisa2 = $('#selector1 option:selected').text();
        seleccionDivisaMC = seleccionDivisa2;
        if (seleccionDivisaMC == "Moneda Nacional") {
            divisass = 1;
        } else if (seleccionDivisaMC == "Dolar Americano") {
            divisass = 2;
        } else if (seleccionDivisaMC == "Onza Libertad de Plata") {
            divisass = 3;
        } else if (seleccionDivisaMC == "Dolar Canadiense") {
            divisass = 5;
        } else if (seleccionDivisaMC == "Euros") {
            divisass = 7;
        }

        $.ajax({
            url: ur,
            contentType: "application/json; charset=UTF-8",
            type: "POST",
            data: JSON.stringify(
                {
                    "Operacion": 3,
                    "Opcion": 4,
                    "Perfil": "" + perfil,
                    "IdTipoDivisa": divisass,
                    "Inicio": "" + fechaActual,
                    "Empleado": "" + UsuarioMovtosCaja,
                    "Origen": "",
                    "Imprime": true,
                    "ImprimeDetalle": false,
                    "NoEmpleado": "" + UsuarioMovtosCaja,
                    "TipoDivisa": "" + seleccionDivisaMC
                }),
            dataType: 'json',
            crossDomain: true,
            success: function (data) {
                //MensajeImpresion(""+data.Respuesta);
                mostrarLoading(false);
                imprimirCarta("" + data.RutaPDF);

                // MensajeImpresion("Se imprimio correctamente?");
            },
            error: function () {
                // alert(data);
                mostrarLoading(false);
                MensajeImpresion("NO SE PUDO CONSUMIR EL SERVICIO");

                //$("#rev").text("Error en el consumo del servicio ");
            }
        });
    }
}
function imprimeCajaDetalle() {
    
    if (!habImpMtosCaja) {
        alert("No hay Informacion para imprimir");
    } else {
        mostrarLoading(true);
        var fechaActual = fechaI();
        
        extreDivisaMovtosCaja();

        var emplDetalle = getUrlVars()["usuario"];
        var urDetalle = getUrlsMtosCaja(btnImpresiones);
        ServicePerfilesMtosCaja();
        var divisass;
        var UsuarioMovtosCaja = getUrlVars()["usuario"];
        var seleccionDivisa2 = $('#selector1 option:selected').text();
        seleccionDivisaMC = seleccionDivisa2;
        if (seleccionDivisaMC == "Moneda Nacional") {
            divisass = 1;
        } else if (seleccionDivisaMC == "Dolar Americano") {
            divisass = 2;
        } else if (seleccionDivisaMC == "Onza Libertad de Plata") {
            divisass = 3;
        } else if (seleccionDivisaMC == "Dolar Canadiense") {
            divisass = 5;
        } else if (seleccionDivisaMC == "Euros") {
            divisass = 7;
        }
        $.ajax({
            url: urDetalle,
            contentType: "application/json; charset=UTF-8",
            type: "POST",
            data: JSON.stringify(
                {
                    "Operacion": 3,
                    "Opcion": 4,
                    "Perfil": "" + perfil,
                    "IdTipoDivisa": divisass,
                    "Inicio": "" + fechaActual,
                    "Empleado": "" + emplDetalle,
                    "Origen": "",
                    "Imprime": false,
                    "ImprimeDetalle": true,
                    "NoEmpleado": "" + emplDetalle,
                    "TipoDivisa": "" + seleccionDivisaMC
                }),
            dataType: 'json',
            crossDomain: true,
            success: function (data) {
                mostrarLoading(false);
                //MensajeImpresion("se imprimio correctamente?");
                imprimirCartaDetalle(data.RutaPDF);
            },
            error: function () {
                // alert(data);
                mostrarLoading(false);
                $("#rev").text("Error en el consumo del servicio ");
            }
        });
    }
}
function MensajeDetalle(top, detalle, opcion, origenDesc) {
    var origenDesc2
    $('#mensajeTitulo2').html('Mensaje del sistema:');
    $('#mensajeTexto2').html("Detalle TOP: " + top + " - " + detalle);
    if (origenDesc == 1) {
        origenDesc2 = "Banco - Negocio";
    }
    if (origenDesc == 3) {
        origenDesc2 = "Banco - Administracion";
    }
    if (origenDesc == 2) {
        origenDesc2 = "Comercio - Negocio";
    }

    $('#origenDesc').html("TIPO ORIGEN: " + origenDesc2);
    $j('#modalDetalle').modal();
    movtosCajaDetalle(top,opcion);
}
function movtosCajaDetalle(top,opcion) {
    mostrarLoading(true);
    var fechaActual = fechaI();
    var num = top;
    var empl = getUrlVars()["usuario"];
    ServicePerfilesMtosCaja();
    var urll = getUrlsMtosCaja(mtosCajaDetalle);
    //mostrarCarga(true);
    var divisass;
    var seleccionDivisa2 = $('#selector1 option:selected').text();
    seleccionDivisaMC = seleccionDivisa2;
    if (seleccionDivisaMC == "Moneda Nacional") {
        divisass = 1;
    } else if (seleccionDivisaMC == "Dolar Americano") {
        divisass = 2;
    } else if (seleccionDivisaMC == "Onza Libertad de Plata") {
        divisass = 3;
    } else if (seleccionDivisaMC == "Dolar Canadiense") {
        divisass = 4;
    } else if (seleccionDivisaMC == "Euros") {
        divisass = 5;
    }
    $.ajax({
        
        url:urll,
        contentType: "application/json; charset=UTF-8",
        type: "POST",
        data: JSON.stringify(
            {
               
                "Opcion": opcion,
                "Top": num,
                "Perfil": "" + perfil,
                "IdTipoDivisa": divisass,
                "Inicio": ""+fechaActual,
                "Empleado": ""+empl,
                "EmpCons": "",
                "Tipo": 1

            }),
        dataType: 'json',
        crossDomain: true,
        success: function (data) {
            mostrarLoading(false);
            muestraDetalles(data);
            
        },
        error: function () {
            mostrarLoading(false);         
            $("#rev").text("Error en el consumo del servicio ");
        }
    });
}
function muestraDetalles(respuestajson) {
    if (respuestajson.NoError == 0) {
        if (respuestajson.Respuesta!=null || respuestajson.Respuesta==0) {
            obtenerDetallesMtos(respuestajson);

        }
    }
    else if (respuestajson.NoError == 1) {
        document.getElementById("ingresosBanco").innerHTML = respuestajson.Descripcion;
    } else if (respuestajson.Respuesta == 3) {
        document.getElementById("ingresosBanco").innerHTML = respuestajson.Descripcion;
    } else {
        document.getElementById("ingresosBanco").innerHTML = "Intente mas tarde.";
    }
}
function obtenerDetallesMtos(respjson){
   // mostrarLoading(true);
    var datos = respjson.Respuesta;
    var tablaDetalle = '';
    var contMtos = 0;
    var suma = 0;
    tablaDetalle += '<table class="tblGeneral3 tCenter"><tbody><tr><th>No. Operacion</th>' +
                    '<th>Num. Cajero</th>'+
                    '<th>Puesto Base</th>'+
                    '<th>Puesto Rol</th>'+
                    '<th>Hora Op.</th>'+
                    '<th>referencia</th>'+
                    '<th class="tRight">Importe</th></tr>';

    $.each(datos,function (i,p){
    
    
        tablaDetalle += '<tr class="gris1" style="height: 10px;">' +
                                      '<td>' + p.FiNoTransac+ '</td>' +
                                      '<td>'+p.FcNoCajero+ '</td>' +
                                      '<td> ' + p.FiPuestoId + '</td>' +//Puesto Base
                                      '<td>' + p.FiPuestoRol + '</td>' + //Puesto Rol
                                      '<td>' + p.FdMovFecHr + '</td>' +//Hora Op 
                                      '<td>' + p.FcRefMov + '</td>' + //referencia
                                      '<td class="tRight">' + formatMoney(p.FnImpMov) + '</td>' +//importe                                      
                                     '</tr>';
        suma += parseFloat(p.FnImpMov);
        contMtos++;

    });
    tablaDetalle += '</tbody></table>'
    $('#detalleSumas').html("Total transacciones:" + contMtos + " | MontoNeto: " + formatMoney(suma));
    
    //$('#mensajeTexto2').html("Detalle TOP: " + datos[0].FiTipoOp.toString() + " - " + datos[0].FcRefMov.toString());

    $('#detalleMC').html(tablaDetalle);
    mostrarLoading(false);
}
function ServicePerfilesMtosCaja(usuario) {
    mostrarLoading(true);
    var host1 = getUrlBase();
    $.ajax({
        url: getUrlsMtosCaja(perfilMotscaja),
        contentType: "application/json; charset=UTF-8",
        type: "POST",
        data: JSON.stringify({
            "NoEmpleado": "" + usuario,
        }),
        dataType: 'json',
        crossDomain: true,
        success: function (data) {
            mostrarLoading(false);
            usrPerfil = data.Respuesta;
            
            return data.Respuesta;
        },
        error: function () {
            $("#bMensaje").text("Ocurrió un error en el consumo del servicio.");
            mostrarLoading(false);
        }
    });
}