﻿function EsconderURLs(letra) {
    let link;
    switch (letra) {
        case 'A':
            link = [6,7];
            break;
        case 'B':
            link = [4, 6];
            break;
        case 'C':
            link = [4, 6];
            break;
        case 'D':
            link = [];
            break;
        case 'E':
            link = [];
            break;
        default:
            link = [1,2,3,4,5,6,7,8];
            break;
    }
    let lista = "";
    for (let i = 0 ; i < link.length ; i++)
        EsconderLink(link[i])
}

function EsconderLink(opcion) {
    let link;
    switch (opcion) {
        case 1:
            link = "#sIniciales";
            break;
        case 2:
            link = "#sActuales";
            break;
        case 3:
            link = "#ventanaTopes";
            break;
        case 4:
            link = "#movimientos"; 
            break;
        case 5:
            link = "#consultaOperaciones";
            break;
        case 6:
            link = "#consMovtosSinFlujo";            
            break;
        case 7:
            link = "#EntSal";
            break;
        case 8:
            link = "#mvtosCentroCanje";
            break;
    }
    $(link).hide();
}

function CambiarTitulo(opcion) {
    let link = "Lectura de Caja - ";
    grisTodosLosBotones();
    switch (opcion) {
        case 1:
            link += 'Saldos iniciales';
            $('#sIniciales').attr('class', 'btnVSaldos');
            break;
        case 2:
            link += 'Saldos actuales';
            $('#sActuales').attr('class', 'btnVSaldos');
            break;
        case 3:
            link += 'Topes';
            $('#ventanaTopes').attr('class', 'btnVSaldos');
            break;
        case 4:
            link += 'Movimientos caja';
            $('#movimientos').attr('class', 'btnVSaldos');
            break;
        case 5:
            link += 'Consulta de Operaciones';
            $('#consultaOperaciones').attr('class', 'btnVSaldos');
            break;
        case 6:
            link += 'Cons. Movtos. Sin Flujo';
            $('#consMovtosSinFlujo').attr('class', 'btnVSaldos');
            break;
        case 7:
            link += 'Entrada/salida';
            $('#EntSal').attr('class', 'btnVSaldos');
            break;
       
        case 8:
            link += 'Movimientos Centro de Canje';
            $('#mvtosCentroCanje').attr('class', 'btnVSaldos');
            break;
        case 27:
            link = 'Consulta de Operaciones del Dia';
            break;

    }
    $('#tituloCaja').html(link);
}

function grisTodosLosBotones() {
    let etiquetas = ['#sIniciales', '#sActuales', '#ventanaTopes', '#movimientos', '#consultaOperaciones', '#consMovtosSinFlujo', '#EntSal', '#mvtosCentroCanje'];
    for (let i = 0 ; i < etiquetas.length ; i++)
        $(etiquetas[i]).attr('class', 'btnGSaldos');
}