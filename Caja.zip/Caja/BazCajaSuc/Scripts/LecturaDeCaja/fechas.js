﻿$(document).ready(function () {
    cargaInicial();
    
});
function cargaInicial() {
    setTimeout(function () {

        setTimeout(function () {
            getTimeSystem();
            getDateSystem();
            serviceTiendaEmpleado();
        }, 1500);
        //mostrarCarga(false);
        //mostrarCarga(true);                            
    }, 1500);


}
function getTimeSystem() {
    var date = new Date();
    var hora = date.getHours();
    var min = date.getMinutes();
    var horaSis = hora + ":" + min;    
    $("#timeSis").text(horaSis + "Hrs");
}

function getDateSystem() {
    var date = new Date();
    var mes = date.getMonth() + 1;
    var dia = date.getDate();
    var anio = date.getFullYear();
    if (mes<10){
        var fechaSis = dia + "/0" + mes + "/" + anio;
    } else {
        var fechaSis = dia + "/" + mes + "/" + anio;
    }
    
    $("#fechaSist").text(fechaSis);
    $('#datepicker').val(fechaSis);

}
