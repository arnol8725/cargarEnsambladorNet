﻿$(document).ready(function () {
    getDateSystem();
    getTimeSystem();

});

function getDateSystem() {
    var date = new Date();
    var mes = date.getMonth() + 1;
    var dia = date.getDate();
    var anio = date.getFullYear();
    if (dia < 10) {
        dia = "0" + date.getDate();
    }
    if (mes < 10) {
        mes = date.getMonth() + 1;
    }          
     else {
        var fechaSis = dia + "/" + mes + "/" + anio;
    }
    var fechaSis = dia + "/" + mes + "/" + anio;
    $("#fechaSist").text(fechaSis);

    $('#datepicker').val(fechaSis);

    
}
function getTimeSystem() {
    var date = new Date();
    var hora = date.getHours();
    var min = date.getMinutes();
    if (min < 10) {
        var horaSis = hora + ":0" + min + " Hrs.";
    } else {
        var horaSis = hora + ":" + min + " Hrs.";

    }
    $("#timeSis").text(horaSis);
    
}