﻿var pantallaCargada = false;
var usuario;
var usuario2;
var usuarioLetra;
var seleccionDivisa;
var ServEmpl = "LecturaCaja/LecturaDeCaja.svc/wsLecturaEntradasSalidas";
var urlEyS = "LecturaCaja/LecturaDeCaja.svc/wsLecturaEntradasSalidas";
var servImpresion = "LecturaCaja/LecturaDeCaja.svc/wsLecturaEntradasSalidas";
var mtosCajaDetalleES = "LecturaCaja/LecturaDeCaja.svc/wsLecturaMovtosCajaDetalle";
var perfilEnSal2;
var canImpES = false;

var urlPerfilES = "LecturaCaja/lecturaDeCaja.svc/wsLecturaPerfiles";

function cmabio() {
    mostrarLoading(true);
    $j('#selector').change(function () {

        var divisa = 1;
        var seleccionDivisa2 = $('#selector1 option:selected').text();
        seleccionDivisaMC = seleccionDivisa2;
        if (seleccionDivisaMC == "Moneda Nacional") {
            divisa = 1;
        } else if (seleccionDivisaMC == "Dolar Americano") {
            divisa = 2;
        } else if (seleccionDivisaMC == "Onza Libertad de Plata") {
            divisa = 3;
        } else if (seleccionDivisaMC == "Dolar Canadiense") {
            divisa = 5;
        } else if (seleccionDivisaMC == "Euros") {
            divisa = 7;
        }



        var valor2 = $('#selector option:selected').text();
        if (valor2 == "TODOS LOS EMPLEADOS") {
            usuarioLetra = valor2;
            valor2 = getUrlVars()["usuario"];
            usuario = valor2;


            servEntradaSalida(usuario, perfilEnSal2, divisa);
        } else {
            var val;
            usuario2 = valor2.split(' ');
            val = usuario2[0];
            usuarioLetra = val;
            $.ajax({
                url: getUrlsEs(urlPerfilES),
                contentType: "application/json; charset=UTF-8",
                type: "POST",
                data: JSON.stringify({
                    //"NoEmpleado": "" + getUrlVars()["usuario"],
                    "NoEmpleado": val,
                }),
                dataType: 'json',
                crossDomain: true,
                success: function (data) {
                    perfilEnSal = data.Respuesta;
                    mostrarLoading(false);
                },
                error: function () {

                    $("#bMensaje").text("Ocurrió un error en el consumo del servicio.");
                    mostrarLoading(false);
                }
            });

            limpia();
            servEntradaSalida(val, perfilEnSal2, divisa);

        }
    });

    mostrarLoading(false);
}

function extreDivisa() {
    var seleccionDivisa2 = $('#selector1 option:selected').text();
    seleccionDivisa = seleccionDivisa2;
}
function limpia() {
    $('#tabla1').html("");
    $('#tabla2').html("");
    $('#ingresos').html("");
    $('#egresos').html("");

}

function getUrlsEs(serv) {
    var url = "";
    if (window.location.hostname == "localhost") {
        url = "http://10.54.28.226:9014/Caja/Servicios/" + serv;
    } else {
        url = "http://" + window.location.hostname + ":9014/Caja/Servicios/" + serv;
    }
    return url;
}
function servEntradaSalida(empleado, perfilEnSal, divisa) {
    mostrarLoading(true);
    perfilEnSal2 = perfilEnSal;
    var us;
    var us2;
    var fechaActual = fechaI();
    if (empleado == "TODOS LOS EMPLEADOS" || empleado === getUrlVars()["usuario"]) {
        us == getUrlVars()["usuario"];
        $.ajax({
            url: getUrlsEs(urlEyS), //opcion a cambios en la url 
            contentType: "application/json; charset=UTF-8",
            type: "POST",
            data: JSON.stringify(
                {
                    "Operacion": 5,
                    "Opcion": 9,
                    "Perfil": "" + perfilEnSal,
                    "IdTipoDivisa": divisa,
                    "Inicio": "" + fechaActual,
                    "Empleado": "" + us,
                    "Folio": 0,
                    "Modulo": 0,
                    "Origen": null

                }),
            dataType: 'json',
            crossDomain: true,
            success: function (data) {
                if (data.Respuesta.length != 0) {
                    obtieneEntradaSalida(data);
                    canImpES = true;
                } else {
                    limpia();
                    canImpES = false;
                }
                mostrarLoading(false);
            },
            error: function () {
                // alert(data);
                canImpES = false;
                $("#rev").text("Error en el consumo del servicio ");
                mostrarLoading(false);
            }
        });
    } else {
        us = getUrlVars()["usuario"];
        us2 = empleado;

        $.ajax({
            url: getUrlsEs(urlEyS), //opcion a cambios en la url 
            contentType: "application/json; charset=UTF-8",
            type: "POST",
            data: JSON.stringify(
                {
                    "Operacion": 5,
                    "Opcion": 9,
                    "Perfil": "" + perfilEnSal,
                    "IdTipoDivisa": divisa,
                    "Inicio": "" + fechaActual,
                    "Empleado": "" + us,
                    "Folio": 0,
                    "Modulo": 0,
                    "Origen": null,
                    "NoEmpleado": us2
                }),
            dataType: 'json',
            crossDomain: true,
            success: function (data) {
                if (data.Respuesta.length != 0) {
                    obtieneEntradaSalida(data);
                    canImpES = true;
                } else {
                    limpia();
                    canImpES = false;
                    //$('#entra').html("no hay movimientos");
                }
                mostrarLoading(false);
            },
            error: function () {
                // alert(data);
                canImpES = false;
                $("#rev").text("Error en el consumo del servicio ");
                mostrarLoading(false);
            }
        });
    }
}
function servEmpleados(usuario, perfil, divisass) {

    mostrarLoading(true);
    var fechaActual = fechaI();   

    $.ajax({
        url: getUrlsEs(ServEmpl),
        contentType: "application/json; charset=UTF-8",
        type: "POST",
        data: JSON.stringify(
            {
                "Operacion": 5,
                "Opcion": 9,
                "Perfil": "" + perfil,
                "IdTipoDivisa": divisass,
                "Inicio": "" + fechaActual,
                "Empleado": "" + usuario,
                "Folio": 0,
                "Modulo": 0,
                "Origen": null
            }),
        dataType: 'json',
        crossDomain: true,
        success: function (data) {
            obtineneEmpleados(data);
            mostrarLoading(false);
        },
        error: function () {
            $("#rev").text("Error en el consumo del servicio ");
            mostrarLoading(false);
        }
    });


}
function obtineneEmpleados(jsonResp) {
    var selector = '';//'<select class="normal_select " id="empleados" name="empleado>"';

    selector += '<option value=0>TODOS LOS EMPLEADOS</option>';
    $.each(jsonResp.Empleados, function (i, p) {
        selector += '<option value="' + i + 1 + '">' + p.Nombre.toString().trim() + '</option>';
    });
    $('#selector').html(selector);
}
function obtieneEntradaSalida(jsonResp) {
    var suma = 0;
    if (jsonResp.NoError == 0) {
        obtineEntradasSalidas(jsonResp);
    }
    else if (jsonResp.NoError == 1) {
        document.getElementById("rev").innerHTML = jsonResp.Descripcion;
    } else if (jsonResp.Descripcion == 3) {
        document.getElementById("rev").innerHTML = jsonResp.Descripcion;
    } else {
        document.getElementById("rev").innerHTML = "Intente mas tarde.";
    }
}
function obtineEntradasSalidas(jsonResp) {
    mostrarLoading(true);
    if (jsonResp.Respuesta.length == 0) {
        limpia();
    }
    else {
        var sumaingreso = 0, sumaegreso = 0;
        var queryTO = Enumerable.From(jsonResp.Respuesta) //para la parte que lleva datos de los empleados
        .Select(function (x) {
            return {
                'FiTipoOp': x['FiTipoOp'],
                'FcTopDesc': x['FcTopDesc'],
                'FiIngEgr': x['FiIngEgr'],
                'CuentaOp': x['CuentaOp'],
                'MontoOp': x['MontoOp']
            };
        })
        .ToArray();

        var tablaTipoOperacion = '<table class="tblGeneral2Movimientos" id="tabla1">' +
                             '<tbody>' +
                                     '<tr class="total">' +
                                     '<th>TOP</th>' +
                                    '<th>Descripción</th>' +
                                     '<th>Tot.op.</th>' +
                                     '<th style="text-align:right;">Importe</th>' +
                                      '</tr>';
        var tblTipoOp = '<table class="tblGeneral2Movimientos" id="tabla2">' +
                        '<tbody>' +
                            '<tr class="total">' +
                            '<th>TOP</th>' +
                            '<th>Descripción</th>' +
                            '<th>Tot.op.</th>' +
                            '<th align="right">Importe</th>' +
                            '</tr>';
        var comparacion;

        // selector += '</select>';
        $.each(queryTO, function (i, p) {
            comparacion = queryTO[i].FiIngEgr.toString().trim();
            if (comparacion === "1") {
                tablaTipoOperacion += '<tr onclick="DetalleES(' + queryTO[i].FiTipoOp + ',\'' + queryTO[i].FcTopDesc + '\')">' +
                                   '<td>' + queryTO[i].FiTipoOp.toString().trim() + '</td>' +
                                      '<td><div>' + queryTO[i].FcTopDesc.toString().trim() + '</div></td>' +
                                      '<td>' + queryTO[i].CuentaOp.toString().trim() + '</td>' +
                                      '<td class="importe tRight">' + formatMoney(queryTO[i].MontoOp) + '</td></div>' +
                                    '</tr>';
                sumaingreso += parseFloat(queryTO[i].MontoOp.toString().trim());
            }
            else if (comparacion == "2") {
                tblTipoOp += '<tr onclick="DetalleES(' + queryTO[i].FiTipoOp + ',\'' + queryTO[i].FcTopDesc + '\')">' +
                                '<td>' + queryTO[i].FiTipoOp.toString().trim() + '</td>' +
                                '<td><div>' + queryTO[i].FcTopDesc.toString().trim() + '</div></td>' +
                                '<td>' + queryTO[i].CuentaOp.toString().trim() + '</td>' +
                                '<td class="importe tRight">' + formatMoney(queryTO[i].MontoOp) + '</td>' +
                                '</tr>';
                sumaegreso += parseFloat(queryTO[i].MontoOp.toString().trim());

            }

        });
        if (sumaingreso === 0) {
            tablaTipoOperacion += '<tr>' +
                                   '<td></td>' +
                                      '<td><div></div></td>' +
                                      '<td> NO HAY OPERACIONES</td>' +
                                      '<td></td></div>' +
                                    '</tr>';
        }
        tablaTipoOperacion += '</tbody>' +
                                      '</table>';

        $('#entra').html(tablaTipoOperacion);
        $('#entra2').html(tblTipoOp);
        $('#ingresos').html(formatMoney(sumaingreso));
        $('#egresos').html(formatMoney(sumaegreso));
    }

    mostrarLoading(false);
}

function DetalleES(top, detall) {
    $('#mensajeTitulo2').html('Mensaje del sistema:');
    $('#mensajeTexto2').html("   Detalle TOP :  " + top + "  -  " + detall);
    $j('#modalDetalle').modal();
    EstradasSalidasDetalles(top);
}
function EstradasSalidasDetalles(top) {

    mostrarLoading(true);
    var fechaActual = fechaI();

    var num = top;
    var empl = getUrlVars()["usuario"];
    var urll = getUrls(mtosCajaDetalleES);
    var divisass;
    var seleccionDivisa2 = $('#selector1 option:selected').text();    
    seleccionDivisaMC = seleccionDivisa2;
    if (seleccionDivisaMC == "Moneda Nacional") {
        divisass = 1;
    } else if (seleccionDivisaMC == "Dolar Americano") {
        divisass = 2;
    } else if (seleccionDivisaMC == "Onza Libertad de Plata") {
        divisass = 3;
    } else if (seleccionDivisaMC == "Dolar Canadiense") {
        divisass = 5;
    } else if (seleccionDivisaMC == "Euros") {
        divisass = 7;
    }
    var valor2 = $('#selector option:selected').text();
    if (valor2 == "TODOS LOS EMPLEADOS") {
        usuario = getUrlVars()["usuario"];
    } else {
        usuario2 = valor2.split(' ');
        usuario = usuario2[0];
    }
    $.ajax({

        url: urll,
        contentType: "application/json; charset=UTF-8",
        type: "POST",
        data: JSON.stringify(
            {

                "Opcion": 1,
                "Top": num,
                "Perfil": "" + perfilEnSal2,
                "IdTipoDivisa": divisass,
                "Inicio": "" + fechaActual,
                "Empleado": "" + usuario,
                "EmpCons": "",
                "Tipo": 1

            }),
        dataType: 'json',
        crossDomain: true,
        success: function (data) {
            muestraDetallesES(data);
            mostrarLoading(false);
        },
        error: function () {
            $("#rev").text("Error en el consumo del servicio ");
            mostrarLoading(false);
        }
    });
}
function muestraDetallesES(respuestajson) {
    if (respuestajson.NoError == 0) {
        obtenerDetallesES(respuestajson);
    }
    else if (respuestajson.NoError == 1) {
        document.getElementById("ingresosBanco").innerHTML = respuestajson.Descripcion;
    } else if (respuestajson.Respuesta == 3) {
        document.getElementById("ingresosBanco").innerHTML = respuestajson.Descripcion;
    } else {
        document.getElementById("ingresosBanco").innerHTML = "Intente mas tarde.";
    }
}
function obtenerDetallesES(respjson) {
    mostrarLoading(true);
    var datos = respjson.Respuesta;
    var tablaDetalle = '';
    var contMtos = 0;
    var suma = 0;
    tablaDetalle += '<table class="tblGeneral3 tCenter" style="width:90%;"><tbody><tr><th>No. Operacion</th>' +
                    '<th>Num. Cajero</th>' +
                    '<th>Puesto Base</th>' +
                    '<th>Puesto Rol</th>' +
                    '<th>Hora Op.</th>' +
                    '<th>referencia</th>' +
                    '<th class="tRight">Importe</th></tr>';

    $.each(datos, function (i, p) {


        tablaDetalle += '<tr class="gris1">' +
                                      '<td>' + p.FiNoTransac + '</td>' +
                                      '<td>' + p.FcNoCajero + '</td>' +
                                      '<td> ' + p.FiPuestoId + '</td>' +//Puesto Base
                                      '<td>' + p.FiPuestoRol + '</td>' + //Puesto Rol
                                      '<td>' + p.FdMovFecHr + '</td>' +//Hora Op 
                                      '<td>' + p.FcRefMov + '</td>' + //referencia
                                      '<td class="tRight">' + formatMoney(p.FnImpMov) + '</td>' +//importe                                      
                                     '</tr>';
        suma += parseFloat(p.FnImpMov);
        contMtos++;

    });
    tablaDetalle += '</tbody></table>';
    $('#detalleSumas').html("Total transacciones:" + contMtos + " | MontoNeto: " + formatMoney(suma));

    $('#detalleMC').html(tablaDetalle);
    mostrarLoading(false);
}
function imprimirES(empleado) {
    mostrarLoading(true);
    if (!canImpES) {
        alert('No existe información para imprimir');
    } else {
        var fecha = fechaI();
        var seleccionDivisa2 = $('#selector1 option:selected').text();

        seleccionDivisa = seleccionDivisa2;
        var aux;
        var valor2 = $('#selector option:selected').text();

        if (valor2 == "TODOS LOS EMPLEADOS") {
            aux = getUrlVars()["usuario"];
            usuarioLetra = aux + " " + valor2;
            ServicePerfilesES(aux);

        } else {
            usuario2 = valor2.split(' ');
            aux = usuario2[0];
            usuarioLetra = valor2;
            ServicePerfilesES(valor2);

        }

        var empl = aux;
        var divisass;

        seleccionDivisaMC = seleccionDivisa2;

        if (seleccionDivisaMC == "Moneda Nacional") {
            divisass = 1;
        } else if (seleccionDivisaMC == "Dolar Americano") {
            divisass = 2;
        } else if (seleccionDivisaMC == "Onza Libertad de Plata") {
            divisass = 3;
        } else if (seleccionDivisaMC == "Dolar Canadiense") {
            divisass = 5;
        } else if (seleccionDivisaMC == "Euros") {
            divisass = 7;
        }
        $.ajax({
            url: getUrlsEs(servImpresion),
            contentType: "application/json; charset=UTF-8",
            type: "POST",
            data: JSON.stringify(
                {
                    "Operacion": 5,
                    "Opcion": 9,
                    "Perfil": "" + perfilEnSal2,
                    "IdTipoDivisa": divisass,
                    "Inicio": "" + fecha,
                    "Empleado": "" + empl,
                    "Folio": 0,
                    "Modulo": 0,
                    "Origen": null,
                    "ImprimeDetalle": false,
                    "Imprime": true,
                    "NoEmpleado": "" + usuarioLetra,
                    "TipoDivisa": "" + seleccionDivisa
                }),
            dataType: 'json',
            crossDomain: true,
            success: function (data) {
                imprimirCarta(data.RutaPDF);
                mostrarLoading(false);
            },
            error: function () {
                $("#rev").text("Error en el consumo del servicio ");
                mostrarLoading(false);
            }
        });
    }
}
function imprimirESDetalle() {
    mostrarLoading(true);
    if (!canImpES) {
        alert('No existe información para imprimir');
    } else {
        var fecha = fechaI();
        var seleccionDivisa2 = $('#selector1 option:selected').text();
        seleccionDivisa = seleccionDivisa2;
        var aux;
        var valor2 = $('#selector option:selected').text();
        if (valor2 == "TODOS LOS EMPLEADOS") {
            aux = getUrlVars()["usuario"];
            usuarioLetra = aux + " " + valor2;

            ServicePerfilesES(aux);

        } else {
            usuario2 = valor2.split(' ');
            aux = usuario2[0];
            usuarioLetra = valor2;
            ServicePerfilesES(aux);

        }

        var empl = aux;
        var divisass;
        var seleccionDivisa2 = $('#selector1 option:selected').text();
        seleccionDivisaMC = seleccionDivisa2;
        if (seleccionDivisaMC == "Moneda Nacional") {
            divisass = 1;
        } else if (seleccionDivisaMC == "Dolar Americano") {
            divisass = 2;
        } else if (seleccionDivisaMC == "Onza Libertad de Plata") {
            divisass = 3;
        } else if (seleccionDivisaMC == "Dolar Canadiense") {
            divisass = 5;
        } else if (seleccionDivisaMC == "Euros") {
            divisass = 7;
        }
        $.ajax({
            url: getUrls(servImpresion),
            contentType: "application/json; charset=UTF-8",
            type: "POST",
            data: JSON.stringify(
                {
                    "Operacion": 5,
                    "Opcion": 9,
                    "Perfil": "" + perfilEnSal2,
                    "IdTipoDivisa": divisass,
                    "Inicio": "" + fecha,
                    "Empleado": "" + empl,
                    "Folio": 0,
                    "Modulo": 0,
                    "Origen": null,
                    "Imprime": false,
                    "ImprimeDetalle": true,
                    "NoEmpleado": "" + usuarioLetra,
                    "TipoDivisa": "" + seleccionDivisa
                }),
            dataType: 'json',
            crossDomain: true,
            success: function (data) {
                imprimirCartaDetalle(data.RutaPDF);
                mostrarLoading(false);
            },
            error: function () {
                $("#rev").text("Error en el consumo del servicio ");
                mostrarLoading(false);
            }
        });
    }
}
function ServicePerfilesES(empleado) {
    mostrarLoading(true);
    var host1 = getUrlBase();
    $.ajax({
        url: getUrlsEs(urlPerfilES),
        contentType: "application/json; charset=UTF-8",
        type: "POST",
        data: JSON.stringify({
            //"NoEmpleado": "" + getUrlVars()["usuario"],
            "NoEmpleado": empleado,
        }),
        dataType: 'json',
        crossDomain: true,
        success: function (data) {
            perfilEnSal2 = data.Respuesta;
            mostrarLoading(false);
        },
        error: function () {
            $("#bMensaje").text("Ocurrió un error en el consumo del servicio.");
            mostrarLoading(false);
        }
    });
}
