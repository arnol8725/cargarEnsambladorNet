﻿var pantallaCargada = false;
var urlConsOpera="LecturaCaja/LecturaDeCaja.svc/wsLecturaConsultaOperaciones";
var SerImpr = "LecturaCaja/LecturaDeCaja.svc/wsLecturaConsultaOperaciones";
var SerImprTP = "LecturaCaja/LecturaDeCaja.svc/wsLecturaGeneraPDFSaldosTP";
var PerfilOpera;
var seleccionDivOpera;
var urlperfilOperaciones = "LecturaCaja/lecturaDeCaja.svc/wsLecturaPerfiles";
var saldosGlobales = "LecturaCaja/lecturaDeCaja.svc/wsLecturaConsultaSaldosTP";
var urlUtileriaCo = "Servicios/wsUtileriaCaja/wsUtileria.svc/wsTiendaEmpleado";


var habilitaImprimir = false;
function getUrlsOpera(serv) {
    var url = "";
    if (window.location.hostname == "localhost") {
        url = "http://10.54.28.226:9014/Caja/Servicios/" + serv;
    } else {
        url = "http://" + window.location.hostname + ":9014/Caja/Servicios/" + serv;
    }
    return url;
}
function extreDivisaOperaciones() {
    var seleccionDivisa2 = $('#selector1 option:selected').text();
    seleccionDivOpera = seleccionDivisa2;
}
function ServicePerfilesOperaciones() {
    mostrarLoading(true);
    var host1 = getUrlBase();
    $.ajax({
        url: getUrlsOpera(urlperfilOperaciones),
        contentType: "application/json; charset=UTF-8",
        type: "POST",
        data: JSON.stringify({
            "NoEmpleado": "" + getUrlVars()["usuario"],
        }),
        dataType: 'json',
        crossDomain: true,
        success: function (data) {
            PerfilOpera = data.Respuesta;
            mostrarLoading(false);
            return data.Respuesta;
        },
        error: function () {
            mostrarLoading(false);
            $("#bMensaje").text("Ocurrió un error en el consumo del servicio.");
        }
    });
}

function serviceNombreEmpleado(noEmp) {   
    mostrarLoading(true);
    var nombreResp;
    var url;
    if (window.location.hostname == "localhost") {
        url = "http://10.54.28.226:9014/Caja/" + urlUtileriaCo;
    } else {
        url = "http://" + window.location.hostname + ":9014/Caja/" + urlUtileriaCo;
    }
   //var url = "http://" + window.location.hostname + ":9014/Caja/"+ urlUtileriaCo;

    let nombreEmp = "";
    $.ajax({
        url: "" + url,
        contentType: "application/json; charset=UTF-8",
        type: "POST",
        async: false,
        data: JSON.stringify({
            "Empleado": "" + noEmp
        }),
        dataType: 'json',
        crossDomain: true,
        success: function (data) {
            nombreResp = data.EmpNombre == null ? "" : data.EmpNombre;
            $("#bMensaje3").val(nombreResp);
            mostrarLoading(false);
        },
        error: function () {
            mostrarLoading(false);
        }
    });
    return nombreResp;
}


function initOp() {
    if (perfil !== 'D') {
        $('#btnSearchOp').hide();
        $("#bMensaje2").prop('disabled', true);
        $("#bMensaje3").hide();
    } else {
        $('#btnSearchOp').show();
        $("#bMensaje2").prop('disabled', false);
        $("#bMensaje3").show();
    }
}

function eventSearchOp(){ 

    if (document.getElementById('ventanaNuevaIniciales')) {
        recarga(getUrlVars()["usuario"], perfil, divisass);
    }
    else if (document.getElementById('ventanaNuevaActuales')) {
        recargaActuales(getUrlVars()["usuario"], perfil, divisass);
    }
    else if (document.getElementById('ventanaNuevaTopes')) {
        cambios(getUrlVars()["usuario"], perfil, divisass);
    }
    else if (document.getElementById('ventanaNuevaSinFlujo')) {
        serviceConsMovtosSinFlujo(usuario, perfil, divisass);
    }
    else if (document.getElementById('ventanaNuevaConsOpera')) {
        var usSelected = usuario;
        if (usSelected !== $('#bMensaje2').val()) {
            usSelected = $('#bMensaje2').val();
        }
        consOpera(usSelected, nombre, perfil, divisass);
    }
    else if (document.getElementById('NuevaCentroCanje')) {
        servMovtosCentroCanje(usuario);
    }
    else if (document.getElementById('ventanaNuevaEntSalidas')) {
        servEntradaSalida(usuario, perfil, divisass);
        servEmpleados(usuario, perfil, divisass);
    }
    else if (document.getElementById('ventanaNuevaMOvtosCaja')) {
        movimientoCaja(usuario, perfil, divisass);
    }
}


function consOpera(usuario, nombre, PerfilOpera,divisa) {
    mostrarLoading(true);
    var fechaActual = fechaI();
    
    ServicePerfilesOperaciones();
    $.ajax({
        url: getUrlsOpera(urlConsOpera),
        contentType: "application/json; charset=UTF-8",
        type: "POST",
        data: JSON.stringify(
           {
               "Operacion": 4,
               "Opcion": 7,
               "Perfil": "" + PerfilOpera,
               "IdTipoDivisa": divisa,
               "Inicio": ""+fechaActual,
               "Empleado": "" + usuario,
               "Origen": ""
           }),
        dataType: 'json',
        crossDomain: true,
        success: function (data) {
            if (data.Respuesta.length!=0) {

                $('#bMensaje2').val(usuario);
                var nEmp = $("#bMensaje2").val();
                if (nEmp !== "" && nEmp !== undefined) {
                    $("#bMensaje3").val(serviceNombreEmpleado(nEmp));
                } else {
                    $("#bMensaje3").val(serviceNombreEmpleado(getUrlVars()["usuario"]));
                }
                servicioConsultaOperaciones(data);
                habilitaImprimir = false;
                // $('#ImpConsopera').prop('disabled', false);
                $('#buscaSalGlob').attr("disabled", false);
                $('#BuscaGlobal').attr("disabled", false);
            }
            else {
                $('#bMensaje2').val(usuario);
                var nEmp = $("#bMensaje2").val();
                if (nEmp !== "" && nEmp !== undefined) {
                    $("#bMensaje3").val(serviceNombreEmpleado(nEmp));
                } else {
                    $("#bMensaje3").val(serviceNombreEmpleado(getUrlVars()["usuario"]));                    
                }
                $("#bMensaje4").val('NO HAY OPERACIONES');
                $("#bMensaje4").setpr
                //$('#ImpConsopera').prop('disabled', true);
                habilitaImprimir = true;
                alert("No hay operaciones");
                $('#operaciones').html("");
                $('#buscaSalGlob').attr("disabled", true);
                $('#BuscaGlobal').attr("disabled", true);
            }
            mostrarLoading(false);
        },
        error: function () {
            // alert(data);
            $("#rev").text("Error en el consumo del servicio ");
            mostrarLoading(false);
        }
    });   
}
function servicioConsultaOperaciones(jsonResptopes) {
    var suma = 0;
    if (jsonResptopes.NoError == 0) {
        respConsulta(jsonResptopes.Respuesta);
    }
    else if (jsonResptopes.NoError == 1) {
        document.getElementById("operaciones").innerHTML = jsonResptopes.Descripcion;
    } else if (jsonResptopes.Respuesta == 3) {
        document.getElementById("operaciones").innerHTML = jsonResptopes.Descripcion;
    } else {
        document.getElementById("operaciones").innerHTML = "Intente mas tarde.";
    }
}

function respConsulta(jsonConsuOpera) {
    mostrarLoading(true);
        if (jsonConsuOpera===null || jsonConsuOpera===undefined || jsonConsuOpera.length === 0) {
            alert("no hay movimientos");
    }
    else {
        var tablaopera = '';
        var compara;
        $('#bMensaje4').val('SALDO INICINAL:    $'+jsonConsuOpera[0].SaldoInicial);

        var queryTo = Enumerable.From(jsonConsuOpera)
        .Select(function (x) {
            return {
                'FiNoTransac': x['FiNoTransac'],
                'FiTIPOOP': x['FiTIPOOP'],
                'FcTopDesc': x['FcTopDesc'],
                'FnImpMov': x['FnImpMov'],
                'FiIngEgr': x['FiIngEgr'],
                'SaldoActual': x['SaldoActual'],
                'Hora': x['Hora']
            };
        })
        .ToArray();
        tablaopera += '<table class="tblGeneral2" id="operaciones">' +
            '<tbody>' +
            '        <tr>' +
             '           <th class="tLeft">No. de operación</th>' +
              '          <th>TOP</th>' +
               '         <th>Descripción</th>' +
                '        <th>Ingresos</th>' +
                 '       <th>Egresos</th>' +
                  '      <th>Saldo</th>' +
                   '     <th>Hora</th>' +
                   ' </tr>';
        var primera = true;
        var sum ;
        if (queryTo[0].SaldoActual==null || queryTo[0].SaldoActual==undefined || queryTo[0].SaldoActual=="") {
            sum=0;
        } else {
            sum = parseFloat(queryTo[0].SaldoActual);
        }
        
        var cont = 0;
        $.each(queryTo, function (i, p) {
            if (primera) {
                compara = queryTo[i].FiIngEgr;
                if (compara == 1) { // ingresos
                    tablaopera += '<tr>' +
                           '<td>' + queryTo[i].FiNoTransac.toString().trim() + '</td>' +
                           '<td>' + queryTo[i].FiTIPOOP.toString().trim() + '</td>' +
                           '<td>' + queryTo[i].FcTopDesc.toString().trim() + '</td>' +
                           '<td class="tRight">' + formatMoney(queryTo[i].FnImpMov) + '</td>' +
                           '<td>&nbsp;</td>' +
                           '<td class="tRight">' + formatMoney(sum) + '</td>' +
                           '<td class="tRight">' + queryTo[i].Hora.toString().trim() + '</td>' +
                           '</tr>';
                    sum -= parseFloat(queryTo[i].FnImpMov);
                }
                else if (compara == 2) { //egresos
                    tablaopera += '<tr>' +
                          '<td>' + queryTo[i].FiNoTransac.toString().trim() + '</td>' +
                          '<td>' + queryTo[i].FiTIPOOP.toString().trim() + '</td>' +
                          '<td>' + queryTo[i].FcTopDesc.toString().trim() + '</td>' +
                          '<td>&nbsp;</td>' +
                          '<td class="tRight">' + formatMoney(queryTo[i].FnImpMov) + '</td>' +
                          '<td class="tRight">' + formatMoney(sum) + '</td>' +
                          '<td class="tRight">' + queryTo[i].Hora.toString().trim() + '</td>' +
                          '</tr>';
                    sum += parseFloat( queryTo[i].FnImpMov);
                }
                primera = false;
                
            }
            else {
                compara = parseInt(queryTo[i].FiIngEgr);
                
                if (compara === 1) { // ingresos
                    

                    tablaopera += '<tr>' +
                           '<td>' + queryTo[i].FiNoTransac.toString().trim() + '</td>' +
                           '<td>' + queryTo[i].FiTIPOOP.toString().trim() + '</td>' +
                           '<td>' + queryTo[i].FcTopDesc.toString().trim() + '</td>' +
                           '<td class="tRight">' + formatMoney(queryTo[i].FnImpMov) + '</td>' +
                           '<td>&nbsp;</td>' +
                           '<td class="tRight">' + formatMoney(sum) + '</td>' +
                           '<td class="tRight">' + queryTo[i].Hora.toString().trim() + '</td>' +
                           '</tr>';
                    sum -= parseFloat(queryTo[i].FnImpMov);
                    
                }
                else if (compara === 2) { //egresos
                    tablaopera += '<tr>' +
                          '<td>' + queryTo[i].FiNoTransac.toString().trim() + '</td>' +
                          '<td>' + queryTo[i].FiTIPOOP.toString().trim() + '</td>' +
                          '<td>' + queryTo[i].FcTopDesc.toString().trim() + '</td>' +
                          '<td>&nbsp;</td>' +
                          '<td class="tRight">' + formatMoney(queryTo[i].FnImpMov) + '</td>' +
                          '<td class="tRight">' + formatMoney(sum) + '</td>' +
                          '<td class="tRight">' + queryTo[i].Hora.toString().trim() + '</td>' +
                          '</tr>';
                    sum += parseFloat(queryTo[i].FnImpMov);
                    
                }
                cont++;
            }
            
        });

        tablaopera += '</tbody></table>';
        $('#operaciones').html(tablaopera);
        

        }
        mostrarLoading(false);
}

function imprimirOperaciones(empleado) {
        mostrarLoading(true);
        var fecha = fechaI();
        var empl = getUrlVars()["usuario"];
        var urlConsOp = getUrlsOpera(SerImpr);
        extreDivisaOperaciones();
        ServicePerfilesOperaciones();
        var divisass;
        var seleccionDivisa2 = $('#selector1 option:selected').text();

        seleccionDivisaMC = seleccionDivisa2;
        if (seleccionDivisaMC == "Moneda Nacional") {
            divisass = 1;
        } else if (seleccionDivisaMC == "Dolar Americano") {
            divisass = 2;
        } else if (seleccionDivisaMC == "Onza Libertad de Plata") {
            divisass = 3;
        } else if (seleccionDivisaMC == "Dolar Canadiense") {
            divisass = 5;
        } else if (seleccionDivisaMC == "Euros") {
            divisass = 7;
        }
        $.ajax({

            url: urlConsOp,
            contentType: "application/json; charset=UTF-8",
            type: "POST",
            data: JSON.stringify(
                {
                    "Operacion": 4,
                    "Opcion": 7,
                    "Perfil": "" + PerfilOpera,
                    "IdTipoDivisa": divisass,
                    "Inicio": "" + fecha,
                    "Empleado": "" + empl,
                    "Imprime": true,
                    "ImprimeDetalle": false,
                    "Origen": "",
                    "NoEmpleado": "" + empl,
                    "TipoDivisa": "" + seleccionDivOpera
                }),
            dataType: 'json',
            crossDomain: true,
            success: function (data) {
                imprimirCarta(data.RutaPDF);
                mostrarLoading(false);
            },
            error: function () {
                // alert(data);
                $("#rev").text("Error en el consumo del servicio ");
                mostrarLoading(false);
            }
        });
}
function imprimirOperacionesTP(empleado) {
    mostrarLoading(true);
    var fecha = fechaI();
    var empl = getUrlVars()["usuario"];
    var urlConsOp = getUrlsOpera(SerImprTP);
    extreDivisaOperaciones();
    ServicePerfilesOperaciones();
    var divisass;
    var seleccionDivisa2 = $('#selector1 option:selected').text();

    seleccionDivisaMC = seleccionDivisa2;
    if (seleccionDivisaMC == "Moneda Nacional") {
        divisass = 1;
    } else if (seleccionDivisaMC == "Dolar Americano") {
        divisass = 2;
    } else if (seleccionDivisaMC == "Onza Libertad de Plata") {
        divisass = 3;
    } else if (seleccionDivisaMC == "Dolar Canadiense") {
        divisass = 5;
    } else if (seleccionDivisaMC == "Euros") {
        divisass = 7;
    }
    $.ajax({

        url: urlConsOp,
        contentType: "application/json; charset=UTF-8",
        type: "POST",
        data: JSON.stringify(
            {
                "Operacion": 4,
                "Opcion": 7,
                "Perfil": "" + PerfilOpera,
                "IdTipoDivisa": divisass,
                "Inicio": "" + fecha,
                "Empleado": "" + empl,
                "Imprime": true,
                "ImprimeDetalle": false,
                "Origen": "",
                "NoEmpleado": "" + empl,
                "TipoDivisa": "" + seleccionDivOpera
            }),
        dataType: 'json',
        crossDomain: true,
        success: function (data) {
            imprimirCarta(data.RutaPDF);
            mostrarLoading(false);
        },
        error: function () {
            // alert(data);
            $("#rev").text("Error en el consumo del servicio ");
            mostrarLoading(false);
        }
    });
}

function saldoGlobal() {
    $j('#modalDetalle').modal();
    DetallesSaldosGlobales();
}
function DetallesSaldosGlobales() {

    mostrarLoading(true);
    var fechaActual = fechaI();
    var anio = fechaActual.substring(0, 4);
    var mes = fechaActual.substring(4, 6);
    var dia = fechaActual.substring(6, 8);
    //var num = top;
    var empl = getUrlVars()["usuario"];
    var urll = getUrls(saldosGlobales);  
    $.ajax({

        url: urll,
        contentType: "application/json; charset=UTF-8",
        type: "POST",
        data: JSON.stringify(
            {

                "Anio": ""+anio,
                "Dia": ""+dia,
                "Mes": ""+mes,
                "NoEmpleado": ""+empl              

            }),
        dataType: 'json',
        crossDomain: true,
        success: function (data) {
            detalleSalGlob(data);
            mostrarLoading(false);
        },
        error: function () {
            $("#rev").text("Error en el consumo del servicio ");
            mostrarLoading(false);
        }
    });
}
function detalleSalGlob(respuestajson) {
    if (respuestajson.NoError == 0) {
        omuestraSaldoGlobal(respuestajson);
    }
    else if (respuestajson.NoError == 1) {
        document.getElementById("operaciones").innerHTML = respuestajson.Descripcion;
    } else if (respuestajson.Respuesta == 3) {
        document.getElementById("operaciones").innerHTML = respuestajson.Descripcion;
    } else {
        document.getElementById("operaciones").innerHTML = "Intente mas tarde.";
    }
}
function omuestraSaldoGlobal(respjson) {
    mostrarLoading(true);
    let mes = ["Ene", "Feb", "Mar", "Abr", "May", "Jun", "Jul", "Ago", "Sep", "Oct", "Nov", "Dic"];
    var datos = respjson.TiposPago;
    var tablaDetalle = '';
    var contMtos = 0;
    var suma = 0;
    tablaDetalle += '<table class="tblGeneral3 tCenter" style="width:90%;"><tbody><tr>' +
                    '<th>No.</th>' +
                    '<th>Concepto</th>' +
                    '<th>Fecha</th>' +
                    '<th>Saldo</th></tr>';

    $.each(datos, function (i, p) {


        tablaDetalle += '<tr class="gris1">' +
                                      '<td>' + (i+1) + '</td>' +//Numero Consecutivo
                                      '<td>' + p.FcTpagDesc + '</td>';//Descripcion
        if (mes[p.FiMes -1]<0) {
            tablaDetalle += '<td> ' + p.FiDia + '/' + mes[12] + '/' + p.FiAnio + '</td>'+ //Fecha
                '<td class="tRight">' + formatMoney(p.FnSaldoCjr) + '</td>' +//Saldo
                '</tr>';
        }
        else
            {
            tablaDetalle +='<td> ' + p.FiDia+'/'+mes[p.FiMes -1]+'/'+p.FiAnio + '</td>' +//Fecha
                           '<td class="tRight">' + formatMoney(p.FnSaldoCjr) + '</td>' +//Saldo
                           '</tr>';
        }
        suma += p.FnSaldoCjr;
    });
    tablaDetalle += '</tbody></table>';
    $('#tablaGlobal').html(tablaDetalle);
    $('#totalSaldo').html("Saldo Total:  " + formatMoney(suma));
    mostrarLoading(false);
}
