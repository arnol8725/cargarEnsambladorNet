﻿var pantallaCargada = false;
var urlServ = "LecturaCaja/LecturaDeCaja.svc/wsLecturaDeCajaSaldos";
var SaldoInicial = "SaldoInicial";
var urlActCaja = "LecturaCaja/LecturaDeCaja.svc/wsLecturaDeCajaSaldosCaja";

var urlPerfilInicial = "LecturaCaja/lecturaDeCaja.svc/wsLecturaPerfiles";

function recarga(usuario, perfil, divisa) {
   
    limpiarIniciales();
    serviceLecturaInicial(usuario, perfil, divisa);
    sActCaja(usuario, perfil, divisa);
     
   
}

function Mensaje(mensaje) {

    $('#mensajeTitulo').html('Mensaje del sistema:');
    $('#mensajeTexto').html(mensaje);
    $j('#modalImpresion').modal();
}
function limpiarIniciales() {
    $('#pruebaBanco').html('');
    $('#pruebaComercio').html('');
    $('#pruebaOtros').html('');
    $('#tablaTotalSaldIni').html('');
    $('#tablaTotalCajasIni').html('');
    $('#TablaSalIniCaja').html('');

}
function getUrlsIniciales(serv) {
    var url = "";
    if (window.location.hostname == "localhost") {
        url = "http://10.54.28.226:9014/Caja/Servicios/" + serv;
    } else {
        url = "http://" + window.location.hostname + ":9014/Caja/Servicios/" + serv;
    }
    return url;
}
function PerfileInicial() {
    var host2 = getUrlsIniciales(urlPerfilInicial);
    $.ajax({
        url: host2,
       
        contentType: "application/json; charset=UTF-8",
        type: "POST",
        data: JSON.stringify({
            "NoEmpleado": "" + getUrlVars()["usuario"],
        }),
        dataType: 'json',
        crossDomain: true,
        success: function (data) {
            //mostrarCarga(false);
            perfilIniciales = data.Respuesta;

            return data.Respuesta;
        },
        error: function () {
            $("#bMensaje").text("Ocurrió un error en el consumo del servicio.");
        }
    });
}
function serviceLecturaInicial(empleado, perfilIniciales, divisass) {

    mostrarLoading(true);
   
    var fechaActual = fechaI();

    $.ajax({
        url: getUrlsIniciales(urlServ),
        contentType: "application/json; charset=UTF-8",
        type: "POST",
        data: JSON.stringify(
            {

                "Operacion": 1,
                "Opcion": 1,
                "Perfil": ""+perfilIniciales,
                "IdTipoDivisa": divisass,
                "Inicio": "" + fechaActual,
                "Empleado": "" + empleado,
                "Origen": "1"
            }),
        dataType: 'json',
        crossDomain: true,
        success: function (data) {
            
            if (data.Respuesta != 0 || data.Respuesta != null) {
                ServicioInicial(data);
            }
            else {
                $('#elimina').html("");

            }
            mostrarLoading(false);
        },
        error: function () {

            $("#tablaTotalSaldIni").text("Error en el consumo del servicio ");
        
            mostrarLoading(false);
        }
    });

}
function ServicioInicial(jsonResp) {
    var suma = 0;
    if (jsonResp.NoError == 0) {
        rep(jsonResp.Respuesta);
    }
    else if (jsonResp.NoError == 1) {
        document.getElementById("tablaTotalSaldIni").innerHTML = jsonResp.Descripcion;
    } else if (jsonResp.Respuesta == 3) {
        document.getElementById("tablaTotalSaldIni").innerHTML = jsonResp.Descripcion;
    } else {
        document.getElementById("tablaTotalSaldIni").innerHTML = "Intente mas tarde.";
    }
}


function rep(jsonResp) {
    if (jsonResp.length == 0) {
        alert("NO HAY INFORMACION");
    } else {
        mostrarLoading(true);
        var tabla = '';
        var suma = 0.00;

        var queryResult = Enumerable.From(jsonResp)
        .Select(function (x) {
            return {
                'A': x['FiIdPuestoBase'] + " - " + x['DescPuestoBase'],
                'B': x['DescribeFuncion'],
                'C': x['FcEmpNo'] + " - " + x['Nombre'],
                'D': x['FiTipoPago'] + " - " + x['FcTpagDesc'],
                'E': x['SaldoTP'],
                'F': x['SaldoIni']
            };
        })
        .ToArray();
        var formatResult = Enumerable.From(queryResult)
           .Let(grouper('A', function (g1) {
               return g1.Let(grouper('B', function (g2) {
                   return g2.Let(grouper('C', function (g3) {
                       return g3.Let(grouper('D', function (g4) {
                           return g4.Select("$.E").ToArray();
                       }));
                   }));
               }));
           }))
        .ToArray();
        //Puestos (1 = Banco; 2 = Comercio)
        var queryPuestos = Enumerable.From(jsonResp)
            .GroupBy(function (x) { return x.TipoPuesto })
            .Select(function (x) {
                return x.Max(function (z) { return z.TipoPuesto });
            })
        .ToArray();
        /**************************************************************************
         *** Seccion Banco
         **************************************************************************/
         //Banco
        var queryPuestosBanco = Enumerable.From(jsonResp)
            .Where("$.TipoPuesto == 1")
            .Select(function (x) {
                return {
                    'A': x['FiIdPuestoBase'] + " - " + x['DescPuestoBase'],
                    'B': x['DescribeFuncion'],
                    'C': x['FcEmpNo'] + " - " + x['Nombre'] + " - " + x['EmpStatus'],
                    'D': x['FiTipoPago'] + " - " + x['FcTpagDesc'],
                    'E': x['SaldoTP']                    
                };
            })
            .ToArray();

        var queryPuestosBancoSuma = Enumerable.From(jsonResp)
        .Where("$.TipoPuesto == 1")
        .Select(function (x) {
            return {
                'C': x['FcEmpNo'] + " - " + x['Nombre'],
                'E': x['SaldoIni']
            };
        })
        .ToArray();

        var puestosBancossM1 = Enumerable.From(queryPuestosBancoSuma).GroupBy("$.C", null,
          function (key, g) {
              return {
                  C: Enumerable.From(g.source).FirstOrDefault().C,
                  E: Enumerable.From(g.source).FirstOrDefault().E
              };
          }).ToArray();

    


        var formatResultPuestosBanco = Enumerable.From(queryPuestosBanco)
            .Let(grouper('A', function (g1) {
                return g1.Let(grouper('B', function (g2) {
                    return g2.Let(grouper('C', function (g3) {
                        return g3.Let(grouper('D', function (g4) {
                            return g4.Select("$.E").ToArray();
                        }));
                    }));
                }));
            }))
            .ToArray();

        //sumas de saldos para el nivel 1
        var subQueryN1PuestosBanco = Enumerable.From(jsonResp).Where("$.TipoPuesto == 1")
            .Select(function (x) {
                return {
                    'A': x['FiIdPuestoBase'] + " - " + x['DescPuestoBase'],
                    'F': x['SaldoIni'],
                    'E': x['FcEmpNo']
                };
            })
            .ToArray();

        var puestosBancosq1 = Enumerable.From(subQueryN1PuestosBanco).GroupBy("$.E", null,
          function (key, g) {
              return {
                  F: Enumerable.From(g.source).FirstOrDefault().F,
                  A: Enumerable.From(g.source).FirstOrDefault().A,
                  E: Enumerable.From(g.source).FirstOrDefault().E
              };
          }).ToArray();

        var sumN1PuestosBanco = Enumerable.From(puestosBancosq1).GroupBy("$.A", null,
            function (key, g) {
                var result = {
                    currency: key,
                    total: g.Sum("$.F")
                }
                return result;
            }).ToArray();

        //sumas de saldos para el nivel 2
        var subQueryN2PuestosBancos = Enumerable.From(jsonResp).Where("$.TipoPuesto == 1")
            .Select(function (x) {
                return {
                    'A': x['FiIdPuestoBase'] + " - " + x['DescribeFuncion'],
                    'F': x['SaldoIni'],
                    'E': x['FcEmpNo']
                };
            })
            .ToArray();
        
        var puestosBancosq2 = Enumerable.From(subQueryN2PuestosBancos).GroupBy("$.E", null,
             function (key,g) {
                 return {
                     F: Enumerable.From(g.source).FirstOrDefault().F,
                     A: Enumerable.From(g.source).FirstOrDefault().A,
                     E: Enumerable.From(g.source).FirstOrDefault().E
                 };
             }).ToArray();

        var sumN2PuestosBanco = Enumerable.From(puestosBancosq2).GroupBy("$.A", null,
            function (key, g) {
                var result = {
                    currency: key,
                    total: g.Sum("$.F")
                }
                return result;
            }).ToArray();

        //NIVEL 3 
        //sumas de saldos para el nivel 3
        var subQueryN3PuestosBancos = Enumerable.From(jsonResp).Where("$.TipoPuesto == 1")
            .Select(function (x) {
                return {
                    'A': x['FiIdPuestoBase'] + " - " + x['Nombre'] + " - " + x['FcEmpNo'],
                    'F': x['SaldoIni']
                };
            })
            .ToArray();

        var sumN3PuestosBancos = Enumerable.From(subQueryN3PuestosBancos).GroupBy("$.A", null,
            function (key, g) {
                var result = {
                    currency: key,
                    total: Enumerable.From(g).FirstOrDefault().F
                }
                return result;
            }).ToArray();
        //FIN NIVEL 3 
      
        /**************************************************************************
         *** Seccion Banco
         **************************************************************************/
        /**************************************************************************
         *** Seccion Comercio
         **************************************************************************/
        //Comercio
        
        var queryPuestosComercio = Enumerable.From(jsonResp)
            .Where("$.TipoPuesto == 2")
            .Select(function (x) {
                return {
                    'A': x['FiIdPuestoBase'] + " - " + x['DescPuestoBase'],
                    'B': x['DescribeFuncion'],
                    'C': x['FcEmpNo'] + " - " + x['Nombre'] + " - " + x['EmpStatus'],
                    'D': x['FiTipoPago'] + " - " + x['FcTpagDesc'],
                    'E': x['SaldoTP']
                };
            })
            .ToArray();

        var queryPuestoComercioSuma = Enumerable.From(jsonResp)
        .Where("$.TipoPuesto == 2")
        .Select(function (x) {
            return {
                'C': x['FcEmpNo'] + " - " + x['Nombre'],
                'E': x['SaldoIni']
            };
        })
        .ToArray();
      
        var puestosComerciosM1 = Enumerable.From(queryPuestoComercioSuma).GroupBy("$.C", null,
         function (key, g) {
             return {
                 C: Enumerable.From(g.source).FirstOrDefault().C,
                 E: Enumerable.From(g.source).FirstOrDefault().E
             };
         }).ToArray();

        var formatResultPuestosComercio = Enumerable.From(queryPuestosComercio)
          .Let(grouper('A', function (g1) {
              return g1.Let(grouper('B', function (g2) {
                  return g2.Let(grouper('C', function (g3) {
                      return g3.Let(grouper('D', function (g4) {
                          return g4.Select("$.E").ToArray();
                      }));
                  }));
              }));
          }))
          .ToArray();

        //sumas de saldos para el nivel 1
        var subQueryN1 = Enumerable.From(jsonResp).Where("$.TipoPuesto == 2")
            .Select(function (x) {
                return {
                    'A': x['FiIdPuestoBase'] + " - " + x['DescPuestoBase'],
                    'F': x['SaldoIni'],
                    'E': x['FcEmpNo']

                };
            })
            .ToArray();

        var puestosComercio1 = Enumerable.From(subQueryN1).GroupBy("$.E", null,
         function (key, g) {
             return {
                 F: Enumerable.From(g.source).FirstOrDefault().F,
                 A: Enumerable.From(g.source).FirstOrDefault().A,
                 E: Enumerable.From(g.source).FirstOrDefault().E
             };
         }).ToArray();

        var sumN1PuestosComercio = Enumerable.From(puestosComercio1).GroupBy("$.A", null,
            function (key, g) {
                var result = {
                    currency: key,
                    total: g.Sum("$.F")
                }
                return result;
            }).ToArray();

        // numero cero 
        var subquery0 = Enumerable.From(jsonResp).Where("$.FiIdPuestoBase==0")
       .Select(function (x) {
           return {
               'A': x['FiIdPuestoBase'] + " - " + x['DescPuestoBase'],
               'F': x['SaldoIni']
           };
       })
           .ToArray();
        var sumN1PuestosComercio0 = Enumerable.From(subquery0).GroupBy("$.A", null,
            function (key, g) {
                var result = {
                    currency: key,
                    total: g.Sum("$.F")
                }
                return result;
            }).ToArray();
        //sumas de saldos para el nivel 2
        var subQueryN2 = Enumerable.From(jsonResp).Where("$.TipoPuesto == 2")
            .Select(function (x) {
                return {
                    'A': x['FiIdPuestoBase'] + " - " + x['DescribeFuncion'],
                    'F': x['SaldoIni'],
                    'E': x['FcEmpNo']
                };
            })
            .ToArray();

        var puestosComercio2 = Enumerable.From(subQueryN2).GroupBy("$.E", null,
          function (key, g) {
              return {
                  F: Enumerable.From(g.source).FirstOrDefault().F,
                  A: Enumerable.From(g.source).FirstOrDefault().A,
                  E: Enumerable.From(g.source).FirstOrDefault().E
              };
          }).ToArray();


        var sumN2PuestosComercio = Enumerable.From(puestosComercio2).GroupBy("$.A", null,
            function (key, g) {
                var result = {
                    currency: key,
                    total: g.Sum("$.F")
                }
                return result;
            }).ToArray();
        //sumas de saldos para el nivel 3
        var subQueryN3 = Enumerable.From(jsonResp).Where("$.TipoPuesto == 2")
            .Select(function (x) {
                return {
                    'A': x['FiIdPuestoBase'] + " - " + x['Nombre'] + " - " + x['FcEmpNo'],
                    'F': x['SaldoIni']
                };
            })
            .ToArray();
        var sumN3PuestosComercio = Enumerable.From(subQueryN3).GroupBy("$.A", null,
            function (key, g) {
                var result = {
                    currency: key,
                    total: Enumerable.From(g).FirstOrDefault().F
                }
                return result;
            }).ToArray();
        /**************************************************************************
         *** Seccion Comercio
         **************************************************************************/
        /**************************************************************************
         *** Seccion Otro
         **************************************************************************/
        //Otros
        var queryPuestosOtros = Enumerable.From(jsonResp)
            .Where("$.TipoPuesto == 3")
            .Select(function (x) {
                return {
                    'A': x['FiIdPuestoBase'] + " - " + x['DescPuestoBase'],
                    'B': x['DescribeFuncion'],
                    'C': x['FcEmpNo'] + " - " + x['Nombre'] + " - " + x['EmpStatus'],
                    'D': x['FiTipoPago'] + " - " + x['FcTpagDesc'],
                    'E': x['SaldoTP']
                };
            })
            .ToArray();


           var queryPuestoComercioOtrosSm = Enumerable.From(jsonResp)
            .Where("$.TipoPuesto == 3")
            .Select(function (x) {
                return {
                    'C': x['FcEmpNo']+ " - " +x['Nombre'],
                    'E': x['SaldoIni']
                    };
            })
            .ToArray();

           var puestosOtrosSumaM1 = Enumerable.From(queryPuestoComercioOtrosSm).GroupBy("$.C", null,
             function (key, g) {
                 return {
                      C: Enumerable.From(g.source).FirstOrDefault().C,
                      E: Enumerable.From(g.source).FirstOrDefault().E
                      };
                }).ToArray();


        var formatResultPuestosOtros = Enumerable.From(queryPuestosOtros)
            .Let(grouper('A', function (g1) {
                return g1.Let(grouper('B', function (g2) {
                    return g2.Let(grouper('C', function (g3) {
                        return g3.Let(grouper('D', function (g4) {
                            return g4.Select("$.E").ToArray();
                        }));
                    }));
                }));
            }))
            .ToArray();
        //sumas de saldos para el nivel 1
        var subQueryN1Otro = Enumerable.From(jsonResp).Where("$.TipoPuesto == 3")
            .Select(function (x) {
                return {
                    'A': x['FiIdPuestoBase'] + " - " + x['DescPuestoBase'],
                    'F': x['SaldoTP']
                };
            })
            .ToArray();
        var sumN1Otro = Enumerable.From(subQueryN1Otro).GroupBy("$.A", null,
            function (key, g) {
                var result = {
                    currency: key,
                    total: g.Sum("$.F")
                }
                return result;
            }).ToArray();


        //sumas de saldos para el nivel 2
        var subQueryN2Otro = Enumerable.From(jsonResp).Where("$.TipoPuesto == 3")
            .Select(function (x) {
                return {
                    'A': x['FiIdPuestoBase'] + " - " + x['DescribeFuncion'],
                    'F': x['SaldoIni'],
                    'E': x['FcEmpNo']
                };
            })
            .ToArray();


        var puestosOtros2 = Enumerable.From(subQueryN2Otro).GroupBy("$.E", null,
      function (key, g) {
          return {
              F: Enumerable.From(g.source).FirstOrDefault().F,
              A: Enumerable.From(g.source).FirstOrDefault().A,
              E: Enumerable.From(g.source).FirstOrDefault().E
          };
      }).ToArray();

        var sumN2Otro = Enumerable.From(puestosOtros2).GroupBy("$.A", null,
            function (key, g) {
                var result = {
                    currency: key,
                    total: g.Sum("$.F")
                }
                return result;
            }).ToArray();


        //sumas de saldos para el nivel 3
        var subQueryN3Otro = Enumerable.From(jsonResp).Where("$.TipoPuesto == 3")
            .Select(function (x) {
                return {
                    'A': x['FiIdPuestoBase'] + " - " + x['Nombre'] + " - " + x['FcEmpNo'],
                    'F': x['SaldoIni']
                };
            })
            .ToArray();
        var sumN3Otro = Enumerable.From(subQueryN3Otro).GroupBy("$.A", null,
            function (key, g) {
                var result = {
                    currency: key,
                    total: Enumerable.From(g).FirstOrDefault().F
                }
                return result;
            }).ToArray();
        /**************************************************************************
         *** Seccion Otro
         **************************************************************************/
      

        
        //var sumTotalBanco = Enumerable.From(queryPuestosBanco).Sum("$.E");
        var sumTotalBanco = Enumerable.From(puestosBancossM1).Sum("$.E");

        var contN1 = 0, contN2 = -1, contN3 = -1;

        //if (subquery0.length!=0) {
           // var sumTotalComercio = Enumerable.From(queryPuestosComercio).Sum("$.E") + sumN1PuestosComercio0[0].total;
           var sumTotalComercio = Enumerable.From(puestosComerciosM1).Sum("$.E");
        //}
        //else {
        //    var sumTotalComercio = Enumerable.From(queryPuestosComercio).Sum("$.E");
        //}

         var sumTotalOtro = Enumerable.From(puestosOtrosSumaM1).Sum("$.E");

        var acc = [];
        var empl = {};
        if (formatResultPuestosBanco != 0) {
            var tabla = '<table class="tblGeneral"><tr><td class="p0 tLeft"><strong>Puestos de Banco</strong></td><td class="tRight w150 p2"><strong>' + formatMoney(sumTotalBanco) + '</strong></td></tr></table>' +
           '<dl class="accordion">';

            $.each(formatResultPuestosBanco, function (i, p) {   //cajero

                tabla += '<dt class="AcoInpar">' +
                           '<table class="tblGeneral1">' +

                              '<tr>' +
                                  '<td class="p0 tLeft" >' + p.text + '</td>' +
                                  '<td class="tRight w150">' + formatMoney(sumN1PuestosBanco[contN1].total) + '</td>' +
                              '</tr>' +
                            '</table>' +
                        '</dt>' +
               '<dd class="AcoInpar">' +
              '<div class="inner">' +
              '<div class="nivel2">';
                contN1++;
                $.each(p.children, function (i, p) {
                    contN2++;
                    tabla += '<dl class="accordion1">' +
                              '<dt>' +
                                 '<table class="tblGeneral1">' +
                                     '<tr>' +
                                        '<td class="p0"> ' + p.text + '</td>' +
                                        '<td class="tRight w150">' + formatMoney(sumN2PuestosBanco[contN2].total) + '</td>' +
                                     '</tr>' +
                                 '</table>' +
                             '</dt>' +
                           '<dd class="AcoInpar">' +
                        '<div class="inner">' +
                    '<div class="nivel3">'; 
                    
                    $.each(p.children, function (i, p) {
                        contN3++;
                        tabla += ' <dl class="accordion2">' +
                                     '<dt class="AcoInpar">' +
                                           '<table class="tblGeneral1">' +
                                                   '<tr >' +
                                                  ((((p.text).split("-")[2]).trim() === "1") ? '<td class="p0" >' + (((p.text).split("-")[0]).trim() + " - " + ((p.text).split("-")[1]).trim()).toString() + '</td>' : '<td class="p0 cAz" >' + (((p.text).split("-")[0]).trim() + " - " + ((p.text).split("-")[1]).trim()).toString() + '</td>') +
                                                   '<td class="tRight w150">' + formatMoney(sumN3PuestosBancos[contN3].total) + '</td>' + //debe ser el 
                                                   '</tr>' +
                                            '</table>' +
                                     '</dt>' +
                                  '<dd class="AcoInpar">' +
                                '<div class="inner">' +
                            '<table class="tblNivel2 t2">';
                        
                        $.each(p.children, function (i, p) {
                            tabla +=
                                        '<tr>' +
                                        '<td>' + p.text + '</td>' +
                                        '<td class="w150">' + formatMoney(p.children) + '</td>' +
                                        '</tr>';
                        });
                        tabla += '</table></div></dd>';
                    });
                    tabla += '</dl></div>' +
                         '</div>' +
                    '</dd>' +
                    '<div class="clear"></div>';
                });
                tabla += '</dl></div>' +
                      '</div>' +
                    '</dd>' +
                    '<div class="clear"></div>';


            });
            tabla += '</dl>' + crearBanco();
            tabla = tabla.substring(0, tabla.length - "undefined".length);
            $('#pruebaBanco').html(tabla);
        }
        contN1 = 0; contN2 = -1; contN3 = -1;

        if (formatResultPuestosComercio.length != 0) {
            var tablaComercio = '<table class="tblGeneral"><tr><td class="p0 tLeft"><strong>Puestos Comercio</strong></td><td class="tRight w150 p2"><strong>' + formatMoney(sumTotalComercio) + '</strong></td></tr></table>' +
            '<dl class="accordion">';          
            $.each(formatResultPuestosComercio, function (i, p) {   //cajero             
                tablaComercio +=
                    '<dt class="AcoInpar">' +
                           '<table class="tblGeneral1">' +

                              '<tr>' +
                                  '<td class="p0 tLeft" >' + p.text + '</td>' +
                                  '<td class="tRight w150">' + formatMoney(sumN1PuestosComercio[contN1].total) + '</td>' +
                              '</tr>' +
                            '</table>' +
                        '</dt>' +
               '<dd class="AcoInpar">' +
              '<div class="inner">' +
              '<div class="nivel2">';
                contN1++;
                $.each(p.children, function (i, p) {
                    contN2++;
                    tablaComercio += '<dl class="accordion1">' +
                              '<dt>' +
                                 '<table class="tblGeneral1">' +
                                     '<tr>' +
                                        '<td class="p0"> ' + p.text + '</td>' +
                                        '<td class="tRight w150">' + formatMoney(sumN2PuestosComercio[contN2].total) + '</td>' +
                                     '</tr>' +
                                 '</table>' +
                             '</dt>' +
                           '<dd class="AcoInpar">' +
                        '<div class="inner">' +
                    '<div class="nivel3">';
                    
                    $.each(p.children, function (i, p) {
                        contN3++;
                        tablaComercio += ' <dl class="accordion2">' +
                                     '<dt class="AcoInpar">' +
                                           '<table class="tblGeneral1">' +
                                                   '<tr >' +
                                                    ((((p.text).split("-")[2]).trim() === "1") ? '<td class="p0" >' + (((p.text).split("-")[0]).trim() + " - " + ((p.text).split("-")[1]).trim()).toString() + '</td>' : '<td class="p0 cAz" >' + (((p.text).split("-")[0]).trim() + " - " + ((p.text).split("-")[1]).trim()).toString() + '</td>') +
                                                     '<td class="tRight w150">' + formatMoney(sumN3PuestosComercio[contN3].total) + '</td>' +
                                                   '</tr>' +
                                            '</table>' +
                                     '</dt>' +
                                  '<dd class="AcoInpar">' +
                                '<div class="inner">' +
                            '<table class="tblNivel2 t2">';
                        
                        $.each(p.children, function (i, p) {
                            tablaComercio +=
                                        '<tr>' +
                                        '<td>' + p.text + '</td>' +
                                        '<td class="w150">' + formatMoney(p.children) + '</td>' +
                                        '</tr>';
                        });
                        tablaComercio += '</table></div></dd>';
                    });
                    tablaComercio += '</dl></div>' +
                         '</div>' +
                    '</dd>' +
                    '<div class="clear"></div>';
                });
                tablaComercio += '</dl></div>' +
                      '</div>' +
                    '</dd>' +
                    '<div class="clear"></div>';


            });
            tablaComercio += '</dl>';
           // tablaComercio = tablaComercio.substring(0, tablaComercio.length - "undefined".length);
            $('#pruebaComercio').html(tablaComercio);
        }
        contN1 = 0; contN2 = 0; contN3 = 0;

        if (formatResultPuestosOtros.length != 0) {
            var tablaOtros = '<table class="tblGeneral"><tr><td class="p0 tLeft"><strong>Otros</strong></td><td class="tRight w150 p2"><strong>' + formatMoney(sumTotalOtro) + '</strong></td>' +
                       ' </tr>'+
                    '</table>'+
            '<dl class="accordion">';
            $.each(formatResultPuestosOtros, function (i, p) {   //cajero

                tablaOtros += '<dt class="AcoInpar">' +
                           '<table class="tblGeneral1">' +

                              '<tr>' +
                                  '<td class="p0 tLeft" >' + p.text + '</td>' +
                                  '<td class="tRight w150 p1">' + formatMoney(sumN1Otro[contN1].total) + '</td>' +
                              '</tr>' +
                            '</table>' +
                        '</dt>' +
               '<dd class="AcoInpar">' +
              '<div class="inner">' +
              '<div class="nivel2">';
                contN1++;
                $.each(p.children, function (i, p) {
                    tablaOtros += '<dl class="accordion1">' +
                              '<dt>' +
                                 '<table class="tblGeneral1">' +
                                     '<tr>' +
                                        '<td class="p0"> ' + p.text + '</td>' +
                                        '<td class="tRight w150">' + formatMoney(sumN2Otro[contN2].total) + '</td>' +
                                     '</tr>' +
                                 '</table>' +
                             '</dt>' +
                           '<dd class="AcoInpar">' +
                        '<div class="inner">' +
                    '<div class="nivel3">';
                    contN2++;
                    $.each(p.children, function (i, p) {
                        tablaOtros += ' <dl class="accordion2">' +
                                     '<dt class="AcoInpar">' +
                                           '<table class="tblGeneral1">' +
                                                   '<tr >' +
                                                       ((((p.text).split("-")[2]).trim() === "1") ? '<td class="p0" >' + (((p.text).split("-")[0]).trim() + " - " + ((p.text).split("-")[1]).trim()).toString() + '</td>' : '<td class="p0 cAz" >' + (((p.text).split("-")[0]).trim() + " - " + ((p.text).split("-")[1]).trim()).toString() + '</td>') +
                                                       '<td class="tRight w150">' + formatMoney(sumN3Otro[contN3].total) + '</td>' +
                                                   '</tr>' +
                                            '</table>' +
                                     '</dt>' +
                                  '<dd class="AcoInpar">' +
                                '<div class="inner">' +
                            '<table class="tblNivel2 t2">';
                        contN3++;
                        $.each(p.children, function (i, p) {
                            tablaOtros +=
                                        '<tr>' +
                                        '<td>' + p.text + '</td>' +
                                        '<td class="w150">' + formatMoney(p.children) + '</td>' +
                                        '</tr>';
                        });
                        tablaOtros += '</table></div></dd>';
                    });
                    tablaOtros += '</dl></div>' +
                         '</div>' +
                    '</dd>' +
                    '<div class="clear"></div>';
                });
                tablaOtros += '</dl></div>' +
                      '</div>' +
                    '</dd>' +
                    '<div class="clear"></div>';


            });
            tablaOtros += '</dl>' ;
           // tablaOtros = tablaOtros.substring(0, tablaOtros.length - "undefined".length);
            $('#pruebaOtros').html(tablaOtros);

        }
        
        var tablaTotalSaldIni = "";
     

        var sum = sumTotalBanco+sumTotalComercio+sumTotalOtro;
        tablaTotalSaldIni += '<table class="tblTotaleSaldos"><tbody>' +
                          '<tr>' +
                              '<td><strong>Total:  </strong></td>' +
                              '<td> <strong>' + formatMoney(sum) + '</strong></td>' +
                          '</tr>' +
                        '</tbody></table>';
        $('#tablaTotalSaldIni').html(tablaTotalSaldIni);


    }
    mostrarLoading(false);
}
function crearBanco() {
    jQuery(function () {

        var allPanels = $('.accordion > dd').hide();

        jQuery('.accordion > dt').on('click', function () {
            $this = $(this);
            //the target panel content
            $target = $this.next();

            jQuery('.accordion > dt').removeClass('accordion-active');
            if ($target.hasClass("in")) {
                $this.removeClass('accordion-active');
                $target.slideUp();
                $target.removeClass("in");

            } else {
                $this.addClass('accordion-active');
                jQuery('.accordion > dd').removeClass("in");
                $target.addClass("in");
                $(".subSeccion").show();

                jQuery('.accordion > dd').slideUp();
                $target.slideDown();
            }
        });

        var allPanels = $('.accordion1 > dd').hide();

        jQuery('.accordion1 > dt').on('click', function () {
            $this = $(this);
            //the target panel content
            $target = $this.next();

            jQuery('.accordion1 > dt').removeClass('accordion-active');
            if ($target.hasClass("in")) {
                $this.removeClass('accordion-active');
                $target.slideUp();
                $target.removeClass("in");

            } else {
                $this.addClass('accordion-active');
                jQuery('.accordion1 > dd').removeClass("in");
                $target.addClass("in");
                $(".subSeccion").show();

                jQuery('.accordion1 > dd').slideUp();
                $target.slideDown();
            }
        });

        var allPanels = $('.accordion2 > dd').hide();

        jQuery('.accordion2 > dt').on('click', function () {
            $this = $(this);
            //the target panel content
            $target = $this.next();

            jQuery('.accordion2 > dt').removeClass('accordion-active');
            if ($target.hasClass("in")) {
                $this.removeClass('accordion-active');
                $target.slideUp();
                $target.removeClass("in");

            } else {
                $this.addClass('accordion-active');
                jQuery('.accordion2 > dd').removeClass("in");
                $target.addClass("in");
                $(".subSeccion").show();

                jQuery('.accordion2 > dd').slideUp();
                $target.slideDown();
            }
        });
    });
}
function crearComercio() {

    jQuery(function () {

        var allPanels = $('.accordion > dd').hide();

        jQuery('.accordion > dt').on('click', function () {
            $this = $(this);
            //the target panel content
            $target = $this.next();

            jQuery('.accordion > dt').removeClass('accordion-active');
            if ($target.hasClass("in")) {
                $this.removeClass('accordion-active');
                $target.slideUp();
                $target.removeClass("in");

            } else {
                $this.addClass('accordion-active');
                jQuery('.accordion > dd').removeClass("in");
                $target.addClass("in");
                $(".subSeccion").show();

                jQuery('.accordion > dd').slideUp();
                $target.slideDown();
            }
        });

        var allPanels = $('.accordion1 > dd').hide();

        jQuery('.accordion1 > dt').on('click', function () {
            $this = $(this);
            //the target panel content
            $target = $this.next();

            jQuery('.accordion1 > dt').removeClass('accordion-active');
            if ($target.hasClass("in")) {
                $this.removeClass('accordion-active');
                $target.slideUp();
                $target.removeClass("in");

            } else {
                $this.addClass('accordion-active');
                jQuery('.accordion1 > dd').removeClass("in");
                $target.addClass("in");
                $(".subSeccion").show();

                jQuery('.accordion1 > dd').slideUp();
                $target.slideDown();
            }
        });

        var allPanels = $('.accordion2 > dd').hide();

        jQuery('.accordion2 > dt').on('click', function () {
            $this = $(this);
            //the target panel content
            $target = $this.next();

            jQuery('.accordion2 > dt').removeClass('accordion-active');
            if ($target.hasClass("in")) {
                $this.removeClass('accordion-active');
                $target.slideUp();
                $target.removeClass("in");

            } else {
                $this.addClass('accordion-active');
                jQuery('.accordion2 > dd').removeClass("in");
                $target.addClass("in");
                $(".subSeccion").show();

                jQuery('.accordion2 > dd').slideUp();
                $target.slideDown();
            }
        });
    });
}
function crearOtros() {
    jQuery(function () {

        var allPanels = $('.accordion > dd').hide();

        jQuery('.accordion > dt').on('click', function () {
            $this = $(this);
            //the target panel content
            $target = $this.next();

            jQuery('.accordion > dt').removeClass('accordion-active');
            if ($target.hasClass("in")) {
                $this.removeClass('accordion-active');
                $target.slideUp();
                $target.removeClass("in");

            } else {
                $this.addClass('accordion-active');
                jQuery('.accordion > dd').removeClass("in");
                $target.addClass("in");
                $(".subSeccion").show();

                jQuery('.accordion > dd').slideUp();
                $target.slideDown();
            }
        });

        var allPanels = $('.accordion1 > dd').hide();

        jQuery('.accordion1 > dt').on('click', function () {
            $this = $(this);
            //the target panel content
            $target = $this.next();

            jQuery('.accordion1 > dt').removeClass('accordion-active');
            if ($target.hasClass("in")) {
                $this.removeClass('accordion-active');
                $target.slideUp();
                $target.removeClass("in");

            } else {
                $this.addClass('accordion-active');
                jQuery('.accordion1 > dd').removeClass("in");
                $target.addClass("in");
                $(".subSeccion").show();

                jQuery('.accordion1 > dd').slideUp();
                $target.slideDown();
            }
        });

        var allPanels = $('.accordion2 > dd').hide();

        jQuery('.accordion2 > dt').on('click', function () {
            $this = $(this);
            //the target panel content
            $target = $this.next();

            jQuery('.accordion2 > dt').removeClass('accordion-active');
            if ($target.hasClass("in")) {
                $this.removeClass('accordion-active');
                $target.slideUp();
                $target.removeClass("in");

            } else {
                $this.addClass('accordion-active');
                jQuery('.accordion2 > dd').removeClass("in");
                $target.addClass("in");
                $(".subSeccion").show();

                jQuery('.accordion2 > dd').slideUp();
                $target.slideDown();
            }
        });
    });
}



function grouper(propertyName, selector) {
    return function (e) {
        return e.GroupBy("$." + propertyName, null, function (k, g) {
            return {
                text: k,
                children: g.Let(selector).ToArray()
            };
        });
    };
}

function groupBy(array, f) {
    var groups = {};
    array.forEach(function (o) {
        var group = JSON.stringify(f(o));
        groups[group] = groups[group] || [];
        groups[group].push(o);
    });
    return Object.keys(groups).map(function (group) {
        return groups[group];
    })
}

function sActCaja(empleado, perfilIniciales, divisa) {
    var fechaActual = fechaI();
    mostrarLoading(true);
    
    $.ajax({
        url: getUrlsIniciales(urlActCaja),
        contentType: "application/json; charset=UTF-8",
        type: "POST",
        data: JSON.stringify(
            {
                "Opcion": 3,
                "Perfil": ""+perfilIniciales,
                "IdTipoDivisa": divisa,
                "Fecha": "" + fechaActual,
                "Empleado": "" + empleado
            }),
        dataType: 'json',
        crossDomain: true,
        success: function (data) {
            if (data.Respuesta!=0 || data.Respuesta!=null) {
                InicialCaja(data);
            }
            else {
                $('#limpCaja').html('');
                //$('#tablaTotalCajasIni').html("");

            }
            mostrarLoading(false);
        },
        error: function () {
            // alert(data);
            mostrarLoading(false);
            $("#TablaSalIniCaja").text("Error en el consumo del servicio ");
        }
    });
}
function InicialCaja(respuestaCajas) {
    var suma = 0;
    if (respuestaCajas.NoError == 0) {
        RespCajas(respuestaCajas.Respuesta);
    }
    else if (respuestaCajas.NoError == 1) {
        document.getElementById("TablaSalIniCaja").innerHTML = respuestaCajas.Descripcion;
    } else if (respuestaCajas.Respuesta == 3) {
        document.getElementById("TablaSalIniCaja").innerHTML = respuestaCajas.Descripcion;
    } else {
        document.getElementById("TablaSalIniCaja").innerHTML = "Intente mas tarde.";
    }
}
function RespCajas(json) {
    mostrarLoading(true);
    if (json.length != 0) {


        var tabla2 = '';
        var queryResultC = Enumerable.From(json)
        .Select(function (x) {
            return {
                'A': x['FiCjId'] + " - " + x['FcCjDesc'],
                'B': x['FiTipoPago'] + " - " + x['FcTpagDesc'],
                'C': x['SaldoTP']

            };
        })
        .ToArray();

        var queryResultSumC = Enumerable.From(json)
       .Select(function (x) {
           return {
               'A': x['FcCjDesc'],
               'C': x['SaldoIniCaja']
           };
       })
       .ToArray();

        var sqCajaSum3 = Enumerable.From(queryResultSumC).GroupBy("$.A", null,
              function (key, g) {
                  return {
                      A: Enumerable.From(g.source).FirstOrDefault().A,
                      C: Enumerable.From(g.source).FirstOrDefault().C
                  };
              }).ToArray();




        var formatResult = Enumerable.From(queryResultC)
           .Let(grouper('A', function (g1) {
               return g1.Let(grouper('B', function (g2) {
                   return g2.Select("$.C").ToArray();
               }));
           }))
        .ToArray();


        //sumas de saldos para el nivel 3
        var subQueryN3 = Enumerable.From(json)
            .Select(function (x) {
                return {
                    'A': x['FiCjId'] + " - " + x['FcCjDesc'],
                    'F': x['SaldoIniCaja']
                };
            })
            .ToArray();

        var sqCajan3 = Enumerable.From(subQueryN3).GroupBy("$.A", null,
              function (key, g) {
                  return {
                      F: Enumerable.From(g.source).FirstOrDefault().F,
                      A: Enumerable.From(g.source).FirstOrDefault().A
                  };
              }).ToArray();

        var sumN3 = Enumerable.From(sqCajan3).GroupBy("$.A", null,
            function (key, g) {
                var result = {
                    currency: key,
                    total: g.Sum("$.F")
                }
                return result;
            }).ToArray();



        var sumTotal = Enumerable.From(sqCajaSum3).Sum("$.C");
        var contN1 = 0;
        var sum = sumTotal;
        tabla2 = '<dl class="accordion1Caja">';



        $.each(formatResult, function (i, p) {   //NIVEL1
            tabla2 += '<dt class="AcoInpar">' +
                       '<table class="tblGeneral1">' +
                          '<tr>' +
                              '<td class="p0 tLeft">' + p.text + '</td>' +
                              '<td class="tRight w180" style="margin-right:100px;"> ' + formatMoney(sumN3[contN1].total) + '</td>' +
                          '</tr>' +
                        '</table>' +
                    '</dt>' +
           '<dd>' +
           '<div class="nivel1"><table class="tblNivel11"><tbody>';
            contN1++;
            $.each(p.children, function (i, p) {//nivel2
                tabla2 += '<tr>' +
                          '<td>' + p.text + '</td>' +
                          '<td class="w180" >' + formatMoney(p.children) + '</td>' +
                         '</tr>';


            });
            tabla2 += '</tbody></table></div></dd>';
        });

        tabla2 += '</dl>' + cajasAcordion();
        tabla2 = tabla2.substring(0, tabla2.length - "undefined".length);
        $('#TablaSalIniCaja').html(tabla2);
        var tablaTotalCajasIni = "";
        tablaTotalCajasIni += '<table class="tblTotalesCaja"><tbody>' +
                          '<tr>' +
                              '<td><strong>Total:  </strong></td>' +
                              '<td><strong> ' + formatMoney(sum) + '</strong></td>' +
                          '</tr>' +
                        '</tbody></table>';
        $('#tablaTotalCajasIni').html(tablaTotalCajasIni);
    }
    mostrarLoading(false);
}






    function cajasAcordion() {
        jQuery(function () {

            var allPanels = $('.accordion1Caja > dd').hide();

            jQuery('.accordion1Caja > dt').on('click', function () {
                $this = $(this);
                //the target panel content
                $target = $this.next();

                jQuery('.accordion1Caja > dt').removeClass('accordionCaja-active');
                if ($target.hasClass("in")) {
                    $this.removeClass('accordionCaja-active');
                    $target.slideUp();
                    $target.removeClass("in");

                } else {
                    $this.addClass('accordionCaja-active');
                    jQuery('.accordion1Caja > dd').removeClass("in");
                    $target.addClass("in");
                    $(".subSeccion").show();

                    jQuery('.accordion1Caja > dd').slideUp();
                    $target.slideDown();
            }
            });

            var allPanels = $('.accordion12 > dd').hide();

            jQuery('.accordion12 > dt').on('click', function () {
                $this = $(this);
                //the target panel content
                $target = $this.next();

                jQuery('.accordion12 > dt').removeClass('accordion-active');
                if ($target.hasClass("in")) {
                    $this.removeClass('accordion-active');
                    $target.slideUp();
                    $target.removeClass("in");

                } else {
                    $this.addClass('accordion-active');
                    jQuery('.accordion12 > dd').removeClass("in");
                    $target.addClass("in");
                    $(".subSeccion").show();

                    jQuery('.accordion12 > dd').slideUp();
                    $target.slideDown();
            }
            });

            var allPanels = $('.accordion21 > dd').hide();

            jQuery('.accordion21 > dt').on('click', function () {
                $this = $(this);
                //the target panel content
                $target = $this.next();

                jQuery('.accordion21 > dt').removeClass('accordion-active');
                if ($target.hasClass("in")) {
                    $this.removeClass('accordion-active');
                    $target.slideUp();
                    $target.removeClass("in");

                } else {
                    $this.addClass('accordion-active');
                    jQuery('.accordion21 > dd').removeClass("in");
                    $target.addClass("in");
                    $(".subSeccion").show();

                    jQuery('.accordion21 > dd').slideUp();
                    $target.slideDown();
            }
            });
        });

}

