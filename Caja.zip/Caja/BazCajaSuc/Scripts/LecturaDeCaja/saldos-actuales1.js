﻿var pantallaCargada = false;
var servActuales = "LecturaCaja/LecturaDeCaja.svc/wsLecturaDeCajaSaldos";
var urlPerfActual = "LecturaCaja/lecturaDeCaja.svc/wsLecturaPerfiles";
var urlActCajas = "LecturaCaja/LecturaDeCaja.svc/wsLecturaDeCajaSaldosCaja";
var PerfilActual;
function recargaActuales(usuario, perfil, divisa) {
    limpiarActuales();
    serviceLecturaActual(usuario, perfil, divisa);
    sActCajaActuales(usuario, perfil, divisa);
}
function limpiarActuales() {    
        $('#BancoActuales').html('');
        $('#ComercioActuales').html('');
        $('#OtrosActuales').html('');     //SEGUIR LIMPIANDO LAS CAJAS DE TEXTO
        $('#tablaTotalSaldAct').html('');
        $('#SaldoscajasActuales').html('');
        $('#tablaTotalCajasIni2').html('');

    
}
function PerfileActual() {
    mostrarLoading(true);
    var host1 = getUrlBase();
    $.ajax({
        url: getUrlss(urlPerfActual),

        contentType: "application/json; charset=UTF-8",
        type: "POST",
        data: JSON.stringify({
            "NoEmpleado": "" + getUrlVars()["usuario"],
        }),
        dataType: 'json',
        crossDomain: true,
        success: function (data) {
            mostrarCarga(false);
            PerfilActual = data.Respuesta;
            mostrarLoading(false);
            return data.Respuesta;
        },
        error: function () {
            $("#bMensaje").text("Ocurrió un error en el consumo del servicio.");
            mostrarLoading(false);
        }
    });
}

function getUrlsActuales(serv) {
    var url = "";
    if (window.location.hostname == "localhost") {
        url = "http://10.54.28.226:9014/Caja/Servicios/" + serv;
    } else {
        url = "http://" + window.location.hostname + ":9014/Caja/Servicios/" + serv;
        }
    return url;
}
function serviceLecturaActual(empleado, PerfilActual, divisass) {
    mostrarLoading(true);
    var fechaActual = fechaI();   
   
    $.ajax({
        url: getUrlsActuales(servActuales),
        contentType: "application/json; charset=UTF-8",
        type: "POST",
        data: JSON.stringify(
            {

                "Operacion": 1,
                "Opcion": 2,
                "Perfil": ""+PerfilActual,
                "IdTipoDivisa": divisass,
                "Inicio": ""+fechaActual,
                "Empleado": ""+empleado,
                "Origen": "1"



            }),
        dataType: 'json',
        crossDomain: true,
        success: function (data) {
            ServicioActual(data);
            mostrarLoading(false);
        },
        error: function () {
            // alert(data);
            $("#BancoActuales").text("Error en el consumo del servicio ");
            mostrarLoading(false);
        }
    });

}
function ServicioActual(jsonRespactual) {
    var suma = 0;
    if (jsonRespactual.NoError == 0) {
        repActual(jsonRespactual.Respuesta);
    }
    else if (jsonRespactual.NoError == 1) {
        document.getElementById("BancoActuales").innerHTML = jsonRespactual.Descripcion;
    } else if (jsonRespactual.Respuesta == 3) {
        document.getElementById("BancoActuales").innerHTML = jsonRespactual.Descripcion;
    } else {
        document.getElementById("BancoActuales").innerHTML = "Intente mas tarde.";
    }
}

function repActual(jsonRespActual) {
    mostrarLoading(true);
    if (jsonRespActual.length === 0) {
        alert("no hay movimientos");
    }
    else {
        var tabla = '';
        var suma = 0;
        var queryResult = Enumerable.From(jsonRespActual)
        .Select(function (x) {
            return {
                'A': x['FiIdPuestoBase'] + " - " + x['DescPuestoBase'],
                'B': x['DescribeFuncion'],
                'C': x['FcEmpNo'] + " - " + x['Nombre'],
                'D': x['FiTipoPago'] + " - " + x['FcTpagDesc'],
                'E': x['NoDoctos'] + " - " + x['SaldoIni'],
                'F': x['SaldoTP']
            };
        })
        .ToArray();

        var formatResult = Enumerable.From(queryResult)
           .Let(grouper('A', function (g1) {
               return g1.Let(grouper('B', function (g2) {
                   return g2.Let(grouper('C', function (g3) {
                       return g3.Let(grouper('D', function (g4) {
                           return g4.Select("$.E").ToArray();
                       }));
                   }));
               }));
           }))
        .ToArray();
       

        //Puestos (1 = Banco; 2 = Comercio)
        var queryPuestos = Enumerable.From(jsonRespActual)
            .GroupBy(function (x) { return x.TipoPuesto })
            .Select(function (x) {
                return x.Max(function (z) { return z.TipoPuesto });
            })
        .ToArray();


        /**************************************************************************
        *** Seccion Banco
        **************************************************************************/
        //Banco
        var queryPuestosBanco = Enumerable.From(jsonRespActual)
            .Where("$.TipoPuesto == 1")
            .Select(function (x) {
                return {
                    'A': x['FiIdPuestoBase'] + " - " + x['DescPuestoBase'],
                    'B': x['DescribeFuncion'],
                    'C': x['FcEmpNo'] + " - " + x['Nombre'] + " - " + x['EmpStatus'],
                    'D': x['FiTipoPago'] + " - " + x['FcTpagDesc'],
                    'E': x['NoDoctos'] + " - " + x['SaldoTP'],
                    'F': x['SaldoTP'],
                    'DOCS': x['NoDoctos']
                };
            })
            .ToArray();

        var queryPuestosBancoSuma = Enumerable.From(jsonRespActual)
                .Where("$.TipoPuesto == 1")
                .Select(function (x) {
                    return {
                        'C': x['FcEmpNo'] + " - " + x['Nombre'],
                        'E': x['SaldoAct']
                    };
                })
                .ToArray();

            var puestosBancoTTSm = Enumerable.From(queryPuestosBancoSuma).GroupBy("$.C", null,
                function (key, g) {
                    return {
                        C: Enumerable.From(g.source).FirstOrDefault().C,
                        E: Enumerable.From(g.source).FirstOrDefault().E
                    };
                }).ToArray();


        var formatResultPuestosBanco = Enumerable.From(queryPuestosBanco)
            .Let(grouper('A', function (g1) {
                return g1.Let(grouper('B', function (g2) {
                    return g2.Let(grouper('C', function (g3) {
                        return g3.Let(grouper('D', function (g4) {
                            return g4.Select("$.E").ToArray();
                        }));
                    }));
                }));
            }))
            .ToArray();


        //sumas de saldos para el nivel 1
        var subQueryN1PuestosBanco = Enumerable.From(jsonRespActual).Where("$.TipoPuesto == 1")
            .Select(function (x) {
                return {
                    'A': x['FiIdPuestoBase'] + " - " + x['DescPuestoBase'],
                    'F': x['SaldoAct'],
                    'E': x['FcEmpNo'],
                    'D': x['NoDoctos']
                };
            })
            .ToArray();
        var puestosBancoSaq1 = Enumerable.From(subQueryN1PuestosBanco).GroupBy("$.E", null,
              function (key, g) {
                  return {
                      F: Enumerable.From(g.source).FirstOrDefault().F,
                      A: Enumerable.From(g.source).FirstOrDefault().A,
                      E: Enumerable.From(g.source).FirstOrDefault().E
                  };
              }).ToArray();
        var sumN1PuestosBanco = Enumerable.From(puestosBancoSaq1).GroupBy("$.A", null,
            function (key, g) {
                var result = {
                    currency: key,
                    total: g.Sum("$.F")
                }
                return result;
            }).ToArray();

        var sumN1BancosDoctosN1 = Enumerable.From(subQueryN1PuestosBanco).GroupBy("$.A", null,
                    function (key, g) {
                        var result = {
                            currency: key,
                            total: g.Sum("$.D")
                                }
                            return result;
            }).ToArray();

        //sumas de saldos para el nivel 2
        var subQueryN2PuestosBancos = Enumerable.From(jsonRespActual).Where("$.TipoPuesto == 1")
            .Select(function (x) {
                return {
                    'A': x['FiIdPuestoBase'] + " - " + x['DescribeFuncion'],
                    'F': x['SaldoAct'],
                    'E': x['FcEmpNo'],
                    'D': x['NoDoctos']
                };
            })
            .ToArray();

         var puestosBancosq2 = Enumerable.From(subQueryN2PuestosBancos).GroupBy("$.E", null,
                 function (key, g) {
                     return {
                         F: Enumerable.From(g.source).FirstOrDefault().F,
                         A: Enumerable.From(g.source).FirstOrDefault().A,
                         E: Enumerable.From(g.source).FirstOrDefault().E
                     };
                 }).ToArray();


         var sumN2PuestosBanco = Enumerable.From(puestosBancosq2).GroupBy("$.A", null,
            function (key, g) {
                var result = {
                    currency: key,
                    total: g.Sum("$.F")
                }
                return result;
            }).ToArray();

         var sumN2BancoDoctos = Enumerable.From(subQueryN2PuestosBancos).GroupBy("$.A", null,
        function (key, g) {
            var result = {
                currency: key,
                total: g.Sum("$.D")
            }
            return result;
        }).ToArray();


        //sumas de saldos para el nivel 3  -- Modificado agregado + " - " + x['FcEmpNo']
        var subQueryN3PuestosBancos = Enumerable.From(jsonRespActual).Where("$.TipoPuesto == 1")
            .Select(function (x) {
                return {
                    'A': x['FiIdPuestoBase'] + " - " + x['Nombre']+ " - " + x['FcEmpNo'],
                    'F': x['SaldoAct'],
                    'D': x['NoDoctos']
                };
            })
            .ToArray();

        var sumN3PuestosBanco = Enumerable.From(subQueryN3PuestosBancos).GroupBy("$.A", null,
            function (key, g) {
                var result = {
                    currency: key,
                    total: Enumerable.From(g).FirstOrDefault().F,
                    NumDoctos: g.Sum("$.D")
                }
                return result;
            }).ToArray();


        //sumas de documentos Nivel1
        var subQueryDocsBancos1 = Enumerable.From(jsonRespActual).Where("$.TipoPuesto == 1")
        .Select(function (x) {
            return {
                'A': x['FiIdPuestoBase'] + " - " + x['DescPuestoBase'],
                'F': x['NoDoctos']
            };
        })
        .ToArray();
        var sumDocsBancos1 = Enumerable.From(subQueryDocsBancos1).GroupBy("$.A", null,
        function (key, g) {
            var result = {
                currency: key,
                total: g.Sum("$.F")
            }
            return result;
        }).ToArray();

        //sumas de documentos Nivel2
        var subQueryDocsBancos2 = Enumerable.From(jsonRespActual).Where("$.TipoPuesto == 1")
        .Select(function (x) {
            return {
                'A': x['FiIdPuestoBase'] + " - " + x['DescPuestoBase'],
                'B': x['DescribeFuncion'],
                'F': x['NoDoctos']
            };
        })
        .ToArray();
        var sumDocsBancos2 = Enumerable.From(subQueryDocsBancos2).GroupBy("$.B", null,
        function (key, g) {
            var result = {
                currency: key,
                total: g.Sum("$.F")
            }
            return result;
        }).ToArray();


        //sumas de documentos Nivel3
        var subQueryDocsBancos3 = Enumerable.From(jsonRespActual).Where("$.TipoPuesto == 1")
        .Select(function (x) {
            return {
                'A': x['FiIdPuestoBase'] + " - " + x['DescPuestoBase'],
                'C': x['FcEmpNo'] + " - " + x['Nombre'],
                'F': x['NoDoctos']
            };
        })
        .ToArray();
        var sumDocsBancos3 = Enumerable.From(subQueryDocsBancos3).GroupBy("$.C", null,
        function (key, g) {
            var result = {
                currency: key,
                total: g.Sum("$.F")
            }
            return result;
        }).ToArray();

        //sumas de documentos Nivel4
        var subQueryDocsBancos4 = Enumerable.From(jsonRespActual).Where("$.TipoPuesto == 1")
        .Select(function (x) {
            return {
                'D': x['FiTipoPago'] + " - " + x['FcTpagDesc'],
                'F': x['NoDoctos']
            };
        })
        .ToArray();

        var sumDocsBancos4 = Enumerable.From(subQueryDocsBancos4).GroupBy("$.D", null,
        function (key, g) {
            var result = {
                currency: key,
                total: g.Sum("$.F")
            }
            return result;
        }).ToArray();


        /**************************************************************************
         *** Seccion Banco
         **************************************************************************/
        /**************************************************************************
         *** Seccion Comercio
         **************************************************************************/
        //Comercio
        var queryPuestosComercio = Enumerable.From(jsonRespActual)
            .Where("$.TipoPuesto == 2")
            .Select(function (x) {
                return {
                    'A': x['FiIdPuestoBase'] + " - " + x['DescPuestoBase'],
                    'B': x['DescribeFuncion'],
                    'C': x['FcEmpNo'] + " - " + x['Nombre'] + " - " + x['EmpStatus'],
                    'D': x['FiTipoPago'] + " - " + x['FcTpagDesc'],
                    'E': x['NoDoctos'] + " - " + x['SaldoIni'],
                    'F': x['SaldoTP'],
                    'G': x['SaldoIni'],
                    'DOCS': x['NoDoctos']
                };
            })
            .ToArray();
        var formatResultPuestosComercio = Enumerable.From(queryPuestosComercio)
            .Let(grouper('A', function (g1) {
                return g1.Let(grouper('B', function (g2) {
                    return g2.Let(grouper('C', function (g3) {
                        return g3.Let(grouper('D', function (g4) {
                            return g4.Select("$.E").ToArray();
                        }));
                    }));
                }));
            }))
            .ToArray();

        
        var queryPuestosComercioSuma = Enumerable.From(jsonRespActual)
                     .Where("$.TipoPuesto == 2")
                     .Select(function (x) {
                         return {
                             'C': x['FcEmpNo'] + " - " + x['Nombre'],
                             'E': x['SaldoAct']
                         };
                     })
                     .ToArray();

        var puestosComercioTTSm = Enumerable.From(queryPuestosComercioSuma).GroupBy("$.C", null,
            function (key, g) {
                return {
                    C: Enumerable.From(g.source).FirstOrDefault().C,
                    E: Enumerable.From(g.source).FirstOrDefault().E
                };
            }).ToArray();



        //sumas de saldos para el nivel 1
        var subQueryN1 = Enumerable.From(jsonRespActual).Where("$.TipoPuesto == 2")
            .Select(function (x) {
                return {
                    'A': x['FiIdPuestoBase'] + " - " + x['DescPuestoBase'],
                    'F': x['SaldoAct'],
                    'E': x['FcEmpNo'],
                    'D': x['NoDoctos']
                };
            })
            .ToArray();

        var puestosComercioSaq1 = Enumerable.From(subQueryN1).GroupBy("$.E", null,
                  function (key, g) {
                      return {
                          F: Enumerable.From(g.source).FirstOrDefault().F,
                          A: Enumerable.From(g.source).FirstOrDefault().A,
                          E: Enumerable.From(g.source).FirstOrDefault().E
                      };
                  }).ToArray();

        var sumN1PuestosComercio = Enumerable.From(puestosComercioSaq1).GroupBy("$.A", null,
            function (key, g) {
                var result = {
                    currency: key,
                    total: g.Sum("$.F")
                }
                return result;
            }).ToArray();

        var sumN1ComercioDoctosN1 = Enumerable.From(subQueryN1).GroupBy("$.A", null,
            function(key, g) {
                var result = {
                        currency: key,
                        total: g.Sum("$.D")
                        }
                    return result;
                    }).ToArray();
//--------------------------------------------------------------------------
        var subquery0 = Enumerable.From(jsonRespActual).Where("$.FiIdPuestoBase==0")
        .Select(function (x) {
            return {
                'A': x['FiIdPuestoBase'] + " - " + x['DescPuestoBase'],
                'F': x['SaldoIni']
            };
        })
            .ToArray();
        var sumN1PuestosComercio0 = Enumerable.From(subquery0).GroupBy("$.A", null,
            function (key, g) {
                var result = {
                    currency: key,
                    total: g.Sum("$.F")
                }
                return result;
            }).ToArray();
        //var completo = sumN1PuestosComercio0.Union(sumN1PuestosComercio);
        //sumas de saldos para el nivel 2
        var subQueryN2 = Enumerable.From(jsonRespActual).Where("$.TipoPuesto == 2")
            .Select(function (x) {
                return {
                    'A': x['FiIdPuestoBase'] + " - " + x['DescribeFuncion'],
                    'F': x['SaldoAct'],
                    'E': x['FcEmpNo'],
                    'D': x['NoDoctos']
                };
            })
            .ToArray();

        var puestosComercioq2 = Enumerable.From(subQueryN2).GroupBy("$.E", null,
          function (key, g) {
              return {
                  F: Enumerable.From(g.source).FirstOrDefault().F,
                  A: Enumerable.From(g.source).FirstOrDefault().A,
                  E: Enumerable.From(g.source).FirstOrDefault().E
              };
          }).ToArray();

        var sumN2PuestosComercio = Enumerable.From(puestosComercioq2).GroupBy("$.A", null,
            function (key, g) {
                var result = {
                    currency: key,
                    total: g.Sum("$.F")
                }
                return result;
            }).ToArray();

        var sumN2ComercioDoctos = Enumerable.From(subQueryN2).GroupBy("$.A", null,
            function(key, g) {
                var result = {
                    currency: key,
                            total: g.Sum("$.D")
                            }
                return result;
                    }).ToArray();


        //sumas de saldos para el nivel 3
        var subQueryN3 = Enumerable.From(jsonRespActual).Where("$.TipoPuesto == 2")
            .Select(function (x) {
                return {
                    'A': x['FiIdPuestoBase'] + " - " + x['Nombre'],
                    'F': x['SaldoAct'],
                    'D': x['NoDoctos']
                };
            })
            .ToArray();
        var sumN3PuestosComercio = Enumerable.From(subQueryN3).GroupBy("$.A", null,
            function (key, g) {
                var result = {
                    currency: key,
                    total: Enumerable.From(g).FirstOrDefault().F,
                   NumDoctos: g.Sum("$.D")
                }
                return result;
            }).ToArray();


        //sumas de documentos
        var subQueryDocsComercio = Enumerable.From(jsonRespActual).Where("$.TipoPuesto == 2")
        .Select(function (x) {
            return {
                'A': x['FiIdPuestoBase'] + " - " + x['DescPuestoBase'],
                'F': x['NoDoctos']
            };
        })
        .ToArray();
        var sumDocsComercio = Enumerable.From(subQueryDocsComercio).GroupBy("$.A", null,
        function (key, g) {
            var result = {
                currency: key,
                total: g.Sum("$.F")
            }
            return result;
        }).ToArray();
        /**************************************************************************
         *** Seccion Comercio
         **************************************************************************/
        /**************************************************************************
         *** Seccion Otro
         **************************************************************************/
        //Otros
        var queryPuestosOtros = Enumerable.From(jsonRespActual)
            .Where("$.TipoPuesto == 3")
            .Select(function (x) {
                return {
                    'A': x['FiIdPuestoBase'] + " - " + x['DescPuestoBase'],
                    'B': x['DescribeFuncion'],
                    'C': x['FcEmpNo'] + " - " + x['Nombre'] + " - " + x['EmpStatus'],
                    'D': x['FiTipoPago'] + " - " + x['FcTpagDesc'],
                    'E': x['NoDoctos'] + " - " + x['SaldoIni'],
                    'F': x['SaldoTP'],
                    'DOCS': x['NoDoctos']
                };
            })
            .ToArray();
        var formatResultPuestosOtros = Enumerable.From(queryPuestosOtros)
            .Let(grouper('A', function (g1) {
                return g1.Let(grouper('B', function (g2) {
                    return g2.Let(grouper('C', function (g3) {
                        return g3.Let(grouper('D', function (g4) {
                            return g4.Select("$.E").ToArray();
                        }));
                    }));
                }));
            }))
            .ToArray();

        var queryPuestosOtrosSuma = Enumerable.From(jsonRespActual)
          .Where("$.TipoPuesto == 3")
          .Select(function (x) {
              return {
                  'C': x['FcEmpNo'] + " - " + x['Nombre'],
                  'E': x['SaldoAct']
              };
          })
          .ToArray();

        var puestosOtrosTTSm = Enumerable.From(queryPuestosOtrosSuma).GroupBy("$.C", null,
            function (key, g) {
                return {
                    C: Enumerable.From(g.source).FirstOrDefault().C,
                    E: Enumerable.From(g.source).FirstOrDefault().E
                };
            }).ToArray();
    

        //sumas de saldos para el nivel 1
        var subQueryN1Otro = Enumerable.From(jsonRespActual).Where("$.TipoPuesto == 3")
            .Select(function (x) {
                return {
                    'A': x['FiIdPuestoBase'] + " - " + x['DescPuestoBase'],
                    'F': x['SaldoAct'],
                    'E': x['FcEmpNo'],
                    'D': x['NoDoctos']
                };
            })
            .ToArray();

        var puestosComercioSaq1 = Enumerable.From(subQueryN1Otro).GroupBy("$.E", null,
                      function (key, g) {
                          return {
                              F: Enumerable.From(g.source).FirstOrDefault().F,
                              A: Enumerable.From(g.source).FirstOrDefault().A,
                              E: Enumerable.From(g.source).FirstOrDefault().E
                          };
                      }).ToArray();

        var sumN1Otro = Enumerable.From(puestosComercioSaq1).GroupBy("$.A", null,
            function (key, g) {
                var result = {
                    currency: key,
                    total: g.Sum("$.F")
                }
                return result;
            }).ToArray();

        var sumN1OtrosDoctosN1 = Enumerable.From(subQueryN1Otro).GroupBy("$.A", null,
            function(key, g) {
                var result = {
                    currency: key,
                    total: g.Sum("$.D")
                            }
                return result;
                    }).ToArray();

        //sumas de saldos para el nivel 2
        var subQueryN2Otro = Enumerable.From(jsonRespActual).Where("$.TipoPuesto == 3")
            .Select(function (x) {
                return {
                    'A': x['FiIdPuestoBase'] + " - " + x['DescribeFuncion'],
                    'F': x['SaldoAct'],
                    'E': x['FcEmpNo'],
                    'D': x['NoDoctos']
                };
            })
            .ToArray();

        var puestosComercioq2 = Enumerable.From(subQueryN2Otro).GroupBy("$.E", null,
                    function (key, g) {
                        return {
                            F: Enumerable.From(g.source).FirstOrDefault().F,
                            A: Enumerable.From(g.source).FirstOrDefault().A,
                            E: Enumerable.From(g.source).FirstOrDefault().E
                        };
                    }).ToArray();

            var sumN2Otro = Enumerable.From(puestosComercioq2).GroupBy("$.A", null,
            function (key, g) {
                var result = {
                    currency: key,
                    total: g.Sum("$.F")
                }
                return result;
            }).ToArray();

            var sumN2OtrosDoctos = Enumerable.From(subQueryN2Otro).GroupBy("$.A", null,
            function(key, g) {
                var result = {
                        currency: key,
                                total: g.Sum("$.D")
                            }
                    return result;
                            }).ToArray();

        //sumas de saldos para el nivel 3
        var subQueryN3Otro = Enumerable.From(jsonRespActual).Where("$.TipoPuesto == 3")
            .Select(function (x) {
                return {
                    'A': x['FiIdPuestoBase'] + " - " + x['Nombre'],
                    'F': x['SaldoAct'],
                    'D': x['NoDoctos']
                };
            })
            .ToArray();
        var sumN3Otro = Enumerable.From(subQueryN3Otro).GroupBy("$.A", null,
            function (key, g) {
                var result = {
                    currency: key,
                    total: Enumerable.From(g).FirstOrDefault().F,
                    NumDoctos: g.Sum("$.D")
                }
                return result;
            }).ToArray();

        //sumas de documentos
        var subQueryDocsOtros = Enumerable.From(jsonRespActual).Where("$.TipoPuesto == 3")
        .Select(function (x) {
            return {
                'A': x['FiIdPuestoBase'] + " - " + x['DescPuestoBase'],
                'F': x['NoDoctos']
            };
        })
        .ToArray();
        var sumDocsOtros = Enumerable.From(subQueryDocsOtros).GroupBy("$.A", null,
        function (key, g) {
            var result = {
                currency: key,
                total: g.Sum("$.F")
            }
            return result;
        }).ToArray();
        /**************************************************************************
         *** Seccion Otro
         **************************************************************************/

        
        //sumas de documentos
        var subQueryDocs = Enumerable.From(jsonRespActual)
        .Select(function (x) {
            return {
                'A': x['FiIdPuestoBase'] + " - " + x['DescPuestoBase'],
                'F': x['NoDoctos']
            };
        })
        .ToArray();
        var sumDocs = Enumerable.From(subQueryDocs).GroupBy("$.A", null,
        function (key, g) {
            var result = {
                currency: key,
                total: g.Sum("$.F")
            }
            return result;
        }).ToArray();
        //sumas de saldos para el nivel 1
        var subQueryN1 = Enumerable.From(jsonRespActual)
        .Select(function (x) {
            return {
                'A': x['FiIdPuestoBase'] + " - " + x['DescPuestoBase'],
                'F': x['SaldoTP']
            };
        })
        .ToArray();
        var sumN1 = Enumerable.From(subQueryN1).GroupBy("$.A", null,
        function (key, g) {
            var result = {
                currency: key,
                total: g.Sum("$.F")
            }
            return result;
        }).ToArray();
        //sumas de saldos para el nivel 2
        var subQueryN2 = Enumerable.From(jsonRespActual)
        .Select(function (x) {
            return {
                'A': x['FiIdPuestoBase'] + " - " + x['DescribeFuncion'],
                'F': x['SaldoTP']
            };
        })
        .ToArray();
        var sumN2 = Enumerable.From(subQueryN2).GroupBy("$.A", null,
        function (key, g) {
            var result = {
                currency: key,
                total: g.Sum("$.F")
            }
            return result;
        }).ToArray();
        //sumas de saldos para el nivel 3
        var subQueryN3 = Enumerable.From(jsonRespActual)
        .Select(function (x) {
            return {
                'A': x['FiIdPuestoBase'] + " - " + x['Nombre'],
                'F': x['SaldoTP']
            };
        })
        .ToArray();
        var sumN3 = Enumerable.From(subQueryN3).GroupBy("$.A", null,
        function (key, g) {
            var result = {
                currency: key,
                total: g.Sum("$.F")
            }
            return result;
        }).ToArray();
        var sumTotal = parseFloat(Enumerable.From(queryResult).Sum("$.E"));

        var sumTotalBanco = Enumerable.From(puestosBancoTTSm).Sum("$.E");
      
        var sumTotalComercio = Enumerable.From(puestosComercioTTSm).Sum("$.E");

        var totDocBan = Enumerable.From(queryPuestosBanco).Sum("$.DOCS");

        var totDocCom = Enumerable.From(queryPuestosComercio).Sum("$.DOCS");

        var totDocOtr = Enumerable.From(queryPuestosOtros).Sum("$.DOCS");


        //var sumTotalComercio = Enumerable.From(queryPuestosComercio).Sum("$.F");
        var sumTotalOtros = Enumerable.From(puestosOtrosTTSm).Sum("$.F");

        var contN1 = 0, contN2 = -1, contN3 = -1, contN4 = 0; 
        if (formatResultPuestosBanco != 0) {
            //var tabla = '<table style="width:100%;"><tr><td style="width:60%">Puestos de Banco</td><td style="text-align:right;width:88.8%;">' + formatMoney(sumTotalBanco) + '</td></tr></table>' +
            var tabla = '<table class="tblGeneral"><tr><td class="p0 tLeft"><strong>Puestos de Banco</strong></td><td class="tCenter w110 pb"> ' + totDocBan + '</td><td class="tRight w150 p2"><strong>' + formatMoney(sumTotalBanco) + '</strong></td></tr></table>' +
            '<dl class="accordion">';            
            $.each(formatResultPuestosBanco, function (i, p) {
                tabla += '<dt class="AcoInpar">' +
                           '<table class="tblGeneral1">' +
                              '<tr>' +
                                  '<td class="p0 tLeft">' + p.text + '</td>' +
                                   '<td class="tCenter w110 pb p2"> ' + sumN1BancosDoctosN1[contN1].total + '</td>' +
                                  '<td class="tRight pbSaldos w150">' + formatMoney(sumN1PuestosBanco[contN1].total) + '</td>' +
                              '</tr>' +
                            '</table>' +
                        '</dt>' +
               '<dd class="AcoInpar">' +
              '<div class="inner">' +
              '<div class="nivel2">';
                contN1++;
                $.each(p.children, function (i, p) {
                	contN2++;
                    tabla += '<dl class="accordion1">' +
                              '<dt>' +
                                 '<table class="tblGeneral1">' +
                                     '<tr>' +
                                        '<td class="p0"> ' + p.text + '</td>' +
                                        '<td class="tCenter w110 p2"> ' + sumN2BancoDoctos[contN2].total + '</td>' +
                                        '<td class="tRight w150">' + formatMoney(sumN2PuestosBanco[contN2].total) + '</td>' +
                                     '</tr>' +
                                 '</table>' +
                             '</dt>' +
                           '<dd class="AcoInpar">' +
                        '<div class="inner">' +
                    '<div class="nivel3">';
                    
                    $.each(p.children, function (i, p) {
                    	contN3++;
                        tabla += ' <dl class="accordion2">' +
                                     '<dt class="AcoInpar">' +
                                           '<table class="tblGeneral1">' +
                                                   '<tr>' +
                                                        ((((p.text).split("-")[2]).trim() === "1") ? '<td class="p0" >' + (((p.text).split("-")[0]).trim() + " - " + ((p.text).split("-")[1]).trim()).toString() + '</td>' : '<td class="p0 cAz" >' + (((p.text).split("-")[0]).trim() + " - " + ((p.text).split("-")[1]).trim()).toString() + '</td>') +
                                                       '<td class="tCenter w110 p2"> ' + sumN3PuestosBanco[contN3].NumDoctos + '</td>' +
                                                       '<td class="tRight w150">' + formatMoney(sumN3PuestosBanco[contN3].total) + '</td>' +
                                                   '</tr>' +
                                            '</table>' +
                                     '</dt>' +
                                  '<dd class="AcoInpar">' +
                                '<div class="inner">' +
                            '<table class="tblNivel2Actuales t2">';
                        
                        $.each(p.children, function (i, p) {
                            var docSaldos = p.children[0].split("-");
                            tabla +=
                                        '<tr>' +
                                        '<td>' + p.text + '</td>' +
                                        '<td class="tCenter w110 pbTp"> ' + docSaldos[0] + '</td>' +
                                        '<td class="tRight w150 pbSaldos">' + formatMoney(docSaldos[1]) + '</td>' +
                                        '</tr>';
                            contN4++;
                        });
                        tabla += '</table></div></dd>';
                    });
                    tabla += '</dl></div>' +
                         '</div>' +
                    '</dd>' +
                    '<div class="clear"></div>';
                });
                tabla += '</dl></div>' +
                      '</div>' +
                    '</dd>' +
                    '<div class="clear"></div>';
            });
            tabla += '</dl>' + crearActuales();
            tabla = tabla.substring(0, tabla.length - "undefined".length);
            $('#BancoActuales').html(tabla);

        }
        contN1 = 0, contN2 = -1, contN3 = -1;
        if (formatResultPuestosComercio != 0) {
            //var tabla = '<table style="width:100%;"><tr><td style="width:60%">Puestos de Comercio</td><td style="text-align:right;width:88.8%;">' + formatMoney(sumTotalComercio) + '</td></tr></table>' +
            var tabla = '<table class="tblGeneral"><tr><td class="p0 tLeft"><strong>Puestos de Comercio</strong></td><td class="tCenter w110 pb"> ' + totDocCom + '</td><td class="tRight w150 p2"><strong>' + formatMoney(sumTotalComercio) + '</strong></td></tr></table>' +

            '<dl class="accordion">';

            $.each(formatResultPuestosComercio, function (i, p) {
               
                tabla += '<dt class="AcoInpar">' +
                           '<table class="tblGeneral1">' +
                              '<tr>' +
                                  '<td class="p0 tLeft">' + p.text + '</td>' +
                                   '<td class="tCenter w110 pb p2"> ' +  sumN1ComercioDoctosN1[contN1].total + '</td>' +
                                  '<td class="tRight pbSaldos w150">' + formatMoney(sumN1PuestosComercio[contN1].total) + '</td>' +
                              '</tr>' +
                            '</table>' +
                        '</dt>' +
               '<dd class="AcoInpar">' +
              '<div class="inner">' +
              '<div class="nivel2">';
                contN1++;
                $.each(p.children, function (i, p) {
                	contN2++;
                    tabla += '<dl class="accordion1">' +
                              '<dt>' +
                                 '<table class="tblGeneral1">' +
                                     '<tr>' +
                                        '<td class="p0"> ' + p.text + '</td>' +
                                         '<td class="tCenter w110 p2"> ' + sumN2ComercioDoctos[contN2].total + '</td>' +
                                        '<td class="tRight w150">' + formatMoney(sumN2PuestosComercio[contN2].total) + '</td>' +
                                     '</tr>' +
                                 '</table>' +
                             '</dt>' +
                           '<dd class="AcoInpar">' +
                        '<div class="inner">' +
                    '<div class="nivel3">';
                    
                    $.each(p.children, function (i, p) {
                    	contN3++;
                        tabla += ' <dl class="accordion2">' +
                                     '<dt class="AcoInpar">' +
                                           '<table class="tblGeneral1">' +
                                                   '<tr>' +
                                                         ((((p.text).split("-")[2]).trim() === "1") ? '<td class="p0" >' + (((p.text).split("-")[0]).trim() + " - " + ((p.text).split("-")[1]).trim()).toString() + '</td>' : '<td class="p0 cAz" >' + (((p.text).split("-")[0]).trim() + " - " + ((p.text).split("-")[1]).trim()).toString() + '</td>') +
                                                       '<td class="tCenter w110 p2"> ' + sumN3PuestosComercio[contN3].NumDoctos + '</td>' +
                                                       '<td class="tRight w150">' + formatMoney(sumN3PuestosComercio[contN3].total) + '</td>' +
                                                   '</tr>' +
                                            '</table>' +
                                     '</dt>' +
                                  '<dd class="AcoInpar">' +
                                '<div class="inner">' +
                            '<table class="tblNivel2Actuales t2">';
                        
                        $.each(p.children, function (i, p) {
                            var docSaldos = p.children[0].split("-");
                            tabla +=
                                        '<tr>' +
                                        '<td>' + p.text + '</td>' +
                                        '<td class="tCenter w110 pbTp"> ' + docSaldos[0] + '</td>' +
                                        '<td class="tRight w150 pbSaldos">' + formatMoney(docSaldos[1]) + '</td>' +
                                        '</tr>';
                        });
                        tabla += '</table></div></dd>';
                    });
                    tabla += '</dl></div>' +
                         '</div>' +
                    '</dd>' +
                    '<div class="clear"></div>';
                });
                tabla += '</dl></div>' +
                      '</div>' +
                    '</dd>' +
                    '<div class="clear"></div>';
            });
            tabla += '</dl>' ;
            //tabla = tabla.substring(0, tabla.length - "undefined".length);
            $('#ComercioActuales').html(tabla);

        }
        contN1 = 0, contN2 = 0, contN3 = 0;
        if (formatResultPuestosOtros != 0) {
            //var tabla = '<table style="width:100%;"><tr><td style="width:60%"> Otros</td><td style="text-align:right;width:88.8%;">' + formatMoney(sumTotalOtros) + '</td></tr></table>' +
            var tabla = '<table class="tblGeneral"><tr><td class="p0 tLeft">Otros</td><td class="tCenter w110 p2"> ' + totDocOtr + '</td><td class="tRight w150 pb">' + formatMoney(sumTotalOtros) + '</td></tr></table>' +

            '<dl class="accordion">';

            $.each(formatResultPuestosOtros, function (i, p) {
                tabla += '<dt class="AcoInpar">' +
                           '<table class="tblGeneral1">' +
                              '<tr>' +
                                  '<td class="p0 tLeft">' + p.text + '</td>' +
                                   '<td class="tCenter w150 p2"> ' + sumN1OtrosDoctosN1[i].total + '</td>' +
                                  '<td class="tRight w150">' + formatMoney(sumN1Otro[i].total) + '</td>' +
                              '</tr>' +
                            '</table>' +
                        '</dt>' +
               '<dd class="AcoInpar">' +
              '<div class="inner">' +
              '<div class="nivel2">';
                contN1++;
                $.each(p.children, function (i, p) {
                    tabla += '<dl class="accordion1">' +
                              '<dt>' +
                                 '<table class="tblGeneral1">' +
                                     '<tr>' +
                                        '<td class="p0"> ' + p.text + '</td>' +
                                        '<td class="tCenter w150"> ' + sumN2OtrosDoctos[i].total + '</td>' +
                                        '<td class="tRight w150">' + formatMoney(sumN2Otro[i].total) + '</td>' +
                                     '</tr>' +
                                 '</table>' +
                             '</dt>' +
                           '<dd class="AcoInpar">' +
                        '<div class="inner">' +
                    '<div class="nivel3">';
                    contN2++;
                    $.each(p.children, function (i, p) {
                        tabla += ' <dl class="accordion2">' +
                                     '<dt class="AcoInpar">' +
                                           '<table class="tblGeneral1">' +
                                                   '<tr>' +
                                                         ((((p.text).split("-")[2]).trim() === "1") ? '<td class="p0" >' + (((p.text).split("-")[0]).trim() + " - " + ((p.text).split("-")[1]).trim()).toString() + '</td>' : '<td class="p0 cAz" >' + (((p.text).split("-")[0]).trim() + " - " + ((p.text).split("-")[1]).trim()).toString() + '</td>') +
                                                       '<td class="tCenter w150"> ' + sumN3Otro[i].NumDoctos + '</td>' +
                                                       '<td class="tRight w150">' + formatMoney(sumN3Otro[i].total) + '</td>' +
                                                   '</tr>' +
                                            '</table>' +
                                     '</dt>' +
                                  '<dd class="AcoInpar">' +
                                '<div class="inner">' +
                            '<table class="tblNivel2 t2">';
                        contN3++;
                        $.each(p.children, function (i, p) {
                            var docSaldos = p.children[0].split("-");
                            tabla +=
                                        '<tr>' +
                                        '<td>' + p.text + '</td>' +
                                        '<td class="tCenter w150"> ' + docSaldos[0] + '</td>' +
                                        '<td class="w150">' + formatMoney(docSaldos[1]) + '</td>' +
                                        '</tr>';
                        });
                        tabla += '</table></div></dd>';
                    });
                    tabla += '</dl></div>' +
                         '</div>' +
                    '</dd>' +
                    '<div class="clear"></div>';
                });
                tabla += '</dl></div>' +
                      '</div>' +
                    '</dd>' +
                    '<div class="clear"></div>';
            });
            tabla += '</dl>' ;
           // tabla = tabla.substring(0, tabla.length - "undefined".length);
            $('#OtrosActuales').html(tabla);

        }
       
        var tablaTotalSaldAct = "";

        tablaTotalSaldAct += '<table class="tblTotaleSaldos"><tbody>' +
                          '<tr>' +
                              '<td><strong>Total:  </strong></td>' +
                              '<td> <strong> ' + formatMoney(sumTotalBanco + sumTotalComercio + sumTotalOtros) + '</strong></td>' +
                          '</tr>' +
                        '</tbody></table>';
        $('#tablaTotalSaldAct').html(tablaTotalSaldAct);
    }
    mostrarLoading(false);
}

function grouper(propertyName, selector) {
    return function (e) {
        return e.GroupBy("$." + propertyName, null, function (k, g) {
            return {
                text: k,
                children: g.Let(selector).ToArray()
            };
        });
    };
}

function groupBy(array, f) {
    var groups = {};
    array.forEach(function (o) {
        var group = JSON.stringify(f(o));
        groups[group] = groups[group] || [];
        groups[group].push(o);
    });
    return Object.keys(groups).map(function (group) {
        return groups[group];
    })
}
function crearActuales() {
    jQuery(function () {

        var allPanels = $('.accordion > dd').hide();

        jQuery('.accordion > dt').on('click', function () {
            $this = $(this);
            //the target panel content
            $target = $this.next();

            jQuery('.accordion > dt').removeClass('accordion-active');
            if ($target.hasClass("in")) {
                $this.removeClass('accordion-active');
                $target.slideUp();
                $target.removeClass("in");

            } else {
                $this.addClass('accordion-active');
                jQuery('.accordion > dd').removeClass("in");
                $target.addClass("in");
                $(".subSeccion").show();

                jQuery('.accordion > dd').slideUp();
                $target.slideDown();
            }
        });

        var allPanels = $('.accordion1 > dd').hide();

        jQuery('.accordion1 > dt').on('click', function () {
            $this = $(this);
            //the target panel content
            $target = $this.next();

            jQuery('.accordion1 > dt').removeClass('accordion-active');
            if ($target.hasClass("in")) {
                $this.removeClass('accordion-active');
                $target.slideUp();
                $target.removeClass("in");

            } else {
                $this.addClass('accordion-active');
                jQuery('.accordion1 > dd').removeClass("in");
                $target.addClass("in");
                $(".subSeccion").show();

                jQuery('.accordion1 > dd').slideUp();
                $target.slideDown();
            }
        });

        var allPanels = $('.accordion2 > dd').hide();

        jQuery('.accordion2 > dt').on('click', function () {
            $this = $(this);
            //the target panel content
            $target = $this.next();

            jQuery('.accordion2 > dt').removeClass('accordion-active');
            if ($target.hasClass("in")) {
                $this.removeClass('accordion-active');
                $target.slideUp();
                $target.removeClass("in");

            } else {
                $this.addClass('accordion-active');
                jQuery('.accordion2 > dd').removeClass("in");
                $target.addClass("in");
                $(".subSeccion").show();

                jQuery('.accordion2 > dd').slideUp();
                $target.slideDown();
            }
        });
    });
}

function sActCajaActuales(empleado, PerfilActual, divisass) {
    var fechaActual = fechaI();
    
    mostrarLoading(true);
    $.ajax({
        url: getUrlsActuales(urlActCajas),
        contentType: "application/json; charset=UTF-8",
        type: "POST",
        data: JSON.stringify(
            {
                "Opcion": 4,
                "Perfil": ""+PerfilActual,
                "IdTipoDivisa": divisass,
                "Fecha": ""+fechaActual,
                "Empleado": ""+empleado
            }),
        dataType: 'json',
        crossDomain: true,
        success: function (data) {
            InicialCajaActual(data);
            mostrarLoading(false);
        },
        error: function () {
            // alert(data);
            $("#TablaSalIniCaja").text("Error en el consumo del servicio ");
            mostrarLoading(false);
        }
    });
}
function InicialCajaActual(respuestaCajas) {
    var suma = 0;
    if (respuestaCajas.NoError == 0) {
        RespCajasActuales(respuestaCajas.Respuesta);
    }
    else if (respuestaCajas.NoError == 1) {
        document.getElementById("TablaSalIniCaja").innerHTML = respuestaCajas.Descripcion;
    } else if (respuestaCajas.Respuesta == 3) {
        document.getElementById("TablaSalIniCaja").innerHTML = respuestaCajas.Descripcion;
    } else {
        document.getElementById("TablaSalIniCaja").innerHTML = "Intente mas tarde.";
    }
}
function RespCajasActuales(json) {
    mostrarLoading(true);
    var tabla2 = '';
    var queryResultC = Enumerable.From(json)
    .Select(function (x) {
        return {
            'A': x['FiCjId'] + " - " + x['FcCjDesc'],
            'B': x['FiTipoPago'] + " - " + x['FcTpagDesc'],
            'C': x['SaldoTP']

        };
    })
    .ToArray();

    var queryResultSumC = Enumerable.From(json)
       .Select(function (x) {
           return {
               'A': x['FcCjDesc'],
               'C': x['SaldoActCaja']
           };
       })
       .ToArray();

    var sqCajaSum3 = Enumerable.From(queryResultSumC).GroupBy("$.A", null,
             function (key, g) {
                 return {
                     A: Enumerable.From(g.source).FirstOrDefault().A,
                     C: Enumerable.From(g.source).FirstOrDefault().C
                 };
             }).ToArray();


    var formatResult = Enumerable.From(queryResultC)
       .Let(grouper('A', function (g1) {
           return g1.Let(grouper('B', function (g2) {
               return g2.Select("$.C").ToArray();
           }));
       }))
    .ToArray();


    //sumas de saldos para el nivel 3
    var subQueryN3 = Enumerable.From(json)
        .Select(function (x) {
            return {
                'A': x['FiCjId'] + " - " + x['FcCjDesc'],
                'F': x['SaldoActCaja']
            };
        })
        .ToArray();

    var sqCajan3 = Enumerable.From(subQueryN3).GroupBy("$.A", null,
            function (key, g) {
                return {
                    F: Enumerable.From(g.source).FirstOrDefault().F,
                    A: Enumerable.From(g.source).FirstOrDefault().A
                };
            }).ToArray();

    var sumN3 = Enumerable.From(sqCajan3).GroupBy("$.A", null,
    function (key, g) {
        var result = {
            currency: key,
            total: g.Sum("$.F")
        }
        return result;
    }).ToArray();



    var sumTotal = Enumerable.From(sqCajaSum3).Sum("$.C");
    var contN1 = 0;
    var sum = sumTotal;
    tabla2 = '<dl class="accordion1Caja">';
    $.each(formatResult, function (i, p) {   //NIVEL1
        tabla2 += '<dt class="AcoInpar">' +
                   '<table class="tblGeneral1">' +
                      '<tr>' +
                          '<td class="p0 tLeft">' + p.text + '</td>' +
                          '<td class="tRight w180" style="margin-right:100px;"> ' + formatMoney(sumN3[contN1].total) + '</td>' +
                      '</tr>' +
                    '</table>' +
                '</dt>' +
       '<dd>' +
       '<div class="nivel1"><table class="tblNivel11"><tbody>';
        contN1++;
        $.each(p.children, function (i, p) {//nivel2
            tabla2 += '<tr>' +
                      '<td>' + p.text + '</td>' +
                      '<td class="w180" >' + formatMoney(p.children) + '</td>' +
                     '</tr>';


        });
        tabla2 += '</tbody></table></div></dd>';
    });

    tabla2 += '</dl>' + cajasAcordionActuales();
    tabla2 = tabla2.substring(0, tabla2.length - "undefined".length);
    $('#SaldoscajasActuales').html(tabla2);
    var tablaTotalCajasIni2 = "";
    tablaTotalCajasIni2 += '<table class="tblTotalesCaja"><tbody>' +
                      '<tr>' +
                          '<td><strong>Total:  </strong></td>' +
                          '<td> <strong>' + formatMoney(sum) + '</strong></td>' +
                      '</tr>' +
                    '</tbody></table>';
    $('#tablaTotalCajasIni2').html(tablaTotalCajasIni2);
    mostrarLoading(false);
}
function cajasAcordionActuales() {
    mostrarLoading(true);
    jQuery(function () {

        var allPanels = $('.accordion1Caja > dd').hide();

        jQuery('.accordion1Caja > dt').on('click', function () {
            $this = $(this);
            //the target panel content
            $target = $this.next();

            jQuery('.accordion1Caja > dt').removeClass('accordionCaja-active');
            if ($target.hasClass("in")) {
                $this.removeClass('accordionCaja-active');
                $target.slideUp();
                $target.removeClass("in");

            } else {
                $this.addClass('accordionCaja-active');
                jQuery('.accordion1Caja > dd').removeClass("in");
                $target.addClass("in");
                $(".subSeccion").show();

                jQuery('.accordion1Caja > dd').slideUp();
                $target.slideDown();
            }
        });

        var allPanels = $('.accordion12 > dd').hide();

        jQuery('.accordion12 > dt').on('click', function () {
            $this = $(this);
            //the target panel content
            $target = $this.next();

            jQuery('.accordion12 > dt').removeClass('accordion-active');
            if ($target.hasClass("in")) {
                $this.removeClass('accordion-active');
                $target.slideUp();
                $target.removeClass("in");

            } else {
                $this.addClass('accordion-active');
                jQuery('.accordion12 > dd').removeClass("in");
                $target.addClass("in");
                $(".subSeccion").show();

                jQuery('.accordion12 > dd').slideUp();
                $target.slideDown();
            }
        });

        var allPanels = $('.accordion21 > dd').hide();

        jQuery('.accordion21 > dt').on('click', function () {
            $this = $(this);
            //the target panel content
            $target = $this.next();

            jQuery('.accordion21 > dt').removeClass('accordion-active');
            if ($target.hasClass("in")) {
                $this.removeClass('accordion-active');
                $target.slideUp();
                $target.removeClass("in");

            } else {
                $this.addClass('accordion-active');
                jQuery('.accordion21 > dd').removeClass("in");
                $target.addClass("in");
                $(".subSeccion").show();

                jQuery('.accordion21 > dd').slideUp();
                $target.slideDown();
            }
        });
    });
    mostrarLoading(false);
}


