﻿
				$(document).ready(function() {
				    $j("#owl-demo").owlCarousel({
				        pagination: false,
				        navigation: false,
				        autoPlay: 6000,
				        items: 4,
				        navigationText: [
							"<img src='../../Imgs/slider/btnIzquierda.png'>",
							"<img src='../../imgs/slider/btnDerecha.png'>"
				        ]
				    });
				    read();
				    caro();
				});

				function read() {
				    $(document).ready(function () {

				        $j(".normal_select").dropkick({
				            mobile: true
				        });


				        //Modales
				        $('.modal01_view').click(function () {
				            $('#modal01').modal();
				            return false;
				        });

				        $('.modal02_view').click(function () {
				            $('#modal02').modal();
				            return false;
				        });

				        $('.modal03_view').click(function () {
				            $('#modal03').modal();
				            return false;
				        });
				    });
				}
				function caro() {
				    jQuery(function () {

				        var allPanels = $('.accordion > dd').hide();

				        jQuery('.accordion > dt').on('click', function () {
				            $this = $(this);
				            //the target panel content
				            $target = $this.next();

				            jQuery('.accordion > dt').removeClass('accordion-active');
				            if ($target.hasClass("in")) {
				                $this.removeClass('accordion-active');
				                $target.slideUp();
				                $target.removeClass("in");

				            } else {
				                $this.addClass('accordion-active');
				                jQuery('.accordion > dd').removeClass("in");
				                $target.addClass("in");
				                $(".subSeccion").show();

				                jQuery('.accordion > dd').slideUp();
				                $target.slideDown();
				            }
				        });

				        var allPanels = $('.accordion1 > dd').hide();

				        jQuery('.accordion1 > dt').on('click', function () {
				            $this = $(this);
				            //the target panel content
				            $target = $this.next();

				            jQuery('.accordion1 > dt').removeClass('accordion-active');
				            if ($target.hasClass("in")) {
				                $this.removeClass('accordion-active');
				                $target.slideUp();
				                $target.removeClass("in");

				            } else {
				                $this.addClass('accordion-active');
				                jQuery('.accordion1 > dd').removeClass("in");
				                $target.addClass("in");
				                $(".subSeccion").show();

				                jQuery('.accordion1 > dd').slideUp();
				                $target.slideDown();
				            }
				        });

				        var allPanels = $('.accordion2 > dd').hide();

				        jQuery('.accordion2 > dt').on('click', function () {
				            $this = $(this);
				            //the target panel content
				            $target = $this.next();

				            jQuery('.accordion2 > dt').removeClass('accordion-active');
				            if ($target.hasClass("in")) {
				                $this.removeClass('accordion-active');
				                $target.slideUp();
				                $target.removeClass("in");

				            } else {
				                $this.addClass('accordion-active');
				                jQuery('.accordion2 > dd').removeClass("in");
				                $target.addClass("in");
				                $(".subSeccion").show();

				                jQuery('.accordion2 > dd').slideUp();
				                $target.slideDown();
				            }
				        });
				    });

				}