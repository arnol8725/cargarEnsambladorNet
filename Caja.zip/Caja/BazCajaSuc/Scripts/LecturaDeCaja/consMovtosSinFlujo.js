﻿var pantallaCargada = false;
var urlMtosSf = "LecturaCaja/LecturaDeCaja.svc/wsLecturaMovtosSinFlujo";
var btnImp = "LecturaCaja/LecturaDeCaja.svc/wsLecturaMovtosSinFlujo"
var PerfilSinFlujo;
var seleccionDivisaSF;
var usrMtosSF;
var canImp = false;
var urlPerfilMovtosSinflujo = "LecturaCaja/lecturaDeCaja.svc/wsLecturaPerfiles";
function getUrlsMovtosSflujo(serv) {
    var url = "";
    if (window.location.hostname == "localhost") {
        url = "http://10.54.28.226:9014/Caja/Servicios/" + serv;
    } else {
        url = "http://" + window.location.hostname + ":9014/Caja/Servicios/" + serv;
    }
    return url;
}
function extreDivisaSWinFlujo() {
    var seleccionDivisa2 = $('#selector1 option:selected').text();
    seleccionDivisaSF = seleccionDivisa2;
}
function ServicePerfilesSF() {
    mostrarLoading(true);
    var host1 = getUrlBase();
    $.ajax({
        url: getUrlsMovtosSflujo(urlPerfilMovtosSinflujo),
        contentType: "application/json; charset=UTF-8",
        type: "POST",
        data: JSON.stringify({
            "NoEmpleado": "" + getUrlVars()["usuario"],
        }),
        dataType: 'json',
        crossDomain: true,
        success: function (data) {
            PerfilSinFlujo = data.Respuesta;
            mostrarLoading(false);
            return data.Respuesta;
        },
        error: function () {
            $("#bMensaje").text("Ocurrió un error en el consumo del servicio.");
        }
    });
}
function serviceConsMovtosSinFlujo(usuario, perfil, divisa) {
    var fecha = fechaI();
    mostrarLoading(true);
    ServicePerfilesSF();
    $.ajax({
        url: getUrls(urlMtosSf),
        contentType: "application/json; charset=UTF-8",
        type: "POST",
        data: JSON.stringify(
            {
                "OpcionOT": 1,
                "OpcionEmpleados": 2,
                "Perfil": ""+perfil,
                "IdTipoDiv": divisa,
                "Inicio": fecha,
                "TipoOperacion": 0,
                "Imprime":false
            }),
        dataType: 'json',
        crossDomain: true,
        success: function (data) {
            if (data.RespuestaEmpleados.length!=0 || data.RespuestaTO !=null) {
                obtieneImportesEmpleados(data);
                canImp = true;
            } else {
                alert("No hay movimientos");
                $('#tablaTipoOperacion').html("");
                $('#tablaEmpleados').html("");
                canImp = false;
            }
                
            mostrarLoading(false);
        },
        error: function () {
            // alert(data);
            $("#rev").text("Error en el consumo del servicio ");
            mostrarLoading(false);
            canImp = false;
        }
    });
}
//boton imprimir movtos sin flujo
function botonImprimir() {
    mostrarLoading(true);
    if (!canImp) {
        alert('No existe información para imprimir');
    } else {
        extreDivisaSWinFlujo();
        ServicePerfilesSF();
        var fecha = fechaI();
        var emp = getUrlVars()["usuario"];
        var rul = getUrls(urlMtosSf);
        var divisass;
        var seleccionDivisa2 = $('#selector1 option:selected').text();
        seleccionDivisaMC = seleccionDivisa2;
        if (seleccionDivisaMC == "Moneda Nacional") {
            divisass = 1;
        } else if (seleccionDivisaMC == "Dolar Americano") {
            divisass = 2;
        } else if (seleccionDivisaMC == "Onza Libertad de Plata") {
            divisass = 3;
        } else if (seleccionDivisaMC == "Dolar Canadiense") {
            divisass = 5;
        } else if (seleccionDivisaMC == "Euros") {
            divisass = 7;
        }
        $.ajax({
            url: rul,
            contentType: "application/json; charset=UTF-8",
            type: "POST",
            data: JSON.stringify(
                {
                    "OpcionOT": 1,
                    "Empleado": "" + emp,
                    "OpcionEmpleados": 2,
                    "Perfil": "" + PerfilSinFlujo,
                    "IdTipoDiv": divisass,
                    "Inicio": "" + fecha,
                    "TipoOperacion": 0,
                    "Imprime": true,
                    "NoEmpleado": "" + emp,
                    "TipoDivisa": "" + seleccionDivisaSF
                }
                ),
            dataType: 'json',
            crossDomain: true,
            success: function (data) {
                imprimirCarta(data.RutaPDF);
            },
            error: function () {
                // alert(data);
                $("#rev").text("Error en el consumo del servicio ");
            }
        });
    }
    mostrarLoading(false);
}

function obtieneImportesEmpleados(jsonResp) {
   
    var suma = 0;
    if (jsonResp.NoError == 0) {
        respObtieneImportesEmpleados2(jsonResp);
    }
    else if (jsonResp.NoError == 1) {
        document.getElementById("tablaEmpleados").innerHTML = jsonResp.Descripcion;
    } else if (jsonResp.Descripcion == 3) {
        document.getElementById("tablaEmpleados").innerHTML = jsonResp.Descripcion;
    } else {
        document.getElementById("tablaEmpleados").innerHTML = "Intente mas tarde.";
    }
}

function formatMoney(num) {
    var p = Number(num).toFixed(2).split(".");
    return divisa_symbol + " " + p[0].split("").reverse().reduce(function (acc, num, i, orig) {
        return num == "-" ? acc : num + (i && !(i % 3) ? "," : "") + acc;
    }, "") + "." + p[1];
}


function respObtieneImportesEmpleados2(jsonMsF) {
    mostrarLoading(true);
    var fechaSel = $('#datepicker').val();

        var queryTO = Enumerable.From(jsonMsF.RespuestaTO)
        .Select(function (x) {
            return {
                'CuentaOp': x['CuentaOp'],
                'DescTOP': x['DescTOP'],
                'MontoOp': x['MontoOp']
            };
        })
        .ToArray();
        var queryEmpleados = Enumerable.From(jsonMsF.RespuestaEmpleados)
        .OrderBy(function (x) { return x.FdOperacion })
        .Select(function (x) {
            return {
                'FiNoPedido': x['FiNoPedido'],
                'FcUsuario': x['FcUsuario'],
                'FcEmpNom': x['FcEmpNom'],
                'FcEmpApm': x['FcEmpApm'],
                'FcEmpApp': x['FcEmpApp'],
                'FnImporte': x['FnImporte'],
                'FdOperacion': fechaSel +' '+ x['FdOperacion']
            };
        })
        .ToArray();
        var tablaTipoOperacion = '<table class="tblGeneralFlujo"><tbody>' +
             '<tr>' +
              '<th >No. Operaciones</th>' +
               '<th >Tipo Operación</th>' +
                '<th >Importe Total</th>' +
                 '</tr>';
        var tablaEmpleados = '<table class="tblGeneralFlujo"><tbody>' +
            '<tr>' +
                      '<th>No. Operaciones</th>' +
                      '<th>Empleado</th>' +
                      '<th>Fecha/Hora</th>' +
                      '<th>Importe</th>' +
                   '</tr>';
        $.each(queryTO, function (i, p) {
            tablaTipoOperacion +=
                          '<tr>' +
                               '<td>' + queryTO[i].CuentaOp.toString().trim() + '</td>' +
                               '<td>' + queryTO[i].DescTOP.toString().trim() + '</td>' +
                               '<td align="right">' + formatMoney(queryTO[i].MontoOp.toString().trim()) + '</td>' +
                          '</tr>';

        });



        $.each(queryEmpleados, function (i, p) {
            tablaEmpleados +=
                          '<tr>' +
                               '<td>' + queryEmpleados[i].FiNoPedido.toString().trim() + '</td>' +
                               '<td>' + queryEmpleados[i].FcUsuario.toString().trim() + " - " +
                               queryEmpleados[i].FcEmpNom.toString().trim() + " " +
                               queryEmpleados[i].FcEmpApm.toString().trim() + " " +
                               queryEmpleados[i].FcEmpApp.toString().trim() + '</td>' +
                               '<td>' + queryEmpleados[i].FdOperacion.toString().trim() + '</td>' +
                               '<td align="right">' + formatMoney(queryEmpleados[i].FnImporte) + '</td>' +
                          '</tr>';

        });
        tablaTipoOperacion += '</tbody></table>';

        tablaEmpleados += '</body></table>';
        $('#tablaTipoOperacion').html(tablaTipoOperacion);
        $('#tablaEmpleados').html(tablaEmpleados);
    //}
        mostrarLoading(false);
}

function grouper(propertyName, selector) {
    return function (e) {
        return e.GroupBy("$." + propertyName, null, function (k, g) {
            return {
                text: k,
                children: g.Let(selector).ToArray()
            };
        });
    };
}

function groupBy(array, f) {
    var groups = {};
    array.forEach(function (o) {
        var group = JSON.stringify(f(o));
        groups[group] = groups[group] || [];
        groups[group].push(o);
    });
    return Object.keys(groups).map(function (group) {
        return groups[group];
    })
}



