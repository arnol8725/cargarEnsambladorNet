﻿if ($j === undefined) { var $j = jQuery.noConflict(true); console.log($().jquery); console.log($j().jquery); }
//Este archivo se debe listar ANTES del js de InformesCaja.js dentro del archivo InformesCaja.html
/////////////////////////////////////Métodos para usar Servicios////////////////////////////////////////////////

const ServidorPrueba = "10.54.28.222";
const PuertoPrueba = "9014";

//funciòn que obtiene la URL completa de un servicio dependiendo del entorno donde se ejecute
function GetUrlSvc(rutaMetodo) {
    var url = "";
    if (window.location.hostname == "localhost") {
        url = "http://" + ServidorPrueba + ":" + PuertoPrueba + "/Caja/Servicios/" + rutaMetodo;
    } else {
        url = "http://" + window.location.hostname + ":9014/Caja/Servicios/" + rutaMetodo;
    }
    return url;
}

//funcion para consumir un servicio web:
//-url: url completa del servicio que se va a consumir. Debe definirse.
//-objEntrada: objeto JSON de entrada. Puede dejarse sin definir o en null si los siguientes parametros sí definen.
//-nombreError: Si el parametro de Numero de error tiene un nombre distinto a 'NoError', se puede definir el nombre aquí. Puede dejarse sin definir.
//-nombreDescripcion: Si el parametro de descripción de error tiene un nombre distinto a 'Descripcion', se puede definir el nombre aquí. Puede dejarse sin definir.
function ConsumirServicio(url, objEntrada, nombreError, nombreDescripcion) {

    if (objEntrada === undefined || objEntrada === null)
        objEntrada = {}
    if (nombreError === undefined || nombreError === null)
        nombreError = 'NoError'
    if (nombreDescripcion === undefined || nombreDescripcion === null)
        nombreDescripcion = 'Descripcion'
    var objRespuesta = {}
    Object.defineProperty(objRespuesta, nombreError, { enumerable: true, configurable: true, writable: true, value: null });
    Object.defineProperty(objRespuesta, nombreDescripcion, { enumerable: true, configurable: true, writable: true, value: null });
    $.ajax({
        url: "" + url,
        contentType: "application/json; charset=UTF-8",
        type: "POST",
        async: false,
        data: JSON.stringify(objEntrada),
        dataType: 'json',
        crossDomain: true,
        success: function (data) {
            objRespuesta = data;
        },
        error: function () {
            objRespuesta[nombreError] = 2; //codigo 2 significa que el error fue al contactar al servicio.
            objRespuesta[nombreDescripcion] = "No se pudo contactar al servicio o hubo error en el request.";
        }
    });
    return objRespuesta;
}

/////////////////////////////////////Funciones para mostrar mensajes///////////////////////////////////////////////////

//esta variable es para que la instrucción de mostrarCarga de util.js funcione correctamente.
var pantallaCargada = false;

var refFuncError = null;
var refFuncMensaje = null;
var refFuncAceptar = null;
var refFuncCancelar = null;

// Función para disparar un mensaje de advertencia de error
//-mensaje: mensaje principal que se va a mostrar en la ventana
//-causa: explica la causa del error (muestra 'Error de <causa>:')
//-textoBoton: texto que va a ir dentro del boton. Puede dejarse sin definir o con null si se definen los siguientes argumentos.
//-cierraVentana: si al darle clic, la ventana se va a cerrar o no. Por defecto cierra la ventana. Puede dejarse sin definir o con null si se definen los siguientes argumentos.
//-refE: funcion (sin argumentos) que se va a ejecutar al ponerle clic al botón que aparece en la ventana. Puede dejarse sin definir.
function DispararError(mensaje, causa, textoBoton, cierraVentana, refE) {
    refFuncError = (refE === undefined) ? null : refE;
    if (textoBoton === undefined || textoBoton === null)
        $('#textoBotonError').html('Cerrar');
    else
        $('#textoBotonError').html(textoBoton);
    if (cierraVentana === undefined || cierraVentana === null)
        cierraVentana = true;
    if (cierraVentana === true)
        $('#errorBoton').addClass('simplemodal-close');
    $('#errorTitulo').html('Error de ' + causa + ':');
    $('#errorTexto').html(mensaje);
    $j('#modalError').modal({ escClose: false });
}

// Función para disparar un mensaje al usuario
//-mensaje: mensaje principal que se va a mostrar en la ventana
//-refM: funcion (sin argumentos) que se va a ejecutar al ponerle clic al botón que aparece en la ventana. Puede dejarse sin definir.
function DispararMensaje(mensaje, refM) {
    refFuncMensaje = (refM === undefined) ? null : refM;
    $('#mensajeTitulo').html('Mensaje del sistema:');
    $('#mensajeTexto').html(mensaje);
    $j('#modalMensaje').modal({ escClose: false });
}

// Función para disparar una ventana para confirmar una decisión
//-mensaje: mensaje principal que se va a mostrar en la ventana
//-refA: funcion (sin argumentos) que se va a ejecutar al ponerle clic al botón 'aceptar'. Puede dejarse sin definir.
//-refC: funcion (sin argumentos) que se va a ejecutar al ponerle clic al botón 'cancelar'. Puede dejarse sin definir.
//-mensA: texto que aparece dentro del boton 'aceptar'. Puede dejarse sin definir. Por defecto el botón dice 'Aceptar'.
//-mensC: texto que aparece dentro del boton 'cancelar'. Puede dejarse sin definir. Por defecto el botón dice 'Cancelar'.
function DispararConfirmacion(mensaje, refA, refC, mensA, mensC) {
    refFuncAceptar = (refA === undefined) ? null : refA;
    refFuncCancelar = (refC === undefined) ? null : refC;
    if (mensA !== undefined) //si esta definido
        $('#mensA').html(mensA);
    if (mensC !== undefined) //si esta definido
        $('#mensC').html(mensC);
    $('#confTitulo').html('Mensaje del sistema:');
    $('#confTexto').html(mensaje);
    $j('#modalConfirmacion').modal({ escClose: false });
}

function botonDiagError() {
    if (refFuncError != null)
        refFuncError();
}

function botonDiagMensaje() {
    if (refFuncMensaje != null)
        refFuncMensaje();
}

function botonDiagAceptar() {
    if (refFuncAceptar != null)
        refFuncAceptar();
}

function botonDiagCancelar() {
    if (refFuncCancelar != null)
        refFuncCancelar();
}

function CerrarAplicativo() {
    try {
        window.close();
    } catch (err) {
        alert('La ventana debería cerrarse, Error: ' + err);
    }
}

/////////////////////////////////////Funciones de utilidad para informes de caja///////////////////////////////////////

Number.prototype.formatMoney = function (c, d, t) {
    var n = this,
        c = isNaN(c = Math.abs(c)) ? 2 : c,
        d = d == undefined ? "." : d,
        t = t == undefined ? "," : t,
        s = n < 0 ? "-" : "",
        i = String(parseInt(n = Math.abs(Number(n) || 0).toFixed(c))),
        j = (j = i.length) > 3 ? j % 3 : 0;
    return s + (j ? i.substr(0, j) + t : "") + i.substr(j).replace(/(\d{3})(?=\d)/g, "$1" + t) + (c ? d + Math.abs(n - i).toFixed(c).slice(2) : "");
};

//imprimir un valor monetario con el formato correcto, dependiendo de la divias
function formatoDinero(numero, divisaID) {
    numero = Number(numero);
    return (divisaID == "3") ? pi_objDivisas[divisaID].Simbolo + ' ' + numero : pi_objDivisas[divisaID].Simbolo + (numero).formatMoney(2);
}

function ObtenerFormatoHora(hora) {
    if (hora == '' || hora == null)
        return '';
    try{
        let arr = hora.split(':');
        let time = new Date(2018, 1, 1, Number(arr[0]), Number(arr[1]), 0, 0);
        return time.toLocaleString('en-US', { hour: 'numeric', minute: 'numeric', hour12: true })
    } catch (e) {
        return hora;
    }
}

function isNumberKey(evt) {
    var charCode = (evt.which) ? evt.which : evt.keyCode
    if (charCode > 31 && (charCode < 48 || charCode > 57))
        return false;
    return true;
}

function isNumberDecimalKey(evt) {
    var charCode = (evt.which) ? evt.which : evt.keyCode
    if (charCode > 31 && (charCode < 48 || charCode > 57) && charCode != 46)
        return false;
    return true;
}

function toFixedJ(num, fixed) {
    var re = new RegExp('^-?\\d+(?:\.\\d{0,' + (fixed || -1) + '})?');
    return num.toString().match(re)[0];
}

function pad(number, length) {
    var str = '' + number;
    while (str.length < length)
        str = '0' + str;
    return str;
}