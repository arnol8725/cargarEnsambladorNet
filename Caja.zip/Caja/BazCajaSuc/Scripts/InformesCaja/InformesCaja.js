﻿//parámetros generales
var pg_empleadoID = null;
var pg_opcion = null;
var pg_empleadoAut = null;
var pg_hora = null;
var pg_cajaNombre = null;

//parámetros para los datos de informes
var pi_nombreOperacion = "";
var pi_objInforme = null;
var pi_objDivisas = [];
var pi_objSaldos = null;
var pi_objFaltSobr = null;
var pi_objDotacion = null;
var pi_objRecoleccion = null;
var pi_objDiferencias = null;
var pi_Booleanos = {
    "HaySobrantes": 0,
    "HayFaltantes": 0,
    "HayDotaciones": 0,
    "HayRecolecciones": 0,
    "HaySdosInactivos": 0,
    "HaySdosActivos": 0
}

//variables para guardar variables de datos necesarias
var pd_DescripcionPuesto = '';
var pd_Fecha = '';
var pd_NombreEmpleado = '';
var pd_NoTienda = '';
var pd_NombreTienda = '';
var pd_NombreAut = '';
var pd_HrApertura = '';
var pd_HrCierre = '';

//primera función que se ejecuta
$(document).ready(function () {
    $('#contCuadrosCaja').hide();
    $('#contCuadrosEmp').hide();
    var date = new Date();
    $('#tagHora').html(pad(date.getHours(),2) + ":" + pad(date.getMinutes(), 2));
    $('#tagFecha').html(pad(date.getDate(),2) + "/" + pad((date.getMonth() + 1),2) + "/" + date.getFullYear());
    $('.lblFechaInforme').html("Fecha de Informe: " + pad(date.getDate(), 2) + "/" + pad((date.getMonth() + 1), 2) + "/" + date.getFullYear());

    pg_empleadoID = getUrlVars()["empleado"];
    pg_opcion = getUrlVars()["accion"];
    pg_empleadoAut = pg_empleadoID; //getUrlVars()["empaut"]; //TEMP en lo que encontramos de donde sale este dato
    pg_cajaNombre = getUrlVars()["ws"];
    if (pg_empleadoID === undefined || pg_empleadoID == ""
        || pg_opcion === undefined || pg_opcion == ""
        || pg_cajaNombre === undefined || pg_cajaNombre == "") {
        DispararError("Los parámetros no son correctos.", 'parámetros de la URL', null, false, CerrarAplicativo);
        return;
    }
    //hay que asegurarse que los parametros que pasamos no tengan un #
    pg_empleadoID = pg_empleadoID.toString().replace('#', '');
    pg_opcion = Number(pg_opcion.toString().replace('#', ''));
    //pg_empleadoAut = pg_empleadoAut.toString().replace('#', '');
    pg_hora = pad(date.getHours(), 2) + ":" + pad(date.getMinutes(), 2);
    pg_cajaNombre = pg_cajaNombre.toString().replace('#', '');
    
    if (!(pg_opcion >= 1 && pg_opcion <= 11)) { //si la opción no está en el rango permitido
        DispararError("No existe la opción " + pg_opcion + ".", 'parámetro de opción', null, false, CerrarAplicativo);
        return;
    }

    //si es par, es empleado, si es impar, es caja
    if ((pg_opcion % 2) == 0)
        $('#contCuadrosEmp').show();
    else
        $('#contCuadrosCaja').show();

    mostrarCarga(true); //pantalla carga inicia
    setTimeout(function () {
        //cargar servicio de empleado
        let obj = Cons_InfoEmpleado(pg_empleadoID);
        if (obj.NoError != 0) {
            DispararError("No se pudo traer la información del empleado.", 'consulta de empleado', null, false, CerrarAplicativo);
            mostrarCarga(false);
            return;
        }
        $('#tagEstacion').html(pg_cajaNombre + " -");
        $('#tagEmpNombre').html(obj.InformacionInicial.NombreEmpleado);
        $('.lblNombreEmp').html(obj.InformacionInicial.NombreEmpleado);
        $('#tagEmpDescripcion').html(obj.InformacionInicial.DescripcionPBase);
        //pg_empleadoPuesto = obj.InformacionInicial.PuestoRol;
        $('.lblNumRolEmp').html(pg_empleadoID + ' - ' + obj.InformacionInicial.PuestoRol + ' ' + obj.InformacionInicial.DescripcionPBase);
        $('#tagNumTienda').html(obj.InformacionInicial.NoTienda);
        $('#tagNombreTienda').html(obj.InformacionInicial.NombreTienda);
        $('#tagPais').html(obj.InformacionInicial.DescripcionPais);

        pd_DescripcionPuesto = obj.InformacionInicial.DescripcionPBase;
        pd_Fecha = pad(date.getDate(),2) + "/" + pad((date.getMonth() + 1),2) + "/" + date.getFullYear();
        pd_NombreEmpleado = obj.InformacionInicial.NombreEmpleado;
        pd_NoTienda = obj.InformacionInicial.NoTienda;
        pd_NombreTienda = obj.InformacionInicial.NombreTienda;

        //cargar info de divisas

        obj = Cons_InfoDivisas();
        
        if (obj.NoError != 0) { // si no se trajo correctamente
            for (let i = 0; i < 8 ; i++) {
                pi_objDivisas.push({
                    "Descripcion": "Moneda Nacional",
                    "DescripcionCorta": "PESOS",
                    "EsMoneda": false,
                    "Id": i,
                    "Imagen": "FlgMexico.Ico",
                    "Leyenda": "PESOS|M.N.|PESO|,|.",
                    "Simbolo": "$"
                });
            }
        } else { // si se trajo correctamente el objeto de divisas
            let indice = 0;
            for (let i = 0; i < obj.Divisas.length ;) {
                if (obj.Divisas[i].Id == indice) {
                    pi_objDivisas.push(obj.Divisas[i]);
                    i++;
                } else { //en indices donde no hay divisas solo agrega la divisa de pesos, como placeholder
                    pi_objDivisas.push({
                        "Descripcion": "Moneda Nacional",
                        "DescripcionCorta": "PESOS",
                        "EsMoneda": false,
                        "Id": indice,
                        "Imagen": "FlgMexico.Ico",
                        "Leyenda": "PESOS|M.N.|PESO|,|.",
                        "Simbolo": "$"
                    });
                }
                indice++;
            }
        }

        //cargar servicio para traer datos iniciales

        obj = pi_objInforme = Cons_DatosInforme();
        
        if(obj.NoError != 0){
            DispararError("No se pudieron traer los datos del informe.", 'informe de caja', null, false, CerrarAplicativo);
            mostrarCarga(false);
            return;
        }
        let imprime2Cols = (pg_opcion == 1 || pg_opcion == 2 || pg_opcion == 9 || pg_opcion == 10); //si el dato se imprime en dos columnas
        let tabla = "";
        let nombreEstiloDato = ""; //esta variable es para determinar el estilo de los datos que se van a mostrar en la tabla
        let divisaActual = "";
        let datos = null; //objeto para no hacer las lineas de codigo tan largas dentro del for
        if (imprime2Cols)
            tabla += "<tbody><tr><th>Tipos de pago</th><th>&nbsp;</th><th>&nbsp;</th><th>&nbsp;</th><th>Saldo actual</th><th>Tope</th></tr>";
        else
            tabla += "<tbody><tr><th>Tipos de pago</th><th>Saldo actual</th><th>Ingresos</th><th>Egresos</th><th>Saldo final</th><th>Tope</th></tr>";
        //imprimir los datos que se trajeron

        //primero se va a imprimir efectivo
        tabla += '<tr><td colspan="6"><div class="tittbl1">' + obj.TiposPago[0].Nombre + '</div></td></tr>'
        for (let j = 0; j < obj.TiposPago[0].Divisas.length ; j++) { //por cada divisa dentro de efectivo
            divisaActual = obj.TiposPago[0].Divisas[j].idDivisa;
            if (pg_opcion % 2 == 0) { // si es opcion de empleado, imprimir con 2 niveles, si no, imprimir con 3 niveles
                nombreEstiloDato = "tittbl2";
            } else {
                nombreEstiloDato = "tittbl3";
                tabla += '<tr><td><div class="tittbl2">' + obj.TiposPago[0].Divisas[j].Descripcion + '</div></td><td colspan="5">&nbsp;</td></tr>';
            }
            datos = obj.TiposPago[0].Divisas[j].Datos;
            for (let k = 0; k < datos.length ; k++) { //para cada uno de los datos
                tabla += '<tr><td><div class="' + nombreEstiloDato + '">' + ((pg_opcion % 2 == 0) ? obj.TiposPago[0].Divisas[j].Descripcion : datos[k].DescCaja) + '</div></td>' +
                    '<td>' + (imprime2Cols ? "&nbsp;" : formatoDinero(datos[k].SaldoActual, divisaActual)) + '</td>' +
                    '<td>' + (imprime2Cols ? "&nbsp;" : formatoDinero(datos[k].Ingresos, divisaActual)) + '</td>' +
                    '<td>' + (imprime2Cols ? "&nbsp;" : formatoDinero(datos[k].Egresos, divisaActual)) + '</td>' +
                    '<td>' + (imprime2Cols ? formatoDinero(datos[k].SaldoActual, divisaActual) : formatoDinero(datos[k].SaldoFinal, divisaActual)) + '</td>' +
                    '<td>' + formatoDinero(datos[k].Tope, divisaActual) + '</td></tr>'
            }
        }
        //luego se va a imprimir caja documentos, usamos otras variables para poner la tabla de esta seccion
        let tablaEspeciales = "";
        let tablaResto = "";
        let reg = "";
        let chequeImpreso = '<tr><td><div class="tittbl2">Cheques</div></td><td colspan="5">&nbsp;</td></tr>';
        let ticketImpreso = '<tr><td><div class="tittbl2">Tickets en Custodia</div></td><td colspan="5">&nbsp;</td></tr>';
        tablaEspeciales += '<tr><td colspan="6"><div class="tittbl1">' + obj.TiposPago[1].Nombre + '</div></td></tr>'
        for (let j = 0; j < obj.TiposPago[1].Divisas.length ; j++) { //por cada divisa dentro del objeto
            divisaActual = obj.TiposPago[1].Divisas[j].idDivisa;
            datos = obj.TiposPago[1].Divisas[j].Datos;
            for (let k = 0; k < datos.length ; k++) { //para cada uno de los datos
                if (datos[k].TipoPago == 2) { // si es Tipo de Pago 2 (tarjeta)
                    nombreEstiloDato = "tittbl2";
                } else if (datos[k].TipoPago == 3) { //si es cheque
                    tablaEspeciales += chequeImpreso;
                    chequeImpreso = '';
                    nombreEstiloDato = "tittbl3";
                } else if (datos[k].TipoPago == 20) {
                    nombreEstiloDato = "tittbl3";
                    tablaResto += ticketImpreso;
                    ticketImpreso = '';
                } else
                    nombreEstiloDato = "tittbl2";
                     
                reg = '<tr><td><div class="' + nombreEstiloDato + '">' +
                    (((datos[k].TipoPago == 20) || (datos[k].TipoPago == 3)) ? obj.TiposPago[1].Divisas[j].Descripcion : datos[k].DescTipoPago) +
                    '</div></td>' +
                    '<td>' + (imprime2Cols ? "&nbsp;" : formatoDinero(datos[k].SaldoActual, divisaActual)) + '</td>' +
                    '<td>' + (imprime2Cols ? "&nbsp;" : formatoDinero(datos[k].Ingresos, divisaActual)) + '</td>' +
                    '<td>' + (imprime2Cols ? "&nbsp;" : formatoDinero(datos[k].Egresos, divisaActual)) + '</td>' +
                    '<td>' + (imprime2Cols ? formatoDinero(datos[k].SaldoActual, divisaActual) : formatoDinero(datos[k].SaldoFinal, divisaActual)) + '</td>' +
                    '<td>' + formatoDinero(datos[k].Tope, divisaActual) + '</td></tr>'
                if (datos[k].TipoPago == 2 || datos[k].TipoPago == 3)
                    tablaEspeciales += reg;
                else
                    tablaResto += reg;
            }
        }
        tabla += tablaEspeciales + tablaResto;

        if (pg_opcion == 11) {
            obj = pi_objDiferencias = Cons_DatosDiferencias();
            let tempTabla = '';
            if (obj.NoError == 0) { //si hay diferencias
                tempTabla += '<tr><td colspan="6"><div class="tittbl1">DIFERENCIAS</div></td></tr>';
                tempTabla += "<tr><th>Categoria</th><th>Saldo Actual</th><th>Saldo Cierre</th><th>Ingresos</th><th>Egresos</th><th>Diferencia</th></tr>";
                for (let i = 0; i < obj.DiferenciasCaja.length ; i++) {
                    tempTabla += '<tr><td>' + obj.DiferenciasCaja[i].Categoria + '</td>' +
                        '<td>' + obj.DiferenciasCaja[i].UltSaldoAct + '</td>' +
                        '<td>' + obj.DiferenciasCaja[i].UltSaldoCierre + '</td>' +
                        '<td>' + obj.DiferenciasCaja[i].Ingresos + '</td>' +
                        '<td>' + obj.DiferenciasCaja[i].Egresos + '</td>' +
                        '<td>' + obj.DiferenciasCaja[i].Ajuste + '</td></tr>'
                }
            }
            tabla += tempTabla;
        }

        tabla += "</tbody>";
        $('#tblResumen').html(tabla);

        //elementos que se muestran en las dos pantallas:
        pi_Booleanos.HayFaltantes = obj.HayFaltantes;
        pi_Booleanos.HaySobrantes = obj.HaySobrantes;
        $('.lblFaltantes').html((obj.HayFaltantes == 1) ? "Sí" : "No");
        $('.lblSobrantes').html((obj.HaySobrantes == 1) ? "Sí" : "No");
        if ((obj.HaySobrantes == 0) && (obj.HayFaltantes == 0))
            $('.btnFaltSobr').hide();
        else
            pi_objFaltSobr = {}

        //elementos que solo pertenecen a la pantalla de caja o empleados
        if (pg_opcion % 2 != 0) { //si la opcion es de caja
            pi_Booleanos.HayDotacion = obj.HayDotacion;
            pi_Booleanos.HayRecoleccion = obj.HayRecoleccion;
            $('.lblDotaciones').html((obj.HayDotacion == 1) ? "Sí" : "No");
            $('.lblRecolecciones').html((obj.HayRecoleccion == 1) ? "Sí" : "No");
            if ((obj.HayDotacion == 0) && (obj.HayRecoleccion == 0))
                $('.btnDotRec').hide();
            pi_Booleanos.HaySdosActivos = obj.HaySdoCajeros;
            pi_Booleanos.HaySdosInactivos = obj.HaySdoInactivos;
            $('.lblEmpSaldos').html((obj.HaySdoCajeros == 1) ? "Sí" : "No");
            $('.lblEmpInactivos').html((obj.HaySdoInactivos == 1) ? "Sí" : "No");
            if ((obj.HaySdoCajeros == 0) && (obj.HaySdoInactivos == 0))
                $('.btnCajeros').hide();

            $('.lblPared').html(formatoDinero(obj.ParedElectronica,1));
        }
        //termina de consultar servicios
        pd_NombreAut = (obj.NombreEmpAut == null ? '' : obj.NombreEmpAut);
        //en este switch se ponen las características parciculares de cada pantalla, despues de poner los datos
        $('.lblEmpAut').hide(); //TEMP
        switch (pg_opcion) {
            case 1:
                $('.lblHrApertura').html('Apertura: ' + ObtenerFormatoHora(pg_hora));
                $('.lblHrCierre').hide();
                pd_HrApertura = ObtenerFormatoHora(pg_hora);
                pi_nombreOperacion = 'Informe de apertura general de caja';
                break;
            case 2:
                $('.lblHrApertura').html('Apertura: ' + ObtenerFormatoHora(pg_hora));
                $('.lblHrCierre').hide();
                //$('.lblEmpAut').hide();
                pd_HrApertura = ObtenerFormatoHora(pg_hora);
                pi_nombreOperacion = 'Informe de apertura general del empleado';
                break;
            case 3:
                $('.lblHrApertura').html('Apertura: ' + ObtenerFormatoHora(pg_hora));
                $('.lblHrCierre').hide();
                pd_HrApertura = ObtenerFormatoHora(pg_hora);
                pi_nombreOperacion = 'Informe de reapertura parcial de caja';
                break;
            case 4:
                $('.lblHrApertura').html('Apertura: ' + ObtenerFormatoHora(pg_hora));
                $('.lblHrCierre').hide();
                //$('.lblEmpAut').hide();
                pd_HrApertura = ObtenerFormatoHora(pg_hora);
                pi_nombreOperacion = 'Informe de reapertura parcial del empleado';
                break;
            case 5:
                $('.lblHrApertura').html('Apertura: ' + ObtenerFormatoHora(obj.HoraApertura));
                $('.lblHrCierre').html('Cierre: ' + ObtenerFormatoHora(pg_hora));
                pd_HrApertura = ObtenerFormatoHora(obj.HoraApertura);
                pd_HrCierre = ObtenerFormatoHora(pg_hora);
                pi_nombreOperacion = 'Informe de cierre parcial de caja';
                break;
            case 6:
                $('.lblHrApertura').html('Apertura: ' + ObtenerFormatoHora(obj.HoraApertura));
                $('.lblHrCierre').html('Cierre: ' + ObtenerFormatoHora(pg_hora));
                //$('.lblEmpAut').html("Autorizó el cierre:<br>" + pg_empleadoAut + (obj.NombreEmpAut == null ? "" : " - " + obj.NombreEmpAut))
                pd_HrApertura = ObtenerFormatoHora(obj.HoraApertura);
                pd_HrCierre = ObtenerFormatoHora(pg_hora);
                pi_nombreOperacion = 'Informe de cierre parcial del empleado';
                break;
            case 7:
                $('.lblHrApertura').html('Apertura: ' + ObtenerFormatoHora(obj.HoraApertura));
                $('.lblHrCierre').html('Cierre: ' + ObtenerFormatoHora(pg_hora));
                pd_HrApertura = ObtenerFormatoHora(obj.HoraApertura);
                pd_HrCierre = ObtenerFormatoHora(pg_hora);
                pi_nombreOperacion = 'Informe de cierre general de caja';
                break;
            case 8:
                $('.lblHrApertura').html('Apertura: ' + ObtenerFormatoHora(obj.HoraApertura));
                $('.lblHrCierre').html('Cierre: ' + ObtenerFormatoHora(pg_hora));
                //$('.lblEmpAut').html("Autorizó el cierre:<br>" + pg_empleadoAut + (obj.NombreEmpAut == null ? "" : " - " + obj.NombreEmpAut))
                pd_HrApertura = ObtenerFormatoHora(obj.HoraApertura);
                pd_HrCierre = ObtenerFormatoHora(pg_hora);
                pi_nombreOperacion = 'Informe de cierre general del empleado';
                break;
            case 9:
                $('.lblHrApertura').html('Apertura actual: ' + ObtenerFormatoHora(pg_hora));
                $('.lblHrCierre').html('Cierre: ' + ObtenerFormatoHora(obj.HoraCierre));
                pi_nombreOperacion = 'Informe de cierre día anterior de caja';
                pd_HrApertura = ObtenerFormatoHora(pg_hora);
                pd_HrCierre = ObtenerFormatoHora(obj.HoraCierre);
                break;
            case 10:
                $('.lblHrApertura').html('Apertura actual: ' + ObtenerFormatoHora(pg_hora));
                $('.lblHrCierre').html('Cierre: ' + ObtenerFormatoHora(obj.HoraCierre));
                //$('.lblEmpAut').html("Autorizó el cierre:<br>" + pg_empleadoAut + (obj.NombreEmpAut == null ? "" : " - " + obj.NombreEmpAut))
                pd_HrApertura = ObtenerFormatoHora(pg_hora);
                pd_HrCierre = ObtenerFormatoHora(obj.HoraCierre);
                pi_nombreOperacion = 'Informe de cierre día anterior del empleado';
                break;
            case 11:
                $('.lblHrApertura').html('Apertura: ' + ObtenerFormatoHora(obj.HoraApertura));
                $('.lblHrCierre').html('Cierre: ' + ObtenerFormatoHora(pg_hora));
                pd_HrApertura = ObtenerFormatoHora(obj.HoraApertura);
                pd_HrCierre = ObtenerFormatoHora(pg_hora);
                pi_nombreOperacion = 'Informe de cierre rápido de caja';
                break;
        }
        $('.lblTitulo').html(pi_nombreOperacion);

        mostrarCarga(false);

        //declarar comportamiento de elementos estáticos
    }, 200);
});

/////////////////////////////////////Funciones para modificar la pagina///////////////////////

function AbrirVentanaFaltSobr() {
    mostrarCarga(true);
    setTimeout(function () {
        let mostrarEmpleado = ((pg_opcion % 2 != 0) && (pg_opcion != 11)) //si es impar y no es 11, se muestra empleado
        let obj = Cons_DatosAjustes();
        if (obj.NoError != 0) {
            DispararError(obj.Descripcion, 'obtención de ajustes', null, true);
            mostrarCarga(false);
            return;
        }
        if (obj.lstAjuste == null)
            obj.lstAjuste = [];
        pi_objFaltSobr = obj.lstAjuste;
        let tabla = '<tbody><tr><th>&nbsp;</th><th>Tipo de ajuste<th>Divisa</th><th>Tipo de Pago</th><th>Monto</th>' + (mostrarEmpleado ? '<th>Empleado</th>' : '') + '</tr>';
        for (let i = 0; i < obj.lstAjuste.length ; i++) {
            tabla += '<tr><td><div class="' + (obj.lstAjuste[i].TipoAjuste == "F" ? 'puntoR' : 'puntoV') + '"></div></td>' +
                '<td>' + obj.lstAjuste[i].Operacion + '</td>' +
                '<td>' + obj.lstAjuste[i].Divisa + '</td>' +
                '<td>' + obj.lstAjuste[i].TipoPago + '</td>' +
                '<td>' + (Number(obj.lstAjuste[i].Monto)).formatMoney(2) + '</td>' +
                (mostrarEmpleado ? '<td>' + obj.lstAjuste[i].Nombre + '</td>' : '') + '</tr>'
        }
        if (tabla == '<tbody><tr><th>&nbsp;</th><th>Tipo de ajuste<th>Divisa</th><th>Tipo de Pago</th><th>Monto</th>' + (mostrarEmpleado ? '<th>Empleado</th>' : '') + '</tr>')
            tabla += '<td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td>'
        tabla += '</tbody>'
        $('#tblAjustes').html(tabla);
        $j('#modalFaltSobr').modal({ escClose: false });
        mostrarCarga(false);
    }, 200);
}

function AbrirVentanaDotRec() {
    mostrarCarga(true);
    setTimeout(function () {
        let obj = Cons_DatosDotaReco();
        if (obj.NoError != 0) {
            DispararError(obj.Descripcion, 'dotaciones y recolecciones', null, true);
            mostrarCarga(false);
            return;
        }
        //primero tabla de recolecciones
        if (obj.lstRecoleccion == null)
            obj.lstRecoleccion = [];
        pi_objRecoleccion = obj.lstRecoleccion;
        let tabla = '<tbody><tr><th>Solicitud</th><th>Divisa</th><th>Fecha Operación</th><th>Tope CP</th><th>Saldo CP</th><th>Fecha Promesa</th><th>Tipo</th>';
        for (let i = 0; i < obj.lstRecoleccion.length ; i++) {
            tabla += '<tr><td>' + obj.lstRecoleccion[i].IdSolicitud + '</td>' +
                '<td>' + obj.lstRecoleccion[i].Desc + '</td>' +
                '<td>' + obj.lstRecoleccion[i].FecSolicitud + '</td>' +
                '<td>' + (Number(obj.lstRecoleccion[i].MontoCjMax)).formatMoney(2) + '</td>' +
                '<td>' + (Number(obj.lstRecoleccion[i].SaldoCj)).formatMoney(2) + '</td>' +
                '<td>' + obj.lstRecoleccion[i].FechaPromesa + '</td>' +
                '<td>' + obj.lstRecoleccion[i].Tipo + '</td>' +
                '</tr>'
        }
        if (tabla == '<tbody><tr><th>Solicitud</th><th>Divisa</th><th>Fecha Operación</th><th>Tope CP</th><th>Saldo CP</th><th>Fecha Promesa</th><th>Tipo</th>')
            tabla += '<tr><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>';
        tabla += '</tbody>'
        $('#tblRecolecciones').html(tabla);
        //luego la tabla de dotaciones
        if (obj.lstDotacion == null)
            obj.lstDotacion = [];
        pi_objDotacion = obj.lstDotacion;
        tabla = '<tbody><tr><th>Solicitud</th><th>Divisa</th><th>Fecha Solicitud</th><th>Fecha Promesa</th><th>Importe</th><th>Tope CP</th><th>Estatus</th>';
        for (let i = 0; i < obj.lstDotacion.length ; i++) {
            tabla += '<tr><td>' + obj.lstDotacion[i].IdSolicitud + '</td>' +
                '<td>' + obj.lstDotacion[i].Desc + '</td>' +
                '<td>' + obj.lstDotacion[i].FechaSolicitud + '</td>' +
                '<td>' + obj.lstDotacion[i].FechaPromesa + '</td>' +
                '<td>' + (Number(obj.lstDotacion[i].ImporteDotacion)).formatMoney(2) + '</td>' +
                '<td>' + (Number(obj.lstDotacion[i].TopeCajaPrincipal)).formatMoney(2) + '</td>' +
                '<td>' + obj.lstDotacion[i].Status + '</td>' +
                '</tr>'
        }
        if (tabla == '<tbody><tr><th>Solicitud</th><th>Divisa</th><th>Fecha Solicitud</th><th>Fecha Promesa</th><th>Importe</th><th>Tope CP</th><th>Estatus</th>')
            tabla += '<tr><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>';
        tabla += '</tbody>'
        $('#tblDotaciones').html(tabla);

        $j('#modalDotRec').modal({ escClose: false });
        mostrarCarga(false);
    }, 200);
}

function AbrirVentanaCajeros() {

    mostrarCarga(true);
    setTimeout(function () {
        let obj = Cons_DatosSaldosEmpleados();
        if (obj.NoError != 0) {
            DispararError(obj.Descripcion, 'obtención de saldos', null, true);
            mostrarCarga(false);
            return;
        }
        if (obj.lstCajero == null)
            obj.lstCajero = [];
        let objDatos = pi_objSaldos = obj.lstCajero;
        let tablaSdos = '<tbody><tr><th>Nombre</th><th>Tipo de Pago<th>Divisa</th><th>Saldo</th></tr>';
        let tablaInac = '<tbody><tr><th>Nombre</th><th>Tipo de Pago<th>Divisa</th><th>Saldo</th></tr>';
        for (let i = 0; i < obj.lstCajero.length ; i++) {
            if (obj.lstCajero[i].EmpStatus == 0) //si es empleado inactivo
                tablaInac += '<tr>' +
                '<td>' + obj.lstCajero[i].Nombre + '</td>' +
                '<td>' + obj.lstCajero[i].PagoDesc + '</td>' +
                '<td>' + obj.lstCajero[i].DescDivisa + '</td>' +
                '<td>' + (Number(obj.lstCajero[i].Saldo)).formatMoney(2) + '</td>' +
                '</tr>';
            else
                tablaSdos += '<tr>' +
                '<td>' + obj.lstCajero[i].Nombre + '</td>' +
                '<td>' + obj.lstCajero[i].PagoDesc + '</td>' +
                '<td>' + obj.lstCajero[i].DescDivisa + '</td>' +
                '<td>' + (Number(obj.lstCajero[i].Saldo)).formatMoney(2) + '</td>' +
                '</tr>';
        }
        if (tablaSdos == '<tbody><tr><th>Nombre</th><th>Tipo de Pago<th>Divisa</th><th>Saldo</th></tr>')
            tablaSdos = '<tr><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>';
        if (tablaInac == '<tbody><tr><th>Nombre</th><th>Tipo de Pago<th>Divisa</th><th>Saldo</th></tr>')
            tablaInac = '<tr><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>';

        tablaSdos += '</tbody>';
        tablaInac += '</tbody>';
        $('#tblEmpSaldos').html(tablaSdos);
        $('#tblEmpInactivos').html(tablaInac);
        $j('#modalCajeros').modal({ escClose: false });
        mostrarCarga(false);
    }, 200);

}

/////////////////////////////////////Funciones para la ventana y la pagina////////////////////

var tempImpObj = null;
function botonImprimir() {
    mostrarCarga(true);
    setTimeout(function () {
        try {
            var obj = Cons_GeneraPDF();
            if (obj.NoError != 0) { //si hubo error
                mostrarCarga(false);
                DispararConfirmacion('¿El documento se imprimió correctamente?', null, botonImprimir, "Sí", "No");
                return;
            }
            tempImpObj = obj;
            setTimeout(function () {
                //servicio configura impresion
                let obj = tempImpObj;
                let ruta = obj.Ruta;
                obj = Cons_ImpresionInformes(ruta);
                Cons_BorraPDF(ruta);
                DispararConfirmacion('¿El documento se imprimió correctamente?', null, botonImprimir, "Sí", "No");
                mostrarCarga(false);
            }, 1000);
        } catch (err) {
            DispararError("Error de ejecución:<br>" + err, 'ejecución');
            mostrarCarga(false);
        }
    }, 200);
    
}

/////////////////////////////Funciones para consumir servicios////////////////////////////////////

//Rutas para los servicios
const Ruta_ValidaEmpleado = "Comun/WsCajaComun.svc/wsConsultaInformacionInicial";
const Ruta_DatosInformeCaja = "InformesCaja/InformesCaja.svc/wsInfoReportesCaja";
const Ruta_DatosInformeEmp = "InformesCaja/InformesCaja.svc/wsInfoReportesEmp";
const Ruta_DatosAjustes = "InformesCaja/InformesCaja.svc/wsConsultasAjustes";
const Ruta_DatosSaldosEmpleados = "InformesCaja/InformesCaja.svc/wsConsultasInforme";
const Ruta_DatosDotRec = "InformesCaja/InformesCaja.svc/wsConsultasRecoDota";
const Ruta_GeneraPDF = "InformesCaja/InformesCaja.svc/wsGeneraPDF";
const Ruta_BorraPDF = "Arqueo/WsCajaArqueo.svc/wsEliminaDocumentoImpresion";
const Ruta_Divisas = "Comun/WsCajaComun.svc/wsconsultaDivisa";

//URL's completas para consumir los servicios
const Url_Impresion = "http://localhost:9001/WSDesTecAppsLocal/ImprimirDocumentoPDFCarta";

function Cons_InfoEmpleado(empleado) {
    return ConsumirServicio(GetUrlSvc(Ruta_ValidaEmpleado), {
        "NoEmpleado": "" + empleado
    });
}

function Cons_InfoDivisas() {
    return ConsumirServicio(GetUrlSvc(Ruta_Divisas));
}

function Cons_DatosInforme() {
    if (pg_opcion % 2 == 0) //si es empleado
    {
        return ConsumirServicio(GetUrlSvc(Ruta_DatosInformeEmp), {
            "NoCajero": pg_empleadoID,
            "NoEmpAut": pg_empleadoAut,
            "Diferencias": 0,
            "Opcion": pg_opcion,
            "Accion": 0
        });
    } else {
        return ConsumirServicio(GetUrlSvc(Ruta_DatosInformeCaja), {
            "NoCajero": pg_empleadoID,
            "NoEmpAut": "",
            "Diferencias": 0,
            "Opcion": pg_opcion,
            "Accion": 0
        });
    }
    
}

function Cons_DatosAjustes() {
    return ConsumirServicio(GetUrlSvc(Ruta_DatosAjustes), {
        "NoCajero": pg_empleadoID,
        "NoEmpAut": "",
        "Diferencias": 0,
        "Opcion": pg_opcion,
        "Accion": 3
    });
}

function Cons_DatosSaldosEmpleados() {
    return ConsumirServicio(GetUrlSvc(Ruta_DatosSaldosEmpleados), {
        "NoCajero": "",
        "NoEmpAut": "",
        "Diferencias": 0,
        "Opcion": pg_opcion,
        "Accion": 6
    });
}

function Cons_DatosDotaReco() {
    return ConsumirServicio(GetUrlSvc(Ruta_DatosDotRec), {
        "NoCajero": "",
        "NoEmpAut": "",
        "Diferencias": 0,
        "Opcion": pg_opcion,
        "Accion": 4
    });
}

function Cons_DatosDiferencias() {
    return ConsumirServicio(GetUrlSvc(Ruta_DatosInformeCaja), {
        "NoCajero": pg_empleadoID,
        "NoEmpAut": "",
        "Diferencias": 1,
        "Opcion": 11,
        "Accion": 0
    });
}

function Cons_GeneraPDF() {
    let objEfectivo = [];
    for (let i = 0 ; i < pi_objInforme.TiposPago[0].Divisas.length ; i++) {
        for (let j = 0 ; j < pi_objInforme.TiposPago[0].Divisas[i].Datos.length ; j++) {
            objEfectivo.push({
                "Categoria": "EFECTIVO",
                "DescTipoPago": pi_objInforme.TiposPago[0].Divisas[i].Datos[j].DescTipoPago,
                "DescTipoDivisa": pi_objInforme.TiposPago[0].Divisas[i].Descripcion,
                "DescCaja": pi_objInforme.TiposPago[0].Divisas[i].Datos[j].DescCaja,
                "SaldoInicial": pi_objInforme.TiposPago[0].Divisas[i].Datos[j].SaldoActual,
                "Ingresos": pi_objInforme.TiposPago[0].Divisas[i].Datos[j].Ingresos,
                "Egresos": pi_objInforme.TiposPago[0].Divisas[i].Datos[j].Egresos,
                "SaldoFinal": pi_objInforme.TiposPago[0].Divisas[i].Datos[j].SaldoFinal,
                "Tope": pi_objInforme.TiposPago[0].Divisas[i].Datos[j].Tope
            });
        }
    }

    let objEspeciales = [];
    let objResto = [];
    let compara = 0;
    for (let i = 0 ; i < pi_objInforme.TiposPago[1].Divisas.length ; i++) {
        for (let j = 0 ; j < pi_objInforme.TiposPago[1].Divisas[i].Datos.length ; j++) {
            compara = pi_objInforme.TiposPago[1].Divisas[i].Datos[j].TipoPago;
            if (compara == 2 || compara == 3)
                objEspeciales.push({
                    "Categoria": "DOCUMENTOS",
                    "DescTipoPago": pi_objInforme.TiposPago[1].Divisas[i].Datos[j].DescTipoPago,
                    "DescTipoDivisa": pi_objInforme.TiposPago[1].Divisas[i].Descripcion,
                    "DescCaja": pi_objInforme.TiposPago[1].Divisas[i].Datos[j].DescCaja,
                    "SaldoInicial": pi_objInforme.TiposPago[1].Divisas[i].Datos[j].SaldoActual,
                    "Ingresos": pi_objInforme.TiposPago[1].Divisas[i].Datos[j].Ingresos,
                    "Egresos": pi_objInforme.TiposPago[1].Divisas[i].Datos[j].Egresos,
                    "SaldoFinal": pi_objInforme.TiposPago[1].Divisas[i].Datos[j].SaldoFinal,
                    "Tope": pi_objInforme.TiposPago[1].Divisas[i].Datos[j].Tope
                });
            else if (compara != 20 || (compara == 20 && pi_objInforme.TiposPago[1].Divisas[i].idDivisa == 1))
                objResto.push({
                    "Categoria": "DOCUMENTOS",
                    "DescTipoPago": pi_objInforme.TiposPago[1].Divisas[i].Datos[j].DescTipoPago,
                    "DescTipoDivisa": pi_objInforme.TiposPago[1].Divisas[i].Descripcion,
                    "DescCaja": pi_objInforme.TiposPago[1].Divisas[i].Datos[j].DescCaja,
                    "SaldoInicial": pi_objInforme.TiposPago[1].Divisas[i].Datos[j].SaldoActual,
                    "Ingresos": pi_objInforme.TiposPago[1].Divisas[i].Datos[j].Ingresos,
                    "Egresos": pi_objInforme.TiposPago[1].Divisas[i].Datos[j].Egresos,
                    "SaldoFinal": pi_objInforme.TiposPago[1].Divisas[i].Datos[j].SaldoFinal,
                    "Tope": pi_objInforme.TiposPago[1].Divisas[i].Datos[j].Tope
                });
        }
    }
    let objCajaDocs = objEspeciales.concat(objResto);
    let objResumen = objEfectivo.concat(objCajaDocs);

    //obtener arreglo para los registros de saldos de empleados activos e insctivos
    let objSaldosAct = [];
    let objSaldosInac = [];
    if (pi_Booleanos.HaySdosActivos == 1 || pi_Booleanos.HaySdosInactivos == 1) {
        if (pi_objSaldos == null) {
            let obj = Cons_DatosSaldosEmpleados();
            if (obj.NoError == 0 && obj.lstCajero != null)
                pi_objSaldos = obj.lstCajero;
        }
        if (pi_objSaldos != null) {
            for (let i = 0 ; i < pi_objSaldos.length ; i++) {
                if (pi_objSaldos[i].EmpStatus == 1)
                    objSaldosAct.push({
                        "Nombre": pi_objSaldos[i].Nombre,
                        "Divisa": pi_objSaldos[i].DescDivisa,
                        "TipoPago": pi_objSaldos[i].PagoDesc,
                        "Saldo": pi_objSaldos[i].Saldo
                    });
                else
                    objSaldosInac.push({
                        "Nombre": pi_objSaldos[i].Nombre,
                        "Divisa": pi_objSaldos[i].DescDivisa,
                        "TipoPago": pi_objSaldos[i].PagoDesc,
                        "Saldo": pi_objSaldos[i].Saldo
                    });
            }
        }

    }
    return ConsumirServicio(GetUrlSvc(Ruta_GeneraPDF), {
        "cadenaPDF": JSON.stringify({
            "DescripcionPuesto": pd_DescripcionPuesto, //
            "Fecha": pd_Fecha, //
            "OpcionReporte": pg_opcion, //
            "NombreEmpleado": pd_NombreEmpleado, //
            "NoTienda": pd_NoTienda, //
            "NombreTienda": pd_NombreTienda, //
            "Terminal": pg_cajaNombre, //
            "ParedElectronica": pi_objInforme.ParedElectronica, //
            "HoraApertura": pd_HrApertura, //
            "HoraCierre": pd_HrCierre, //
            "EmpAutNombre": pd_NombreAut, //
            "DenominacionesImpresion": objResumen,
            "EmpleadosSaldos": objSaldosAct,
            "EmpleadoInactivo": objSaldosInac
        })
    });
}

function Cons_ImpresionInformes(ruta) {
    return ConsumirServicio(Url_Impresion, {
        "Ruta": ruta
    }, "EstatusExito", "Detalle");
}

function Cons_BorraPDF(ruta) {
    ConsumirServicio(GetUrlSvc(Ruta_BorraPDF), {
        "Ruta": ruta
    });
}