﻿//var app = getUrlVars()["app"];
//var empleados = "554645|434343";
var pantallaCargada = false;

$(document).ready(function () {
    mostrarCarga(true);
    cargaInicial();     
});



/*
function ValidaApp(app) {
    if (app != "" && app != undefined) {
        sendApp(app);
    } else {
         titulo = "";
         url = "../Fronts/error.htm";
         loadingApp(url, titulo);                          
    }
}

function sendApp(app) {
    var url = "";
    var titulo = "";
    switch (app) {
        case "1":
            titulo = "Fondeo Automatico";
            url = "../Fronts/Fondeo/fondeo.htm";
            loadingApp(url, titulo);
            break;       
        default:
            titulo = "";
            url = "../Fronts/error.htm";
            loadingApp(url, titulo);                          
            break;
    }
}

function loadingApp(url, titulo) {
    $('#titulo').text(titulo);
    $('#content').load(url);
}*/

    
function proceso(iframe) {
    alert(iframe);

   /* val = window.opener.document.getElementById("status").innerHTML = '<div id="myModal" style="display: block; position: fixed; z-index: 1; padding-top: 100px; left: 0; top: 0; width: 100%; height: 100%;  overflow: auto; background-color: rgb(0,0,0); background-color: rgba(0,0,0,0.4);">\n\
            <div style="background-color: #fefefe;margin: auto;padding: 20px; border: 1px solid #888; width: 100%;">\n\
            <div class="form-group">\n\
            <label for="formGroupExampleInput">Example label</label>\n\
            <input type="text" class="form-control" id="formGroupExampleInput" placeholder="Example input">\n\
             <div class="form-group" style=" text-align: right;">\n\
                <button type="button" class="btn btn-success" value="Enviar"><a href="http://localhost:8080/ApplicationAzteca/cerrar.html" target="_blank" style=" text-decoration:none; color: #fff;">Fondear</a></button>                                                 \n\
            </div></div></div>\n\
        </div>';
    window.close();*/
}