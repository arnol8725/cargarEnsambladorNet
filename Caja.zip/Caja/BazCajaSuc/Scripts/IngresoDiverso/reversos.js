﻿if ($j === undefined) { var $j = jQuery.noConflict(true); console.log($().jquery); console.log($j().jquery); }

var empleadoID = null;
var cajaNombre = null;
var idTransaccion = null;

var refAppCont = null;
var tiempoRestanteApp = null;
var pantallaCargada = false;
var refFuncMensaje = null;
var refFuncAceptar = null;
var refFuncCancelar = null;

const UrlValidaEmpleado = "Comun/WsCajaComun.svc/wsConsultaInformacionInicial";
const UrlConsAutorizadosParaReversos = "IngresoDiverso/WSIngresoDiverso.svc/wsConsAutorizadosParaReversos";
const UrlRegReverso = "IngresoDiverso/WSIngresoDiverso.svc/wsRegReverso";
const UrlObtieneValidadores = "wsUtileriaCaja/wsUtileria.svc/wsPerfilAutorizador";

//carga datos iniciales
$(document).ready(function () {
    var date = new Date();
    $('#tagHora').html(date.getHours() + ":" + date.getMinutes());
    $('#tagFecha').html((date.getMonth() + 1) + "/" + date.getDate() + "/" + date.getFullYear());

    empleadoID = getUrlVars()["empleado"];
    cajaNombre = getUrlVars()["ws"];
    if (empleadoID === undefined || empleadoID == ""
        || cajaNombre === undefined || cajaNombre == "") {
        DispararError("Los parámetros no son correctos.","parámetros de la URL");
        return;
    }
    mostrarCarga(true);
    setTimeout(function () {
        obj = ServAppConsultaEmpleado(empleadoID);
        if (obj.NoError != 0) {
            DispararError(obj.Descripcion);
            mostrarCarga(false);
            return;
        }
        $('#tagEmpNombre').html(obj.InformacionInicial.NombreEmpleado);
        $('#tagEmpDescripcion').html(obj.InformacionInicial.DescripcionPBase);
        //empleadoPuesto = obj.InformacionInicial.PuestoRol;
        $('#tagNumTienda').html(obj.InformacionInicial.NoTienda);
        $('#tagNombreTienda').html(obj.InformacionInicial.NombreTienda);
        $('#tagPais').html(obj.InformacionInicial.DescripcionPais);

        LlenarTablaIngresos();
        mostrarCarga(false);
    }, 200);
});

function LlenarTablaIngresos() {
    //resetear valores
    idTransaccion = null;
    //aqui ya supongo que tengo las fechas con el formato correcto
    let obj = ServConsAutorizadosParaReversos();
    if (obj.NoError == 0) { //llena la tabla con la información correspondiente
        let conj = obj.DetalleAutorizadosParaReverso;
        if(conj.length > 0){
            let tabla = "<tbody><tr><th>No. de operación</th><th>Descripcion</th><th>Importe</th><th>Solicitado</th><th>Referencia</th></tr>";
            for (let i in conj) {
                tabla += '<tr id="tag_' + conj[i].NoTransaccion + '" class="">';
                tabla += "<td>" + conj[i].NoTransaccion + "</td>";
                tabla += "<td>" + conj[i].DescripcionConcepto + "</td>";
                tabla += '<td>$<span id="imp_' + conj[i].NoTransaccion + '">' + conj[i].Importe + "</span></td>";
                tabla += "<td>" + conj[i].FechaAutorizacion + "</td>";
                tabla += '<td><span id="ref_' + conj[i].NoTransaccion + '">' + conj[i].ReferenciaMovimiento + "</span></td>";
                tabla += '<input type="hidden" id="con_' + conj[i].NoTransaccion + '" value="' + conj[i].ConceptoMovimiento + '">';
                tabla += "</tr>";
            }
            tabla += "</tbody>";
            $('#tablaIngresos').html(tabla);
            for (let i in conj) {
                $('#tag_' + conj[i].NoTransaccion).unbind('click');
                $('#tag_' + conj[i].NoTransaccion).on('click', function (event) {
                    $("#tag_" + idTransaccion).removeClass("act");
                    $("#" + $(this).attr("id")).addClass("act");
                    idTransaccion = $(this).attr("id").replace("tag_", "");
                });
            }
        } else {
            DispararMensaje("No hay reversos autorizados pendientes.");
            let tabla = "<tbody><tr><th>No. de operación</th><th>Descripcion</th><th>Importe</th><th>Solicitado</th><th>Referencia</th></tr>";
            $('#tablaIngresos').html(tabla);
        }
    } else {
        DispararError(obj.Descripcion, 'consulta de reversos autorizados');
    }
}

//de esta manera se inicializa la autenticación
function AbrirHuellaValidar() {
    mostrarCarga(true);
    setTimeout(function () {
        var obj = ServObtenerValidadores();
        if (obj.Estatus != 0) { //si hubo error
            DispararError(obj.msjError, 'obtención de validadores');
            mostrarCarga(false);
            return;
        }
        mostrarCarga(false);
        let empleadosVal = obj.EmpAutorizador
        let empleadosValPerfs = obj.EmpPerfiles
        validarOperador = false;
        let temp = empleadoID.replace(/\D/g, '');
        var json = '{"validarEmp":"' + temp + '","validarAut":"' + empleadosVal + '","perfiles":"' + empleadosValPerfs.replace("632,", "").replace(",632", "") + '","tipo":"1","app":"IngresoDiverso","ws":"' + cajaNombre + '","top":"230","afectaHD":true}';
        json = JSON.parse(json);
        AutenticacionHuella(json);
    }, 300);
}

function RecibirResultadoHuella(resultado) {
    if (resultado.Status == 0) { //si hubo error
        DispararError(resultado.Descripcion, 'autenticación de huella digital');
        return;
    }
    mostrarCarga(true);
    setTimeout(function () {
        let obj = ServRegReverso(idTransaccion,
        Number($('#con_' + idTransaccion).val()),
        Number($('#imp_' + idTransaccion).html()),
        $('#ref_' + idTransaccion).html());
        if (obj.NoError != 0)
            DispararError(obj.Descripcion, 'registro de reverso');
        else
            DispararMensaje('El reverso se ha realizado con éxito', CerrarVentanaApp);
        mostrarCarga(false);
    }, 200);
}

/////////////////////////////////////Funciones para la ventana y la pagina///////////////////////////

//se necesita definir esta función de esta manera para que la pagina pueda recibir el resultado de la autenticación

function BotonReverso() {
    if (idTransaccion != null)
        DispararConfirmacion('¿Desea seleccionar el ingreso con ID <b>' + idTransaccion + '</b> para hacer reverso?', AbrirHuellaValidar, null)
    else
        DispararMensaje('No se ha seleccionado un ID.', null);
}

function DispararError(mensaje, causa) {
    $('#errorTitulo').html('Error de ' + causa + ':');
    $('#errorTexto').html(mensaje);
    $j('#modalError').modal();
    iniciarTimerApp(5);
}

function DispararMensaje(mensaje, refM) {
    refFuncMensaje = (refM !== undefined) ? refM : null;
    $('#mensajeTitulo').html('Mensaje del sistema:');
    $('#mensajeTexto').html(mensaje);
    $j('#modalMensaje').modal();
    
}

function DispararConfirmacion(mensaje, refA, refC) {
    refFuncAceptar = (refA !== undefined) ? refA : null;
    refFuncCancelar = (refC !== undefined) ? refC : null;
    $('#confTitulo').html('Mensaje del sistema:');
    $('#confTexto').html(mensaje);
    $j('#modalConfirmacion').modal();
}

function botonDiagMensaje() {
    if (refFuncMensaje != null)
        refFuncMensaje();
}

function botonDiagAceptar() {
    if (refFuncAceptar != null)
        refFuncAceptar();
}

function botonDiagCancelar() {
    if (refFuncCancelar != null)
        refFuncCancelar();
}

function CerrarVentanaApp() {
    clearInterval(refAppCont);
    try { window.close(); }
    catch (err) { alert('La ventana debería cerrarse, Error: ' + err); }
}

function iniciarTimerApp(tiempoArg) {
    tiempoRestanteApp = tiempoArg;
    timerApp();
    refAppCont = setInterval(function () { timerApp() }, 1000);
}

function timerApp() {
    $("#appTimer").html("Tiempo de espera (" + tiempoRestanteApp + ")");
    if (tiempoRestanteApp > 0) {
        tiempoRestanteApp -= 1;
    }
    else {
        CerrarVentanaApp();
    }
}

/////////////////////////////////////Funciones de utilidad///////////////////////////////////////

function getUrlServicio(servicio) {
    var url = "";
    if (window.location.hostname == "localhost") {
        url = "http://10.54.28.186:9014/Caja/Servicios/" + servicio;
    } else {
        url = "http://" + window.location.hostname + ":9014/Caja/Servicios/" + servicio;
    }
    return url;
}

/////////////////////////////////////Servicios////////////////////////////////////////////////

function ServAppConsultaEmpleado(empleado) {
    var objRespuesta = { NoError: null, Descripcion: null };
    var url = getUrlServicio(UrlValidaEmpleado);
    $.ajax({
        url: "" + url,
        contentType: "application/json; charset=UTF-8",
        type: "POST",
        async: false,
        data: JSON.stringify({
            "NoEmpleado": "" + empleado.replace(/\D/g, '')
        }),
        dataType: 'json',
        crossDomain: true,
        success: function (data) {
            objRespuesta = data;
        },
        error: function () {
            objRespuesta.NoError = 1;
            objRespuesta.Descripcion = "No se pudo contactar al servicio.";
        }
    });
    return objRespuesta;
}

function ServConsAutorizadosParaReversos() {
    var objRespuesta = { NoError: null, Descripcion: null };
    var url = getUrlServicio(UrlConsAutorizadosParaReversos);
    $.ajax({
        url: "" + url,
        contentType: "application/json; charset=UTF-8",
        type: "POST",
        async: false,
        dataType: 'json',
        crossDomain: true,
        success: function (data) {
            objRespuesta = data;
        },
        error: function () {
            objRespuesta.NoError = 1;
            objRespuesta.Descripcion = "No se pudo contactar al servicio.";
        }
    });
    return objRespuesta;
}

function ServRegReverso(transaccion,concepto,importe,referencia) {
    var objRespuesta = { NoError: null, Descripcion: null };
    var url = getUrlServicio(UrlRegReverso);
    $.ajax({
        url: "" + url,
        contentType: "application/json; charset=UTF-8",
        type: "POST",
        async: false,
        data: JSON.stringify({
            "NoTransaccion":transaccion,
            "Ws":cajaNombre,
            "NoEmpleado":empleadoID.replace(/\D/g, ''),
            "Concepto":concepto,
            "Importe":importe,
            "Referencia":referencia,
            "TipoDivisa":1
        }),
        dataType: 'json',
        crossDomain: true,
        success: function (data) {
            objRespuesta = data;
        },
        error: function () {
            objRespuesta.NoError = 1;
            objRespuesta.Descripcion = "No se pudo contactar al servicio.";
        }
    });
    return objRespuesta;
}

function ServObtenerValidadores() {
    var objRespuesta = { Estatus: null, msjError: null };
    var url = getUrlServicio(UrlObtieneValidadores);
    $.ajax({
        url: "" + url,
        contentType: "application/json; charset=UTF-8",
        type: "POST",
        async: false,
        data: JSON.stringify({
            "opc": 1,
            "IdModulo": "27",
            "IdFolio": "3",
            "Empleado": "" + empleadoID.replace(/\D/g, '')
        }),
        dataType: 'json',
        crossDomain: true,
        success: function (data) {
            objRespuesta = data;
        },
        error: function () {
            objRespuesta.Estatus = 1;
            objRespuesta.msjError = "No se pudo contactar al servicio.";
        }
    });
    return objRespuesta;
}