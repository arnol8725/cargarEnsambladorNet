﻿if ($j === undefined) { var $j = jQuery.noConflict(true); console.log($().jquery); console.log($j().jquery); }

var empleadoID = null;
var cajaNombre = null;
var refContApp = null;
var tiempoRestanteApp = null;
var pantallaCargada = false;
var refFuncMensaje = null;
var refFuncAceptar = null;
var refFuncCancelar = null;

var datoSelectConc = null;
var arrConceptos = null;

const UrlValidaEmpleado = "Comun/WsCajaComun.svc/wsConsultaInformacionInicial";
const UrlConsultaConceptos = "IngresoDiverso/WSIngresoDiverso.svc/wsConsConceptos";
const UrlRegistraIngresos = "IngresoDiverso/WSIngresoDiverso.svc/wsRegIngresoDiverso";
const UrlConsultaInfoTicket = "IngresoDiverso/WSIngresoDiverso.svc/wsConsInfoTicket";
//links para impresión
const UrlHostImpresion = "http://localhost:9001/";



const UrlGeneraTicket = "WSDesTecAppsLocal/GenerarTickets";
const UrlImprimeTicket = "WSDesTecAppsLocal/ImprimirTickets?idticket=";

const limiteIngreso = 1000000000.0;

//carga datos iniciales
$(document).ready(function () {
    $('#botonGrabar').show();
    $('#selectConcepto').val("0");
    LimpiarValores();
    ActivarCampos(true);
    let date = new Date();
    //$('#tagHora').html(date.getHours() + ":" + date.getMinutes()); ("00" + d.getHours()).slice(-2) + ":" + ("00" + d.getMinutes()).slice(-2) + ":" + ("00" + d.getSeconds()).slice(-2)
    $('#tagHora').html(getHoraPrincipal());
    //$('#tagFecha').html((date.getMonth() + 1) + "/" + date.getDate() + "/" + date.getFullYear()); getFechaticket
    $('#tagFecha').html(getFechaPrincipal());

    empleadoID = getUrlVars()["empleado"];
    cajaNombre = getUrlVars()["ws"];
    if (empleadoID === undefined || empleadoID == ""
        || cajaNombre === undefined || cajaNombre == "") {
        DispararError("Los parámetros no son correctos.", "parámetros de la URL");
        return;
    }
    mostrarCarga(true);
    setTimeout(function () {
        obj = ServAppConsultaEmpleado(empleadoID);
        if (obj.NoError != 0) {
            DispararError(obj.Descripcion,'consulta de información de empleado');
            mostrarCarga(false);
            return;
        }
        $('#tagEmpNombre').html(obj.InformacionInicial.NombreEmpleado);
        $('#tagEmpDescripcion').html(obj.InformacionInicial.DescripcionPBase);
        //empleadoPuesto = obj.InformacionInicial.PuestoRol;
        $('#tagNumTienda').html(obj.InformacionInicial.NoTienda);
        $('#tagNombreTienda').html(obj.InformacionInicial.NombreTienda);
        $('#tagPais').html(obj.InformacionInicial.DescripcionPais);
        $('#inpImporte').val('');
        $('#conImporte').val('');
        $('#refImporte').val(''); //vaciar comentarios
        mostrarCarga(false);

        //declarar comportamiento de elementos estáticos
        $('#selectConcepto').on('click', function () {
            LimpiarValores();
            if ($(this).val() == "0") {
                ActivarCampos(true);
                LlenarSelectMovimientos();
            }
        });
        $('.camposEntrada').on('click', function () {
            if ($(this).val() != '')
                $(this).focus().select();
        });
        $('.claseImporte').on('keypress change focusout', function (event) {
            if ((event.type == 'keypress' && event.which === 13) || event.type == 'change' || event.type == 'focusout') {
                let temp = Number($(this).val());
                $(this).val((isNaN(temp) || temp > limiteIngreso) ? 0.0 : toFixedJ(temp, 2));
                ActivarBotonGrabar();
                $((event.target.id == 'inpImporte') ? '#conImporte' : '#refImporte').focus().select();
            }
        });

        $('#refImporte').on('change focusout', function (event) {
            if ($(this).val().length > 25)
                $(this).val($(this).val().substring(0, 25));
            ActivarBotonGrabar();
            if(event.type == 'change')
                $(this).blur()
        });
    }, 200);
});
function getFechaPrincipal() {
    let d = new Date();
    let fecha = ("00" + d.getDate()).slice(-2) + "/" + ("00" + (d.getMonth() + 1)).slice(-2) + "/" + d.getFullYear() ;
    return fecha;
}
function getHoraPrincipal() {
    let d = new Date();
    let hr = ("00" + d.getHours()).slice(-2) + ":" + ("00" + d.getMinutes()).slice(-2);
    return hr;
}
//llena el select de movimientos
function LlenarSelectMovimientos() {
    if (datoSelectConc == null) {
        let obj = ServConsultaConcepto();
        if (obj.NoError != 0) {
            DispararError(obj.Descripcion, 'consulta de conceptos');
            return false;
        }
        let opts = "";
        arrConceptos = obj.DetalleConceptos; //para tener acceso a los nombres de los conceptos luego
        for (let i = 0; i < obj.DetalleConceptos.length ; i++)
            opts += '<option value="' + obj.DetalleConceptos[i].Movimiento + '" ' + ((i == 0) ? 'selected': '') + '>' + obj.DetalleConceptos[i].Descripcion + '</option>';
        datoSelectConc = opts;
    }
    $('#selectMovimiento').html(datoSelectConc);
}
//hace que los valores que se habían introducido en los campos de entrada sean vaciados y desactivados
function LimpiarValores() {
    $('#botonGrabar').show();
    $('#inpImporte').val('');
    $('#conImporte').val('');
    $('#refImporte').val('');
    $('#selectMovimiento').html(LlenarSelectMovimientos());
    ActivarCampos(true);
}

//esta funcion es para habilitar o deshabilitar los campos de entrada
function ActivarCampos(activar) {
    $('#inpImporte').prop('disabled', !activar);
    $('#conImporte').prop('disabled', !activar);
    $('#refImporte').prop('disabled', !activar);
    $('#selectMovimiento').prop('disabled', !activar);
  

}

//checa si los campos de importe tienen valores. Si los tienen, se muestra el botón, si no, lo esconde
function ActivarBotonGrabar() {
    
        $('#botonGrabar').show();
}

//toma los datos que se insertaron en la interfaz grafica y manda el request para hacer el ingreso
var temp;
function GrabarIngreso() {
    mostrarCarga(true);
    setTimeout(function () {
        let obj = ServRegistraIngreso(Number($('#selectMovimiento').val()), Number($('#inpImporte').val()), $('#refImporte').val());
        if (obj.NoError != 0) {
            DispararError(obj.Descripcion, 'registro de ingreso');
            mostrarCarga(false);
            return false;
        }
        mostrarCarga(false);
        DispararConfirmacion('El ingreso ha sido grabado con el ID: <b id="idTransaccion">' + obj.IdTransaccion + '</b>.<br>¿Deseas imprimir un ticket?', ImpresionTicket, CerrarVentanaApp);
        temp = obj.IdTransaccion;

    }, 200);
    
}

//realiza la construccion del xml para el ticket, la generacion de este y la impresión
function formatMoney(num) {
    var p = Number(num).toFixed(2).split(".");
    return "$" + p[0].split("").reverse().reduce(function (acc, num, i, orig) {
        return num == "-" ? acc : num + (i && !(i % 3) ? "," : "") + acc;
    }, "") + "." + p[1];
}
function ImpresionTicket() {
    mostrarCarga(true);
    setTimeout(function () {
        let idtrans = $('#idTransaccion').html();
        if (idtrans == undefined) {
            idtrans = temp;
        }
        let importe = Number($('#inpImporte').val());
        let obj = ServConsultaInfoTicket(importe,idtrans);
        if (obj.NoError != "0") {
            DispararConfirmacion('¿El ticket se imprimió correctamente?', CerrarVentanaApp, ImpresionTicket, "Sí", "No");
            //LimpiarValores();
            mostrarCarga(false);
            return;
        }
        obj = obj.InfoTicket;
        let idc = $('#selectMovimiento').val();
        let nombreConcepto = '';
        for (let i = 0; i < arrConceptos.length ; i++)
            if (arrConceptos[i].Movimiento == idc) {
                nombreConcepto = arrConceptos[i].Descripcion;
                break;
            }
       // var frontal = separra(nombreConcepto);
        let date = new Date();
        let muestraxml = "<TICKET><TEXT ALIGNH = \"CENTER\" FONTFAMILY = \"Times New Roman\" FONTSIZE = \"12\" FONTTYPE = \"B\">Referencia Banco Azteca S.A</TEXT>" +
            "<TEXT></TEXT>" +
            "<TEXT ALIGNH = \"CENTER\" FONTFAMILY = \"Times New Roman\" FONTSIZE = \"7\" FONTTYPE = \"N\">Tienda: " + obj.NoTienda + " - " + obj.NombreTienda + "</TEXT>" +
            "<TEXT ALIGNH = \"CENTER\" FONTFAMILY = \"Times New Roman\" FONTSIZE = \"7\" FONTTYPE = \"N\">Opero: " + obj.NombreCorto + " en " + cajaNombre + "</TEXT>" +
            "<TEXT ALIGNH = \"CENTER\" FONTFAMILY = \"Times New Roman\" FONTSIZE = \"7\" FONTTYPE = \"N\">No. Operacion: " + idtrans + "</TEXT>" +
            "<TEXT ALIGNH = \"CENTER\" FONTFAMILY = \"Times New Roman\" FONTSIZE = \"7\" FONTTYPE = \"N\">Fecha: " + getFechaticket()+ "</TEXT>" +
            "<TEXT></TEXT><LINE POSX = \"0\" WIDTH = \"70\" BORDERWIDTH = \"0.3\" />" +
            "<TEXT></TEXT><TEXT ALIGNH = \"CENTER\" FONTFAMILY = \"Times New Roman\" FONTSIZE = \"14\" FONTTYPE = \"B\">Ingresos diversos en tienda</TEXT>" +
           // "<TEXT ALIGNH = \"CENTER\" FONTFAMILY = \"Times New Roman\" FONTSIZE = \"9\" FONTTYPE = \"N\">" + obj.TipoTransac + "-" + obj.ConsecTransac + "</TEXT>" +
            "<TEXT></TEXT><LINE POSX = \"0\" WIDTH = \"70\" BORDERWIDTH = \"0.3\" />" +
            "<TEXT></TEXT>" +
            //"<TEXT ALIGNH = \"LEFT\" FONTFAMILY = \"Times New Roman\" FONTSIZE = \"10\" FONTTYPE = \"B\">Tipo Movimiento: " + nombreConcepto + "</TEXT>" +
            "<TEXT ALIGNH = \"LEFT\" FONTFAMILY = \"Times New Roman\" FONTSIZE = \"10\" FONTTYPE = \"B\">Tipo Movimiento: " + "</TEXT>" +
            separaCadenaTickets(nombreConcepto, "Times New Roman",8 , "N")+
            //"<TEXT></TEXT><TEXT ALIGNH = \"LEFT\" FONTFAMILY = \"Times New Roman\" FONTSIZE = \"9\" FONTTYPE = \"N\">Importe: " + obj.Simbolo + "" + formatMoney(importe) + "</TEXT>" +
            "<TEXT></TEXT><TEXT ALIGNH = \"LEFT\" FONTFAMILY = \"Times New Roman\" FONTSIZE = \"9\" FONTTYPE = \"N\">Importe: " + formatMoney(importe) + "</TEXT>" +
            //"<TEXT ALIGNH = \"LEFT\" FONTFAMILY = \"Times New Roman\" FONTSIZE = \"9\" FONTTYPE = \"N\">(" + obj.TextCantidad + ")</TEXT>" +
            separaCadenaTickets(obj.TextCantidad, "Times New Roman", 8, "N") + //"" +
            "<TEXT></TEXT><TEXT></TEXT><TEXT></TEXT><TEXT></TEXT><LINE POSX = \"10\" WIDTH = \"50\" BORDERWIDTH = \"0.3\" />" +
            "<TEXT ALIGNH = \"CENTER\" FONTFAMILY = \"Times New Roman\" FONTSIZE = \"9\" FONTTYPE = \"N\">Firma Operador</TEXT></TICKET>";
        //hace la generacion del ticket 
        //$('#test').html(muestraxml);
        obj = ServGeneracionTicket(muestraxml);
        if (obj.EstatusExito)
            obj = ServImpresionTicket(obj.Contenido);
        DispararConfirmacion('¿El ticket se imprimió correctamente?', CerrarVentanaApp, ImpresionTicket, "Sí", "No");
       // LimpiarValores();
        mostrarCarga(false);
    }, 200);
}
function convert() {

}

function separaCadenaTickets(cadena, font, size, fontType) {
    let resultado = "";
    let arrstr;
    let temp = cadena;
    arrstr = cadena.split(' ');
    let contPalabras = 0;
    let lineaActual = "";
    for (let i = 0 ; i < arrstr.length ; i++) {
        contPalabras += 1;
        if ((lineaActual.length + arrstr[i].length) >= 35) {
            if (lineaActual.length >= 0)
                resultado += '<TEXT ALIGNH = \"CENTER\" FONTFAMILY = \"' + font + '\" FONTSIZE = \"' + size + '\" FONTTYPE = \"' + fontType + '\">' + lineaActual + '</TEXT>'
            lineaActual = arrstr[i] + " ";
            if (contPalabras == arrstr.length) { //si es la ultima palabra en la lista
                lineaActual = arrstr[i] + "";
                resultado += '<TEXT ALIGNH = \"CENTER\" FONTFAMILY = \"' + font + '\" FONTSIZE = \"' + size + '\" FONTTYPE = \"' + fontType + '\">' + lineaActual + '</TEXT>'
            }
        }
        else {
            if (contPalabras == arrstr.length) //si es la ultima palabra en la lista
                resultado += '<TEXT ALIGNH = \"CENTER\" FONTFAMILY = \"' + font + '\" FONTSIZE = \"' + size + '\" FONTTYPE = \"' + fontType + '\">' + lineaActual + arrstr[i] + "" + '</TEXT>'
            else
                lineaActual = lineaActual + arrstr[i] + " ";
        }
    }

        return resultado;
}

function getFechaticket() {
    let d = new Date();    
    let fecha = ("00" + d.getDate()).slice(-2) + "/" + ("00" + (d.getMonth() + 1)).slice(-2) + "/" + d.getFullYear() + " " + ("00" + d.getHours()).slice(-2) + ":" + ("00" + d.getMinutes()).slice(-2) + ":" + ("00" + d.getSeconds()).slice(-2);
    return fecha;
}
/////////////////////////////////////Funciones para la ventana y la pagina///////////////////////////

function BotonGrabar() {
    if ($('#inpImporte').val() != $('#conImporte').val())
        DispararMensaje('Los campos de importe deben coincidir.', null);
    if ($('#inpImporte').val() == "" || $('#conImporte').val() == "" || $('#refImporte').val() == "")
        DispararMensaje('Aun hay campos vacios.', null);

    else if($('#inpImporte').val() == 0)
        DispararMensaje('Inserte un importe mayor a cero.', null);

    else
        DispararConfirmacion('<b>Recuerda que no puedes ingresar remesas por esta opción.<br>Si lo haces, será tu responsabilidad ante auditoría.</b>' +
        '<br>¿Continuar operación?', GrabarIngreso, null);
}

function DispararError(mensaje, causa) {
    $('#errorTitulo').html('Error de ' + causa + ':');
    $('#errorTexto').html(mensaje);
    $j('#modalError').modal({ escClose: false });
    iniciarTimerApp(5);
}

function DispararMensaje(mensaje, refM) {
    refFuncMensaje = (refM !== undefined) ? refM : null;
    $('#mensajeTitulo').html('Mensaje del sistema:');
    $('#mensajeTexto').html(mensaje);
    $j('#modalMensaje').modal({ escClose: false });
}

function DispararConfirmacion(mensaje, refA, refC, mensA, mensC) {
    refFuncAceptar = (refA !== undefined) ? refA : null;
    refFuncCancelar = (refC !== undefined) ? refC : null;
    if (mensA !== undefined)
        $('#mensA').html(mensA);           
    if(mensC !== undefined)
        $('#mensC').html(mensC);
    $('#confTitulo').html('Mensaje del sistema:');
    $('#confTexto').html(mensaje);
    $j('#modalConfirmacion').modal({ escClose: false });
}

function botonDiagMensaje() {
    if (refFuncMensaje != null)
        refFuncMensaje();
}

function botonDiagAceptar() {
    if (refFuncAceptar != null)
        refFuncAceptar();
}

function botonDiagCancelar() {
    if (refFuncCancelar != null)
        refFuncCancelar();
}

function CerrarVentanaApp() {
    LimpiarValores();
    cerrarControl();
    ActivarCampos(false);
    clearInterval(refContApp);
    $j.modal.close();
    ocultarElementosPantalla();
    muestraFinalizar();
}
function muestraFinalizar() {

     var mensaje="FINALIZO LA SESION"
   // $('#confTitulof').html('Mensaje del sistema:');
    $('#confTextof').html(mensaje);
    $j('#finalizarSesion').modal({escClose:false});
}


function iniciarTimerApp(tiempoArg) {
    tiempoRestanteApp = tiempoArg;
    timerApp();
    refContApp = setInterval(function () { timerApp() }, 1000);
}

function timerApp() {
    $("#appTimer").html("Tiempo de espera (" + tiempoRestanteApp + ")");
    if (tiempoRestanteApp > 0)
        tiempoRestanteApp -= 1;
    else
        CerrarVentanaApp();
}

/////////////////////////////////////Funciones de utilidad///////////////////////////////////////

function getUrlServicio(servicio) {
    var url = "";
    if (window.location.hostname == "localhost") {
        url = "http://10.54.28.226:9014/Caja/Servicios/" + servicio;
    } else {
        url = "http://" + window.location.hostname + ":9014/Caja/Servicios/" + servicio;
    }
    return url;
}

function isNumberDecimalKey(evt) {
    var charCode = (evt.which) ? evt.which : evt.keyCode
    if (charCode > 31 && (charCode < 48 || charCode > 57) && charCode != 46)
        return false;
    return true;
}

function toFixedJ(num, fixed) {
    var re = new RegExp('^-?\\d+(?:\.\\d{0,' + (fixed || -1) + '})?');
    return num.toString().match(re)[0];
}

function pad(number, length) {
    var str = '' + number;
    while (str.length < length)
        str = '0' + str;
    return str;
}

/////////////////////////////////////Servicios////////////////////////////////////////////////

function ServAppConsultaEmpleado(empleado) {
    var objRespuesta = { NoError: null, Descripcion: null };
    var url = getUrlServicio(UrlValidaEmpleado);
    $.ajax({
        url: "" + url,
        contentType: "application/json; charset=UTF-8",
        type: "POST",
        async: false,
        data: JSON.stringify({
            "NoEmpleado": "" + empleado
        }),
        dataType: 'json',
        crossDomain: true,
        success: function (data) {
            objRespuesta = data;
        },
        error: function () {
            objRespuesta.NoError = 1;
            objRespuesta.Descripcion = "No se pudo contactar al servicio.";
        }
    });
    return objRespuesta;
}

function ServConsultaConcepto() {
    var objRespuesta = { NoError: null, Descripcion: null };
    var url = getUrlServicio(UrlConsultaConceptos);
    $.ajax({
        url: "" + url,
        contentType: "application/json; charset=UTF-8",
        type: "POST",
        async: false,
        data: JSON.stringify({
            "Top": 230
        }),
        dataType: 'json',
        crossDomain: true,
        success: function (data) {
            objRespuesta = data;
        },
        error: function () {
            objRespuesta.NoError = 1;
            objRespuesta.Descripcion = "No se pudo contactar al servicio.";
        }
    });
    return objRespuesta;
}

function ServRegistraIngreso(concepto,importe,referencia) {
    var objRespuesta = { NoError: null, Descripcion: null };
    var url = getUrlServicio(UrlRegistraIngresos);
    $.ajax({
        url: "" + url,
        contentType: "application/json; charset=UTF-8",
        type: "POST",
        async: false,
        data: JSON.stringify({
            "Concepto": concepto,
            "Importe": importe,
            "Referencia": referencia,
            "TipoDivisa": 1,
            "Ws": cajaNombre,
            "NoEmpleado": empleadoID.replace(/\D/g, '')
        }),
        dataType: 'json',
        crossDomain: true,
        success: function (data) {
            objRespuesta = data;
        },
        error: function () {
            objRespuesta.NoError = 1;
            objRespuesta.Descripcion = "No se pudo contactar al servicio.";
        }
    });
    return objRespuesta;
}

function ServConsultaInfoTicket(importe,transaccion) {
    var objRespuesta = { NoError: null, Descripcion: null };
    var url = getUrlServicio(UrlConsultaInfoTicket);
    $.ajax({
        url: "" + url,
        contentType: "application/json; charset=UTF-8",
        type: "POST",
        async: false,
        data: JSON.stringify({
            "TipoDivisa": 1,
            "IdNegocio": 32,
            "NoEmpleado": empleadoID.replace(/\D/g, ''),
            "Cantidad": importe,
            "Transaccion": transaccion
        }),
        dataType: 'json',
        crossDomain: true,
        success: function (data) {
            objRespuesta = data;
        },
        error: function () {
            objRespuesta.NoError = 1;
            objRespuesta.Descripcion = "No se pudo contactar al servicio.";
        }
    });
    return objRespuesta;
}

function ServGeneracionTicket(stringxml) {
    var objRespuesta = { EstatusExito: null, Detalle: null };
    var url = UrlHostImpresion + UrlGeneraTicket;
    $.ajax({
        url: "" + url,
        contentType: "application/json; charset=UTF-8",
        type: "POST",
        async: false,
        dataType: 'json',
        crossDomain: true,
        data: JSON.stringify({
            "ListaTickets":[
                {
                    "Aplicacion": "IngresosDiversos",
                    "Contenido": stringxml,
                    "NoCopias": 1
                }
            ]
        }),
        success: function (data) {
            objRespuesta = data;
        },
        error: function () {
            objRespuesta.EstatusExito = false;
            objRespuesta.Detalle = "No se pudo contactar al servicio.";
        }
    });
    return objRespuesta;
}

function ServImpresionTicket(idticket) {
    var objRespuesta = { EstatusExito: null, Detalle: null };
    var url = UrlHostImpresion + UrlImprimeTicket + idticket;
    $.ajax({
        url: "" + url,
        contentType: "application/json; charset=UTF-8",
        type: "POST",
        async: false,
        dataType: 'json',
        crossDomain: true,
        success: function (data) {
            objRespuesta = data;
        },
        error: function () {
            objRespuesta.EstatusExito = false;
            objRespuesta.Detalle = "No se pudo contactar al servicio.";
        }
    });
    return objRespuesta;
}

document.getElementById("refImporte").onkeypress = function (e) {
	
    if ((e.charCode === 0) || (e.charCode === 32) || (e.charCode > 47 && e.charCode < 58) || (e.charCode > 64 && e.charCode < 91) || (e.charCode >= 97 && e.charCode < 123)) {
    } else {
        return false;
    }

    var txtReferencia = document.getElementById("refImporte").value;
    if ((txtReferencia.length >= 23) && (e.charCode != 0))
        return false;
};