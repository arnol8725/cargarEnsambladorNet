﻿if ($j === undefined) { var $j = jQuery.noConflict(true); console.log($().jquery); console.log($j().jquery); }

var empleadoID = null;
var cajaNombre = null;
var fechaAnterior = null;
var idTransaccion = null;
var empleadosVal = null;
var empleadosValPerfs = null;
var validarOperador = null;
var empleadoPuesto = null;

var refAppCont = null;
var tiempoRestanteApp = null;
var pantallaCargada = false;
var refFuncMensaje = null;
var refFuncAceptar = null;
var refFuncCancelar = null;

const UrlValidaEmpleado = "Comun/WsCajaComun.svc/wsConsultaInformacionInicial";
const UrlConsIngresosDiversos = "IngresoDiverso/WSIngresoDiverso.svc/wsConsIngresosDiversos";
const UrlRegSolicReverso = "IngresoDiverso/WSIngresoDiverso.svc/wsRegSolicReverso";
const UrlObtieneValidadores = "wsUtileriaCaja/wsUtileria.svc/wsPerfilAutorizador";

//calendarios
$j.datepicker.regional['es'] = {
    closeText: 'Cerrar',
    prevText: '',
    nextText: ' ',
    currentText: 'Hoy',
    monthNames: ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'],
    monthNamesShort: ['Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun', 'Jul', 'Ago', 'Sep', 'Oct', 'Nov', 'Dic'],
    dayNames: ['Domingo', 'Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado'],
    dayNamesShort: ['Dom', 'Lun', 'Mar', 'Mié', 'Juv', 'Vie', 'Sáb'],
    dayNamesMin: ['Do', 'Lu', 'Ma', 'Mi', 'Ju', 'Vi', 'Sá'],
    weekHeader: 'Sm',
    dateFormat: 'dd/mm/yy',
    firstDay: 1,
    isRTL: false,
    showMonthAfterYear: false,
    yearSuffix: ''
};
$j.datepicker.setDefaults($j.datepicker.regional['es']);
$j(function () {
    $j("#inFecha1").datepicker({
        firstDay: 1
    });
    $j("#inFecha2").datepicker({
        firstDay: 1
    });
});
$j("#inFecha1").on('click', function () {
    fechaAnterior = this.value;
});
$j("#inFecha1").datepicker({
    onSelect: function () {
        //usa una expresion regular para confirmar que la fecha tenga el formato indicado
        if (/^(0?[1-9]|[12][0-9]|3[01])[\/\-](0?[1-9]|1[012])[\/\-]\d{4}$/.test(this.value)) {
            let arrFecha1 = this.value.split('/');
            let arrFecha2 = $('#inFecha2').val().split('/');
            if (!ComparaFechas(arrFecha1, arrFecha2)) {
                DispararMensaje('La primera fecha no puede ser mayor que la segunda, inserte otra fecha.');
                $j("#inFecha1").val(fechaAnterior);
            }
        } else {
            DispararMensaje('La fecha insertada no tiene un formato válido');
            $j("#inFecha1").val(fechaAnterior);
        }
    }
});
$j("#inFecha2").on('click', function () {
    fechaAnterior = this.value;
});
$j("#inFecha2").datepicker({
    onSelect: function () {
        //usa una expresion regular para confirmar que la fecha tenga el formato indicado
        if (/^(0?[1-9]|[12][0-9]|3[01])[\/\-](0?[1-9]|1[012])[\/\-]\d{4}$/.test(this.value)) {
            let arrFecha1 = $('#inFecha1').val().split('/');
            let arrFecha2 = this.value.split('/');
            if (!ComparaFechas(arrFecha1, arrFecha2)) {
                DispararMensaje('La segunda fecha no puede ser menor que la primera, inserte otra fecha.');
                $j("#inFecha2").val(fechaAnterior);
            }
        } else {
            DispararMensaje('La fecha insertada no tiene un formato válido');
            $j("#inFecha2").val(fechaAnterior);
        }
    }
});
function ComparaFechas(arrFecha1,arrFecha2) {
    for (let i = (arrFecha1.length - 1) ; i >= 0 ; i--) {
        if (arrFecha1[i] < arrFecha2[i])
            return true;
        else if (arrFecha1[i] > arrFecha2[i])
            return false;
        else continue;
    }
    return true; //si llega hasta aqui, es porque las dos fechas son iguales
}

//carga datos iniciales
$(document).ready(function () {
    var date = new Date();
    $('#tagHora').html(date.getHours() + ":" + date.getMinutes());
    $('#tagFecha').html((date.getMonth() + 1) + "/" + date.getDate() + "/" + date.getFullYear());
    let fecha = fechaFormato(date.getFullYear(), (date.getMonth() + 1), date.getDate(), false);
    $j("#inFecha1").val(fecha);
    $j("#inFecha2").val(fecha);
    $j("#outFecha1").html(fecha);
    $j("#outFecha2").html(fecha);

    empleadoID = getUrlVars()["empleado"];
    cajaNombre = getUrlVars()["ws"];
    if (empleadoID === undefined || empleadoID == ""
        || cajaNombre === undefined || cajaNombre == "") {
        DispararError("Los parámetros no son correctos.","parámetros de la URL");
        return;
    }
    mostrarCarga(true);
    setTimeout(function () {
        obj = ServAppConsultaEmpleado(empleadoID);
        if (obj.NoError != 0) {
            DispararError(obj.Descripcion);
            mostrarCarga(false);
            return;
        }
        $('#tagEmpNombre').html(obj.InformacionInicial.NombreEmpleado);
        $('#tagEmpDescripcion').html(obj.InformacionInicial.DescripcionPBase);
        empleadoPuesto = obj.InformacionInicial.PuestoRol;
        $('#tagNumTienda').html(obj.InformacionInicial.NoTienda);
        $('#tagNombreTienda').html(obj.InformacionInicial.NombreTienda);
        $('#tagPais').html(obj.InformacionInicial.DescripcionPais);

        let fecha1 = fechaFormato(date.getFullYear(), (date.getMonth() + 1), date.getDate(), true);
        let fecha2 = obtenerDiaSiguiente(date.getFullYear(), date.getMonth(), date.getDate())
        LlenarTablaIngresos(fecha1, fecha2);
        mostrarCarga(false);
    }, 200);
});

function LlenarTablaIngresos(fecha1, fecha2) {
    //resetear valores
    idTransaccion = null;
    //aqui ya supongo que tengo las fechas con el formato correcto
    let obj = ServConsIngresosDiversos(fecha1,fecha2);
    if (obj.NoError == 0) { //llena la tabla con la información correspondiente
        let conj = obj.DetalleIngresosDiversos;
        if(conj.length > 0){
            let tabla = "<tbody><tr><th>No. de operación</th><th>Empleado</th><th>Importe</th><th>Fecha</th><th>Referencia</th></tr>";
            for (let i in conj) {
                tabla += '<tr id="tag_' + conj[i].NoTransaccion + '" class="">';
                tabla += "<td>" + conj[i].NoTransaccion + "</td>";
                tabla += "<td>" + conj[i].Empleado + "</td>";
                tabla += "<td>$" + conj[i].Importe + "</td>";
                tabla += "<td>" + conj[i].FechaRegistro + "</td>";
                tabla += "<td>" + conj[i].ReferenciaMovimiento + "</td>";
                tabla += "</tr>";
            }
            tabla += "</tbody>";
            $('#tablaIngresos').html(tabla);
            for (let i in conj) {
                $('#tag_' + conj[i].NoTransaccion).unbind('click');
                $('#tag_' + conj[i].NoTransaccion).on('click', function (event) {
                    $("#tag_" + idTransaccion).removeClass("act");
                    $("#" + $(this).attr("id")).addClass("act");
                    idTransaccion = $(this).attr("id").replace("tag_", "");
                });
            }
        } else {
            DispararMensaje("No hay ingresos registrados en estas fechas.");
            let tabla = "<tbody><tr><th>No. de operación</th><th>Empleado</th><th>Importe</th><th>Fecha</th><th>Referencia</th></tr>";
            $('#tablaIngresos').html(tabla);
        }
    } else {
        DispararError(obj.Descripcion, 'consulta de ingresos');
    }
}

function SolicitarReverso() {
    if (idTransaccion != null)
        DispararConfirmacion('¿Desea seleccionar el ingreso con ID <b>' + idTransaccion + '</b>?', AbrirHuellaValidar, null)
    else
        DispararMensaje('No se ha seleccionado un ID de ingreso.', null);
}

/////////////////////////////////////Funciones para la ventana y la pagina///////////////////////////

//de esta manera se inicializa la autenticación
function AbrirHuellaValidar() {
    mostrarCarga(true);
    setTimeout(function () {
        var obj = ServObtenerValidadores();
        if (obj.Estatus != 0) { //si hubo error
            DispararError(obj.msjError, 'obtención de validadores');
            mostrarCarga(false);
            return;
        }
        mostrarCarga(false);
        let empleadosVal = obj.EmpAutorizador
        let empleadosValPerfs = obj.EmpPerfiles
        validarOperador = false;
        let temp = empleadoID.replace(/\D/g, '');
        var json = '{"validarEmp":"' + temp + '","validarAut":"' + empleadosVal + '","perfiles":"' + empleadosValPerfs.replace("632,","").replace(",632","") + '","tipo":"1","app":"IngresoDiverso","ws":"' + cajaNombre + '","top":"230","afectaHD":true}';
        json = JSON.parse(json);
        AutenticacionHuella(json);
    }, 300);
}

//se necesita definir esta función de esta manera para que la pagina pueda recibir el resultado de la autenticación
function RecibirResultadoHuella(resultado) {
    if (resultado.Status == 0) { //si hubo error
        DispararError(resultado.Descripcion, 'autenticación de huella digital');
        return;
    }
    mostrarCarga(true);
    setTimeout(function () {
        var obj = ServRegSolicReverso(idTransaccion);
        if (obj.NoError != 0) { //si hubo error
            DispararError(obj.Descripcion, 'confirmacion de arqueo');
            mostrarCarga(false);
            return;
        }
        mostrarCarga(false);
        DispararMensaje('Se ha hecho la solicitud de reverso del ingreso con el ID: ' + idTransaccion, CerrarVentanaApp);
    }, 200);
}

function BotonConsultar(){
    let fecha1 = $("#inFecha1").val();
    let fecha2 = $("#inFecha2").val();
    $("#outFecha1").html(fecha1);
    $("#outFecha2").html(fecha2);
    let arrFecha1 = fecha1.split('/');
    let arrFecha2 = fecha2.split('/');
    fecha1 = fechaFormato(arrFecha1[2], arrFecha1[1], arrFecha1[0], true);
    fecha2 = obtenerDiaSiguiente(arrFecha2[2], Number(arrFecha2[1]) - 1, arrFecha2[0]);
    LlenarTablaIngresos(fecha1, fecha2);
}

function DispararError(mensaje, causa) {
    $('#errorTitulo').html('Error de ' + causa + ':');
    $('#errorTexto').html(mensaje);
    $j('#modalError').modal();
    iniciarTimerApp(5);
}

function DispararMensaje(mensaje, refM) {
    refFuncMensaje = (refM !== undefined) ? refM : null;
    $('#mensajeTitulo').html('Mensaje del sistema:');
    $('#mensajeTexto').html(mensaje);
    $j('#modalMensaje').modal();
    
}

function DispararConfirmacion(mensaje, refA, refC) {
    refFuncAceptar = (refA !== undefined) ? refA : null;
    refFuncCancelar = (refC !== undefined) ? refC : null;
    $('#confTitulo').html('Mensaje del sistema:');
    $('#confTexto').html(mensaje);
    $j('#modalConfirmacion').modal();
}

function botonDiagMensaje() {
    if (refFuncMensaje != null)
        refFuncMensaje();
}

function botonDiagAceptar() {
    if (refFuncAceptar != null)
        refFuncAceptar();
}

function botonDiagCancelar() {
    if (refFuncCancelar != null)
        refFuncCancelar();
}

function CerrarVentanaApp() {
    clearInterval(refAppCont);
    try {
        window.close();
    } catch (err) {
        alert('La ventana debería cerrarse, Error: ' + err);
    }
}

function iniciarTimerApp(tiempoArg) {
    tiempoRestanteApp = tiempoArg;
    timerApp();
    refAppCont = setInterval(function () { timerApp() }, 1000);
}

function timerApp() {
    $("#appTimer").html("Tiempo de espera (" + tiempoRestanteApp + ")");
    if (tiempoRestanteApp > 0) {
        tiempoRestanteApp -= 1;
    }
    else {
        CerrarVentanaApp();
    }
}

function fechaFormato(a, m, d, paraServicio) {
    return (paraServicio ? pad(a, 4) : pad(d, 2)) +
        (paraServicio ? '' : '/') + pad(m, 2) + (paraServicio ? '' : '/') +
        (paraServicio ? pad(d, 2) : pad(a, 4));
}

function obtenerDiaSiguiente(a, m, d) {
    let diaHoy = new Date(a, m, d)
    let ultimoDiaMes = new Date(diaHoy.getFullYear(), (diaHoy.getMonth() + 1), 0)
    if (diaHoy.getDate() == ultimoDiaMes.getDate()) { //si el dia de hoy es el ultimo dia del mes
        if (diaHoy.getMonth() == 11) { //si es el ultimo día del año
            return fechaFormato(diaHoy.getFullYear() + 1, 1, 1, true)
        } else { //si solo es el ultimo dia del mes
            return fechaFormato(diaHoy.getFullYear(), (diaHoy.getMonth() + 2), 1, true)
        }
    } else { // si no es el ultimo dia del mes
        return fechaFormato(diaHoy.getFullYear(), (diaHoy.getMonth() + 1), diaHoy.getDate() + 1, true)
    }
}

/////////////////////////////////////Funciones de utilidad///////////////////////////////////////

function getUrlServicio(servicio) {
    var url = "";
    if (window.location.hostname == "localhost") {
        url = "http://10.54.28.186:9014/Caja/Servicios/" + servicio;
    } else {
        url = "http://" + window.location.hostname + ":9014/Caja/Servicios/" + servicio;
    }
    return url;
}

function pad(number, length) {
    var str = '' + number;
    while (str.length < length)
        str = '0' + str;
    return str;
}

/////////////////////////////////////Servicios////////////////////////////////////////////////

function ServAppConsultaEmpleado(empleado) {
    var objRespuesta = { NoError: null, Descripcion: null };
    var url = getUrlServicio(UrlValidaEmpleado);
    $.ajax({
        url: "" + url,
        contentType: "application/json; charset=UTF-8",
        type: "POST",
        async: false,
        data: JSON.stringify({
            "NoEmpleado": "" + empleado.replace(/\D/g, '')
        }),
        dataType: 'json',
        crossDomain: true,
        success: function (data) {
            objRespuesta = data;
        },
        error: function () {
            objRespuesta.NoError = 1;
            objRespuesta.Descripcion = "No se pudo contactar al servicio.";
        }
    });
    return objRespuesta;
}

function ServConsIngresosDiversos(fecha1,fecha2) {
    var objRespuesta = { NoError: null, Descripcion: null };
    var url = getUrlServicio(UrlConsIngresosDiversos);
    $.ajax({
        url: "" + url,
        contentType: "application/json; charset=UTF-8",
        type: "POST",
        async: false,
        data: JSON.stringify({
            "FechaInicio": fecha1,
            "FechaFin": fecha2
        }),
        dataType: 'json',
        crossDomain: true,
        success: function (data) {
            objRespuesta = data;
        },
        error: function () {
            objRespuesta.NoError = 1;
            objRespuesta.Descripcion = "No se pudo contactar al servicio.";
        }
    });
    return objRespuesta;
}

function ServRegSolicReverso(transaccion) {
    var objRespuesta = { NoError: null, Descripcion: null };
    var url = getUrlServicio(UrlRegSolicReverso);
    $.ajax({
        url: "" + url,
        contentType: "application/json; charset=UTF-8",
        type: "POST",
        async: false,
        data: JSON.stringify({
            "NoTransaccion" : transaccion,
            "Ws": cajaNombre,
            "NoEmpleado": empleadoID.replace(/\D/g, '')
        }),
        dataType: 'json',
        crossDomain: true,
        success: function (data) {
            objRespuesta = data;
        },
        error: function () {
            objRespuesta.NoError = 1;
            objRespuesta.Descripcion = "No se pudo contactar al servicio.";
        }
    });
    return objRespuesta;
}

function ServObtenerValidadores() {
    var objRespuesta = { Estatus: null, msjError: null };
    var url = getUrlServicio(UrlObtieneValidadores);
    $.ajax({
        url: "" + url,
        contentType: "application/json; charset=UTF-8",
        type: "POST",
        async: false,
        data: JSON.stringify({
            "opc": 1,
            "IdModulo": "27",
            "IdFolio": "3",
            "Empleado": "" + empleadoID.replace(/\D/g, '')
        }),
        dataType: 'json',
        crossDomain: true,
        success: function (data) {
            objRespuesta = data;
        },
        error: function () {
            objRespuesta.Estatus = 1;
            objRespuesta.msjError = "No se pudo contactar al servicio.";
        }
    });
    return objRespuesta;
}