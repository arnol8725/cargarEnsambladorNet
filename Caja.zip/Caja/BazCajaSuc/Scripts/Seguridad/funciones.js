﻿if ($j === undefined) { var $j = jQuery.noConflict(true); console.log($().jquery); console.log($j().jquery); }

var pantallaCargada = false;

var sizeCheck;
var opc = getUrlVars()["opc"];
var usuario = getUrlVars()["usuario"];

$(document).ready(function () {
    mostrarCarga(true);   
    loadPage();
});

function loadPage(){
    let date = new Date();
    $('#tagHora').html(date.getHours() + ":" + date.getMinutes());
    $('#tagFecha').html((date.getMonth() + 1) + "/" + date.getDate() + "/" + date.getFullYear());
    $("#tableMedidas").hide();
    if ((opc!=null || opc!=undefined) && (usuario!=null || usuario!=undefined)){    
        $.when(getInfInicial(usuario)).done(function(obj){
            if (obj.NoError != 0) {
                mostrarCarga(false);
                MostrarError(obj.Descripcion);                
                return;
            }
            $('#tagEmpNombre').html(obj.InformacionInicial.NombreEmpleado);
            $('#tagEmpDescripcion').html(obj.InformacionInicial.DescripcionPBase);
            empleadoPuesto = obj.InformacionInicial.PuestoRol;
            $('#tagNumTienda').html(obj.InformacionInicial.NoTienda);
            $('#tagNombreTienda').html(obj.InformacionInicial.NombreTienda);
            $('#tagPais').html(obj.InformacionInicial.DescripcionPais);            
            wsObtieneMedidaSeguridad(opc);        
        });        
    }else{  
         mostrarCarga(false);
         MostrarError("Parámetros de entrada incorrectos");
    }
}

function writeMedidasSeguridad(medidas) {
    sizeCheck= medidas.length;   
    let tabla="";         
    $.each(medidas, function (i, p) {                        
        tabla += '<tr>'+
                   '<td class="tLeft">'+p.Descripcion+'</td>'+
                   '<td>'+
                     "<input onclick='onCheckMedidas(1,"+i+")' type='checkbox' id='checkS"+i+"' class='mLeft2'>"+
                     '<label for="checkS'+i+'"></label>'+
				   '</td>'+
				   '<td>'+
                     "<input onclick='onCheckMedidas(0,"+i+")' type='checkbox' id='checkN"+i+"' class='mLeft2'>"+					 
					 '<label for="checkN'+i+'"></label>'+
				   '</td>'+
				   '<td><input id="observaciones'+i+'" disabled onkeypress="return validaInput(event,2)" maxlength="70" type="text"></td>'+
			     '</tr>';
    });   
    $("#tableMedidas > tbody").html(tabla);
    $("#tableMedidas").show();
    mostrarCarga(false);
}

function onCheckMedidas(tipo, id) {
    switch (tipo) {
        case 1:
            if ($('#checkN' + id).is(':checked')) {
                $('#checkN' + id).prop('checked', false);
                $('#observaciones' + id).attr("disabled", true);
            }
            break;
        case 0:
            $('#observaciones' + id).attr("disabled", false);
            if ($('#checkS' + id).is(':checked')) {
                $('#checkS' + id).prop('checked', false);                
            }
            break;
    }    
}

function getMedidasArray() {  
    let lstMedidas=[]; 
    let realizado;
    let observaciones=""; 
    for (let i=0; i<sizeCheck; i++){
        if ($('#checkN' + i).is(':checked') || $('#checkS' + i).is(':checked')){            
            observaciones=$('#checkN' + i).is(':checked')?$('#observaciones'+i).val():"";
            if($('#checkN' + i).is(':checked') && observaciones==""){                
                MostrarAlert("Debes ingresar las observaciones de las medidas seleccionadas como 'No'");
                lstMedidas=[];
                break;
            }else{
                realizado=$('#checkN' + i).is(':checked')?0:1;
                lstMedidas.push({"realizado":realizado, "observaciones":observaciones});
            }          
        }else{
            MostrarAlert("Debes llenar todas las medidas de seguridad");
            lstMedidas=[]; 
            break;
        }
    }    
    return lstMedidas;
}

function insertMedidas(){    
    let medidas= getMedidasArray();
    console.log(medidas);
    if (medidas.length>0){
        mostrarCarga(true);
        wsInsertaMedidaSeguridad(medidas);
    }
}

function MostrarError(mensaje) {    
    $('#errorTexto').html(mensaje);
    $j('#modalError').modal();    
}

function MostrarExito(mensaje) {    
    $('#textModal').html(mensaje);
    $j('#modalExito').modal();    
}

function MostrarAlert(mensaje){
    $('#textAlert').html(mensaje);
    $j('#modalAlert').modal(); 
}

function cerrarModalError(){
    mostrarCarga(true);
    loadPage();
}

function validaInput(evt, tipo){    
    let valid;    
    let charCode=(evt.which) ? evt.which : evt.keyCode; 
    switch(tipo){
        case 1: //solo numeros            
            valid = (charCode >= 48 && charCode <= 57) || (charCode == 8) || (charCode == 9) || (charCode == 37) || (charCode == 39) || (charCode == 46) || (charCode == 35) || (charCode == 36); //37, 39
            break;
        case 2: //solo letras            
            valid = (charCode >= 65 && charCode <= 90) || (charCode >= 97 && charCode <= 122) || (charCode ==32) || (charCode == 8) || (charCode == 9) || (charCode == 37) || (charCode == 39) || (charCode == 46) || (charCode == 35) || (charCode == 36);
            break;
        case 3: //letras y numeros            
            valid = (charCode >= 48 && charCode <= 57) || (charCode >= 65 && charCode <= 90) || (charCode >= 97 && charCode <= 122) || (charCode ==32) || (charCode == 8) || (charCode == 9) || (charCode == 37) || (charCode == 39) || (charCode == 46)  || (charCode == 35) || (charCode == 36);
            break;

    }  
    return valid;
}